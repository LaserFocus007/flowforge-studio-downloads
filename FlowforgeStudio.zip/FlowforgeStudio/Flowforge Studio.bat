@echo off
rem Starts Flowforge Studio (local web UI in its own window). Simulations keep running when the window is closed.
setlocal
cd /d "%~dp0"

set "PYW="
if exist "runtime\pythonw.exe" set "PYW=runtime\pythonw.exe"
if not defined PYW where pyw >nul 2>nul && set "PYW=pyw -3"
if not defined PYW (
  where pythonw >nul 2>nul && set "PYW=pythonw"
)
if not defined PYW (
  echo.
  echo  Python 3 was not found on this PC.
  echo  Please install Python 3.8 or newer, e.g. from the Microsoft Store ^(search "Python"^),
  echo  then start Flowforge Studio again.
  echo.
  pause
  exit /b 1
)
start "" %PYW% -c "from app import main; main.run()" %*
exit /b 0
