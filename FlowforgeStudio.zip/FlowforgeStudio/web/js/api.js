// Thin client for the local Flowforge Studio API (token protected).

let TOKEN = null;

export function initToken() {
  const url = new URL(window.location.href);
  const t = url.searchParams.get('t');
  if (t) {
    TOKEN = t;
    // also kept per browser profile: the installed app opened from the Start menu has no token in its URL
    try { sessionStorage.setItem('flowforgestudio-token', t); localStorage.setItem('flowforgestudio-token', t); } catch (e) { /* ignore */ }
    url.searchParams.delete('t');
    window.history.replaceState({}, '', url.pathname + url.hash);
  } else {
    try { TOKEN = sessionStorage.getItem('flowforgestudio-token') || localStorage.getItem('flowforgestudio-token')
      || sessionStorage.getItem('apexstudio-token') || localStorage.getItem('apexstudio-token'); /* old name */ } catch (e) { TOKEN = null; }
  }
  return !!TOKEN;
}

// tell the server that this window is closing (it stops after a few seconds unless reloaded)
export function sayGoodbye() {
  if (!TOKEN) return;
  try { navigator.sendBeacon('/api/bye?t=' + encodeURIComponent(TOKEN), new Blob(['{}'], { type: 'text/plain' })); } catch (e) { /* ignore */ }
}

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

async function handle(res) {
  if (res.status === 401) throw new ApiError('Session expired - please restart Flowforge Studio.', 401);
  if (res.status === 402) {
    // licence missing or expired -> back to the activation screen
    if (!window.__flowforgeLicenceReload) { window.__flowforgeLicenceReload = true; window.location.reload(); }
    throw new ApiError('Flowforge Studio is not activated.', 402);
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* ignore */ }
  if (!res.ok) throw new ApiError((data && data.error) || `Request failed (${res.status})`, res.status);
  return data;
}

function qs(params) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params || {})) if (v !== undefined && v !== null) p.set(k, v);
  const s = p.toString();
  return s ? '?' + s : '';
}

export async function get(path, params) {
  let res;
  try {
    res = await fetch('/api/' + path + qs(params), { headers: { 'X-Studio-Token': TOKEN || '' } });
  } catch (e) {
    throw new ApiError('Flowforge Studio server is not reachable. Is it still running?', 0);
  }
  return handle(res);
}

export async function post(path, body, params) {
  let res;
  try {
    res = await fetch('/api/' + path + qs(params), {
      method: 'POST',
      headers: { 'X-Studio-Token': TOKEN || '', 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
  } catch (e) {
    throw new ApiError('Flowforge Studio server is not reachable. Is it still running?', 0);
  }
  return handle(res);
}

export async function getBinary(path, params) {
  const res = await fetch('/api/' + path + qs(params), { headers: { 'X-Studio-Token': TOKEN || '' } });
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try { msg = (await res.json()).error || msg; } catch (e) { /* ignore */ }
    throw new ApiError(msg, res.status);
  }
  const buf = await res.arrayBuffer();
  let bbox = null;
  try { bbox = JSON.parse(res.headers.get('X-BBox')); } catch (e) { /* ignore */ }
  return { buffer: buf, bbox, triangles: parseInt(res.headers.get('X-Triangles') || '0', 10) };
}

// Upload with progress (XHR, since fetch has no upload progress)
export function upload(path, params, file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/' + path + qs(params));
    xhr.setRequestHeader('X-Studio-Token', TOKEN || '');
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
    xhr.onload = () => {
      let data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) { /* ignore */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data);
      else reject(new ApiError((data && data.error) || `Upload failed (${xhr.status})`, xhr.status));
    };
    xhr.onerror = () => reject(new ApiError('Upload failed - server not reachable.', 0));
    xhr.send(file);
  });
}
