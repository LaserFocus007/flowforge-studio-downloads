// Wheel parameters derived from the geometry: shared table for the wizard and the settings tab.

import { h, icon } from './ui.js';

const nice = (p) => p.replace(/^wall_/, '').replace(/_/g, ' ');
const vec = (v) => (v ? '(' + v.map((x) => +(+x).toPrecision(6)).join('  ') + ')' : '-');

// rows: [{patch, ok, error, current, auto, warnings}], changed: patch names that were updated
export function wheelTable(rows, changed = []) {
  const body = rows.map((r) => {
    if (!r.ok) {
      return h('tr', null, h('td', null, nice(r.patch)),
        h('td', { colspan: 4, class: 'muted' }, icon('alert'), ' ', r.error || 'could not be analysed'));
    }
    const a = r.auto;
    const upd = changed.includes(r.patch);
    const omegaOld = r.current && typeof r.current.omega === 'number' ? r.current.omega : null;
    return [
      h('tr', null,
        h('td', null, h('b', null, nice(r.patch))),
        h('td', { class: 'num' }, (a.diameter * 1000).toFixed(2) + ' mm'),
        h('td', { class: 'mono small' }, vec(a.origin) + ' m'),
        h('td', { class: 'num' }, a.omega.toFixed(1) + ' rad/s',
          (upd || r.differs) && omegaOld != null && Math.abs(omegaOld - a.omega) > 0.05
            ? h('div', { class: 'muted small' }, (upd ? 'was ' : 'currently ') + omegaOld) : null),
        h('td', null, upd ? h('span', { class: 'chip ok' }, 'updated')
          : r.differs ? h('span', { class: 'chip warn' }, 'differs') : h('span', { class: 'muted small' }, 'matches'))),
      ...r.warnings.map((w) => h('tr', null, h('td', null), h('td', { colspan: 4, class: 'warn-text small' }, icon('alert'), ' ', w))),
    ];
  });
  return h('table', { class: 'tbl' },
    h('thead', null, h('tr', null, h('th', null, 'Wheel'), h('th', { class: 'num' }, 'Diameter'), h('th', null, 'Axle position'),
      h('th', { class: 'num' }, 'Angular velocity'), h('th', null, ''))),
    h('tbody', null, body.flat()));
}
