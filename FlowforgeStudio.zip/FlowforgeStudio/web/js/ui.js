// UI helpers: DOM builder, icons, toasts, modals, menus and formatters.

// ------------------------------------------------------------------ DOM
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) el.style.setProperty(sk, sv); else el.style[sk] = sv; } }
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    if (Array.isArray(c)) append(el, c);
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function mount(el, ...children) { clear(el); append(el, children); return el; }
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------ icons
const P = {
  plus: 'M12 5v14M5 12h14',
  flame: 'M12 21c-3.9 0-6.5-2.6-6.5-6.2 0-3.3 2.3-5.4 3.7-7.6.4 1.8 1.5 3 2.6 3.4-.3-2.9.9-5.6 3.3-7.6.3 3 2.4 4.9 3.6 6.9 1 1.6 1.8 3.2 1.8 5 0 3.5-2.7 6.1-6.5 6.1zM12 21c-1.6 0-2.8-1.1-2.8-2.6 0-1.7 1.4-2.6 2.1-4 .9 1 2.6 2 3 3.6.4 1.6-.7 3-2.3 3z',
  play: 'M7 4.5v15l12-7.5z',
  stop: 'M6.5 6.5h11v11h-11z',
  record: 'M12 6.5a5.5 5.5 0 1 0 0 11a5.5 5.5 0 1 0 0-11z',
  pause: 'M8 5v14M16 5v14',
  grid: 'M4 4h16v16H4zM4 9.3h16M4 14.7h16M9.3 4v16M14.7 4v16',
  flask: 'M9 3h6M10 3v6L4.5 18.5A1.6 1.6 0 0 0 6 21h12a1.6 1.6 0 0 0 1.5-2.5L14 9V3M7.5 15h9',
  trash: 'M4 7h16M10 11v6M14 11v6M5.5 7l1 13h11l1-13M9 7V4h6v3',
  broom: 'M14 4l-4 8M7 13h8l2 7H5zM9.5 16.5V20M13 16.5V20',
  chart: 'M4 20V4M4 20h16M7.5 15.5l3.5-4.5 3 2.5 5-7',
  wave: 'M3 12c2.5-6 5-6 7.5 0s5 6 7.5 0 3-3 3-3',
  log: 'M5 4h14v16H5zM8.5 8.5h7M8.5 12h7M8.5 15.5h4',
  terminal: 'M4 5h16v14H4zM7.5 9.5l3 2.5-3 2.5M12.5 15h4',
  gear: 'M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zM19.4 13.5l1.6 1.2-2 3.4-1.9-.7a7.4 7.4 0 0 1-2 1.2l-.3 2h-3.9l-.3-2a7.4 7.4 0 0 1-2-1.2l-1.9.7-2-3.4 1.6-1.2a7.3 7.3 0 0 1 0-3l-1.6-1.2 2-3.4 1.9.7a7.4 7.4 0 0 1 2-1.2l.3-2h3.9l.3 2a7.4 7.4 0 0 1 2 1.2l1.9-.7 2 3.4-1.6 1.2a7.3 7.3 0 0 1 0 3z',
  sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4',
  compare: 'M9 4H5v16h4M15 4h4v16h-4M12 2v20',
  folder: 'M3.5 6.5a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z',
  cube: 'M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12L4 7.5',
  list: 'M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01',
  table: 'M4 5h16v14H4zM4 10h16M4 14.5h16M10 5v14',
  check: 'M5 12.5l4.5 4.5L19 7.5',
  x: 'M6 6l12 12M18 6L6 18',
  alert: 'M12 4l9 16H3zM12 10v4.5M12 17.5h.01',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v6M12 7.5h.01',
  chevDown: 'M6 9l6 6 6-6',
  chevRight: 'M9 6l6 6-6 6',
  arrowUp: 'M12 19V5M6 11l6-6 6 6',
  arrowDown: 'M12 5v14M6 13l6 6 6-6',
  upload: 'M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3',
  refresh: 'M20 5v5h-5M4 19v-5h5M19.5 10A8 8 0 0 0 5 7.5M4.5 14A8 8 0 0 0 19 16.5',
  search: 'M10.5 17.5a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4.5-4.5',
  wind: 'M3 8h11a3 3 0 1 0-3-3M3 12h15a3 3 0 1 1-3 3M3 16h7',
  wheel: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM12 3v6.5M12 14.5V21M3.5 9.5l6.2 1.7M14.3 12.8l6.2 1.7',
  layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5',
  box: 'M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10',
  stack: 'M4 17h16M4 13h16M4 9h16M4 5h16',
  map: 'M9 4L3 6.5v13.5l6-2.5 6 2.5 6-2.5V4l-6 2.5zM9 4v13.5M15 6.5V20',
  eye: 'M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
  copy: 'M8 8h11v12H8zM5 16V4h11',
  moon: 'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z',
  sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4',
  save: 'M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6',
  bookmark: 'M6 4h12v17l-6-4.5L6 21z',
  download: 'M12 4v11M7 10.5l5 5 5-5M5 20h14',
  undo: 'M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3',
  external: 'M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5',
  home: 'M4 11l8-7 8 7v9h-5v-6H9v6H4z',
  sidebar: 'M4 4h16v16H4zM9.5 4v16',
  rotate: 'M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5',
  scale: 'M4 20L20 4M14 4h6v6M10 20H4v-6',
  move: 'M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3',
  scissors: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12',
  trophy: 'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2',
  hdd: 'M3 13l2.5-8h13L21 13v6H3zM3 13h18M7 16.5h.01',
  link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
  target: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM12 12h.01',
  fit: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  wrap: 'M4 6h16M4 12h13a3 3 0 0 1 0 6h-4M15 16l-2 2 2 2M4 18h5',
  follow: 'M12 4v14M6 12l6 6 6-6M5 21h14',
};

export function icon(name, cls = '') {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'ic ' + cls);
  svg.dataset.i = name;
  const p = document.createElementNS(ns, 'path');
  p.setAttribute('d', P[name] || P.info);
  if (name === 'play' || name === 'stop') { p.setAttribute('fill', 'currentColor'); p.setAttribute('stroke-width', '1.2'); }
  if (name === 'dots') p.style.strokeWidth = '3.2';   // the three dots are zero-length strokes
  svg.appendChild(p);
  return svg;
}

// ------------------------------------------------------------------ buttons
export function btn(label, opts = {}) {
  const cls = ['btn'];
  if (opts.variant) cls.push('btn-' + opts.variant);
  if (opts.size) cls.push('btn-' + opts.size);
  if (!label && opts.icon) cls.push('btn-icon');
  if (opts.cls) cls.push(opts.cls);
  const b = h('button', { class: cls.join(' '), title: opts.title || null, type: 'button', disabled: opts.disabled || null },
    opts.icon ? icon(opts.icon) : null, label ? h('span', null, label) : null,
    opts.caret ? icon('chevDown') : null);
  if (opts.onClick) b.addEventListener('click', opts.onClick);
  return b;
}

// the current accent colour as #rrggbb (built-in or the custom team colour)
export function accentHex() {
  const v = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  return /^#[0-9a-f]{6}$/i.test(v) ? v : '#ff7a1a';
}

// ------------------------------------------------------------------ range sliders
// the filled part of a slider (CSS --fill) follows its value: on input and when it appears
function rangeFill(el) {
  const lo = +el.min || 0, hi = el.max === '' ? 100 : +el.max, v = +el.value;
  el.style.setProperty('--fill', ((hi > lo ? (v - lo) / (hi - lo) : 0) * 100).toFixed(2) + '%');
}
document.addEventListener('input', (e) => { if (e.target.type === 'range') rangeFill(e.target); }, true);
new MutationObserver((list) => {
  for (const m of list) for (const n of m.addedNodes) {
    if (n.nodeType !== 1) continue;
    if (n.matches('input[type=range]')) rangeFill(n);
    n.querySelectorAll('input[type=range]').forEach(rangeFill);
  }
}).observe(document.documentElement, { childList: true, subtree: true });

// ------------------------------------------------------------------ accent colour (team CI)
// Overrides the orange design colour; empty = the built-in colours of the theme.
export function applyAccent(hex) {
  const st = document.documentElement.style;
  const names = ['--accent', '--accent-2', '--accent-soft', '--accent-line', '--accent-ink'];
  if (!/^#[0-9a-f]{6}$/i.test(hex || '')) { names.forEach((n) => st.removeProperty(n)); return; }
  const rgb = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const lin = rgb.map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
  const lum = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2];
  const light = rgb.map((v) => Math.round(v + (255 - v) * 0.3).toString(16).padStart(2, '0')).join('');
  st.setProperty('--accent', hex);
  st.setProperty('--accent-2', '#' + light);
  st.setProperty('--accent-soft', `rgba(${rgb.join(', ')}, 0.13)`);
  st.setProperty('--accent-line', `rgba(${rgb.join(', ')}, 0.45)`);
  st.setProperty('--accent-ink', lum > 0.35 ? '#1a0d02' : '#ffffff');
}

// ------------------------------------------------------------------ toasts
export function toast(title, msg = '', kind = 'info', ms = 4500) {
  const root = document.getElementById('toastRoot');
  const ic = { ok: 'check', error: 'alert', warn: 'alert', info: 'info' }[kind] || 'info';
  const t = h('div', { class: 'toast ' + kind }, icon(ic, 'lg'),
    h('div', null, h('div', { class: 't-title' }, title), msg ? h('div', { class: 't-msg' }, msg) : null));
  root.appendChild(t);
  const close = () => { t.style.transition = 'opacity .2s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 220); };
  t.addEventListener('click', close);
  setTimeout(close, ms);
}

export function toastError(e, title = 'Something went wrong') {
  toast(title, (e && e.message) || String(e), 'error', 7000);
}

// ------------------------------------------------------------------ modal
export function modal({ title, body, footer, size = '', onClose, closable = true }) {
  const root = document.getElementById('modalRoot');
  const backdrop = h('div', { class: 'modal-backdrop' });
  const closeBtn = closable ? btn('', { icon: 'x', variant: 'ghost', title: 'Close' }) : null;
  const m = h('div', { class: 'modal ' + size, role: 'dialog' },
    title !== undefined ? h('div', { class: 'modal-head' }, h('h2', null, title), closeBtn) : null,
    h('div', { class: 'modal-body' }, body),
    footer ? h('div', { class: 'modal-foot' }, footer) : null);
  backdrop.appendChild(m);
  root.appendChild(backdrop);
  let closed = false;
  const close = (v) => {
    if (closed) return;
    closed = true;
    document.removeEventListener('keydown', onKey);
    backdrop.remove();
    if (onClose) onClose(v);
  };
  const onKey = (e) => { if (e.key === 'Escape' && closable) close(); };
  document.addEventListener('keydown', onKey);
  if (closeBtn) closeBtn.addEventListener('click', () => close());
  backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop && closable) close(); });
  return { el: m, close, body: m.querySelector('.modal-body') };
}

export function confirmDialog({ title, message, details, confirmLabel = 'Confirm', danger = false, extra }) {
  return new Promise((resolve) => {
    let result = false;
    const ok = btn(confirmLabel, { variant: danger ? 'danger' : 'primary' });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const m = modal({
      title,
      body: h('div', null,
        typeof message === 'string' ? h('p', { style: { marginTop: 0 } }, message) : message,
        details || null, extra || null),
      footer: [cancel, ok],
      onClose: () => resolve(result),
    });
    ok.addEventListener('click', () => { result = true; m.close(); });
    cancel.addEventListener('click', () => m.close());
    setTimeout(() => ok.focus(), 50);
  });
}

// ------------------------------------------------------------------ overlays
// Only the full-screen element and its children are visible in full screen (e.g. the Results tab),
// so menus, dialogs and toasts move into it while it is active.
export function overlayRoot() { return document.fullscreenElement || document.body; }
document.addEventListener('fullscreenchange', () => {
  const root = overlayRoot();
  for (const id of ['modalRoot', 'toastRoot', 'tooltip']) {
    const el = document.getElementById(id);
    if (el && el.parentElement !== root) root.appendChild(el);
  }
});

// ------------------------------------------------------------------ menu
let openMenu = null;
export function closeMenu() { if (openMenu) { openMenu.remove(); openMenu = null; } }
document.addEventListener('mousedown', (e) => { if (openMenu && !openMenu.contains(e.target)) closeMenu(); });
window.addEventListener('blur', closeMenu);
window.addEventListener('resize', closeMenu);

export function showMenu(anchor, items) {
  closeMenu();
  const m = h('div', { class: 'menu' });
  for (const it of items) {
    if (it === '-') { m.appendChild(h('div', { class: 'menu-sep' })); continue; }
    if (it.label && it.header) { m.appendChild(h('div', { class: 'menu-label' }, it.label)); continue; }
    const row = h('div', { class: 'menu-item' + (it.danger ? ' danger' : '') + (it.disabled ? ' disabled' : '') },
      it.icon ? icon(it.icon) : null,
      h('div', null, h('div', null, it.label), it.sub ? h('div', { class: 'menu-sub' }, it.sub) : null));
    row.addEventListener('click', () => { closeMenu(); it.onClick && it.onClick(); });
    m.appendChild(row);
  }
  overlayRoot().appendChild(m);
  const r = anchor.getBoundingClientRect();
  const mw = m.offsetWidth, mh = m.offsetHeight;
  let left = r.left, top = r.bottom + 6;
  if (left + mw > window.innerWidth - 8) left = r.right - mw;
  if (top + mh > window.innerHeight - 8) top = r.top - mh - 6;
  m.style.left = Math.max(8, left) + 'px';
  m.style.top = Math.max(8, top) + 'px';
  openMenu = m;
  return m;
}

// ------------------------------------------------------------------ form widgets
// colour swatch with the browser's colour picker; value '#rrggbb'. onInput fires live while
// picking, onChange once the picker is closed
export function colorPick(value, onChange, title, onInput) {
  const inp = h('input', { type: 'color', value, title: title || 'Choose colour' });
  const el = h('label', { class: 'color-pick', title: title || 'Choose colour', style: { '--c': value } }, inp);
  inp.addEventListener('input', () => { el.style.setProperty('--c', inp.value); if (onInput) onInput(inp.value); });
  inp.addEventListener('change', () => onChange(inp.value));
  return el;
}

export function switchEl(checked, onChange) {
  const input = h('input', { type: 'checkbox' });
  input.checked = !!checked;
  input.addEventListener('change', () => onChange && onChange(input.checked));
  const el = h('label', { class: 'switch' }, input, h('span'));
  el.input = input;
  return el;
}

// minimal Markdown: headings, lists (also "- [x]" check items), **bold**, *italic*, `code`, ---,
// paragraphs. breaks: keep single line breaks (notes) instead of joining lines (licence text)
export function renderMarkdown(md, { breaks = false } = {}) {
  const out = [];
  let list = null;
  const inline = (t) => esc(t)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*\w])\*([^*\s][^*]*?)\*(?!\w)/g, '$1<i>$2</i>');
  const flush = () => { if (list) { out.push(`<${list.tag}>${list.items.join('')}</${list.tag}>`); list = null; } };
  let para = [];
  const flushPara = () => { if (para.length) { out.push('<p>' + para.map(inline).join(breaks ? '<br>' : ' ') + '</p>'); para = []; } };
  for (const raw of (md || '').split('\n')) {
    const line = raw.trimEnd();
    let m;
    if (!line.trim()) { flushPara(); flush(); continue; }
    if ((m = /^(#{1,3})\s+(.*)$/.exec(line))) { flushPara(); flush(); out.push(`<h${m[1].length + 2}>${inline(m[2])}</h${m[1].length + 2}>`); continue; }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) { flushPara(); flush(); out.push('<hr>'); continue; }
    if ((m = /^\s*(?:[-*]|\d+\.)\s+(.*)$/.exec(line))) {
      flushPara();
      const tag = /^\s*\d+\./.test(line) ? 'ol' : 'ul';
      if (!list || list.tag !== tag) { flush(); list = { tag, items: [] }; }
      const c = /^\[([ xX])\]\s+(.*)$/.exec(m[1]);
      list.items.push(c ? `<li class="md-check${c[1] === ' ' ? '' : ' done'}">${inline(c[2])}</li>` : '<li>' + inline(m[1]) + '</li>');
      continue;
    }
    flush();
    para.push(line.trim());
  }
  flushPara(); flush();
  return out.join('');
}

export function segmented(options, value, onChange) {
  const el = h('div', { class: 'seg' });
  const render = (v) => {
    clear(el);
    for (const o of options) {
      const b = h('button', { type: 'button', class: o.value === v ? 'active' : '', title: o.title || null }, o.label);
      b.addEventListener('click', () => { render(o.value); onChange(o.value); });
      el.appendChild(b);
    }
  };
  render(value);
  el.set = render;
  return el;
}

// ------------------------------------------------------------------ formatting
export function fmtBytes(n) {
  if (n === null || n === undefined) return '-';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return (i === 0 ? v : v.toFixed(v < 10 ? 2 : v < 100 ? 1 : 0)) + ' ' + u[i];
}

export function fmtDuration(s) {
  if (s === null || s === undefined || !isFinite(s)) return '-';
  s = Math.max(0, Math.round(s));
  const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (d) return `${d}d ${hh}h`;
  if (hh) return `${hh}h ${String(m).padStart(2, '0')}m`;
  if (m) return `${m}m ${String(sec).padStart(2, '0')}s`;
  return `${sec}s`;
}

export function fmtAgo(ts) {
  if (!ts) return '';
  const s = Date.now() / 1000 - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  if (s < 86400 * 30) return Math.floor(s / 86400) + ' d ago';
  return new Date(ts * 1000).toLocaleDateString();
}

export function fmtDate(ts) {
  if (!ts) return '-';
  const d = new Date(ts * 1000);
  return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) + ' ' +
    d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

export function fmtNum(v, digits = 4) {
  if (v === null || v === undefined || !isFinite(v)) return '-';
  const a = Math.abs(v);
  if (a !== 0 && (a < 1e-3 || a >= 1e6)) return v.toExponential(2);
  return Number(v.toPrecision(digits)).toString();
}

export function fmtInt(v) {
  if (v === null || v === undefined) return '-';
  return Number(v).toLocaleString('en-US');
}

export function fmtCells(v) {
  if (!v) return '-';
  if (v >= 1e6) return (v / 1e6).toFixed(2) + ' M';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + ' k';
  return String(v);
}

export function fmtForce(v) {
  if (v === null || v === undefined || !isFinite(v)) return '-';
  return v.toFixed(Math.abs(v) < 1 ? 4 : 3);
}

// "20260626_evolut1on_V3_param_15" -> {date: "2026-06-26", rest: "evolut1on_V3_param_15"}
export function splitName(name) {
  const m = /^(\d{4})(\d{2})(\d{2})[_-]+(.*)$/.exec(name || '');
  if (m) return { date: `${m[1]}-${m[2]}-${m[3]}`, rest: m[4] || name };
  return { date: '', rest: name };
}

export const STATUS = {
  fresh: { label: 'Fresh', desc: 'Set up, not meshed yet' },
  meshed: { label: 'Meshed', desc: 'Mesh ready, not solved' },
  queued: { label: 'Queued', desc: 'Waiting in the run queue' },
  running: { label: 'Running', desc: 'Currently running' },
  finished: { label: 'Finished', desc: 'Results available' },
  stopped: { label: 'Stopped', desc: 'Stopped early, results saved' },
  error: { label: 'Error', desc: 'Failed or aborted' },
};

// Convergence of a force signal: std over the averaging window relative to the force level.
// Same thresholds everywhere (Forces tab, overview, leaderboard).
// rel = uncertainty of the mean drag relative to the drag (see relUnc)
export function convergence(rel) {
  if (rel === null || rel === undefined || !isFinite(rel)) return null;
  const pct = (rel * 100).toFixed(2) + ' %';
  if (rel <= 0.001) return { cls: 'st-ok', label: 'converged', pct };
  if (rel <= 0.005) return { cls: 'st-running', label: 'nearly converged', pct };
  return { cls: 'st-error', label: 'not converged', pct };
}

// relative uncertainty of the mean drag of a result summary (falls back to the scatter for old servers)
export function relUnc(r) {
  if (!r || !r.drag) return null;
  const u = r.drag_sem != null ? r.drag_sem : r.drag_std;
  return u != null ? u / Math.abs(r.drag) : null;
}

// uncertainty of the mean (N) of drag or lift
export function uncOf(r, q = 'drag') {
  if (!r) return null;
  return r[q + '_sem'] != null ? r[q + '_sem'] : r[q + '_std'];
}

// standard error of the mean of an oscillating series (same estimator as the server)
export function meanUncertainty(v) {
  const n = v.length;
  if (n < 20) return null;
  const m = v.reduce((a, b) => a + b, 0) / n;
  const d = v.map((x) => x - m);
  const c0 = d.reduce((a, b) => a + b * b, 0) / n;
  if (c0 <= 0) return 0;
  let tau = 0.5;
  for (let k = 1; k < n / 2; k++) {
    let s = 0;
    for (let i = 0; i < n - k; i++) s += d[i] * d[i + k];
    tau += s / n / c0;
    if (k >= 5 * tau) break;
  }
  let est = Math.sqrt(c0 * 2 * Math.max(tau, 0.5) / n);
  const bl = Math.floor(n / 10);
  if (bl >= 10) {
    const bm = [];
    for (let i = 0; i < 10; i++) bm.push(v.slice(i * bl, (i + 1) * bl).reduce((a, b) => a + b, 0) / bl);
    const mb = bm.reduce((a, b) => a + b, 0) / 10;
    est = Math.max(est, Math.sqrt(bm.reduce((a, b) => a + (b - mb) ** 2, 0) / 9 / 10));
  }
  return est;
}

export function convergencePill(rel, short = false) {
  const c = convergence(rel);
  if (!c) return null;
  return h('span', { class: 'pill ' + c.cls, title: `Uncertainty of the mean: ±${c.pct} (converged below 0.1 %)` },
    short ? '±' + c.pct : c.label);
}

export function statusPill(status, text) {
  return h('span', { class: 'pill st-' + status }, h('span', { class: 'dot' }), text || (STATUS[status] || {}).label || status);
}

export function debounce(fn, ms) {
  let t = null;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export function store(key, value) {
  try {
    if (value === undefined) {
      const cur = localStorage.getItem('flowforge-' + key);
      if (cur !== null) return JSON.parse(cur);
      const old = localStorage.getItem('apex-' + key);        // saved under the old product name
      return old === null ? null : JSON.parse(old);
    }
    localStorage.setItem('flowforge-' + key, JSON.stringify(value));
  } catch (e) { return null; }
  return value;
}
