// Locked previews: what a higher variant would show, greyed out and without any values
// (Regional: forces, comparison; National: drag by part, balance, video, batch screenshots, team colour).

import { h, icon, btn } from './ui.js';
import { openAppSettings } from './appsettings.js';

// the smallest variant that has a feature (app/license.py TIERS)
const NEEDS = {
  forces: 'national', compare: 'national',
  part_forces: 'world', balance: 'world', batch_screenshots: 'world', video: 'world', team_color: 'world',
};
const TIER = { national: { label: 'National', color: '#2f7cf6' }, world: { label: 'World', color: '#ff7a1a' } };

export function tierFor(feature) { return TIER[NEEDS[feature] || 'world']; }

// the settings dialog, scrolled to the licence and with the key field open
export function openUpgrade(app) {
  openAppSettings(app);
  setTimeout(() => {
    const box = document.getElementById('upgradeBox');
    if (!box) return;
    box.scrollIntoView({ block: 'center', behavior: 'smooth' });
    const panel = box.querySelector('.upgrade-panel');
    if (panel && panel.classList.contains('hidden')) box.querySelector('button').click();
  }, 150);
}

export function tierBadge(feature) {
  const t = tierFor(feature);
  return h('span', { class: 'lock-badge', style: { '--lock': t.color } }, icon('lock'), t.label);
}

// a card with a greyed preview (no values) and the hint what the higher variant shows
export function lockedCard(app, { feature, title, ic = 'lock', text, preview, compact = false }) {
  const t = tierFor(feature);
  const up = btn(`Upgrade to ${t.label}`, { size: 'sm', icon: 'external' });
  up.addEventListener('click', () => openUpgrade(app));
  return h('div', { class: 'card locked' + (compact ? ' compact' : ''), style: { '--lock': t.color } },
    h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon(ic), title), tierBadge(feature)),
    h('div', { class: 'locked-body' },
      h('div', { class: 'locked-preview', 'aria-hidden': 'true' }, preview || skeletonChart()),
      h('div', { class: 'locked-over' },
        h('div', { class: 'locked-ic' }, icon('lock', 'lg')),
        h('div', { class: 'locked-title' }, `Available in ${t.label}`),
        text ? h('div', { class: 'locked-text' }, text) : null,
        up)));
}

// a button that would do something in a higher variant
export function lockedButton(app, feature, label, ic) {
  const t = tierFor(feature);
  const b = btn(label, { size: 'sm', variant: 'ghost', icon: ic });
  b.classList.add('locked-btn');
  b.style.setProperty('--lock', t.color);
  b.title = `${label} - available in ${t.label}`;
  b.appendChild(h('span', { class: 'lock-mini' }, icon('lock')));
  b.addEventListener('click', () => openUpgrade(app));
  return b;
}

// ------------------------------------------------------------------ placeholders (shapes only, no numbers)
const NS = 'http://www.w3.org/2000/svg';
function svg(w, hgt, inner) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', `0 0 ${w} ${hgt}`);
  s.setAttribute('preserveAspectRatio', 'none');
  s.setAttribute('class', 'skel-svg');
  s.innerHTML = inner;
  return s;
}

// a swinging signal that settles - the typical drag history, drawn as a shape only
export function skeletonChart(height = 220, seed = 1) {
  const w = 600, hh = 200;
  let d = '', r = seed * 9301;
  const rnd = () => { r = (r * 9301 + 49297) % 233280; return r / 233280; };
  for (let i = 0; i <= 120; i++) {
    const x = 40 + i * (w - 50) / 120;
    const amp = 70 * Math.exp(-i / 30) + 14;
    const y = 100 + Math.sin(i * 0.55 + seed) * amp * (0.6 + 0.4 * rnd());
    d += (i ? 'L' : 'M') + x.toFixed(1) + ',' + y.toFixed(1);
  }
  let grid = '';
  for (let k = 0; k < 5; k++) grid += `<line x1="40" x2="${w - 10}" y1="${20 + k * 40}" y2="${20 + k * 40}" class="skel-grid"/>`;
  const el = h('div', { class: 'skel-chart', style: { height: height + 'px' } });
  el.appendChild(svg(w, hh, grid + `<rect x="${w * 0.45}" y="10" width="${w * 0.53}" height="180" class="skel-band"/>`
    + `<path d="${d}" class="skel-line"/><line x1="${w * 0.45}" x2="${w - 10}" y1="100" y2="100" class="skel-mean"/>`));
  return el;
}

// a row of key figures with dashes instead of values
export function skeletonKpis(labels) {
  return h('div', { class: 'skel-kpis' }, labels.map((l) => h('div', { class: 'skel-kpi' }, h('span', null, l), h('b', null, '—'))));
}

// horizontal bars (drag by part) - part names only
export function skeletonBars(names) {
  const widths = [78, 54, 46, 34, 26, 18, 12, 8];
  return h('div', { class: 'skel-bars' }, names.map((n, i) => h('div', { class: 'skel-bar' },
    h('span', null, n), h('i', { style: { width: (widths[i % widths.length]) + '%' } }))));
}

// a table with real row names and dashes in the value columns
export function skeletonTable(cols, rows) {
  return h('table', { class: 'tbl skel-tbl' },
    h('thead', null, h('tr', null, cols.map((c, i) => h('th', { class: i ? 'num' : '' }, c)))),
    h('tbody', null, rows.map((r) => h('tr', null, h('td', null, r), cols.slice(1).map(() => h('td', { class: 'num' }, '—'))))));
}
