// Family tree of all simulations (dashboard → Family tree).
//
// Every simulation is a card next to the one it was made from (generations from left to right,
// the most recent work on top). A card shows what changed against its origin - geometry parts
// and key settings - and how the drag moved: the line to it is green when the drag went down,
// red when it went up. "Focus" shows only the ancestors and descendants of one simulation; a
// click opens the full list of changes, the notes and Open / Compare.
// Data: /api/lineage (app/lineage.py, cached on the file times) and the case list of the app.

import * as api from './api.js';
import { h, mount, clear, icon, btn, store, splitName, fmtForce, fmtCells, statusPill, renderMarkdown, segmented, switchEl } from './ui.js';
import { partPictures, PartCompare3D } from './geometry.js';

const W = 276, H = 94, GAP_X = 52, GAP_Y = 10, GAP_ROOT = 26;
const SIDE_W = 420;                 // details panel on the right of the canvas
const GRID_MIN = 4, FRAME = 14;     // variants laid out as a grid from this many on; air around its frame
const NEUTRAL = 0.05;                // drag change in % shown as "no change"
const MAX_CHIPS = 2;

const pct = (v, ref) => (v != null && ref ? (v - ref) / Math.abs(ref) * 100 : null);
const trend = (p) => (p == null ? 'none' : Math.abs(p) < NEUTRAL ? 'flat' : p < 0 ? 'down' : 'up');
const fmtPct = (p) => (p > 0 ? '+' : p < 0 ? '−' : '±') + Math.abs(p).toFixed(2) + ' %';
const partName = (f) => f.replace(/\.stl$/i, '').replace(/_/g, ' ');

// shortened in the middle: variants differ at the end of their names (mesh_130 / mesh_140)
function midName(name, cls) {
  const tail = name.length > 16 ? name.slice(-11) : '';
  return h('div', { class: cls }, h('span', { class: 'ft-head' }, tail ? name.slice(0, -11) : name), tail ? h('span', { class: 'ft-tail' }, tail) : null);
}

export class LineageView {
  constructor(app) {
    this.app = app;
    this.focus = store('tree-focus') || null;
    this.collapsed = new Set(store('tree-collapsed') || []);
    this.selected = null;
    this.query = '';
    this.showBest = store('tree-best') !== false;
    this.t = { x: 24, y: 20, s: 0.9 };
    this.canvas = h('div', { class: 'ft-canvas' });
    this.world = h('div', { class: 'ft-world' });
    this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.svg.setAttribute('class', 'ft-edges');
    this.world.append(this.svg);
    this.panel = h('div', { class: 'ft-side hidden' });
    this.bar = h('div', { class: 'ft-bar' });
    // overview of the whole tree with the visible part; click or drag in it to move there
    this.mini = h('canvas', { class: 'ft-mini', title: 'Overview - click or drag to move there' });
    this.canvas.append(this.world, this.panel, this.mini,
      h('div', { class: 'ft-hint' }, 'Drag or hold Space: move  ·  Wheel: scroll  ·  Ctrl + wheel: zoom  ·  Click: details  ·  Arrow keys: walk the tree'),
      this.msg = h('div', { class: 'ft-msg' }, h('div', { class: 'spinner' }), 'Reading the settings of all simulations (the first time takes a while)...'));
    this.el = h('div', { class: 'ft' }, this.bar, this.canvas);
    this.bindCanvas();
    this.bindMini();
    this.renderBar();
    this._resize = () => { if (!this.el.isConnected) { window.removeEventListener('resize', this._resize); return; } this.fitHeight(); };
    window.addEventListener('resize', this._resize);
    this._esc = (e) => this.onKey(e);
    window.addEventListener('keydown', this._esc);
    window.addEventListener('keyup', this._esc);
    requestAnimationFrame(() => this.fitHeight());
    this.load();
  }

  // the canvas fills the window below the toolbar
  fitHeight() {
    if (!this.el.isConnected) return;
    const top = this.canvas.getBoundingClientRect().top + (document.getElementById('content') || document.body).scrollTop;
    this.canvas.style.height = Math.max(460, window.innerHeight - Math.min(top, 260) - 20) + 'px';
  }

  // ------------------------------------------------------------------ data
  async load() {
    try { this.data = await api.get('lineage'); } catch (e) { mount(this.msg, icon('alert'), 'Could not read the simulations: ' + e.message); return; }
    this.dataSig = this.structSig();
    this.msg.remove();
    this.fitHeight();
    this.render(true);
  }

  // names + origins: a change needs the lineage data again; status / drag only a redraw
  structSig() { return this.app.cases.map((c) => c.name + '<' + (c.origin || '')).join('|'); }
  liveSig() { return this.app.cases.map((c) => [c.name, c.status, c.queued, c.results && c.results.drag].join(':')).join('|'); }

  // called on every refresh of the case list (every few seconds)
  update() {
    if (!this.data) return;
    if (this.structSig() !== this.dataSig) { this.load(); return; }
    const sig = this.liveSig();
    if (sig !== this.lastLive) this.render(false);
  }

  // nodes with parent / children, drag change against the parent
  model() {
    const byName = new Map(this.app.cases.map((c) => [c.name, c]));
    const info = new Map((this.data.sims || []).map((s) => [s.name, s]));
    const nodes = new Map();
    for (const c of this.app.cases) {
      const s = info.get(c.name) || {};
      nodes.set(c.name, { name: c.name, c, s, parent: null, kids: [], drag: c.results && c.results.drag != null ? c.results.drag : null });
    }
    for (const n of nodes.values()) {
      const o = n.c.origin;
      if (o && o !== n.name && nodes.has(o)) { n.parent = nodes.get(o); n.parent.kids.push(n); }
    }
    // break cycles (origin set by hand in a loop): such a node becomes a root
    for (const n of nodes.values()) {
      const seen = new Set([n]);
      for (let p = n.parent; p; p = p.parent) {
        if (seen.has(p)) { n.parent.kids = n.parent.kids.filter((k) => k !== n); n.parent = null; break; }
        seen.add(p);
      }
    }
    const created = (n) => n.c.created || 0;
    const latest = (n) => (n._latest != null ? n._latest : (n._latest = Math.max(created(n), ...n.kids.map(latest))));
    for (const n of nodes.values()) {
      n.kids.sort((a, b) => latest(b) - latest(a));
      n.delta = n.parent ? pct(n.drag, n.parent.drag) : null;
    }
    const roots = [...nodes.values()].filter((n) => !n.parent).sort((a, b) => latest(b) - latest(a));
    // the lowest drag of every family (a root and everything made from it): drags of different
    // families (other car, other setup) are not comparable, so there is no single overall best
    const famBest = new Map();
    for (const r of roots) {
      let b = null, count = 0;
      const walk = (n) => { n.root = r; if (n.drag != null) { count++; if (!b || n.drag < b.drag) b = n; } n.kids.forEach(walk); };
      walk(r);
      if (b && count >= 2) famBest.set(r, b);
    }
    return { nodes, roots, famBest, bests: new Set(famBest.values()), byName };
  }

  // ------------------------------------------------------------------ layout
  // From left to right, one column per generation. A parent sits on the row of its first (most
  // recent) child, so a line of development reads along one row; the other variants are stacked
  // below. Compact packing: every column keeps its lowest used row (a skyline), and a card moves
  // up as far as its own column allows - a branch fills the empty space under a long line instead
  // of starting below everything. The vertical line from a parent to its children runs in the gap
  // right of the parent's column: below the parent only cards without own variants may follow
  // until that line ends (their edges come from the left), so no line crosses a card or a line.
  layout(m) {
    let visible = null;
    if (this.focus && m.nodes.has(this.focus)) {
      visible = new Set();
      const f = m.nodes.get(this.focus);
      for (let p = f; p; p = p.parent) visible.add(p);
      const down = (n) => { visible.add(n); n.kids.forEach(down); };
      down(f);
    } else this.focus = null;
    const show = (n) => !visible || visible.has(n);
    // two skylines per column: `card` = below the lowest card, `gap` = below the lowest vertical
    // line in the gap right of the column. A card without own variants only needs `card` (its
    // edge comes from the left), a card with variants also needs `gap` (its lines go right).
    const card = [], gap = [];
    const at = (a, c) => a[c] || 0;
    const STEP = H + GAP_Y;
    let deepest = 0;
    const colX = (c) => c * (W + GAP_X);
    // variants without own variants (e.g. a mesh study) are laid out as a grid of 2 - 3 columns in a
    // frame instead of one long column
    const isLeaf = (k) => !this.collapsed.has(k.name) && !k.kids.some(show);
    const place = (n, depth, minY) => {
      deepest = Math.max(deepest, depth);
      n.x = colX(depth);
      n.grid = null;
      n.gridCol = 0;
      const kids = this.collapsed.has(n.name) ? [] : n.kids.filter(show);
      let y = Math.max(minY, at(card, depth), kids.length ? at(gap, depth) : 0);
      let leaves = kids.filter(isLeaf), lines = kids.filter((k) => !isLeaf(k));
      if (leaves.length < GRID_MIN) { lines = kids; leaves = []; }
      let first = true, last = null;
      for (const k of lines) {
        place(k, depth + 1, y);
        if (first) { y = Math.max(y, k.y); first = false; }
        last = k.y;
      }
      if (leaves.length) {
        const cols = leaves.length >= 9 ? 3 : 2, rows = Math.ceil(leaves.length / cols);
        let gy = y + (first ? 0 : FRAME);
        for (let c = 1; c <= cols; c++) gy = Math.max(gy, at(card, depth + c) + FRAME, c < cols ? at(gap, depth + c) + FRAME : 0);
        if (first) y = gy;
        leaves.forEach((k, i) => {
          k.x = colX(depth + 1 + (i % cols)); k.y = gy + Math.floor(i / cols) * STEP;
          k.gridCol = i % cols; k.grid = null;
        });
        for (let c = 1; c <= cols; c++) {
          card[depth + c] = gy + rows * STEP + FRAME;
          if (c < cols) gap[depth + c] = Math.max(at(gap, depth + c), card[depth + c]);   // the frame spans these gaps
        }
        deepest = Math.max(deepest, depth + cols);
        n.grid = { x: colX(depth + 1), y: gy, w: colX(cols - 1) + W, h: rows * STEP - GAP_Y };
        last = gy + (rows - 1) * STEP;
      }
      card[depth] = y + STEP;
      if (kids.length) gap[depth] = Math.max(y, last == null ? y : last) + STEP;
      n.y = y;
    };
    const roots = visible ? m.roots.filter(show) : m.roots;
    // simulations without origin and without variants: one grid below all families
    const lone = roots.filter(isLeaf), families = roots.filter((r) => !isLeaf(r));
    for (const r of families) {
      deepest = 0;
      place(r, 0, 0);
      // a little air between families
      for (let c = 0; c <= deepest; c++) {
        if (card[c] != null) card[c] += GAP_ROOT - GAP_Y;
        if (gap[c] != null) gap[c] += GAP_ROOT - GAP_Y;
      }
    }
    this.loneGrid = null;
    if (lone.length) {
      const cols = Math.min(lone.length, 6), rows = Math.ceil(lone.length / cols);
      let gy = 0;
      for (let c = 0; c < cols; c++) gy = Math.max(gy, at(card, c), c < cols - 1 ? at(gap, c) : 0);
      gy += families.length ? GAP_ROOT + 16 : 16;
      lone.forEach((k, i) => { k.x = colX(i % cols); k.y = gy + Math.floor(i / cols) * STEP; k.grid = null; k.gridCol = 0; });
      this.loneGrid = { x: 0, y: gy, w: colX(cols - 1) + W, h: rows * STEP - GAP_Y };
    }
    const placed = [];
    const walk = (n) => { placed.push(n); if (!this.collapsed.has(n.name)) n.kids.filter(show).forEach(walk); };
    roots.forEach(walk);
    return placed;
  }

  // ------------------------------------------------------------------ drawing
  render(fit) {
    this.lastLive = this.liveSig();
    const m = this.model();
    this.m = m;
    const placed = this.layout(m);
    this.placed = placed;
    const q = this.query.trim().toLowerCase();
    const match = (n) => !q || n.name.toLowerCase().includes(q) || (n.s.notes || '').toLowerCase().includes(q);
    const chain = new Set();
    if (this.selected && m.nodes.has(this.selected)) for (let p = m.nodes.get(this.selected); p; p = p.parent) chain.add(p.name);
    // the line that led to the lowest drag (gold): how the best design came about
    const bestLine = new Set();
    if (this.showBest) for (const b of m.bests) for (let p = b; p; p = p.parent) bestLine.add(p.name);
    this.edgeEls = new Map();

    // edges
    const maxX = Math.max(0, ...placed.map((n) => n.x)) + W, maxY = Math.max(0, ...placed.map((n) => n.y)) + H;
    this.size = [maxX, maxY];
    this.svg.setAttribute('width', maxX + 20);
    this.svg.setAttribute('height', maxY + 20);
    clear(this.svg);
    const ns = 'http://www.w3.org/2000/svg';
    const shown = new Set(placed);
    // drawing order: neutral trunks, the coloured ends, the highlighted line of the selection on top
    const layer = () => { const g = document.createElementNS(ns, 'g'); this.svg.appendChild(g); return g; };
    const gTrunk = layer(), gEnd = layer(), gChain = layer();
    // frames around the grids of variants (and of the simulations without origin)
    const frame = (g, cls, label) => {
      const rc = document.createElementNS(ns, 'rect');
      rc.setAttribute('x', g.x - 9); rc.setAttribute('y', g.y - 9);
      rc.setAttribute('width', g.w + 18); rc.setAttribute('height', g.h + 18);
      rc.setAttribute('rx', 16);
      rc.setAttribute('class', 'ft-frame' + cls);
      gTrunk.appendChild(rc);
      if (label) {
        const t = document.createElementNS(ns, 'text');
        t.setAttribute('x', g.x + 6); t.setAttribute('y', g.y - 15);
        t.setAttribute('class', 'ft-frame-label');
        t.textContent = label;
        gTrunk.appendChild(t);
      }
    };
    for (const n of placed) if (n.grid) frame(n.grid, q && !match(n) ? ' dim' : '');
    if (this.loneGrid) frame(this.loneGrid, ' lone', 'Without origin or variants');
    for (const n of placed) {
      // in a grid only the first column is joined to the parent; the frame holds the others
      if (!n.parent || !shown.has(n.parent) || n.gridCol > 0) continue;
      // shared trunk just right of the parent, rounded corner into each variant
      const x0 = n.parent.x + W, y0 = n.parent.y + H / 2, x1 = n.x, y1 = n.y + H / 2, mx = x0 + 26, R = 12;
      const straight = y1 - y0 < 2 * R;
      const cls = (chain.has(n.name) ? ' chain' : '') + (bestLine.has(n.name) ? ' best' : '') + (q && !match(n) ? ' dim' : '');
      // the trunk is shared by all variants (neutral), the last bend into a variant shows its drag change
      const trunk = document.createElementNS(ns, 'path');
      trunk.setAttribute('d', straight ? `M${x0},${y0} H${mx}` : `M${x0},${y0} H${mx - R} Q${mx},${y0} ${mx},${y0 + R} V${y1 - R}`);
      trunk.setAttribute('class', 'ft-edge trunk' + cls);
      const end = document.createElementNS(ns, 'path');
      end.setAttribute('d', straight ? `M${mx},${y1} H${x1}` : `M${mx},${y1 - R} Q${mx},${y1} ${mx + R},${y1} H${x1}`);
      end.setAttribute('class', 'ft-edge ' + trend(n.delta) + cls);
      const top = chain.has(n.name) || bestLine.has(n.name);
      (top ? gChain : gTrunk).appendChild(trunk);
      (top ? gChain : gEnd).appendChild(end);
      this.edgeEls.set(n.name, [trunk, end]);
    }
    // nodes
    this.nodeEls = new Map();
    for (const el of [...this.world.querySelectorAll('.ft-node')]) el.remove();
    for (const n of placed) {
      const el = this.nodeEl(n, { dim: q && !match(n), chain: chain.has(n.name), best: bestLine.has(n.name) });
      this.nodeEls.set(n.name, el);
      this.world.appendChild(el);
    }
    this.matches = q ? placed.filter(match) : [];
    this.renderBar();
    if (fit) this.home();
    if (this.selected && !m.nodes.has(this.selected)) this.closePanel();
    this.apply();
  }

  // hovering a card lights up the line it came from (classes only, nothing is redrawn)
  hoverLine(n, on) {
    for (let p = n; p; p = p.parent) {
      for (const e of this.edgeEls.get(p.name) || []) e.classList.toggle('hl', on);
      const el = this.nodeEls.get(p.name);
      if (el && p !== n) el.classList.toggle('hl', on);
    }
  }

  nodeEl(n, { dim, chain, best }) {
    const c = n.c, s = n.s;
    const nm = splitName(n.name);
    const st = c.queued && c.status !== 'running' ? 'queued' : c.status;
    const geo = s.geometry || [], set = s.settings || [];
    const chips = [];
    for (const g of geo) chips.push(h('span', { class: 'ft-chip geo', title: `${partName(g.name)} ${g.state}` }, icon('cube'), partName(g.name)));
    // run control (end time, cores, write interval) says least about the design: last on the card
    const minor = (r) => (r.group === 'Run control' ? 1 : 0);
    for (const r of [...set].sort((a, b) => minor(a) - minor(b))) chips.push(h('span', { class: 'ft-chip', title: `${r.group}: ${r.label}\n${r.a ?? '—'}  →  ${r.b ?? '—'}` }, h('span', { class: 'k' }, r.label), h('b', null, r.b ?? '—')));
    let row;
    if (!n.parent) row = h('span', { class: 'ft-chip muted' }, n.c.origin ? 'origin deleted' : 'start of a line');
    else if (!this.data.changes) row = h('span', { class: 'ft-chip muted', title: 'Showing the changes needs the Compare feature' }, icon('lock'), 'changes');
    else if (s.settings === null) row = h('span', { class: 'ft-chip muted' }, 'settings not readable');
    else if (!chips.length) row = h('span', { class: 'ft-chip muted' }, 'same settings & geometry');
    const more = chips.length - MAX_CHIPS;
    const hiddenKids = this.collapsed.has(n.name) ? this.countDesc(n) : 0;
    const el = h('div', { class: `ft-node st-${st}` + (n.name === this.selected ? ' sel' : '') + (chain ? ' chain' : '') + (dim ? ' dim' : '')
        + (this.m.bests.has(n) ? ' best' : '') + (best ? ' on-best' : '') + (n.name === this.focus ? ' focus' : ''),
      style: { left: n.x + 'px', top: n.y + 'px', width: W + 'px', height: H + 'px' },
      // the first line of the notes usually says what this variant is about
      title: n.name + (s.notes ? '\n' + s.notes.split('\n').find((l) => l.trim()).trim().slice(0, 160) : '') },
    h('div', { class: 'ft-top' }, h('span', { class: 'ft-dot' }), midName(nm.rest, 'ft-name'),
      this.m.bests.has(n) ? h('span', { class: 'ft-best', title: 'Lowest drag of this family (everything made from the same start)' }, icon('trophy')) : null,
      h('span', { class: 'ft-date' }, nm.date ? nm.date.slice(2) : '')),
    h('div', { class: 'ft-mid' },
      n.drag != null ? h('span', { class: 'ft-drag' }, fmtForce(n.drag), h('small', null, ' N')) : h('span', { class: 'ft-drag none' }, STATUS_TEXT[st] || st),
      n.delta != null ? h('span', { class: 'ft-delta ' + trend(n.delta), title: 'Drag compared with its origin' }, fmtPct(n.delta)) : null,
      h('span', { class: 'grow' }),
      c.cells ? h('span', { class: 'ft-cells' }, fmtCells(c.cells)) : null),
    h('div', { class: 'ft-chips' }, row || [chips.slice(0, MAX_CHIPS), more > 0 ? h('span', { class: 'ft-chip more' }, '+' + more) : null]));
    if (n.kids.length) {
      const tog = h('button', { type: 'button', class: 'ft-toggle' + (hiddenKids ? ' closed' : ''), title: hiddenKids ? `Show ${hiddenKids} hidden` : 'Fold this branch' },
        hiddenKids ? '+' + hiddenKids : '−');
      tog.addEventListener('pointerdown', (e) => e.stopPropagation());
      tog.addEventListener('click', (e) => {
        e.stopPropagation();
        if (this.collapsed.has(n.name)) this.collapsed.delete(n.name); else this.collapsed.add(n.name);
        store('tree-collapsed', [...this.collapsed]);
        this.render(false);
      });
      el.appendChild(tog);
    }
    el.addEventListener('click', () => { if (!this.moved) this.select(n.name); });
    el.addEventListener('dblclick', () => this.app.select(n.name));
    el.addEventListener('mouseenter', () => this.hoverLine(n, true));
    el.addEventListener('mouseleave', () => this.hoverLine(n, false));
    return el;
  }

  countDesc(n) { return n.kids.reduce((a, k) => a + 1 + this.countDesc(k), 0); }

  // ------------------------------------------------------------------ toolbar
  renderBar() {
    if (!this.search) {
      this.search = h('input', { class: 'input ft-search', type: 'search', placeholder: 'Find simulation or note...' });
      this.search.addEventListener('input', () => { this.query = this.search.value; this.matchIdx = -1; this.render(false); });
      this.search.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.nextMatch(); } });
    }
    const fit = btn('Fit', { size: 'sm', icon: 'fit', title: 'Show the whole tree' });
    fit.addEventListener('click', () => { this.fit(); this.apply(); });
    const zin = btn('', { size: 'sm', icon: 'plus', title: 'Zoom in' });
    zin.addEventListener('click', () => this.zoomAt(1.2));
    const zout = btn('', { size: 'sm', icon: 'minus', title: 'Zoom out' });
    zout.addEventListener('click', () => this.zoomAt(1 / 1.2));
    let focus = null;
    if (this.focus) {
      const x = h('button', { type: 'button', class: 'ft-focus-x', title: 'Show all simulations' }, icon('x'));
      x.addEventListener('click', () => this.setFocus(null));
      focus = h('span', { class: 'ft-focus' }, icon('target'), 'Line of ', h('b', null, splitName(this.focus).rest), x);
    }
    const fold = this.collapsed.size ? (() => {
      const b = btn('Unfold all', { size: 'sm', variant: 'ghost' });
      b.addEventListener('click', () => { this.collapsed.clear(); store('tree-collapsed', []); this.render(false); });
      return b;
    })() : null;
    // jump to the lowest drag / the newest simulation
    const jump = (label, ic, title, pick) => {
      const b = btn(label, { size: 'sm', icon: ic, title });
      b.addEventListener('click', () => { const n = this.m && pick(); if (n) this.goTo(n); });
      return b;
    };
    // best of the family of the open card, else of the family worked on most recently
    const best = jump('Best', 'trophy', 'Go to the lowest drag of this family (of the open card, else of the newest simulation)', () => {
      const ref = (this.selected && this.m.nodes.get(this.selected)) || this.newest();
      const b = ref && this.m.famBest.get(ref.root);
      return b && this.placed.includes(b) ? b : null;
    });
    const newest = jump('Newest', 'clock', 'Go to the most recently created simulation', () => this.newest());
    const line = h('label', { class: 'ft-toggle-best', title: 'Mark the line that led to the lowest drag of every family (gold)' },
      switchEl(this.showBest, (v) => { this.showBest = v; store('tree-best', v); this.render(false); }), h('i'), 'Best line');
    const q = this.query.trim();
    mount(this.bar, this.search,
      q ? h('span', { class: 'muted small' }, `${(this.matches || []).length} found` + ((this.matches || []).length ? ' · Enter: next' : '')) : null,
      focus, h('div', { class: 'btn-group' }, best, newest), h('span', { class: 'grow' }),
      h('span', { class: 'ft-legend' }, h('i', { class: 'down' }), 'less drag than its origin', h('i', { class: 'up' }), 'more drag', h('i', { class: 'flat' }), 'no change / no result'),
      line, fold, h('div', { class: 'btn-group' }, zout, zin), fit);
  }

  newest() { return (this.placed || []).reduce((a, b) => ((b.c.created || 0) > ((a && a.c.created) || 0) ? b : a), null); }

  // centre a card and open its details
  goTo(n) {
    this.center(n);
    this.select(n.name);
  }

  nextMatch() {
    if (!this.matches || !this.matches.length) return;
    this.matchIdx = ((this.matchIdx ?? -1) + 1) % this.matches.length;
    this.goTo(this.matches[this.matchIdx]);
  }

  // keyboard: Esc closes the details, arrows walk the tree (left: origin, right: first variant,
  // up / down: the card above / below in the same column), Enter opens the simulation, holding
  // Space moves the view with the pointer (no axis lock, also on a touchpad)
  onKey(e) {
    if (!this.el.isConnected) { window.removeEventListener('keydown', this._esc); window.removeEventListener('keyup', this._esc); return; }
    const t = e.target || {};
    if (t.isContentEditable || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'SELECT' || document.querySelector('.modal-backdrop')) return;
    if (e.code === 'Space') {
      e.preventDefault();
      this.spacePan = e.type === 'keydown';
      this.canvas.classList.toggle('space-pan', this.spacePan);
      return;
    }
    if (e.type !== 'keydown' || !this.m) return;
    if (e.key === 'Escape' && this.selected) { this.closePanel(); this.render(false); return; }
    const cur = this.selected && this.m.nodes.get(this.selected);
    if (e.key === 'Enter' && cur) { this.app.select(cur.name); return; }
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return;
    e.preventDefault();
    const shown = new Set(this.placed);
    let next = null;
    if (!cur) next = this.placed[0];
    else if (e.key === 'ArrowLeft') next = cur.parent && shown.has(cur.parent) ? cur.parent : null;
    else if (e.key === 'ArrowRight') next = cur.kids.find((k) => shown.has(k)) || null;
    else {
      const col = this.placed.filter((n) => n.x === cur.x && n !== cur);
      const down = e.key === 'ArrowDown';
      next = col.filter((n) => (down ? n.y > cur.y : n.y < cur.y))
        .sort((a, b) => (down ? a.y - b.y : b.y - a.y))[0] || null;
    }
    if (next) this.select(next.name);      // the view only moves when the card would leave it
  }

  setFocus(name) {
    this.focus = name;
    store('tree-focus', name);
    this.render(true);
  }

  // ------------------------------------------------------------------ details
  // The details are a side panel on the right of the canvas; the view moves a card that would lie
  // under the panel (or outside the view) to the free part.
  select(name) {
    if (this.selected === name) return;
    if (this.cmp3d) { this.cmp3d.destroy(); this.cmp3d = null; }
    this.selected = name;
    this.panel.classList.remove('hidden');
    this.canvas.classList.add('side-open');
    this.render(false);
    const n = this.m.nodes.get(name);
    if (!n) return;
    const r = this.canvas.getBoundingClientRect(), s = this.t.s;
    const free = r.width - SIDE_W - 20;              // width left of the panel
    const sx = this.t.x + n.x * s, sy = this.t.y + n.y * s;
    if (sx < 0 || sx + W * s > free || sy < 0 || sy + H * s > r.height) this.center(n);
    this.renderPanel();
    this.apply();
  }

  closePanel() {
    if (this.cmp3d) { this.cmp3d.destroy(); this.cmp3d = null; }
    this.selected = null;
    this.panel.classList.add('hidden');
    this.canvas.classList.remove('side-open');
  }

  renderPanel() {
    const n = this.m && this.m.nodes.get(this.selected);
    if (!n) { this.closePanel(); return; }
    const s = n.s, nm = splitName(n.name);
    const close = h('button', { type: 'button', class: 'ft-panel-x', title: 'Close (Esc)' }, icon('x'));
    close.addEventListener('click', () => { this.closePanel(); this.render(false); });
    const open = btn('Open', { size: 'sm', variant: 'primary', icon: 'external' });
    open.addEventListener('click', () => this.app.select(n.name));
    const cmp = n.parent && this.app.can('compare') ? btn('Compare', { size: 'sm', icon: 'compare', title: 'Compare with its origin (all settings, files, results)' }) : null;
    if (cmp) cmp.addEventListener('click', () => { this.app.select(n.name); this.app.detail.openCompare(n.parent.name); });
    const foc = btn(this.focus === n.name ? 'Show all' : 'Focus', { size: 'sm', icon: 'target', title: 'Only this simulation, where it came from and what was made from it' });
    foc.addEventListener('click', () => { const name = n.name; this.closePanel(); this.setFocus(this.focus === name ? null : name); });
    const variant = btn('New variant', { size: 'sm', icon: 'plus', title: 'Create a new simulation from this one (it becomes its origin)' });
    variant.addEventListener('click', () => this.app.openWizard(n.name));

    const parentLink = n.parent ? (() => { const a = h('a', null, splitName(n.parent.name).rest); a.addEventListener('click', () => this.select(n.parent.name)); return a; })() : null;
    let changes = null, parts = null;
    if (!n.parent) changes = h('div', { class: 'muted small' }, n.c.origin ? `Its origin ${n.c.origin} no longer exists.` : 'No origin - the start of a line.');
    else if (!this.data.changes) changes = h('div', { class: 'muted small' }, icon('lock'), ' The list of changes needs the Compare feature.');
    else if (s.settings === null) changes = h('div', { class: 'muted small' }, 'The settings could not be read.');
    else {
      const geo = s.geometry || [], set = s.settings || [];
      let group = null;
      parts = geo.length ? h('div', { class: 'ft-parts' }, geo.map((g) => this.partBlock(n, g))) : null;
      changes = h('div', null,
        set.length ? h('table', { class: 'ft-p-tbl' }, h('tbody', null, [...set].sort((x, y) => (x.group === 'Run control') - (y.group === 'Run control')).flatMap((r) => {
          const out = [];
          if (r.group !== group) { group = r.group; out.push(h('tr', null, h('td', { colspan: 2, class: 'ft-p-group' }, r.group))); }
          out.push(h('tr', null, h('td', null, r.label), h('td', null, h('div', { class: 'ft-new' }, r.b ?? '—'), h('div', { class: 'ft-old', title: 'before' }, r.a ?? '—'))));
          return out;
        }))) : (geo.length ? h('div', { class: 'muted small' }, 'Key settings unchanged.') : null),
        !geo.length && !set.length ? h('div', { class: 'muted small' }, 'Same key settings and geometry as its origin (only files outside the key settings may differ).') : null);
    }
    const notes = s.notes ? h('div', { class: 'md-notes ft-p-notes' }) : null;
    if (notes) notes.innerHTML = renderMarkdown(s.notes + (s.notes.length >= 800 ? ' …' : ''), { breaks: true });
    const st = n.c.queued && n.c.status !== 'running' ? 'queued' : n.c.status;
    mount(this.panel, close,
      h('div', { class: 'ft-p-name' }, nm.rest), h('div', { class: 'muted small' }, [nm.date, n.c.cells ? fmtCells(n.c.cells) + ' cells' : null].filter(Boolean).join(' · ')),
      h('div', { class: 'ft-p-stats' }, statusPill(st),
        n.drag != null ? h('span', { class: 'ft-p-drag' }, fmtForce(n.drag), h('small', null, ' N')) : null,
        n.delta != null ? h('span', { class: 'ft-delta ' + trend(n.delta), title: 'Drag compared with its origin' }, fmtPct(n.delta)) : null,
        (() => {
          // change over the whole line: against the first simulation of this line that has a drag
          let first = null;
          for (let p = n.parent; p; p = p.parent) if (p.drag != null) first = p;
          if (!first || first === n.parent || n.drag == null) return null;
          const d = pct(n.drag, first.drag);
          return h('span', { class: 'ft-p-line', title: `Drag compared with ${first.name}, the first simulation of this line with a result` },
            h('span', { class: 'ft-delta ' + trend(d) }, fmtPct(d)), ' since ' + splitName(first.name).rest);
        })(),
        h('span', { class: 'grow' })),
      h('div', { class: 'ft-p-actions' }, open, variant, cmp, foc),
      n.parent ? h('div', { class: 'ft-p-from' }, 'Changed against ', parentLink) : null,
      parts ? [h('div', { class: 'ft-p-sec' }, icon('cube'), 'Geometry'), parts] : null,
      n.parent && changes ? h('div', { class: 'ft-p-sec' }, icon('sliders'), 'Settings') : h('div', { class: 'ft-p-sec' }, 'Origin'),
      changes,
      n.s.warm_from ? h('div', { class: 'muted small', style: { marginTop: '8px' } }, icon('flame'), ' Warm start from ' + splitName(n.s.warm_from).rest) : null,
      notes ? [h('div', { class: 'ft-p-sec' }, icon('log'), 'Notes'), notes] : null);
    this.panel.scrollTop = 0;
  }

  // a changed part: pictures before / after from the same camera, on request a 3D comparison
  partBlock(n, g) {
    const before = { name: n.parent.name, stl: g.a || null }, after = { name: n.name, stl: g.b || null };
    const body = h('div', { class: 'ft-part-body' });
    const tgl = btn('3D', { size: 'sm', icon: 'cube', title: 'Both versions in one 3D view (drag to rotate)' });
    const label = (t) => { tgl.lastChild.textContent = t; };
    const pictures = () => {
      if (this.cmp3d && this.cmp3d.block === body) { this.cmp3d.destroy(); this.cmp3d = null; }
      label('3D');
      // before (grey) and after (orange) from the same camera, on top of each other in one picture
      const img = h('div', { class: 'ft-wipe-a' });
      const frame = h('div', { class: 'ft-wipe' }, img, h('div', { class: 'ft-wipe-wait' }, h('div', { class: 'spinner' })));
      let pics = null, mode = 'both';
      const chips = ['both', 'before', 'after'].map((k) => {
        const c = h('button', { class: 'ft-mode' + (k === mode ? ' on' : ''), type: 'button' },
          k === 'both' ? 'Overlay' : [h('i', { class: 'ft-sw ' + (k === 'before' ? 'b' : 'a') }), k]);
        c.addEventListener('click', () => { mode = k; show(); });
        return c;
      });
      const show = () => {
        chips.forEach((c, i) => c.classList.toggle('on', ['both', 'before', 'after'][i] === mode));
        if (!pics) return;
        const src = pics[mode] || (mode === 'both' ? (pics.after || pics.before) : null);
        if (src) mount(img, h('img', { src, alt: mode, draggable: 'false' }));
        else mount(img, h('span', { class: 'ft-wipe-none' }, mode === 'before' ? 'not in its origin' : 'not in this simulation'));
      };
      mount(body, frame, h('div', { class: 'ft-wipe-cap' }, ...chips));
      this.mirrorOf(n.name).then((mirror) => partPictures(before, after, mirror)).then((r) => {
        frame.querySelector('.ft-wipe-wait').remove();
        pics = r; show();
      }).catch((e) => mount(body, h('div', { class: 'muted small' }, 'Pictures not possible: ' + e.message)));
    };
    const view3d = async () => {
      if (this.cmp3d) { const old = this.cmp3d; this.cmp3d = null; old.destroy(); if (old.back) old.back(); }
      label('Pictures');
      const stage = h('div', { class: 'ft-3d' });
      const seg = segmented([{ label: 'Overlay', value: 'overlay' }, { label: 'Before', value: 'before' }, { label: 'After', value: 'after' }], 'overlay',
        (v) => { if (this.cmp3d) this.cmp3d.show(v); });
      mount(body, stage, h('div', { class: 'ft-3d-bar' }, seg,
        h('span', { class: 'muted small' }, h('i', { class: 'ft-sw b' }), 'before ', h('i', { class: 'ft-sw a' }), 'after')));
      const mirror = await this.mirrorOf(n.name);
      if (!stage.isConnected) return;
      this.cmp3d = new PartCompare3D(stage, before, after, mirror);
      this.cmp3d.block = body;
      this.cmp3d.back = pictures;
    };
    tgl.addEventListener('click', () => (this.cmp3d && this.cmp3d.block === body ? pictures() : view3d()));
    pictures();
    return h('div', { class: 'ft-part' },
      h('div', { class: 'ft-part-head' }, h('b', null, partName(g.name)), h('span', { class: 'geo-badge' }, g.state), h('span', { class: 'grow' }), tgl),
      body);
  }

  // symmetry plane of a simulation (for the part pictures), asked once
  mirrorOf(name) {
    this.mirrors = this.mirrors || new Map();
    if (!this.mirrors.has(name)) this.mirrors.set(name, api.get('geometry/info', { name }).then((r) => r.mirror).catch(() => null));
    return this.mirrors.get(name);
  }

  // ------------------------------------------------------------------ pan / zoom
  apply() {
    this.world.style.transform = `translate(${this.t.x}px, ${this.t.y}px) scale(${this.t.s})`;
    this.drawMini();
    // the view is remembered (whole tree and every focus on its own)
    clearTimeout(this._viewT);
    this._viewT = setTimeout(() => store('tree-view:' + (this.focus || '*'), this.t), 400);
  }

  // ------------------------------------------------------------------ overview map
  drawMini() {
    if (!this.placed || !this.size) return;
    const r = this.canvas.getBoundingClientRect();
    const [w, hh] = this.size;
    // only worth it when the tree does not fit on the screen
    const fits = w * this.t.s <= r.width + 4 && hh * this.t.s <= r.height + 4;
    this.mini.classList.toggle('hidden', fits);
    if (fits) return;
    const MW = 200, sc = Math.min(MW / w, 140 / hh), mw = Math.round(w * sc) + 12, mh = Math.round(hh * sc) + 12;
    const dpr = window.devicePixelRatio || 1;
    if (this.mini.width !== mw * dpr || this.mini.height !== mh * dpr) {
      this.mini.width = mw * dpr; this.mini.height = mh * dpr;
      this.mini.style.width = mw + 'px'; this.mini.style.height = mh + 'px';
    }
    this.miniMap = { sc, off: 6 };
    const ctx = this.mini.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, mw, mh);
    const css = getComputedStyle(this.canvas);
    const col = (v, d) => css.getPropertyValue(v).trim() || d;
    const base = col('--border-strong', '#3a3a42'), acc = col('--accent', '#ff7a1a');
    for (const n of this.placed) {
      ctx.fillStyle = n.name === this.selected ? acc : this.m.bests.has(n) ? '#f2c14e'
        : n.delta == null || Math.abs(n.delta) < NEUTRAL ? base : n.delta < 0 ? col('--ok', '#4ade80') : col('--st-error', '#ff6b6b');
      ctx.fillRect(6 + n.x * sc, 6 + n.y * sc, Math.max(2, W * sc), Math.max(2, H * sc));
    }
    // the visible part
    ctx.strokeStyle = col('--text', '#ededf1');
    ctx.lineWidth = 1.5;
    ctx.strokeRect(6 + (-this.t.x / this.t.s) * sc, 6 + (-this.t.y / this.t.s) * sc, (r.width / this.t.s) * sc, (r.height / this.t.s) * sc);
  }

  bindMini() {
    const go = (e) => {
      const b = this.mini.getBoundingClientRect(), r = this.canvas.getBoundingClientRect(), m = this.miniMap;
      if (!m) return;
      const wx = (e.clientX - b.left - m.off) / m.sc, wy = (e.clientY - b.top - m.off) / m.sc;
      this.t.x = r.width / 2 - wx * this.t.s;
      this.t.y = r.height / 2 - wy * this.t.s;
      this.apply();
    };
    let down = false;
    this.mini.addEventListener('pointerdown', (e) => { down = true; this.mini.setPointerCapture(e.pointerId); go(e); e.stopPropagation(); });
    this.mini.addEventListener('pointermove', (e) => { if (down) go(e); });
    this.mini.addEventListener('pointerup', () => { down = false; });
    this.mini.addEventListener('wheel', (e) => e.stopPropagation());
  }

  // first view: the whole tree if it fits readably, else the top (the most recent work) at a readable size
  // focus: the focused simulation in the upper left third, its variants to the right and below
  home() {
    const saved = store('tree-view:' + (this.focus || '*'));
    if (saved && isFinite(saved.x) && isFinite(saved.y) && saved.s > 0) { this.t = { x: saved.x, y: saved.y, s: saved.s }; return; }
    const [w, hh] = this.size, r = this.canvas.getBoundingClientRect();
    const s = Math.min(1, (r.width - 48) / w, (r.height - 48) / hh);
    const f = this.focus && this.placed.find((n) => n.name === this.focus);
    if (s >= 0.55) this.fit();
    else if (f) {
      const sc = 0.8;
      this.t = { s: sc, x: Math.min(24, r.width * 0.3 - f.x * sc), y: Math.min(20, r.height * 0.18 - f.y * sc) };
    } else this.t = { x: 24, y: 20, s: Math.max(0.55, Math.min(0.9, (r.width - 48) / w)) };
  }

  fit() {
    const [w, hh] = this.size, r = this.canvas.getBoundingClientRect();
    const s = Math.max(0.12, Math.min(1, (r.width - 48) / w, (r.height - 48) / hh));
    this.t = { s, x: (r.width - w * s) / 2, y: Math.max(20, (r.height - hh * s) / 2) };
  }

  center(n) {
    const r = this.canvas.getBoundingClientRect();
    const free = r.width - (this.selected ? SIDE_W + 20 : 0);
    this.t.x = free / 2 - (n.x + W / 2) * this.t.s;
    this.t.y = r.height / 2 - (n.y + H / 2) * this.t.s;
    this.apply();
  }

  zoomAt(f, cx, cy) {
    const r = this.canvas.getBoundingClientRect();
    if (cx == null) { cx = r.width / 2; cy = r.height / 2; }
    const s = Math.max(0.12, Math.min(1.6, this.t.s * f));
    this.t.x = cx - (cx - this.t.x) * s / this.t.s;
    this.t.y = cy - (cy - this.t.y) * s / this.t.s;
    this.t.s = s;
    this.apply();
  }

  bindCanvas() {
    let drag = null;
    this.canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.ft-side, .ft-toggle, .ft-mini')) return;
      drag = { x: e.clientX, y: e.clientY, tx: this.t.x, ty: this.t.y, id: e.pointerId };
      this.moved = false;
    });
    this.canvas.addEventListener('pointermove', (e) => {
      // Space held: the view follows the pointer, no button needed (free in every direction)
      if (this.spacePan && !drag) { this.t.x += e.movementX; this.t.y += e.movementY; this.apply(); return; }
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!this.moved && Math.hypot(dx, dy) < 4) return;
      if (!this.moved) { this.moved = true; this.canvas.setPointerCapture(drag.id); this.canvas.classList.add('panning'); }
      this.t.x = drag.tx + dx; this.t.y = drag.ty + dy;
      this.apply();
    });
    const end = () => { drag = null; this.canvas.classList.remove('panning'); setTimeout(() => { this.moved = false; }, 0); };
    // a click on the empty canvas closes the details
    this.canvas.addEventListener('pointerup', (e) => {
      if (drag && !this.moved && this.selected && !e.target.closest('.ft-node, .ft-side, .ft-toggle, .ft-mini')) { this.closePanel(); this.render(false); }
      end();
    });
    this.canvas.addEventListener('pointercancel', end);
    this.canvas.addEventListener('wheel', (e) => {
      if (e.target.closest('.ft-side')) return;
      e.preventDefault();
      if (e.ctrlKey) {
        const r = this.canvas.getBoundingClientRect();
        this.zoomAt(Math.exp(-e.deltaY * 0.0015), e.clientX - r.left, e.clientY - r.top);
      } else {
        this.t.x -= e.shiftKey ? e.deltaY : e.deltaX;
        this.t.y -= e.shiftKey ? 0 : e.deltaY;
        this.apply();
      }
    }, { passive: false });
  }
}

const STATUS_TEXT = { fresh: 'not run yet', meshed: 'meshed', queued: 'queued', running: 'running...', error: 'failed', stopped: 'stopped', finished: 'no forces' };
