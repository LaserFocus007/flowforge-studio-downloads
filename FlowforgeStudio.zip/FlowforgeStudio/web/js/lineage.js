// Family tree of all simulations (dashboard → Family tree).
//
// Every simulation is a card next to the one it was made from (generations from left to right,
// the most recent work on top). A card shows what changed against its origin - geometry parts
// and key settings - and how the drag moved: the line to it is green when the drag went down,
// red when it went up. "Focus" shows only the ancestors and descendants of one simulation; a
// click opens the full list of changes, the notes and Open / Compare.
// Data: /api/lineage (app/lineage.py, cached on the file times) and the case list of the app.

import * as api from './api.js';
import { h, mount, clear, icon, btn, store, splitName, fmtForce, fmtCells, statusPill, renderMarkdown, toastError } from './ui.js';

const W = 276, H = 94, GAP_X = 70, GAP_Y = 12, GAP_ROOT = 28;
const NEUTRAL = 0.05;                // drag change in % shown as "no change"
const MAX_CHIPS = 2;

const pct = (v, ref) => (v != null && ref ? (v - ref) / Math.abs(ref) * 100 : null);
const trend = (p) => (p == null ? 'none' : Math.abs(p) < NEUTRAL ? 'flat' : p < 0 ? 'down' : 'up');
const fmtPct = (p) => (p > 0 ? '+' : p < 0 ? '−' : '±') + Math.abs(p).toFixed(2) + ' %';
const partName = (f) => f.replace(/\.stl$/i, '').replace(/_/g, ' ');

// shortened in the middle: variants differ at the end of their names (mesh_130 / mesh_140)
function midName(name, cls) {
  const tail = name.length > 16 ? name.slice(-11) : '';
  return h('div', { class: cls }, h('span', { class: 'ft-head' }, tail ? name.slice(0, -11) : name), tail ? h('span', { class: 'ft-tail' }, tail) : null);
}

export class LineageView {
  constructor(app) {
    this.app = app;
    this.focus = store('tree-focus') || null;
    this.collapsed = new Set(store('tree-collapsed') || []);
    this.selected = null;
    this.query = '';
    this.t = { x: 24, y: 20, s: 0.9 };
    this.canvas = h('div', { class: 'ft-canvas' });
    this.world = h('div', { class: 'ft-world' });
    this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.svg.setAttribute('class', 'ft-edges');
    this.world.append(this.svg);
    this.panel = h('div', { class: 'ft-panel hidden' });
    this.bar = h('div', { class: 'ft-bar' });
    this.canvas.append(this.world, this.panel,
      h('div', { class: 'ft-hint' }, 'Drag: move  ·  Wheel: scroll  ·  Ctrl + wheel: zoom  ·  Click: details'),
      this.msg = h('div', { class: 'ft-msg' }, h('div', { class: 'spinner' }), 'Reading the settings of all simulations (the first time takes a while)...'));
    this.el = h('div', { class: 'ft' }, this.bar, this.canvas);
    this.bindCanvas();
    this.renderBar();
    this._resize = () => { if (!this.el.isConnected) { window.removeEventListener('resize', this._resize); return; } this.fitHeight(); };
    window.addEventListener('resize', this._resize);
    requestAnimationFrame(() => this.fitHeight());
    this.load();
  }

  // the canvas fills the window below the toolbar
  fitHeight() {
    if (!this.el.isConnected) return;
    const top = this.canvas.getBoundingClientRect().top + (document.getElementById('content') || document.body).scrollTop;
    this.canvas.style.height = Math.max(460, window.innerHeight - Math.min(top, 260) - 20) + 'px';
  }

  // ------------------------------------------------------------------ data
  async load() {
    try { this.data = await api.get('lineage'); } catch (e) { mount(this.msg, icon('alert'), 'Could not read the simulations: ' + e.message); return; }
    this.dataSig = this.structSig();
    this.msg.remove();
    this.fitHeight();
    this.render(true);
  }

  // names + origins: a change needs the lineage data again; status / drag only a redraw
  structSig() { return this.app.cases.map((c) => c.name + '<' + (c.origin || '')).join('|'); }
  liveSig() { return this.app.cases.map((c) => [c.name, c.status, c.queued, c.results && c.results.drag].join(':')).join('|'); }

  // called on every refresh of the case list (every few seconds)
  update() {
    if (!this.data) return;
    if (this.structSig() !== this.dataSig) { this.load(); return; }
    const sig = this.liveSig();
    if (sig !== this.lastLive) this.render(false);
  }

  // nodes with parent / children, drag change against the parent
  model() {
    const byName = new Map(this.app.cases.map((c) => [c.name, c]));
    const info = new Map((this.data.sims || []).map((s) => [s.name, s]));
    const nodes = new Map();
    for (const c of this.app.cases) {
      const s = info.get(c.name) || {};
      nodes.set(c.name, { name: c.name, c, s, parent: null, kids: [], drag: c.results && c.results.drag != null ? c.results.drag : null });
    }
    for (const n of nodes.values()) {
      const o = n.c.origin;
      if (o && o !== n.name && nodes.has(o)) { n.parent = nodes.get(o); n.parent.kids.push(n); }
    }
    // break cycles (origin set by hand in a loop): such a node becomes a root
    for (const n of nodes.values()) {
      const seen = new Set([n]);
      for (let p = n.parent; p; p = p.parent) {
        if (seen.has(p)) { n.parent.kids = n.parent.kids.filter((k) => k !== n); n.parent = null; break; }
        seen.add(p);
      }
    }
    const created = (n) => n.c.created || 0;
    const latest = (n) => (n._latest != null ? n._latest : (n._latest = Math.max(created(n), ...n.kids.map(latest))));
    for (const n of nodes.values()) {
      n.kids.sort((a, b) => latest(b) - latest(a));
      n.delta = n.parent ? pct(n.drag, n.parent.drag) : null;
    }
    const roots = [...nodes.values()].filter((n) => !n.parent).sort((a, b) => latest(b) - latest(a));
    const withDrag = [...nodes.values()].filter((n) => n.drag != null);
    const best = withDrag.length ? withDrag.reduce((a, b) => (b.drag < a.drag ? b : a)) : null;
    return { nodes, roots, best, byName };
  }

  // ------------------------------------------------------------------ layout
  // from left to right: a parent on the row of its first (most recent) child, so a line of
  // development reads along one row; the other variants are stacked below it
  layout(m) {
    let visible = null;
    if (this.focus && m.nodes.has(this.focus)) {
      visible = new Set();
      const f = m.nodes.get(this.focus);
      for (let p = f; p; p = p.parent) visible.add(p);
      const down = (n) => { visible.add(n); n.kids.forEach(down); };
      down(f);
    } else this.focus = null;
    const show = (n) => !visible || visible.has(n);
    let y = 0;
    const place = (n, depth) => {
      n.x = depth * (W + GAP_X);
      n.y = y;
      const kids = this.collapsed.has(n.name) ? [] : n.kids.filter(show);
      if (!kids.length) { y += H + GAP_Y; return; }
      kids.forEach((k) => place(k, depth + 1));
    };
    const roots = visible ? m.roots.filter(show) : m.roots;
    roots.forEach((r) => { place(r, 0); y += GAP_ROOT; });
    const placed = [];
    const walk = (n) => { placed.push(n); if (!this.collapsed.has(n.name)) n.kids.filter(show).forEach(walk); };
    roots.forEach(walk);
    return placed;
  }

  // ------------------------------------------------------------------ drawing
  render(fit) {
    this.lastLive = this.liveSig();
    const m = this.model();
    this.m = m;
    const placed = this.layout(m);
    this.placed = placed;
    const q = this.query.trim().toLowerCase();
    const match = (n) => !q || n.name.toLowerCase().includes(q) || (n.s.notes || '').toLowerCase().includes(q);
    const chain = new Set();
    if (this.selected && m.nodes.has(this.selected)) for (let p = m.nodes.get(this.selected); p; p = p.parent) chain.add(p.name);

    // edges
    const maxX = Math.max(0, ...placed.map((n) => n.x)) + W, maxY = Math.max(0, ...placed.map((n) => n.y)) + H;
    this.size = [maxX, maxY];
    this.svg.setAttribute('width', maxX + 20);
    this.svg.setAttribute('height', maxY + 20);
    clear(this.svg);
    const ns = 'http://www.w3.org/2000/svg';
    const shown = new Set(placed);
    // drawing order: neutral trunks, the coloured ends, the highlighted line of the selection on top
    const layer = () => { const g = document.createElementNS(ns, 'g'); this.svg.appendChild(g); return g; };
    const gTrunk = layer(), gEnd = layer(), gChain = layer();
    for (const n of placed) {
      if (!n.parent || !shown.has(n.parent)) continue;
      // shared trunk just right of the parent, rounded corner into each variant
      const x0 = n.parent.x + W, y0 = n.parent.y + H / 2, x1 = n.x, y1 = n.y + H / 2, mx = x0 + 26, R = 12;
      const straight = y1 - y0 < 2 * R;
      const cls = (chain.has(n.name) ? ' chain' : '') + (q && !match(n) ? ' dim' : '');
      // the trunk is shared by all variants (neutral), the last bend into a variant shows its drag change
      const trunk = document.createElementNS(ns, 'path');
      trunk.setAttribute('d', straight ? `M${x0},${y0} H${mx}` : `M${x0},${y0} H${mx - R} Q${mx},${y0} ${mx},${y0 + R} V${y1 - R}`);
      trunk.setAttribute('class', 'ft-edge trunk' + cls);
      const end = document.createElementNS(ns, 'path');
      end.setAttribute('d', straight ? `M${mx},${y1} H${x1}` : `M${mx},${y1 - R} Q${mx},${y1} ${mx + R},${y1} H${x1}`);
      end.setAttribute('class', 'ft-edge ' + trend(n.delta) + cls);
      (chain.has(n.name) ? gChain : gTrunk).appendChild(trunk);
      (chain.has(n.name) ? gChain : gEnd).appendChild(end);
    }
    // nodes
    for (const el of [...this.world.querySelectorAll('.ft-node')]) el.remove();
    for (const n of placed) this.world.appendChild(this.nodeEl(n, { dim: q && !match(n), chain: chain.has(n.name) }));
    this.matches = q ? placed.filter(match) : [];
    this.renderBar();
    if (fit) this.home();
    this.apply();
    if (this.selected) this.renderPanel();
  }

  nodeEl(n, { dim, chain }) {
    const c = n.c, s = n.s;
    const nm = splitName(n.name);
    const st = c.queued && c.status !== 'running' ? 'queued' : c.status;
    const geo = s.geometry || [], set = s.settings || [];
    const chips = [];
    for (const g of geo) chips.push(h('span', { class: 'ft-chip geo', title: `${partName(g.name)} ${g.state}` }, icon('cube'), partName(g.name)));
    // run control (end time, cores, write interval) says least about the design: last on the card
    const minor = (r) => (r.group === 'Run control' ? 1 : 0);
    for (const r of [...set].sort((a, b) => minor(a) - minor(b))) chips.push(h('span', { class: 'ft-chip', title: `${r.group}: ${r.label}\n${r.a ?? '—'}  →  ${r.b ?? '—'}` }, h('span', { class: 'k' }, r.label), h('b', null, r.b ?? '—')));
    let row;
    if (!n.parent) row = h('span', { class: 'ft-chip muted' }, n.c.origin ? 'origin deleted' : 'start of a line');
    else if (!this.data.changes) row = h('span', { class: 'ft-chip muted', title: 'Showing the changes needs the Compare feature' }, icon('lock'), 'changes');
    else if (s.settings === null) row = h('span', { class: 'ft-chip muted' }, 'settings not readable');
    else if (!chips.length) row = h('span', { class: 'ft-chip muted' }, 'same settings & geometry');
    const more = chips.length - MAX_CHIPS;
    const hiddenKids = this.collapsed.has(n.name) ? this.countDesc(n) : 0;
    const el = h('div', { class: `ft-node st-${st}` + (n.name === this.selected ? ' sel' : '') + (chain ? ' chain' : '') + (dim ? ' dim' : '')
        + (n === this.m.best ? ' best' : '') + (n.name === this.focus ? ' focus' : ''),
      style: { left: n.x + 'px', top: n.y + 'px', width: W + 'px', height: H + 'px' }, title: n.name },
    h('div', { class: 'ft-top' }, h('span', { class: 'ft-dot' }), midName(nm.rest, 'ft-name'),
      n === this.m.best ? h('span', { class: 'ft-best', title: 'Lowest drag of all simulations' }, icon('trophy')) : null,
      h('span', { class: 'ft-date' }, nm.date ? nm.date.slice(2) : '')),
    h('div', { class: 'ft-mid' },
      n.drag != null ? h('span', { class: 'ft-drag' }, fmtForce(n.drag), h('small', null, ' N')) : h('span', { class: 'ft-drag none' }, STATUS_TEXT[st] || st),
      n.delta != null ? h('span', { class: 'ft-delta ' + trend(n.delta), title: 'Drag compared with its origin' }, fmtPct(n.delta)) : null,
      h('span', { class: 'grow' }),
      c.cells ? h('span', { class: 'ft-cells' }, fmtCells(c.cells)) : null),
    h('div', { class: 'ft-chips' }, row || [chips.slice(0, MAX_CHIPS), more > 0 ? h('span', { class: 'ft-chip more' }, '+' + more) : null]));
    if (n.kids.length) {
      const tog = h('button', { type: 'button', class: 'ft-toggle' + (hiddenKids ? ' closed' : ''), title: hiddenKids ? `Show ${hiddenKids} hidden` : 'Fold this branch' },
        hiddenKids ? '+' + hiddenKids : '−');
      tog.addEventListener('pointerdown', (e) => e.stopPropagation());
      tog.addEventListener('click', (e) => {
        e.stopPropagation();
        if (this.collapsed.has(n.name)) this.collapsed.delete(n.name); else this.collapsed.add(n.name);
        store('tree-collapsed', [...this.collapsed]);
        this.render(false);
      });
      el.appendChild(tog);
    }
    el.addEventListener('click', () => { if (!this.moved) this.select(n.name); });
    el.addEventListener('dblclick', () => this.app.select(n.name));
    return el;
  }

  countDesc(n) { return n.kids.reduce((a, k) => a + 1 + this.countDesc(k), 0); }

  // ------------------------------------------------------------------ toolbar
  renderBar() {
    if (!this.search) {
      this.search = h('input', { class: 'input ft-search', type: 'search', placeholder: 'Find simulation or note...' });
      this.search.addEventListener('input', () => { this.query = this.search.value; this.matchIdx = -1; this.render(false); });
      this.search.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.nextMatch(); } });
    }
    const fit = btn('Fit', { size: 'sm', icon: 'fit', title: 'Show the whole tree' });
    fit.addEventListener('click', () => { this.fit(); this.apply(); });
    const zin = btn('', { size: 'sm', icon: 'plus', title: 'Zoom in' });
    zin.addEventListener('click', () => this.zoomAt(1.2));
    const zout = btn('', { size: 'sm', icon: 'minus', title: 'Zoom out' });
    zout.addEventListener('click', () => this.zoomAt(1 / 1.2));
    let focus = null;
    if (this.focus) {
      const x = h('button', { type: 'button', class: 'ft-focus-x', title: 'Show all simulations' }, icon('x'));
      x.addEventListener('click', () => this.setFocus(null));
      focus = h('span', { class: 'ft-focus' }, icon('target'), 'Line of ', h('b', null, splitName(this.focus).rest), x);
    }
    const fold = this.collapsed.size ? (() => {
      const b = btn('Unfold all', { size: 'sm', variant: 'ghost' });
      b.addEventListener('click', () => { this.collapsed.clear(); store('tree-collapsed', []); this.render(false); });
      return b;
    })() : null;
    const q = this.query.trim();
    mount(this.bar, this.search,
      q ? h('span', { class: 'muted small' }, `${(this.matches || []).length} found` + ((this.matches || []).length ? ' · Enter: next' : '')) : null,
      focus, h('span', { class: 'grow' }),
      h('span', { class: 'ft-legend' }, h('i', { class: 'down' }), 'less drag than its origin', h('i', { class: 'up' }), 'more drag', h('i', { class: 'flat' }), 'no change / no result'),
      fold, h('div', { class: 'btn-group' }, zout, zin), fit);
  }

  nextMatch() {
    if (!this.matches || !this.matches.length) return;
    this.matchIdx = ((this.matchIdx ?? -1) + 1) % this.matches.length;
    const n = this.matches[this.matchIdx];
    this.select(n.name);
    this.center(n);
  }

  setFocus(name) {
    this.focus = name;
    store('tree-focus', name);
    this.render(true);
  }

  // ------------------------------------------------------------------ details
  select(name) {
    this.selected = name;
    for (const el of this.world.querySelectorAll('.ft-node.sel')) el.classList.remove('sel');
    this.render(false);
  }

  renderPanel() {
    const n = this.m && this.m.nodes.get(this.selected);
    if (!n) { this.panel.classList.add('hidden'); return; }
    this.panel.classList.remove('hidden');
    const s = n.s, nm = splitName(n.name);
    const close = h('button', { type: 'button', class: 'ft-panel-x', title: 'Close' }, icon('x'));
    close.addEventListener('click', () => { this.selected = null; this.render(false); });
    const open = btn('Open', { size: 'sm', variant: 'primary', icon: 'external' });
    open.addEventListener('click', () => this.app.select(n.name));
    const cmp = n.parent && this.app.can('compare') ? btn('Compare with origin', { size: 'sm', icon: 'compare' }) : null;
    if (cmp) cmp.addEventListener('click', () => { this.app.select(n.name); this.app.detail.openCompare(n.parent.name); });
    const foc = btn(this.focus === n.name ? 'Show all' : 'Focus', { size: 'sm', icon: 'target', title: 'Only this simulation, where it came from and what was made from it' });
    foc.addEventListener('click', () => this.setFocus(this.focus === n.name ? null : n.name));

    const parentLink = n.parent ? (() => { const a = h('a', null, splitName(n.parent.name).rest); a.addEventListener('click', () => { this.select(n.parent.name); this.center(n.parent); }); return a; })() : null;
    let changes;
    if (!n.parent) changes = h('div', { class: 'muted small' }, n.c.origin ? `Its origin ${n.c.origin} no longer exists.` : 'No origin - the start of a line.');
    else if (!this.data.changes) changes = h('div', { class: 'muted small' }, icon('lock'), ' The list of changes needs the Compare feature.');
    else if (s.settings === null) changes = h('div', { class: 'muted small' }, 'The settings could not be read.');
    else {
      const geo = s.geometry || [], set = s.settings || [];
      let group = null;
      changes = h('div', null,
        geo.length ? h('div', { class: 'ft-p-geo' }, geo.map((g) => h('span', { class: 'ft-chip geo' }, icon('cube'), partName(g.name), h('small', null, ' ' + g.state)))) : null,
        set.length ? h('table', { class: 'ft-p-tbl' }, h('tbody', null, [...set].sort((x, y) => (x.group === 'Run control') - (y.group === 'Run control')).flatMap((r) => {
          const out = [];
          if (r.group !== group) { group = r.group; out.push(h('tr', null, h('td', { colspan: 2, class: 'ft-p-group' }, r.group))); }
          out.push(h('tr', null, h('td', null, r.label), h('td', null, h('div', { class: 'ft-new' }, r.b ?? '—'), h('div', { class: 'ft-old', title: 'before' }, r.a ?? '—'))));
          return out;
        }))) : null,
        !geo.length && !set.length ? h('div', { class: 'muted small' }, 'Same key settings and geometry as its origin (only files outside the key settings may differ).') : null);
    }
    const notes = s.notes ? h('div', { class: 'md-notes ft-p-notes' }) : null;
    if (notes) notes.innerHTML = renderMarkdown(s.notes + (s.notes.length >= 800 ? ' …' : ''), { breaks: true });
    const st = n.c.queued && n.c.status !== 'running' ? 'queued' : n.c.status;
    mount(this.panel, close,
      h('div', { class: 'ft-p-name' }, nm.rest), h('div', { class: 'muted small' }, [nm.date, n.c.cells ? fmtCells(n.c.cells) + ' cells' : null].filter(Boolean).join(' · ')),
      h('div', { class: 'ft-p-stats' }, statusPill(st),
        n.drag != null ? h('span', { class: 'ft-p-drag' }, fmtForce(n.drag), h('small', null, ' N')) : null,
        n.delta != null ? h('span', { class: 'ft-delta ' + trend(n.delta) }, fmtPct(n.delta)) : null),
      h('div', { class: 'row wrap', style: { gap: '6px', margin: '10px 0 4px' } }, open, cmp, foc),
      h('div', { class: 'ft-p-sec' }, n.parent ? ['Changed against ', parentLink] : 'Origin'), changes,
      n.s.warm_from ? h('div', { class: 'muted small', style: { marginTop: '8px' } }, icon('flame'), ' Warm start from ' + splitName(n.s.warm_from).rest) : null,
      n.kids.length ? [h('div', { class: 'ft-p-sec' }, `${n.kids.length} variant${n.kids.length === 1 ? '' : 's'} made from it`),
        h('div', { class: 'ft-p-kids' }, n.kids.map((k) => {
          const a = h('div', { class: 'ft-p-kid' }, h('span', { class: 'ft-dot st-' + k.c.status }), midName(splitName(k.name).rest, 'ft-name'),
            k.delta != null ? h('span', { class: 'ft-delta ' + trend(k.delta) }, fmtPct(k.delta)) : null);
          a.addEventListener('click', () => { this.select(k.name); this.center(k); });
          return a;
        }))] : null,
      notes ? [h('div', { class: 'ft-p-sec' }, 'Notes'), notes] : null);
  }

  // ------------------------------------------------------------------ pan / zoom
  apply() { this.world.style.transform = `translate(${this.t.x}px, ${this.t.y}px) scale(${this.t.s})`; }

  // first view: the whole tree if it fits readably, else the top (the most recent work) at a readable size
  // focus: the focused simulation in the upper left third, its variants to the right and below
  home() {
    const [w, hh] = this.size, r = this.canvas.getBoundingClientRect();
    const s = Math.min(1, (r.width - 48) / w, (r.height - 48) / hh);
    const f = this.focus && this.placed.find((n) => n.name === this.focus);
    if (s >= 0.55) this.fit();
    else if (f) {
      const sc = 0.8;
      this.t = { s: sc, x: Math.min(24, r.width * 0.3 - f.x * sc), y: Math.min(20, r.height * 0.18 - f.y * sc) };
    } else this.t = { x: 24, y: 20, s: Math.max(0.55, Math.min(0.9, (r.width - 48) / w)) };
  }

  fit() {
    const [w, hh] = this.size, r = this.canvas.getBoundingClientRect();
    const s = Math.max(0.12, Math.min(1, (r.width - 48) / w, (r.height - 48) / hh));
    this.t = { s, x: (r.width - w * s) / 2, y: Math.max(20, (r.height - hh * s) / 2) };
  }

  center(n) {
    const r = this.canvas.getBoundingClientRect();
    this.t.x = r.width / 2 - (n.x + W / 2) * this.t.s - (this.selected ? 180 : 0);
    this.t.y = r.height / 2 - (n.y + H / 2) * this.t.s;
    this.apply();
  }

  zoomAt(f, cx, cy) {
    const r = this.canvas.getBoundingClientRect();
    if (cx == null) { cx = r.width / 2; cy = r.height / 2; }
    const s = Math.max(0.12, Math.min(1.6, this.t.s * f));
    this.t.x = cx - (cx - this.t.x) * s / this.t.s;
    this.t.y = cy - (cy - this.t.y) * s / this.t.s;
    this.t.s = s;
    this.apply();
  }

  bindCanvas() {
    let drag = null;
    this.canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.ft-panel, .ft-toggle')) return;
      drag = { x: e.clientX, y: e.clientY, tx: this.t.x, ty: this.t.y, id: e.pointerId };
      this.moved = false;
    });
    this.canvas.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!this.moved && Math.hypot(dx, dy) < 4) return;
      if (!this.moved) { this.moved = true; this.canvas.setPointerCapture(drag.id); this.canvas.classList.add('panning'); }
      this.t.x = drag.tx + dx; this.t.y = drag.ty + dy;
      this.apply();
    });
    const end = () => { drag = null; this.canvas.classList.remove('panning'); setTimeout(() => { this.moved = false; }, 0); };
    this.canvas.addEventListener('pointerup', end);
    this.canvas.addEventListener('pointercancel', end);
    this.canvas.addEventListener('wheel', (e) => {
      if (e.target.closest('.ft-panel')) return;
      e.preventDefault();
      if (e.ctrlKey) {
        const r = this.canvas.getBoundingClientRect();
        this.zoomAt(Math.exp(-e.deltaY * 0.0015), e.clientX - r.left, e.clientY - r.top);
      } else {
        this.t.x -= e.shiftKey ? e.deltaY : e.deltaX;
        this.t.y -= e.shiftKey ? 0 : e.deltaY;
        this.apply();
      }
    }, { passive: false });
  }
}

const STATUS_TEXT = { fresh: 'not run yet', meshed: 'meshed', queued: 'queued', running: 'running...', error: 'failed', stopped: 'stopped', finished: 'no forces' };
