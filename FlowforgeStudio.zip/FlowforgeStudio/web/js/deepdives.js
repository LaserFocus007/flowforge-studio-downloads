// Top-bar "Tutorials": with the World licence the deep-dive tutorials 03 + 04 open in their own window
// (deepdives.html, js/ddviewer.js); other variants see what the tutorials contain and that they come with World.
import { h, icon, modal } from './ui.js';
import * as api from './api.js';

let win = null;

export async function openDeepdives() {
  let info = null;
  try { info = await api.get('deepdives'); } catch (e) { info = null; }
  if (info && info.installed && info.allowed) {
    if (win && !win.closed) { win.focus(); return; }
    const w = Math.min(1400, screen.availWidth - 40), ht = screen.availHeight - 40;
    win = window.open('deepdives.html', 'flowforge-deepdives', `popup=yes,width=${w},height=${ht},left=20,top=10`);
    if (win) return;
  }
  const body = h('div', { class: 'dd-note' });
  modal({ title: 'Deep-dive tutorials', body, size: 'medium' });
  if (info && info.installed && info.allowed) {
    body.append(icon('info', 'lg'), h('p', null, 'The tutorial window could not be opened. Please allow pop-up windows for Flowforge Studio and try again.'));
  } else if (!info || !info.installed) {
    body.append(icon('info', 'lg'), h('p', null, 'The deep-dive tutorials are not part of this installation. Download the current version of Flowforge Studio to get them.'));
  } else {
    body.append(icon('lock', 'lg'), h('h3', null, 'Included in the World licence'),
      h('p', null, 'Tutorial 03 explains every setting and how to tune a simulation, tutorial 04 the theory behind Flowforge Studio. Both come with the World licence; an upgrade costs only the difference in price.'),
      h('ul', null, ...info.docs.map((d) => h('li', null, `${d.title} · ${d.pages} pages`))));
  }
}
