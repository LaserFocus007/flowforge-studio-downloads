// Flowforge Studio - application shell: sidebar, dashboard, queue drawer, polling.

import * as api from './api.js';
import { applyAccent, h, mount, clear, icon, btn, toast, toastError, showMenu, confirmDialog, modal, fmtAgo, fmtDuration,
  fmtForce, fmtCells, fmtDate, splitName, STATUS, statusPill, store, debounce, convergence, relUnc, uncOf } from './ui.js';
import { DetailView } from './detail.js';
import { prewarmRequests } from './resultstab.js';
import { openWizard } from './wizard.js';
import { openAppSettings } from './appsettings.js';
import { DragProgress } from './dragprogress.js';
import { showActivation } from './activation.js';

export const app = {
  info: null,
  cases: [],
  runner: null,
  selected: null,
  search: '',
  // default: last activity first (new key, so an older stored choice does not override the new default)
  sort: store('sidebar-sort') || 'activity',
  selectMode: false,
  checked: new Set(),
  detail: null,
  queueOpen: false,
  prevStatus: new Map(),
  prevMesh: new Map(),

  meshReadyPopup(c) {
    if (store('mesh-popup') === false) return;
    const shown = store('mesh-popup-shown') || [];
    if (shown.includes(c.mesh_ready)) return;
    store('mesh-popup-shown', shown.concat([c.mesh_ready]).slice(-50));
    const never = h('input', { type: 'checkbox' });
    const later = btn('Later', { variant: 'ghost' });
    const view = btn('View mesh', { variant: 'primary', icon: 'grid' });
    const solving = c.status === 'running';
    const m = modal({
      title: 'Mesh ready',
      body: h('div', null,
        h('p', { style: { marginTop: 0 } }, h('b', null, c.name), ' has been meshed.',
          solving ? ' The solver continues in the background.' : ''),
        h('p', { class: 'muted' }, 'Have a look at the mesh before relying on the results - for example at the refinement around the car and the boundary layers on the symmetry plane.'),
        h('label', { class: 'check-row', style: { cursor: 'pointer' } }, never, h('span', null, "Don't show this again"))),
      footer: [later, view],
      onClose: () => { if (never.checked) store('mesh-popup', false); },
    });
    later.addEventListener('click', () => m.close());
    view.addEventListener('click', () => {
      m.close();
      if (this.selected !== c.name) this.select(c.name);
      setTimeout(() => this.detail && this.detail.showTab('mesh'), 60);
    });
  },
  // offer the installed-app mode (window buttons in our top bar) once at start until it is used or declined
  async installHint() {
    if (store('app-install-hint') === false) return;
    let st;
    try { st = await api.get('app/status'); } catch (e) { return; }
    if (!st || st.installed || !st.possible) return;
    const never = h('input', { type: 'checkbox' });
    const later = btn('Not now', { variant: 'ghost' });
    const go = btn('Install', { variant: 'primary', icon: 'external' });
    const m = modal({
      title: 'Install Flowforge Studio as an app?',
      body: h('div', null,
        h('p', { style: { marginTop: 0 } }, 'Without the browser title bar: minimise, maximise and close move into the Flowforge Studio top bar.'),
        h('p', { class: 'muted' }, 'A one-time click in Microsoft Edge. You can also do it later in the settings (gear icon).'),
        h('label', { class: 'check-row', style: { cursor: 'pointer' } }, never, h('span', null, "Don't ask again"))),
      footer: [later, go],
      onClose: () => { if (never.checked) store('app-install-hint', false); },
    });
    later.addEventListener('click', () => m.close());
    go.addEventListener('click', async () => {
      m.close();
      try {
        await api.post('app/install');
        toast('Almost done', 'Click "Install" in the Edge window that just opened.', 'info', 9000);
      } catch (e) { toastError(e, 'Could not open the installation'); }
    });
  },
  loaded: false,

  byName(name) { return this.cases.find((c) => c.name === name); },

  // what the licensed variant allows (app/license.py TIERS) and its colour
  can(feature) { const l = this.info && this.info.license; return !!(l && l.features && l.features[feature]); },
  accent() {
    const f = (this.info.license && this.info.license.features) || {};
    return (f.team_color && this.info.config.accent) || f.color || '';
  },

  async refresh() {
    try {
      const r = await api.get('cases');
      this.notifyTransitions(r.cases);
      this.cases = r.cases;
      this.runner = r.runner;
      this.loaded = true;
      renderSidebar();
      renderTopbar();
      if (!this.selected) renderHome();
      if (this.detail) this.detail.onCasesUpdated();
      if (this.queueOpen) renderQueue();
      setOffline(false);
    } catch (e) {
      if (e.status === 401) showFatal(e.message);
      else if (e.status === 0) setOffline(true);
    }
  },

  notifyTransitions(list) {
    for (const c of list) {
      const prevMesh = this.prevMesh.get(c.name);
      if (this.prevMesh.has(c.name) && c.mesh_ready && c.mesh_ready !== prevMesh) this.meshReadyPopup(c);
      this.prevMesh.set(c.name, c.mesh_ready || null);
      const prev = this.prevStatus.get(c.name);
      if (prev === 'running' && c.status !== 'running') {
        const ok = c.status === 'finished' || c.status === 'meshed' || c.status === 'stopped';
        const paused = ok && c.queued;   // paused runs are queued again right away
        const title = paused ? `${c.name}: Paused` : ok ? `${c.name}: ${STATUS[c.status].label}` : `${c.name} failed`;
        toast(title, paused ? 'Saved. It continues from there when you resume the queue.' : ok ? 'The run completed.' : (c.error || 'See the log for details.'), ok ? 'ok' : 'error', 9000);
        if ('Notification' in window && Notification.permission === 'granted' && document.hidden) {
          try { new Notification('Flowforge Studio', { body: title, icon: 'img/logo.svg' }); } catch (e) { /* ignore */ }
        }
      }
      this.prevStatus.set(c.name, c.status);
    }
  },

  select(name) {
    this.selected = name;
    store('selected', name);
    prewarm(name);
    if (this.detail) { this.detail.destroy(); this.detail = null; }
    const content = document.getElementById('content');
    clear(content);
    content.scrollTop = 0;
    if (name) this.detail = new DetailView(content, name, this);
    else renderHome();
    renderSidebar();
    renderTopbar();
  },

  async run(names, mode) {
    if (!names.length) return;
    try {
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
      let r = await api.post('run', { names, mode });
      if (r.needs_confirm) {
        const ok = await confirmDialog({ title: 'Please check', message: h('div', null, ...r.warnings.map((w) => h('p', null, w))),
          confirmLabel: 'Queue anyway' });
        if (!ok) return;
        r = await api.post('run', { names, mode, force: true });
      }
      if (r.added.length) toast(r.added.length === 1 ? 'Added to the queue' : `${r.added.length} simulations queued`,
        `${this.info.modes[mode]}: ${r.added.join(', ')}`, 'ok');
      if (r.waiting) toast('Daily limit reached', `${r.waiting} run${r.waiting > 1 ? 's' : ''} will wait in the queue and start automatically on the next day.`, 'warn', 9000);
      if (r.skipped.length) toast('Already queued or running', r.skipped.join(', '), 'warn');
      await this.refresh();
      if (this.detail) this.detail.reload();
    } catch (e) { toastError(e, 'Could not start'); }
  },

  openWizard(origin) {
    openWizard(this, origin || this.selected);
  },

  async reloadInfo() {
    this.info = await api.get('info');
    applyTheme(this.info.config.theme);
    applyAccent(this.accent());
  },
};

// ---------------------------------------------------------------- connection
let offline = false;
function setOffline(v) {
  if (v === offline) return;
  offline = v;
  let el = document.getElementById('offlineBanner');
  if (v && !el) {
    el = h('div', { id: 'offlineBanner', class: 'callout error', style: { position: 'fixed', left: '50%', top: '64px', transform: 'translateX(-50%)', zIndex: 150, boxShadow: 'var(--shadow)', background: 'var(--panel)' } },
      icon('alert', 'lg'), h('div', { class: 'callout-body' }, h('div', { class: 'callout-title' }, 'Connection to Flowforge Studio lost'),
        h('div', { class: 'muted small' }, 'Running simulations are not affected. Start "Flowforge Studio.bat" again to reconnect.')));
    document.body.appendChild(el);
  } else if (!v && el) el.remove();
}

// ---------------------------------------------------------------- theme
function applyTheme(t) {
  document.documentElement.dataset.theme = t === 'light' ? 'light' : 'dark';
  // colour of the window buttons area when running as installed app
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = t === 'light' ? '#fafafb' : '#111113';
  const b = document.getElementById('btnTheme');
  mount(b, icon(t === 'light' ? 'moon' : 'sun'));
}

// ---------------------------------------------------------------- sidebar
const side = { list: null, built: false };

const NAME_ORDER = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

function filteredCases() {
  const q = app.search.trim().toLowerCase();
  return sortCases(app.cases.filter((c) => !q || c.name.toLowerCase().includes(q) || (c.origin || '').toLowerCase().includes(q)));
}

// the sort orders of the sidebar and of the leaderboard (each has its own choice; "My order" is shared)
const SORTS = [
  ['name-desc', 'Newest first'], ['name-asc', 'Oldest first'], ['alpha', 'Name A–Z'], ['alpha-desc', 'Name Z–A'],
  ['activity', 'Last activity'], ['drag', 'Lowest drag'], ['custom', 'My order (drag & drop)'],
];

function sortMenuItems(current, pick) {
  return [{ label: 'Sort by', header: true },
    ...SORTS.filter(([v]) => v !== 'drag' || app.can('forces')).map(([v, label]) => ({ label, icon: current === v ? 'check' : null, onClick: () => pick(v) }))];
}

function sortCases(list, s = app.sort) {
  // own order (drag & drop); simulations that are not in it yet (new ones) come first, newest on top
  const own = s === 'custom' ? new Map((store('sidebar-order') || []).map((n, i) => [n, i])) : null;
  return list.slice().sort((a, b) => {
    if (own) {
      const ia = own.has(a.name) ? own.get(a.name) : -1, ib = own.has(b.name) ? own.get(b.name) : -1;
      return ia - ib || chronoKey(b).localeCompare(chronoKey(a));
    }
    // date in the folder name, then the real creation time (several simulations per day)
    if (s === 'name-asc') return chronoKey(a).localeCompare(chronoKey(b));
    if (s === 'activity') return (b.mtime || 0) - (a.mtime || 0);
    if (s === 'drag') return (a.results?.drag ?? Infinity) - (b.results?.drag ?? Infinity);
    // name as shown (without the date), natural order: param_9 before param_10; same name -> newest first
    if (s === 'alpha' || s === 'alpha-desc') {
      const d = NAME_ORDER.compare(splitName(a.name).rest, splitName(b.name).rest);
      return (s === 'alpha' ? d : -d) || chronoKey(b).localeCompare(chronoKey(a));
    }
    return chronoKey(b).localeCompare(chronoKey(a));
  });
}

// drop `name` before / after `target`: takes the order shown right now (sidebar or leaderboard)
// and switches that list to the own order
function moveCase(name, target, after, inBoard = false) {
  const all = sortCases(app.cases, inBoard ? homeSort : app.sort).map((c) => c.name).filter((n) => n !== name);
  const i = all.indexOf(target);
  if (i < 0) return;
  all.splice(i + (after ? 1 : 0), 0, name);
  store('sidebar-order', all);
  if (inBoard) {
    homeSort = 'custom'; store('home-sort-mode', 'custom');
    if (app.sort === 'custom') renderSidebar();
  } else setSort('custom');
  renderHome();   // the leaderboard can show "My order" too
}

function buildSidebar() {
  const sb = document.getElementById('sidebar');
  const search = h('input', { placeholder: 'Search simulations...', value: app.search });
  search.addEventListener('input', debounce(() => { app.search = search.value; renderSidebar(); }, 120));
  const count = h('span', { class: 'count' });
  const selBtn = btn('Select', { size: 'sm', variant: 'ghost', icon: 'check' });
  selBtn.addEventListener('click', () => {
    app.selectMode = !app.selectMode;
    if (!app.selectMode) app.checked.clear();
    renderSidebar();
  });
  const sortBtn = btn('', { size: 'sm', variant: 'ghost', icon: 'list', title: 'Sort' });
  sortBtn.addEventListener('click', () => showMenu(sortBtn, sortMenuItems(app.sort, setSort)));
  const refreshBtn = btn('', { size: 'sm', variant: 'ghost', icon: 'refresh', title: 'Refresh' });
  refreshBtn.addEventListener('click', () => app.refresh());
  const hideBtn = btn('', { size: 'sm', variant: 'ghost', icon: 'sidebar', title: 'Hide the simulation list (Ctrl+B)' });
  hideBtn.addEventListener('click', () => setSidebarHidden(true));
  // slim rail shown instead of the list while it is hidden
  const showBtn = btn('', { variant: 'ghost', icon: 'sidebar', title: 'Show the simulation list (Ctrl+B)' });
  showBtn.classList.add('btn-icon');
  showBtn.addEventListener('click', () => setSidebarHidden(false));
  side.rail = h('div', { class: 'side-rail' }, showBtn);
  side.list = h('div', { class: 'sim-list' });
  side.selbar = h('div', { class: 'selection-bar hidden' });
  side.count = count;
  side.selBtn = selBtn;
  mount(sb,
    h('div', { class: 'side-head' },
      h('div', { class: 'search' }, icon('search'), search),
      h('div', { class: 'side-tools' }, count, h('div', { class: 'row' }, refreshBtn, sortBtn, selBtn, hideBtn))),
    side.list, side.selbar, side.rail, sidebarResizer());
  side.built = true;
}

const SIDE_MIN = 240, SIDE_MAX = 640, SIDE_COLLAPSE = 170, SIDE_DEFAULT = 340;

function setSidebarWidth(w) {
  document.querySelector('.layout').style.setProperty('--side-w', Math.round(w) + 'px');
}

// drag the right edge of the list; dragging it very narrow folds it away
function sidebarResizer() {
  const handle = h('div', { class: 'side-resizer', title: 'Drag to resize - double-click for the default width' });
  const layout = () => document.querySelector('.layout');
  handle.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    handle.setPointerCapture(e.pointerId);
    const left = layout().getBoundingClientRect().left;
    let w = null;
    layout().classList.add('resizing');
    const move = (ev) => {
      w = ev.clientX - left;
      const fold = w < SIDE_COLLAPSE;
      layout().classList.toggle('side-hidden', fold);
      if (!fold) setSidebarWidth(Math.min(SIDE_MAX, Math.max(SIDE_MIN, w)));
    };
    const up = () => {
      handle.removeEventListener('pointermove', move);
      layout().classList.remove('resizing');
      if (w === null) return;
      if (w < SIDE_COLLAPSE) setSidebarHidden(true);
      else {
        store('sidebar-width', Math.min(SIDE_MAX, Math.max(SIDE_MIN, w)));
        window.dispatchEvent(new Event('resize'));
      }
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up, { once: true });
    handle.addEventListener('pointercancel', up, { once: true });
  });
  handle.addEventListener('dblclick', () => {
    store('sidebar-width', SIDE_DEFAULT);
    setSidebarWidth(SIDE_DEFAULT);
    window.dispatchEvent(new Event('resize'));
  });
  return handle;
}

function setSidebarHidden(hidden, initial) {
  const w = store('sidebar-width');
  setSidebarWidth(typeof w === 'number' && w >= SIDE_MIN ? Math.min(SIDE_MAX, w) : SIDE_DEFAULT);
  document.querySelector('.layout').classList.toggle('side-hidden', hidden);
  if (initial) return;
  window.dispatchEvent(new Event('resize'));   // charts / 3D views take the new width
}

// a simulation with results that stays open for a moment: the server prepares its Results tab
let prewarmT = null;
function prewarm(name) {
  clearTimeout(prewarmT);
  const c = name && app.byName(name);
  if (!c || !(c.status === 'finished' || c.status === 'stopped')) return;
  prewarmT = setTimeout(() => {
    if (app.selected === name) api.post('results/prewarm', { name, requests: prewarmRequests() }).catch(() => {});
  }, 1200);
}

function setSort(s) { app.sort = s; store('sidebar-sort', s); renderSidebar(); }

function renderSidebar() {
  if (!side.built) buildSidebar();
  if (side.dragging) { side.pending = true; return; }   // a refresh would cancel the drag
  const list = filteredCases();
  side.count.textContent = `${list.length} simulation${list.length === 1 ? '' : 's'}`;
  side.selBtn.classList.toggle('btn-primary', app.selectMode);
  side.selBtn.classList.toggle('btn-ghost', !app.selectMode);
  side.list.classList.toggle('select-mode', app.selectMode);
  const scroll = side.list.scrollTop;
  clear(side.list);
  if (!app.loaded) { side.list.appendChild(h('div', { class: 'side-empty' }, h('div', { class: 'spinner' }))); return; }
  if (!list.length) {
    side.list.appendChild(h('div', { class: 'side-empty' }, app.cases.length ? 'No simulation matches the filter.' :
      'No simulations found in the simulations folder.'));
  }
  for (const c of list) side.list.appendChild(simItem(c));
  side.list.scrollTop = scroll;
  renderSelectionBar();
}

function simItem(c) {
  const st = c.status;
  const { date, rest } = splitName(c.name);
  const cb = h('input', { type: 'checkbox' });
  cb.checked = app.checked.has(c.name);
  const toggle = () => {
    if (app.checked.has(c.name)) app.checked.delete(c.name); else app.checked.add(c.name);
    renderSidebar();
  };
  cb.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); toggle(); });
  let sub = STATUS[st] ? STATUS[st].label : st;
  let extra = null;
  if (st === 'running' && c.progress) {
    const p = c.progress;
    sub = p.kind === 'solve' && p.fraction != null ? `Solving ${Math.round(p.fraction * 100)}%` : (p.label || 'Running');
  }
  const prog = st === 'running' ? h('div', { class: 'mini-progress' + (c.progress && c.progress.fraction != null ? '' : ' indet') },
    h('i', { style: { width: Math.round(((c.progress && c.progress.fraction) || 0) * 100) + '%' } })) : null;
  const warm = c.warm_from ? h('span', { class: 'warm-text', title: 'Warm start from ' + c.warm_from }, icon('flame')) : null;
  if (c.queued && st !== 'running') extra = h('span', { class: 'pill st-queued', style: { height: '18px', fontSize: '10.5px', padding: '0 7px' } }, 'queued');
  const item = h('div', { class: `sim-item st-${st}` + (app.selected === c.name ? ' selected' : ''), title: c.error || c.name },
    h('label', { class: 'sim-check' }, cb),
    h('div', { class: 'sim-body' },
      h('div', { class: 'sim-name' }, h('span', { class: 'nm' }, rest), date ? h('span', { class: 'sim-date' }, date) : null),
      h('div', { class: 'sim-sub' }, h('span', { class: 'dot' }), h('span', { class: 'stlabel' }, sub), warm, extra,
        c.origin ? h('span', { class: 'origin' }, '← ' + splitName(c.origin).rest) : null),
      prog));
  item.addEventListener('click', () => {
    if (app.selectMode) { toggle(); return; }
    app.select(c.name);
  });
  // drag & drop to sort by hand
  item.draggable = !app.selectMode;
  const mark = (after) => { item.classList.toggle('drop-before', after === false); item.classList.toggle('drop-after', after === true); };
  item.addEventListener('dragstart', (e) => {
    side.dragging = c.name;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', c.name);
    setTimeout(() => item.classList.add('dragging'));
  });
  item.addEventListener('dragover', (e) => {
    if (!side.dragging || side.dragging === c.name) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const r = item.getBoundingClientRect();
    mark(e.clientY > r.top + r.height / 2);
  });
  item.addEventListener('dragleave', () => mark(null));
  item.addEventListener('drop', (e) => {
    e.preventDefault();
    const after = item.classList.contains('drop-after'), name = side.dragging;
    mark(null);
    side.dragging = null;
    if (name && name !== c.name) moveCase(name, c.name, after);
  });
  item.addEventListener('dragend', () => {
    item.classList.remove('dragging');
    const again = side.pending || side.dragging;
    side.dragging = null; side.pending = false;
    if (again) renderSidebar();
  });
  return item;
}

function renderSelectionBar() {
  const bar = side.selbar;
  bar.classList.toggle('hidden', !app.selectMode);
  if (!app.selectMode) return;
  const names = [...app.checked].filter((n) => app.byName(n));
  const runBtn = btn('Run', { size: 'sm', variant: 'primary', icon: 'play', caret: true, disabled: !names.length });
  runBtn.addEventListener('click', () => showMenu(runBtn, runMenuItems(names)));
  const cmpBtn = btn('Compare', { size: 'sm', icon: 'compare', disabled: names.length !== 2 });
  cmpBtn.addEventListener('click', () => { app.select(names[0]); app.detail.openCompare(names[1]); });
  const allBtn = btn('All visible', { size: 'sm', variant: 'ghost' });
  allBtn.addEventListener('click', () => { filteredCases().forEach((c) => app.checked.add(c.name)); renderSidebar(); });
  const noneBtn = btn('None', { size: 'sm', variant: 'ghost' });
  noneBtn.addEventListener('click', () => { app.checked.clear(); renderSidebar(); });
  mount(bar,
    h('div', { class: 'row' }, h('b', null, `${names.length} selected`), h('span', { class: 'spacer' }), allBtn, noneBtn),
    h('div', { class: 'row' }, runBtn, app.can('compare') ? cmpBtn : null),
    names.length > 1 ? h('div', { class: 'muted small' }, 'Selected simulations run one after another.') : null);
}

export function runMenuItems(names) {
  const one = names.length === 1 ? app.byName(names[0]) : null;
  const items = [
    { label: 'Full run', sub: 'Mesh + solve (autorun)', icon: 'play', onClick: () => app.run(names, 'full') },
    { label: 'Mesh only', sub: 'blockMesh → snappyHexMesh → checkMesh', icon: 'grid', onClick: () => app.run(names, 'mesh') },
    { label: 'Solve only', sub: 'Uses the existing mesh, restarts from 0', icon: 'flask', onClick: () => app.run(names, 'solve') },
    { label: 'Continue solving', sub: 'From the latest results (raise end time first)', icon: 'chevRight', onClick: () => app.run(names, 'continue') },
  ];
  if (one && (one.status === 'running' || one.queued)) items.forEach((i) => { i.disabled = true; });
  return items;
}

// ---------------------------------------------------------------- topbar
function renderTopbar() {
  const center = document.getElementById('topbarRunning');
  clear(center);
  // the open simulation already shows its own progress bar - only point to runs that are not open
  const running = app.cases.filter((c) => c.status === 'running' && c.name !== app.selected);
  const r = running.find((c) => !c.external) || running[0];
  if (r) {
    const p = r.progress || {};
    const frac = p.fraction != null ? p.fraction : null;
    const sub = p.kind === 'solve' && p.current != null
      ? `${p.current} / ${p.end} it${p.eta != null ? ' · ' + fmtDuration(p.eta) + ' left' : ''}`
      : (p.label || 'Running');
    const ind = h('div', { class: 'run-indicator st-running', title: 'Show running simulation' },
      h('span', { class: 'dot' }), h('span', { class: 'ri-name' }, splitName(r.name).rest),
      h('span', { class: 'ri-sub' }, sub),
      h('span', { class: 'ri-bar' }, h('i', { style: { width: (frac != null ? Math.round(frac * 100) : 8) + '%' } })),
      running.length > 1 ? h('span', { class: 'muted small' }, `+${running.length - 1}`) : null);
    ind.addEventListener('click', () => app.select(r.name));
    center.appendChild(ind);
  }
  const qb = document.getElementById('btnQueue');
  const pending = app.cases.filter((c) => c.queued).length;
  const runningN = app.runner && app.runner.alive && app.runner.case ? 1 : 0;
  mount(qb, icon('list'), h('span', null, 'Queue'),
    (pending + runningN) ? h('span', { class: 'badge-count' + (runningN ? ' running' : '') }, pending + runningN) : null);
}

// ---------------------------------------------------------------- home / dashboard
// own sort of the leaderboard (default oldest first) - the drag progress chart follows this order
let homeSort = store('home-sort-mode') || 'name-asc';
if (!SORTS.some(([v]) => v === homeSort)) homeSort = 'name-asc';
let lbDragging = null, lbPending = false;   // drag & drop in the leaderboard (lbDrag)

function renderHome() {
  if (app.selected) return;
  if (lbDragging) { lbPending = true; return; }   // a refresh would cancel the drag
  const content = document.getElementById('content');
  if (!app.can('forces')) { renderPictureHome(content); return; }
  let withRes = app.cases.filter((c) => c.results && c.results.drag != null);
  const cards = kpiCards(withRes);
  withRes = sortCases(withRes, homeSort);
  const drags = withRes.map((c) => c.results.drag);
  const dMin = Math.min(...drags), dMax = Math.max(...drags);
  const barW = (v) => dMax > dMin ? 12 + 88 * (v - dMin) / (dMax - dMin) : 50;
  const th = (label, k, cls = '') => h('th', { class: cls }, label);
  const sortBtn = btn(SORTS.find(([v]) => v === homeSort)[1], { size: 'sm', variant: 'ghost', icon: 'list', title: 'Sort the leaderboard (and the drag progress chart)' });
  sortBtn.addEventListener('click', () => showMenu(sortBtn, sortMenuItems(homeSort, (v) => { homeSort = v; store('home-sort-mode', v); renderHome(); })));
  const head = (app.info && app.info.config.force_headline === 'pressure') ? 'pressure only' : 'pressure + viscous';
  // check boxes: which simulations the drag progress chart above shows
  const chart = dragChart();
  const shownBox = (names) => {
    const cb = h('input', { type: 'checkbox', title: 'Show in the drag progress chart' });
    const on = names.filter((n) => !chart.hidden.has(n)).length;
    cb.checked = on > 0 && on === names.length;
    cb.indeterminate = on > 0 && on < names.length;
    cb.addEventListener('click', (e) => { e.stopPropagation(); chart.setShown(names, cb.checked); });
    return h('td', { class: 'lb-check', onclick: (e) => e.stopPropagation() }, cb);
  };
  const allBox = shownBox(withRes.map((c) => c.name));
  const table = withRes.length ? h('div', { class: 'table-scroll' }, h('table', { class: 'tbl' },
    h('thead', null, h('tr', null, h('th', { class: 'lb-check', title: 'Show all / none in the chart' }, allBox.firstChild), h('th', null, '#'), th('Simulation', 'name'), th('Drag [N]', 'drag', 'num'),
      h('th', { class: 'num', title: 'Uncertainty of the mean drag (statistical, 1 sigma), relative to the drag. Below 0.1 % the result is converged.' }, '\u00b1 Drag'),
      th('Lift [N]', 'lift', 'num'), th('Cells', 'cells', 'num'), th('Iterations', 'iterations', 'num'), h('th', null, 'From'))),
    h('tbody', null, withRes.map((c, i) => {
      const nm = splitName(c.name);
      const conv = convergence(relUnc(c.results));
      const tr = h('tr', { class: 'clickable' + (chart.hidden.has(c.name) ? ' lb-off' : ''), title: c.name },
        shownBox([c.name]),
        h('td', { class: 'muted' }, i + 1),
        h('td', null, h('div', { class: 'row st-' + c.status }, h('span', { class: 'dot' }), h('span', { class: 'lb-name' }, nm.rest),
          nm.date ? h('span', { class: 'sim-date' }, nm.date) : null)),
        h('td', { class: 'num bar-cell', style: { minWidth: '130px' } },
          h('div', { class: 'bar', style: { width: Math.round(barW(c.results.drag)) + '%' } }),
          h('span', null, fmtForce(c.results.drag))),
        h('td', { class: 'num' }, conv ? h('span', { class: 'conv-text ' + conv.cls, title: conv.label }, conv.pct) : '-'),
        h('td', { class: 'num' }, fmtForce(c.results.lift)),
        h('td', { class: 'num' }, fmtCells(c.cells)),
        h('td', { class: 'num' }, c.results.iterations != null ? Math.round(c.results.iterations) : '-'),
        h('td', { class: 'muted ellipsis', style: { maxWidth: '200px' }, title: c.origin || '' }, c.origin ? splitName(c.origin).rest : '-'));
      tr.addEventListener('click', () => app.select(c.name));
      lbDrag(tr, c.name);
      return tr;
    })))) : h('div', { class: 'empty' }, icon('chart', 'xl'), h('h3', null, 'No results yet'), h('div', null, 'Finished simulations appear here with their forces.'));

  mount(content, h('div', { class: 'page' },
    h('div', { class: 'hero' },
      h('div', null, h('h1', null, 'Simulations'),
        h('p', null, `${app.cases.length} simulations in `, h('a', { title: 'Open in Explorer', onclick: () => api.post('open', { what: 'sims_dir' }) }, app.info ? app.info.config.sims_dir : '')))),
    cards,
    dragHistorySection(withRes),
    h('div', { class: 'card', style: { marginTop: '14px' } },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('trophy'), 'Results leaderboard'),
        h('div', { class: 'row' }, h('span', { class: 'muted small' }, `Mean over the averaging window · ${head} · full car`),
          sortBtn, sheetButtons())),
      table)));
}

// home page of a variant without force values: the finished simulations only
function renderPictureHome(content) {
  const done = sortCases(app.cases.filter((c) => c.status === 'finished' || c.status === 'stopped'), homeSort);
  const table = done.length ? h('div', { class: 'table-scroll' }, h('table', { class: 'tbl' },
    h('thead', null, h('tr', null, h('th', null, 'Simulation'), h('th', { class: 'num' }, 'Cells'), h('th', null, 'From'))),
    h('tbody', null, done.map((c) => {
      const nm = splitName(c.name);
      const tr = h('tr', { class: 'clickable', title: c.name },
        h('td', null, h('div', { class: 'row st-' + c.status }, h('span', { class: 'dot' }), h('span', { class: 'lb-name' }, nm.rest),
          nm.date ? h('span', { class: 'sim-date' }, nm.date) : null)),
        h('td', { class: 'num' }, fmtCells(c.cells)),
        h('td', { class: 'muted ellipsis', style: { maxWidth: '200px' }, title: c.origin || '' }, c.origin ? splitName(c.origin).rest : '-'));
      tr.addEventListener('click', () => app.select(c.name));
      return tr;
    })))) : h('div', { class: 'empty' }, icon('eye', 'xl'), h('h3', null, 'No results yet'), h('div', null, 'Finished simulations appear here. Open one and use the Results tab for the flow pictures.'));
  mount(content, h('div', { class: 'page' },
    h('div', { class: 'hero' },
      h('div', null, h('h1', null, 'Simulations'),
        h('p', null, `${app.cases.length} simulations in `, h('a', { title: 'Open in Explorer', onclick: () => api.post('open', { what: 'sims_dir' }) }, app.info ? app.info.config.sims_dir : '')))),
    kpiCards([]),
    h('div', { class: 'card', style: { marginTop: '14px' } },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('eye'), 'Finished simulations')),
      table)));
}

// drag & drop in the leaderboard: sorts by hand ("My order", shared with the sidebar)
function lbDrag(tr, name) {
  tr.draggable = true;
  const mark = (after) => { tr.classList.toggle('drop-before', after === false); tr.classList.toggle('drop-after', after === true); };
  tr.addEventListener('dragstart', (e) => {
    lbDragging = name;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', name);
    setTimeout(() => tr.classList.add('dragging'));
  });
  tr.addEventListener('dragover', (e) => {
    if (!lbDragging || lbDragging === name) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const r = tr.getBoundingClientRect();
    mark(e.clientY > r.top + r.height / 2);
  });
  tr.addEventListener('dragleave', () => mark(null));
  tr.addEventListener('drop', (e) => {
    e.preventDefault();
    const after = tr.classList.contains('drop-after'), moved = lbDragging;
    mark(null);
    lbDragging = null;
    if (moved && moved !== name) moveCase(moved, name, after, true);
  });
  tr.addEventListener('dragend', () => {
    tr.classList.remove('dragging');
    const again = lbPending || lbDragging;
    lbDragging = null; lbPending = false;
    if (again) renderHome();
  });
}

// ---------------------------------------------------------------- KPI cards (home)
// sortable "age" of a simulation: date in the folder name (or creation date), then creation time
function chronoKey(c) {
  const m = /^(\d{8})/.exec(c.name);
  const day = m ? m[1] : c.created ? new Date(c.created * 1000).toISOString().slice(0, 10).replace(/-/g, '') : '00000000';
  return day + String(Math.round(c.created || 0)).padStart(12, '0') + c.name;
}

function kpiCards(withRes) {
  const cards = h('div', { class: 'kpi-cards' });
  const card = (cls, label, main, sub, onClick, title) => {
    const el = h('div', { class: 'kpi ' + cls + (onClick ? ' clickable' : ''), title: title || '' },
      h('div', { class: 'kpi-label' }, label), h('div', { class: 'kpi-main' }, main), h('div', { class: 'kpi-sub' }, sub));
    if (onClick) el.addEventListener('click', onClick);
    cards.appendChild(el);
  };
  const relOf = (c) => relUnc(c.results);

  // best drag
  if (withRes.length) {
    const best = withRes.reduce((a, b) => (b.results.drag < a.results.drag ? b : a));
    card('st-accent', 'Lowest drag', h('span', null, fmtForce(best.results.drag), h('small', null, ' N')),
      splitName(best.name).rest, () => app.select(best.name), best.name);
  } else if (app.can('forces')) card('', 'Lowest drag', '-', 'No results yet');

  // latest result and its change against the simulation it was made from
  if (withRes.length) {
    const last = withRes.slice().sort((a, b) => chronoKey(b).localeCompare(chronoKey(a)))[0];
    const parent = last.origin ? app.byName(last.origin) : null;
    let delta = null;
    if (parent && parent.results && parent.results.drag) {
      const d = (last.results.drag - parent.results.drag) / Math.abs(parent.results.drag) * 100;
      const ul = uncOf(last.results), up = uncOf(parent.results);
      const noise = (ul != null && up != null) ? Math.hypot(ul, up) / Math.abs(parent.results.drag) * 100 : null;
      const inNoise = noise != null && Math.abs(d) < noise;
      delta = h('span', { class: inNoise ? 'muted' : d < 0 ? 'ok' : 'bad',
        title: inNoise ? `Within the scatter of the two results (\u00b1${noise.toFixed(1)} %)` : '' },
        `${d > 0 ? '+' : ''}${d.toFixed(2)} % vs ${splitName(parent.name).rest}${inNoise ? ' (within scatter)' : ''}`);
    }
    const conv = convergence(relOf(last));
    card('st-meshed', 'Latest result', h('span', null, fmtForce(last.results.drag), h('small', null, ' N'),
      conv ? h('span', { class: 'conv-text ' + conv.cls, title: conv.label }, ' \u00b1' + conv.pct) : null),
    h('span', null, splitName(last.name).rest, delta ? h('br') : null, delta), () => app.select(last.name), last.name);
  }

  // activity
  const running = app.cases.filter((c) => c.status === 'running');
  const queued = app.cases.filter((c) => c.queued && c.status !== 'running').length;
  if (running.length) {
    const r = running[0], p = r.progress || {};
    const pct = p.fraction != null ? Math.round(p.fraction * 100) + ' %' : (p.label || 'running');
    card('st-running', 'Running now', h('span', null, splitName(r.name).rest),
      `${p.kind === 'solve' ? 'Solving' : 'Meshing'} ${pct}${p.eta != null ? ' \u00b7 ' + fmtDuration(p.eta) + ' left' : ''}${queued ? ` \u00b7 ${queued} queued` : ''}`,
      () => app.select(r.name));
  } else {
    card('st-fresh', 'Activity', 'Idle', queued ? `${queued} queued` : 'Nothing queued', queued ? toggleQueue : null);
  }
  return cards;
}

// ---------------------------------------------------------------- drag progress (home)
const dragProg = { el: null, chart: null };

function dragChart() {
  dragHistorySection(null);
  return dragProg.chart;
}

function dragHistorySection(withRes) {
  if (!dragProg.el) {
    const body = h('div');
    dragProg.el = h('div', { class: 'card', style: { marginTop: '14px' } },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('chart'), 'Drag progress'),
        h('span', { class: 'muted small' }, 'final drag per simulation \u00b7 green = new best')),
      body);
    // hiding a point (click in the chart or leaderboard check box) updates the leaderboard too
    dragProg.chart = new DragProgress(body, { onChange: () => renderHome() });
  }
  if (withRes) dragProg.chart.setData(withRes);
  return dragProg.el;
}

function sheetButtons() {
  const sh = (app.info && app.info.sheet) || {};
  const open = btn('Spreadsheet', { size: 'sm', icon: 'external', title: sh.path || '' });
  open.addEventListener('click', () => api.post('sheet/open').catch((e) => toastError(e)));
  const sync = btn('Sync', { size: 'sm', icon: 'refresh', title: 'Write all results to the spreadsheet and remove rows of deleted simulations' });
  sync.addEventListener('click', async () => {
    sync.disabled = true;
    try {
      const r = await api.post('sheet/sync');
      app.info.sheet = r.info;
      toast('Spreadsheet updated', `${r.added.length} added · ${r.updated.length} updated · ${r.removed.length} removed`, 'ok');
    } catch (e) { toastError(e, 'Could not update the spreadsheet'); }
    sync.disabled = false;
  });
  const note = sh.pending ? h('span', { class: 'warnc small', title: 'The spreadsheet was open in LibreOffice - results are written as soon as it is closed.' },
    `${sh.pending} pending`) : null;
  return h('div', { class: 'row' }, note, open, sync);
}

// ---------------------------------------------------------------- queue drawer
async function renderQueue() {
  const d = document.getElementById('queueDrawer');
  let q;
  try { q = await api.get('queue'); } catch (e) { return; }
  const running = q.jobs.filter((j) => j.state === 'running');
  const pending = q.jobs.filter((j) => j.state === 'pending');
  const done = q.jobs.filter((j) => !['running', 'pending'].includes(j.state)).reverse();
  const modes = app.info.modes;
  const act = async (action) => { await api.post('queue', { action }); renderQueue(); app.refresh(); };
  const pauseBtn = btn(q.paused ? 'Resume' : 'Pause', { size: 'sm', icon: q.paused ? 'play' : 'pause', variant: q.paused ? 'primary' : '' });
  pauseBtn.addEventListener('click', () => {
    if (q.paused) { act('resume'); return; }
    if (!running.length) { act('pause'); return; }
    showMenu(pauseBtn, [
      { label: 'Pause now', icon: 'pause', onClick: () => act('pause_now'),
        sub: 'Saves the current iteration; Resume continues there' },
      { label: 'Pause after the current run', icon: 'list', onClick: () => act('pause'),
        sub: 'The current run finishes; no new runs start' },
    ]);
  });
  const closeBtn = btn('', { icon: 'x', variant: 'ghost' });
  closeBtn.addEventListener('click', toggleQueue);
  const item = (j, kind, idx) => {
    const c = app.byName(j.case);
    const p = c && c.progress;
    const sub = kind === 'running'
      ? (p ? (p.kind === 'solve' && p.current != null ? `${modes[j.mode]} · iteration ${p.current} / ${p.end}` : `${modes[j.mode]} · ${p.label || ''}`) : modes[j.mode])
      : kind === 'pending' ? `${modes[j.mode]} · added ${fmtAgo(j.added)}${q.quota.left === 0 && ['full', 'solve'].includes(j.mode) && !j.count_id ? ' · waits for the next day' : ''}`
        : `${modes[j.mode]} · ${j.state === 'done' ? 'done' : j.state} ${fmtAgo(j.ended)}${j.message && j.state !== 'done' ? ' · ' + j.message : ''}`;
    const name = h('div', { class: 'q-name' }, j.case);
    name.addEventListener('click', () => { app.select(j.case); });
    const btns = h('div', { class: 'q-btns' });
    if (kind === 'pending') {
      const up = btn('', { icon: 'arrowUp', size: 'sm', variant: 'ghost', title: 'Move up', disabled: idx === 0 });
      up.addEventListener('click', async () => { await api.post('queue', { action: 'move', id: j.id, delta: -1 }); renderQueue(); });
      const dn = btn('', { icon: 'arrowDown', size: 'sm', variant: 'ghost', title: 'Move down', disabled: idx === pending.length - 1 });
      dn.addEventListener('click', async () => { await api.post('queue', { action: 'move', id: j.id, delta: 1 }); renderQueue(); });
      const rm = btn('', { icon: 'x', size: 'sm', variant: 'ghost', title: 'Remove from queue' });
      rm.addEventListener('click', async () => { await api.post('queue', { action: 'remove', id: j.id }); renderQueue(); app.refresh(); });
      btns.append(up, dn, rm);
    }
    const st = kind === 'running' ? 'running' : kind === 'pending' ? 'queued' : j.state === 'done' ? 'finished' : j.state === 'paused' ? 'stopped' : 'error';
    return h('div', { class: 'q-item st-' + st + (kind === 'running' ? ' running' : '') },
      kind === 'running' ? h('div', { class: 'spinner', style: { color: 'var(--st-running)' } }) : h('span', { class: 'dot' }),
      h('div', { class: 'q-main' }, name, h('div', { class: 'q-sub' }, sub)), btns);
  };
  const clearBtn = done.length ? btn('Clear', { size: 'sm', variant: 'ghost' }) : null;
  if (clearBtn) clearBtn.addEventListener('click', async () => { await api.post('queue', { action: 'clear' }); renderQueue(); });
  const runnerNote = (!q.runner.alive && pending.length && !q.paused)
    ? h('div', { class: 'callout warn' }, icon('alert'), h('div', { class: 'callout-body' }, 'The queue is not being processed.',
      h('div', { style: { marginTop: '6px' } }, (() => { const b = btn('Start processing', { size: 'sm', variant: 'primary', icon: 'play' }); b.addEventListener('click', async () => { await api.post('queue', { action: 'resume' }); renderQueue(); app.refresh(); }); return b; })())))
    : null;
  mount(d,
    h('div', { class: 'drawer-head' }, icon('list', 'lg'), h('h2', null, 'Run queue'), pauseBtn, closeBtn),
    h('div', { class: 'drawer-body' },
      q.paused ? h('div', { class: 'callout warn' }, icon('pause'), h('div', { class: 'callout-body' },
        running.length ? 'Pausing. A running solver saves the current iteration and stops (meshing is finished first); then it waits at the top of the queue.'
          : 'Queue paused. Resume continues with the first run' + (pending.length && pending[0].mode === 'continue' ? ` (${pending[0].case} from its saved iteration).` : '.'))) : null,
      runnerNote,
      q.quota.limit != null ? h('div', { class: 'callout' }, icon('info'), h('div', { class: 'callout-body' },
        `${q.quota.used} of ${q.quota.limit} simulations used today. Full and solve-only runs count unless they fail or you abort them; mesh-only and continued runs are free. Further runs wait and start automatically on the next day.`)) : null,
      h('div', { class: 'q-section' }, 'Running'),
      running.length ? running.map((j) => item(j, 'running')) : h('div', { class: 'muted small', style: { padding: '0 4px' } }, 'Nothing is running.'),
      h('div', { class: 'q-section' }, `Up next (${pending.length})`),
      pending.length ? pending.map((j, i) => item(j, 'pending', i)) : h('div', { class: 'muted small', style: { padding: '0 4px' } }, 'The queue is empty. Select simulations in the sidebar and press Run.'),
      done.length ? h('div', { class: 'q-section' }, 'History', clearBtn) : null,
      done.slice(0, 25).map((j) => item(j, 'done'))));
}

function toggleQueue() {
  app.queueOpen = !app.queueOpen;
  const d = document.getElementById('queueDrawer');
  d.classList.toggle('open', app.queueOpen);
  if (app.queueOpen) renderQueue();
}

// ---------------------------------------------------------------- boot
function showFatal(msg) {
  mount(document.getElementById('content'), h('div', { class: 'page' }, h('div', { class: 'empty' }, icon('alert', 'xl'), h('h3', null, 'Not connected'), h('div', null, msg))));
}

async function boot() {
  // start page for the installed app when the local server is not running (see sw.js)
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  if (!api.initToken()) {
    showFatal('Please start Flowforge Studio with "Flowforge Studio.bat".');
    return;
  }
  try {
    await app.reloadInfo();
  } catch (e) {
    showFatal(e.message);
    return;
  }
  if (!app.info.license || !app.info.license.valid) {
    showActivation(app.info);
    return;
  }
  document.querySelector('.brand').title = `Licensed to ${app.info.license.name} · ${app.info.license.features.label}`;
  document.querySelector('.brand-name').append(h('span', { class: 'tier-badge' }, app.info.license.features.label));
  mount(document.getElementById('btnNew'), icon('plus'), h('span', null, 'New simulation'));
  document.getElementById('btnNew').addEventListener('click', () => app.openWizard());
  mount(document.getElementById('btnSettings'), icon('gear'));
  document.getElementById('btnSettings').addEventListener('click', () => openAppSettings(app));
  document.getElementById('btnQueue').addEventListener('click', toggleQueue);
  document.getElementById('btnTheme').addEventListener('click', async () => {
    const t = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    applyTheme(t);
    try { await api.post('config', { updates: { theme: t } }); } catch (e) { /* ignore */ }
    if (app.detail) app.detail.onThemeChanged();
  });
  document.querySelector('.brand').addEventListener('click', () => app.select(null));
  // collapsible simulation list: always open at start, hiding it only lasts until the app is closed
  setSidebarHidden(false, true);
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'b' && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) {
      e.preventDefault();
      setSidebarHidden(!document.querySelector('.layout').classList.contains('side-hidden'));
    }
  });
  buildSidebar();
  renderSidebar();
  await app.refresh();
  app.select(null);
  if (!app.info.bluecfd_valid) {
    toast('blueCFD-Core not found', 'Open the settings (gear icon) and select your blueCFD-Core folder.', 'warn', 12000);
  }
  setInterval(() => app.refresh(), 2500);
  app.installHint();
  // full screen on start: the window is normally opened full screen by the launcher; if the browser
  // ignored that (e.g. Edge was already running), switch with the first click (browsers need a click for it)
  if ((app.info.config.window_mode || 'maximized') === 'fullscreen') {
    const isFull = () => document.fullscreenElement || (window.innerHeight >= screen.height - 1 && window.innerWidth >= screen.width - 1);
    if (!isFull()) {
      const go = () => { if (!isFull()) document.documentElement.requestFullscreen().catch(() => {}); };
      window.addEventListener('pointerdown', go, { once: true, capture: true });
    }
  }
  setInterval(() => api.post('ping').catch(() => {}), 15000);
  window.addEventListener('pagehide', () => api.sayGoodbye());
  // the installed app window just took over (see install.html): close this plain browser window
  try { new BroadcastChannel('flowforgestudio').onmessage = (e) => { if (e.data === 'installed') window.close(); }; } catch (e) { /* ignore */ }
  api.post('ping').catch(() => {});
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && app.queueOpen && !document.querySelector('.modal-backdrop')) toggleQueue();
  });
}

boot();
