// Minimal MP4 writer for one H.264 video track (WebCodecs output, no B-frames): all samples in one
// chunk after the header, the index (moov) at the end. Returns a Blob.

const TIMESCALE = 60000;

function u8(...parts) {
  const out = [];
  for (const p of parts) {
    if (typeof p === 'string') for (const ch of p) out.push(ch.charCodeAt(0));
    else if (p instanceof Uint8Array) for (const b of p) out.push(b);
    else out.push(...p);
  }
  return new Uint8Array(out);
}
const be32 = (n) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
const be16 = (n) => [(n >>> 8) & 255, n & 255];
const zeros = (n) => new Array(n).fill(0);
const box = (type, ...parts) => { const body = u8(...parts); return u8(be32(body.length + 8), type, body); };
const full = (type, version, flags, ...parts) => box(type, [version, (flags >> 16) & 255, (flags >> 8) & 255, flags & 255], ...parts);
const MATRIX = [...be32(0x00010000), ...zeros(12), ...be32(0x00010000), ...zeros(12), ...be32(0x40000000)];

// samples: [{d: Uint8Array, ts: µs, key: bool}] in decode order; avcC: decoder description
export function mp4(samples, avcC, width, height) {
  const n = samples.length;
  const durs = samples.map((s, i) => (i + 1 < n ? Math.max(1, Math.round((samples[i + 1].ts - s.ts) * TIMESCALE / 1e6)) : 0));
  if (n) durs[n - 1] = n > 1 ? durs[n - 2] : TIMESCALE / 60;
  const total = durs.reduce((a, b) => a + b, 0);

  // run-length time to sample table
  const stts = [];
  for (const d of durs) {
    if (stts.length && stts[stts.length - 1][1] === d) stts[stts.length - 1][0]++;
    else stts.push([1, d]);
  }
  const keys = [];
  samples.forEach((s, i) => { if (s.key) keys.push(i + 1); });

  const ftyp = box('ftyp', 'isom', be32(512), 'isom', 'iso2', 'avc1', 'mp41');
  const dataLen = samples.reduce((a, s) => a + s.d.length, 0);
  const mdatHead = u8(be32(dataLen + 8), 'mdat');
  const dataStart = ftyp.length + mdatHead.length;

  const avc1 = box('avc1', zeros(6), be16(1), zeros(16), be16(width), be16(height), be32(0x00480000), be32(0x00480000),
    zeros(4), be16(1), zeros(32), be16(0x18), be16(0xffff), box('avcC', avcC));
  const stbl = box('stbl',
    full('stsd', 0, 0, be32(1), avc1),
    full('stts', 0, 0, be32(stts.length), ...stts.map(([c, d]) => [...be32(c), ...be32(d)])),
    full('stss', 0, 0, be32(keys.length), ...keys.map(be32)),
    full('stsc', 0, 0, be32(1), be32(1), be32(n), be32(1)),
    full('stsz', 0, 0, be32(0), be32(n), ...samples.map((s) => be32(s.d.length))),
    full('stco', 0, 0, be32(1), be32(dataStart)));
  const minf = box('minf',
    full('vmhd', 0, 1, zeros(8)),
    box('dinf', full('dref', 0, 0, be32(1), full('url ', 0, 1))),
    stbl);
  const mdia = box('mdia',
    full('mdhd', 0, 0, zeros(8), be32(TIMESCALE), be32(total), be16(0x55c4), be16(0)),
    full('hdlr', 0, 0, zeros(4), 'vide', zeros(12), 'VideoHandler', [0]),
    minf);
  const trak = box('trak',
    full('tkhd', 0, 3, zeros(8), be32(1), zeros(4), be32(total), zeros(8), zeros(8), MATRIX, be32(width << 16), be32(height << 16)),
    mdia);
  const moov = box('moov',
    full('mvhd', 0, 0, zeros(8), be32(TIMESCALE), be32(total), be32(0x00010000), be16(0x0100), zeros(10), MATRIX, zeros(24), be32(2)),
    trak);
  return new Blob([ftyp, mdatHead, ...samples.map((s) => s.d), moov], { type: 'video/mp4' });
}
