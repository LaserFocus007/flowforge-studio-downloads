// Activation screen shown until a valid licence key for this PC is entered.

import * as api from './api.js';
import { h, mount, icon, btn, toast, renderMarkdown } from './ui.js';

export async function showActivation(info) {
  let lic;
  try { lic = await api.get('license'); } catch (e) { lic = Object.assign({ eula: '' }, info.license || {}); }
  const machine = lic.machine || '';
  const reason = lic.reason && !/not activated/i.test(lic.reason) ? lic.reason : '';

  const codeEl = h('div', { class: 'machine-code mono' }, machine);
  const copyBtn = btn('Copy', { size: 'sm', icon: 'copy' });
  copyBtn.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(machine); toast('Machine code copied', '', 'ok', 2000); }
    catch (e) {
      const r = document.createRange(); r.selectNodeContents(codeEl);
      const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
      toast('Press Ctrl+C to copy', '', 'info', 2500);
    }
  });
  const keyIn = h('textarea', { class: 'input mono', rows: 5, placeholder: 'FLOWFORGE1.xxxxxxxx.xxxxxxxx', spellcheck: 'false' });
  const eulaBox = h('div', { class: 'eula-box', html: renderMarkdown(lic.eula || 'Licence agreement not found.') });
  const accept = h('input', { type: 'checkbox' });
  const errEl = h('div', { class: 'hidden callout error' });
  const go = btn('Activate Flowforge Studio', { variant: 'primary', icon: 'check', size: 'lg' });
  const refresh = () => { go.disabled = !(accept.checked && keyIn.value.trim().length > 20); };
  accept.addEventListener('change', refresh);
  keyIn.addEventListener('input', refresh);
  eulaBox.addEventListener('scroll', () => {
    if (eulaBox.scrollTop + eulaBox.clientHeight >= eulaBox.scrollHeight - 20) eulaBox.classList.add('read');
  });
  refresh();
  go.addEventListener('click', async () => {
    go.disabled = true;
    errEl.classList.add('hidden');
    try {
      const st = await api.post('license/activate', { key: keyIn.value, accept_eula: accept.checked });
      toast('Flowforge Studio activated', 'Licensed to ' + st.name, 'ok');
      setTimeout(() => window.location.reload(), 700);
    } catch (e) {
      mount(errEl, icon('alert'), h('div', { class: 'callout-body' }, e.message));
      errEl.classList.remove('hidden');
      refresh();
    }
  });

  const step = (n, title, ...body) => h('div', { class: 'act-step' },
    h('div', { class: 'act-num' }, String(n)), h('div', { class: 'act-body' }, h('div', { class: 'act-title' }, title), ...body));

  document.getElementById('sidebar').classList.add('hidden');
  document.querySelector('.topbar-actions').classList.add('hidden');
  document.querySelector('.layout').style.gridTemplateColumns = '1fr';
  mount(document.getElementById('content'), h('div', { class: 'activation' },
    h('div', { class: 'act-card' },
      h('h1', null, 'Activate Flowforge Studio'),
      h('p', { class: 'muted' }, 'Flowforge Studio is licensed per PC. Activation works offline and only takes a minute.'),
      reason ? h('div', { class: 'callout warn', style: { margin: '14px 0' } }, icon('alert'), h('div', { class: 'callout-body' }, reason)) : null,
      step(1, 'Send this machine code to your vendor',
        h('div', { class: 'row', style: { marginTop: '8px' } }, codeEl, copyBtn),
        h('div', { class: 'muted small', style: { marginTop: '6px' } }, 'The code identifies this Windows installation. It contains no personal data.')),
      step(2, 'Paste the licence key you received', keyIn),
      step(3, 'Read and accept the licence agreement', eulaBox,
        h('label', { class: 'check-row', style: { marginTop: '10px', cursor: 'pointer' } }, accept,
          h('span', null, 'I have read the licence agreement (EULA) and accept it.'))),
      errEl,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '18px' } }, go))));
}
