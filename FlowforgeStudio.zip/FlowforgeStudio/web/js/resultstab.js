// Results tab: built-in post-processing (instead of ParaView) - car surface, section planes,
// streamlines and iso-surfaces coloured by a field, mirrored at the symmetry plane, presets, clean screenshots on white or black (also as
// a batch over several simulations) and comparison with a second simulation (peek / wipe / difference).

import * as api from './api.js';
import { h, mount, clear, icon, btn, toast, toastError, showMenu, confirmDialog, modal, store, switchEl, segmented,
  splitName, colorPick } from './ui.js';
import { ResultView, colormapAt } from './resultview.js';
import { parsePlaneFlow, planeAxes, traceLines, ribbons } from './planeflow.js';

const AXES = ['x', 'y', 'z'];
// solid colours per theme (screenshots use the same colours as the screen, only the background changes)
const PALETTE = {
  dark: { car: '#8e9ab3', plane: '#565d6e' },
  light: { car: '#e6e6e6', plane: '#c9ced8' },
};
const DARK_EDGES = [0.08, 0.08, 0.1, 0.45];      // same as the section planes
const LIGHT_EDGES = [0.86, 0.89, 0.95, 0.35];

// mesh lines that stand out on the solid colour: dark lines on light surfaces and vice versa
function hexToEdge(hex, alpha = 0.6) {
  const n = parseInt(hex.slice(1), 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255, alpha];
}

function edgesFor(solid, field) {
  if (field && field !== 'none') return DARK_EDGES;          // colour maps are mostly mid / bright
  const n = parseInt(solid.slice(1), 16);
  const lum = (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
  return lum > 0.42 ? DARK_EDGES : LIGHT_EDGES;
}
const STREAM_COLOR = '#e09a2a';
const ISO_COLOR = '#9aa7c7';
const DROP_WIDE = 1.15;         // animated flow lines: ribbon width / line width (room for the soft edge)
// time of flight between two drops on a line: 10 line spacings in the free stream
const dropPeriod = (f, speed) => 10 * f.spacing / (speed || 10);
// animated streamlines: time of flight of one car length in the free stream (the spacing unit)
const cometPeriod = (car, speed) => 1.0 * (car ? Math.max(...[0, 1, 2].map((k) => car[1][k] - car[0][k])) : 0.5) / (speed || 10);
const STATE_VERSION = 2;
const SHOT_BG = { white: [1, 1, 1], black: [0, 0, 0] };
const RES = [['1920x1080', 'Full HD (1920 × 1080)'], ['2560x1440', 'QHD (2560 × 1440)'], ['3840x2160', '4K (3840 × 2160)']];

// short description of a saved view for the menu
function summary(st) {
  if (!st) return '';
  const n = (k, one, many) => { const c = (st[k] || []).filter((x) => x.visible !== false).length; return c ? `${c} ${c === 1 ? one : many}` : null; };
  return [n('planes', 'plane', 'planes'), n('streams', 'streamline set', 'streamline sets'), n('isos', 'iso-surface', 'iso-surfaces'),
    st.mirror ? 'mirrored' : null].filter(Boolean).join(' · ') || 'Car only';
}

function fmtVal(v) {
  if (v == null || !isFinite(v)) return '-';
  const a = Math.abs(v);
  return a >= 1000 ? v.toFixed(0) : a >= 100 ? v.toFixed(1) : a >= 1 ? v.toFixed(2) : v.toPrecision(3);
}
function mm(m) { return (m * 1000).toFixed(1); }

function stamp() {
  const d = new Date(), p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

// requests the Results tab will make for a simulation with the last scene - the server computes
// them in the background while another tab is open (prewarm), so Results opens without waiting
export function prewarmRequests() {
  const s = store('results-scene');
  if (!s || !s.planes || s.v !== STATE_VERSION) return [];
  const out = [];
  for (const p of s.planes) {
    if (!p.visible) continue;
    out.push({ path: 'results/slice', q: { field: p.field, axis: AXES[p.axis], pos: p.pos } });
    if (p.flow && p.flow.on) out.push({ path: 'results/planeflow', q: { axis: AXES[p.axis], pos: p.pos } });
  }
  if (s.car && s.car.visible) out.push({ path: 'results/surface', q: { field: s.car.field } });
  for (const st of s.streams || []) {
    if (st.visible) out.push({ path: 'results/streamlines', q: { field: st.field, shape: st.shape, sc: st.sc, hc: st.hc, sw: st.sw, sh: st.sh, count: st.count, thick: st.thick } });
  }
  for (const iso of s.isos || []) {
    if (iso.visible) out.push({ path: 'results/iso', q: { field: iso.field, value: iso.value, color: iso.color } });
  }
  return out;
}

export class ResultsTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx;
    this.geoms = { A: new Map(), B: new Map(), S: new Map() };      // key -> geom
    this.flowData = new Map();      // case|axis|pos -> {data, lines by spacing} (flow lines in planes)
    this.loading = new Set();
    this.compare = { other: null, mode: (ctx.app.can('compare') && store('res-cmp-mode')) || 'off', info: null };
    this.presetName = null;
    this.lastKey = new WeakMap();      // layer settings -> key of its last loaded geometry
    mount(el, h('div', { class: 'empty' }, h('div', { class: 'spinner' }), h('div', null, 'Loading results...')));
    this.init();
  }

  // ------------------------------------------------------------------ setup
  async init() {
    try { this.info = await api.get('results/info', { name: this.ctx.name }); } catch (e) { toastError(e); return; }
    if (this.dead) return;
    if (!this.info.time) {
      mount(this.el, h('div', { class: 'card' }, h('div', { class: 'empty' }, icon('chart', 'xl'), h('h3', null, 'No results yet'),
        h('div', null, 'Results appear here once the solver has written a time step (and it was reconstructed).'))));
      return;
    }
    this.flowAxis = this.info.flow ? [0, 1, 2].reduce((a, k) => (Math.abs(this.info.flow[k]) > Math.abs(this.info.flow[a]) ? k : a), 0) : 1;
    this.state = this.loadState();
    this.build();
    this.sync();
  }

  defaultState() {
    const car = this.info.car || [[0, 0, 0], [0.05, 0.25, 0.05]];
    const up = 2;
    const vf = this.volumeField();
    return {
      v: STATE_VERSION,
      mirror: !!this.info.mirror,
      car: { visible: true, field: 'none', edges: true },
      planes: [{ id: 1, name: 'Plane', visible: true, axis: up, pos: car[0][up] + 0.12 * (car[1][up] - car[0][up]), field: vf, edges: false }],
      streams: [],
      isos: [],
      ranges: {},
    };
  }

  volumeField() {
    const fields = this.info.fields.map((f) => f.id);
    return fields.includes('Umag') ? 'Umag' : (fields.find((f) => f !== 'yPlus') || 'none');
  }

  sideAxis() { return this.info.mirror ? this.info.mirror[0] : [0, 1, 2].find((k) => k !== this.flowAxis && k !== 2); }

  // seeds just in front of the car: line or rectangle given by centre (side, up) and size, in m
  newStream(id) {
    const c = this.info.car || [[0, 0, 0], [0.05, 0.25, 0.05]];
    const a = this.sideAxis(), H = c[1][2] - c[0][2];
    let s0 = c[0][a], s1 = c[1][a];
    if (this.info.mirror) {
      const m = this.info.mirror[1], far = Math.abs(c[1][a] - m) > Math.abs(c[0][a] - m) ? c[1][a] : c[0][a];
      s0 = m; s1 = m + 1.15 * (far - m);
    }
    return { id, name: 'Streamlines' + (id > 1 ? ' ' + id : ''), visible: true, shape: 'horizontal',
      sc: (s0 + s1) / 2, hc: c[0][2] + 0.3 * H, sw: Math.abs(s1 - s0), sh: 0.8 * H, count: 25, thick: 1.6, field: this.volumeField(), anim: false };
  }

  // animation settings of a streamline set (defaults filled in)
  animFx(st) {
    // filled in place: the sliders keep a reference to this object
    st.fx = st.fx || {};
    const d = { style: 'trails', look: st.look || 'ice', speed: 0.4, spacing: 1, tail: 0.75, glow: 1, guide: 0.09 };
    for (const k in d) if (st.fx[k] == null) st.fx[k] = d[k];
    if (st.fx.style === 'pulse') st.fx.style = 'travel';     // replaced style
    return st.fx;
  }

  // style, colours and sliders of the streamline animation; all live, nothing is recomputed
  animBlock(st, changed, row, select) {
    const fx = this.animFx(st);
    const travel = fx.style === 'travel';
    const live = () => { clearTimeout(this._fxT); this._fxT = setTimeout(() => this.applyScene(), 16); };
    // log: logarithmic slider (fine steps at the slow end)
    const knob = (label, title, key, lo, hi, fmt, log = false) => {
      const to = (v) => log ? Math.log(v / lo) / Math.log(hi / lo) : (v - lo) / (hi - lo);
      const from = (f) => log ? lo * Math.pow(hi / lo, f) : lo + f * (hi - lo);
      const sl = h('input', { type: 'range', min: 0, max: 1000, step: 1, value: Math.round(Math.min(1, Math.max(0, to(fx[key]))) * 1000) });
      const out = h('span', { class: 'muted small rt-pct' }, fmt(fx[key]));
      sl.addEventListener('input', () => { fx[key] = from(+sl.value / 1000); out.textContent = fmt(fx[key]); live(); });
      sl.addEventListener('change', () => changed(false));
      return h('div', { class: 'rt-slide', title }, h('span', { class: 'muted small rt-slide-label' }, label), sl, out);
    };
    const x = (v) => (v < 0.1 ? v.toFixed(3) : v.toFixed(v < 1 ? 2 : 1)).replace(/\.?0+$/, '') + '×';
    const pct = (v) => Math.round(v * 100) + ' %';
    const len = { trails: ['Length', 'Length of the light trails'], particles: ['Size', 'Length of the sparks'],
      smoke: ['Density', 'How dense the smoke is'], travel: ['', ''], reveal: ['Afterglow', 'How long the drawn lines keep glowing'] }[fx.style];
    return h('div', { class: 'rt-sub' },
      row(h('span', { class: 'muted small rt-slide-label' }, 'Style'),
        select([['trails', 'Light trails'], ['particles', 'Particles'], ['smoke', 'Smoke'], ['travel', 'Travel'], ['reveal', 'Reveal']],
          fx.style, (v) => { fx.style = v; changed(false); this.renderPanel(); })),
      // travel: the normal streamlines (field colours, tube) grow - only the speed applies
      travel ? null : row(h('span', { class: 'muted small rt-slide-label' }, 'Colour'),
        select([['ice', 'Ice - blue to white'], ['ember', 'Ember - red to warm'], ['mono', 'Mono - white / graphite'], ['field', 'Field colours']],
          fx.look, (v) => { fx.look = v; changed(false); this.renderPanel(); })),
      knob('Speed', 'Playback speed (1× = one car length per second in the free stream)', 'speed', 0.01, 4, x, true),
      fx.style !== 'reveal' && !travel ? knob(fx.style === 'smoke' ? 'Scale' : 'Spacing', 'Distance between the trails in car lengths', 'spacing', 0.2, 3, x) : null,
      travel ? null : knob(len[0], len[1], 'tail', 0.05, 1, pct),
      travel ? null : knob('Glow', 'Strength of the glow around the light', 'glow', 0, 3, pct),
      travel ? null : knob('Lines', 'Brightness of the whole lines under the animation', 'guide', 0, 0.5, pct),
      travel ? h('div', { class: 'muted small' }, 'The streamlines grow from far upstream to the end, stay a moment, then again.') : null);
  }

  // flow lines inside a section plane: spacing / width relative to the car length
  newFlow() {
    const c = this.info.car || [[0, 0, 0], [0.05, 0.25, 0.05]];
    const len = Math.max(...[0, 1, 2].map((k) => c[1][k] - c[0][k]));
    const r = (v, d) => Math.round(v / d) * d;
    return { on: true, mode: 'solid', color: '#ffffff', spacing: r(len / 70, 0.0005), width: r(len / 450, 0.00005), opacity: 0.9, pulse: false };
  }

  newIso(id) {
    const fields = this.info.fields.filter((f) => f.volume).map((f) => f.id);
    const fid = fields.includes('p0') ? 'p0' : (fields[0] || 'Umag');
    const r = this.info.ranges[fid] || [0, 1];
    return { id, name: 'Iso-surface' + (id > 1 ? ' ' + id : ''), visible: true, field: fid, value: fid === 'p0' ? 0 : (r[0] + r[1]) / 2, color: 'none' };
  }

  // fields shown with colours (for the ranges, colour bars and file names)
  usedFields(st) {
    const s = st || this.state;
    return [...new Set([s.car.visible && s.car.field !== 'none' ? s.car.field : null]
      .concat(s.planes.filter((p) => p.visible && p.field !== 'none').map((p) => p.field))
      .concat(s.planes.filter((p) => p.visible && p.flow && p.flow.on && p.flow.mode === 'speed').map(() => 'Umag'))
      .concat(s.streams.filter((p) => p.visible && p.field !== 'none').map((p) => p.field))
      .concat(s.isos.filter((p) => p.visible && p.color !== 'none').map((p) => p.color)).filter(Boolean))];
  }

  loadState() {
    const s = store('results-scene');
    if (!s || !s.planes) return this.defaultState();
    if (s.v !== STATE_VERSION) {
      // older layout with the three planes Floor / Centre / Wake: start with the single default plane
      const d = this.defaultState();
      Object.assign(s, { v: STATE_VERSION, planes: d.planes, streams: [], isos: [] });
    }
    this.checkFields(s);
    if (!this.info.mirror) s.mirror = false;
    return s;
  }

  checkFields(s) {
    const known = new Set(this.info.fields.map((f) => f.id).concat(['none']));
    s.streams = s.streams || [];
    s.isos = s.isos || [];
    s.planes.forEach((p) => {
      if (!known.has(p.field)) p.field = 'none';
      if (p.flow && p.flow.mode === 'speed' && !known.has('Umag')) p.flow.mode = 'solid';
    });
    s.streams.forEach((p) => {
      if (!known.has(p.field)) p.field = 'none';
      if (!p.shape) {
        // first version: orientation + one position
        const d = this.newStream(p.id);
        if (p.orient === 'vertical') { d.shape = 'vertical'; d.sc = p.pos; } else d.hc = p.pos;
        Object.assign(p, { shape: d.shape, sc: d.sc, hc: d.hc, sw: d.sw, sh: d.sh, thick: d.thick });
        delete p.orient; delete p.pos;
      }
    });
    s.isos.forEach((p) => { if (!known.has(p.color)) p.color = 'none'; });
    s.isos = s.isos.filter((p) => known.has(p.field) && p.field !== 'none');
    if (!known.has(s.car.field)) s.car.field = 'none';
  }

  saveState() { store('results-scene', this.state); }

  field(id) { return this.info.fields.find((f) => f.id === id) || { id, label: id, unit: '' }; }

  // fixed range: user value, else the default (0 .. 1.4 U for velocity etc.); 'auto' = min/max of the shown data
  rangeOf(fid) {
    const r = this.state.ranges[fid];
    if (r && r.auto) {
      let lo = Infinity, hi = -Infinity;
      for (const [key, g] of this.geoms.A) {
        if (!g.hasValues || !this.activeKeys.has(key) || g.header.field !== fid) continue;
        lo = Math.min(lo, g.min); hi = Math.max(hi, g.max);
      }
      if (isFinite(lo) && hi > lo) return [lo, hi];
    }
    if (r && r.min != null && r.max != null && r.max > r.min) return [r.min, r.max];
    return this.info.ranges[fid] || [0, 1];
  }

  // ------------------------------------------------------------------ layout
  build() {
    const panel = h('div', { class: 'rt-panel' });
    const stage = h('div', { class: 'rt-stage' });
    this.root = h('div', { class: 'rt-layout' }, panel, stage);
    mount(this.el, this.root);
    this.rv = new ResultView(stage);
    if (!this.rv.ok) {
      mount(stage, h('div', { class: 'empty' }, icon('alert', 'xl'), h('h3', null, 'WebGL 2 is not available'),
        h('div', null, 'Please update the graphics driver or use an up-to-date Edge / Chrome.')));
      return;
    }
    this.rv.mirror = this.state.mirror && this.info.mirror ? this.info.mirror : null;
    this.applyTheme();
    this.stage = stage;
    this.toolbar = h('div', { class: 'rt-toolbar' });
    this.bars = h('div', { class: 'rt-colorbars' });
    this.tip = h('div', { class: 'rt-tip hidden' });
    this.busy = h('div', { class: 'rt-busy hidden' }, h('div', { class: 'spinner' }), h('span'));
    this.peekLabel = h('div', { class: 'rt-peek hidden' });
    this.wiper = h('div', { class: 'rt-wipe hidden' }, h('div', { class: 'rt-wipe-handle' }, icon('compare')),
      this.wipeA = h('span', { class: 'rt-wipe-label a' }), this.wipeB = h('span', { class: 'rt-wipe-label b' }));
    stage.append(this.toolbar, this.bars, this.tip, this.busy, this.peekLabel, this.wiper);
    this.panel = panel;
    this.renderPanel();
    this.renderToolbar();
    this.bindStage();
    const cam = store('results-camera');
    if (cam) Object.assign(this.rv.cam, cam);
    else this.rv.setView('iso', this.carBox());
    this.rv.onCamera = () => { clearTimeout(this._camT); this._camT = setTimeout(() => store('results-camera', this.rv.cam), 400); };
    this.rv.onRender = () => this.positionWipe();
    this.fitHeight();
    this._resize = () => this.fitHeight();
    window.addEventListener('resize', this._resize);
    this._fs = () => { this.root.classList.toggle('rt-fullscreen', document.fullscreenElement === this.root); this.fitHeight(); this.renderToolbar(); };
    document.addEventListener('fullscreenchange', this._fs);
  }

  fitHeight() {
    if (!this.stage) return;
    const full = document.fullscreenElement === this.root;
    const top = this.stage.getBoundingClientRect().top;
    this.stage.style.height = full ? '100vh' : Math.max(480, window.innerHeight - Math.max(top, 120) - 18) + 'px';
    this.panel.style.maxHeight = this.stage.style.height;
    this.rv.redraw();
  }

  applyTheme() {
    const dark = document.documentElement.dataset.theme !== 'light';
    this.rv.background = dark ? [0.075, 0.075, 0.085] : [0.96, 0.97, 0.98];
    this.rv.redraw();
  }

  carBox() {
    const c = this.info.car;
    if (!c) return null;
    if (!this.rv.mirror) return c;
    const [a, v] = this.rv.mirror, mn = c[0].slice(), mx = c[1].slice();
    mn[a] = Math.min(mn[a], 2 * v - c[1][a]); mx[a] = Math.max(mx[a], 2 * v - c[0][a]);
    return [mn, mx];
  }

  // ------------------------------------------------------------------ side panel
  renderPanel() {
    const s = this.state;
    const fieldOpts = (surface) => [['none', surface ? 'Solid colour' : 'No colour (mesh only)']]
      .concat(this.info.fields.filter((f) => (surface ? f.surface : f.volume)).map((f) => [f.id, f.label + (f.unit ? ` [${f.unit}]` : '')]));
    const select = (opts, value, onChange) => {
      const sel = h('select', { class: 'input' }, opts.map(([v, l]) => h('option', { value: v }, l)));
      sel.value = value;
      sel.addEventListener('change', () => onChange(sel.value));
      return sel;
    };
    const row = (...c) => h('div', { class: 'rt-row' }, ...c);
    // surface / mesh colour of the car or a plane: 'auto' follows the theme (mesh: contrasting)
    const colourRow = (obj, auto) => {
      const isSolid = obj.field === 'none';
      if (!isSolid && !obj.edges) return null;
      const solid = obj.solidColor || auto;
      const cur = { solid, edgeColor: obj.meshColor ? hexToEdge(obj.meshColor) : edgesFor(solid, obj.field) };
      const toHex = (c) => '#' + c.slice(0, 3).map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
      const live = () => { clearTimeout(this._colT); this._colT = setTimeout(() => this.applyScene(), 60); };
      const set = (k) => (v) => { obj[k] = v; changed(false); this.renderPanel(); };
      const reset = btn('Auto', { size: 'sm', variant: 'ghost', title: 'Back to the automatic colours (follow light / dark mode)' });
      reset.addEventListener('click', () => { delete obj.solidColor; delete obj.meshColor; changed(false); this.renderPanel(); });
      return h('div', { class: 'rt-colors' },
        isSolid ? h('span', null, 'Colour') : null,
        isSolid ? colorPick(obj.solidColor || cur.solid, set('solidColor'), 'Surface colour', (v) => { obj.solidColor = v; live(); }) : null,
        obj.edges ? h('span', null, 'Mesh') : null,
        obj.edges ? colorPick(obj.meshColor || toHex(cur.edgeColor), set('meshColor'), 'Mesh line colour', (v) => { obj.meshColor = v; live(); }) : null,
        h('span', { class: 'grow' }),
        obj.solidColor || obj.meshColor ? reset : h('span', { class: 'small' }, 'auto'));
    };
    const changed = (resync = true) => { this.saveState(); this.presetName = null; if (resync) this.sync(); else this.applyScene(); };

    // car
    const car = s.car;
    const carCard = h('div', { class: 'rt-item' + (car.visible ? '' : ' off') },
      row(switchEl(car.visible, (v) => { car.visible = v; changed(); this.renderPanel(); }), h('b', { class: 'rt-name' }, 'Car surface'),
        h('label', { class: 'rt-mini', title: 'Show the mesh edges' }, switchEl(car.edges, (v) => { car.edges = v; changed(false); this.renderPanel(); }), 'Mesh')),
      row(select(fieldOpts(true), car.field, (v) => { car.field = v; changed(); this.renderPanel(); })),
      colourRow(car, this.palette().car));

    // slider + number in mm (values in m)
    const slide = (label, title, value, lo, hi, set, step = 1, digits = 1) => {
      const toPos = (v) => Math.round((v - lo) / ((hi - lo) || 1) * 1000);
      const slider = h('input', { type: 'range', min: 0, max: 1000, step: 1, value: toPos(value) });
      const num = h('input', { class: 'input rt-num', value: (value * 1000 / step).toFixed(digits).replace(/\.0+$/, ''), title });
      slider.addEventListener('input', () => { const v = lo + (+slider.value / 1000) * (hi - lo); set(v); num.value = (v * 1000 / step).toFixed(digits).replace(/\.0+$/, ''); });
      slider.addEventListener('change', () => changed());
      num.addEventListener('change', () => { const v = parseFloat(num.value); if (isFinite(v)) { set(v * step / 1000); changed(); this.renderPanel(); } });
      return h('div', { class: 'rt-slide' }, h('span', { class: 'muted small rt-slide-label' }, label), slider, num, h('span', { class: 'muted small' }, 'mm'));
    };

    // flow lines of a plane: colour / opacity / pulses are live, spacing and width rebuild the lines
    const flowBlock = (f) => {
      const live = () => { clearTimeout(this._colT); this._colT = setTimeout(() => this.applyScene(), 30); };
      const hasU = this.info.fields.some((x) => x.id === 'Umag');
      const op = h('input', { type: 'range', min: 5, max: 100, step: 1, value: Math.round(f.opacity * 100) });
      const opNum = h('span', { class: 'muted small rt-pct' }, Math.round(f.opacity * 100) + ' %');
      op.addEventListener('input', () => { f.opacity = +op.value / 100; opNum.textContent = op.value + ' %'; live(); });
      op.addEventListener('change', () => changed(false));
      return h('div', { class: 'rt-sub' },
        h('div', { class: 'rt-sub-title' }, icon('wave', 'sm'), 'Flow lines'),
        row(segmented([{ label: 'Solid', value: 'solid' }].concat(hasU ? [{ label: 'Speed', value: 'speed' }] : []), f.mode,
          (v) => { f.mode = v; changed(false); this.renderPanel(); }),
        h('span', { class: 'grow' }),
        f.mode === 'solid' ? colorPick(f.color, (v) => { f.color = v; changed(false); }, 'Line colour', (v) => { f.color = v; live(); }) : null),
        slide('Spacing', 'Distance between neighbouring lines (mm) - smaller = more lines', f.spacing, 0.001, 0.015, (v) => { f.spacing = Math.max(0.0005, v); }, 1, 1),
        slide('Width', 'Line width (mm) - scales with the screenshot resolution like the geometry', f.width, 0.00005, 0.003, (v) => { f.width = Math.max(0.00002, v); }, 1, 2),
        h('div', { class: 'rt-slide' }, h('span', { class: 'muted small rt-slide-label' }, 'Opacity'), op, opNum),
        row(h('label', { class: 'rt-mini', title: 'Pulses travel along the lines with the local flow speed' },
          switchEl(f.pulse, (v) => { f.pulse = v; changed(); }), 'Animate')));
    };

    // planes
    const planeCards = s.planes.map((p) => {
      const rng = this.sliderRange(p.axis);
      const slider = h('input', { type: 'range', min: 0, max: 1000, step: 1, value: Math.round((p.pos - rng[0]) / (rng[1] - rng[0]) * 1000) });
      const num = h('input', { class: 'input rt-num', value: mm(p.pos), title: 'Position in mm' });
      slider.addEventListener('input', () => {
        p.pos = rng[0] + (+slider.value / 1000) * (rng[1] - rng[0]); num.value = mm(p.pos);
        changed();          // live while dragging: sync() keeps one request at a time, then the newest
      });
      num.addEventListener('change', () => { const v = parseFloat(num.value); if (isFinite(v)) { p.pos = v / 1000; changed(); this.renderPanel(); } });
      const nameEl = h('b', { class: 'rt-name', title: 'Double-click to rename' }, p.name);
      nameEl.addEventListener('dblclick', async () => {
        const inp = h('input', { class: 'input', value: p.name });
        if (await confirmDialog({ title: 'Rename plane', message: inp, confirmLabel: 'Rename' })) { p.name = inp.value.trim() || p.name; changed(false); this.renderPanel(); }
      });
      const del = btn('', { size: 'sm', icon: 'x', variant: 'ghost', title: 'Remove plane' });
      del.addEventListener('click', () => { s.planes = s.planes.filter((x) => x !== p); changed(); this.renderPanel(); });
      return h('div', { class: 'rt-item' + (p.visible ? '' : ' off') },
        row(switchEl(p.visible, (v) => { p.visible = v; changed(); this.renderPanel(); }), nameEl,
          h('label', { class: 'rt-mini', title: 'Flow lines in the plane (direction of the flow inside the plane: vortices, separation, recirculation)' },
            switchEl(p.flow && p.flow.on, (v) => { if (!p.flow) p.flow = this.newFlow(); p.flow.on = v; changed(); this.renderPanel(); }), 'Flow'),
          h('label', { class: 'rt-mini', title: 'Show the mesh edges' }, switchEl(p.edges, (v) => { p.edges = v; changed(false); this.renderPanel(); }), 'Mesh'), del),
        row(segmented(this.viewAxes().map((v) => ({ label: v.label, value: v.axis, title: `${v.label} section (normal to ${AXES[v.axis].toUpperCase()})` })), p.axis, (v) => {
          p.axis = v; const r = this.sliderRange(v); p.pos = (r[0] + r[1]) / 2; changed(); this.renderPanel();
        }), num, h('span', { class: 'muted small' }, 'mm')),
        slider,
        row(select(fieldOpts(false), p.field, (v) => { p.field = v; changed(); this.renderPanel(); })),
        colourRow(p, this.palette().plane),
        p.flow && p.flow.on ? flowBlock(p.flow) : null);
    });
    const colorOpts = [['none', 'Solid colour']].concat(this.info.fields.filter((f) => f.volume).map((f) => [f.id, f.label + (f.unit ? ` [${f.unit}]` : '')]));
    const head = (obj, list, title) => {
      const nameEl = h('b', { class: 'rt-name', title: 'Double-click to rename' }, obj.name);
      nameEl.addEventListener('dblclick', async () => {
        const inp = h('input', { class: 'input', value: obj.name });
        if (await confirmDialog({ title, message: inp, confirmLabel: 'Rename' })) { obj.name = inp.value.trim() || obj.name; changed(false); this.renderPanel(); }
      });
      const del = btn('', { size: 'sm', icon: 'x', variant: 'ghost', title: 'Remove' });
      del.addEventListener('click', () => { s[list] = s[list].filter((x) => x !== obj); changed(); this.renderPanel(); });
      return row(switchEl(obj.visible, (v) => { obj.visible = v; changed(); this.renderPanel(); }), nameEl, h('span', { style: { flex: 1 } }), del);
    };

    // streamlines from seeds just in front of the car
    const streamCards = s.streams.map((st) => {
      const rs = this.sliderRange(this.sideAxis()), ru = this.sliderRange(2);
      const cnt = h('input', { class: 'input rt-num', type: 'number', min: 1, max: 200, value: st.count, title: 'Number of lines' });
      cnt.addEventListener('change', () => { st.count = Math.max(1, Math.min(200, parseInt(cnt.value, 10) || 25)); changed(); this.renderPanel(); });
      return h('div', { class: 'rt-item' + (st.visible ? '' : ' off') },
        head(st, 'streams', 'Rename streamlines'),
        row(segmented([{ label: '↔ Line', value: 'horizontal' }, { label: '↕ Line', value: 'vertical' }, { label: 'Rectangle', value: 'rect' }],
          st.shape, (v) => { st.shape = v; if (v === 'rect' && st.count < 40) st.count = 60; changed(); this.renderPanel(); })),
        slide('Side', 'Centre of the seeds, lateral (mm)', st.sc, rs[0], rs[1], (v) => { st.sc = v; }),
        slide('Up', 'Centre of the seeds, height (mm)', st.hc, ru[0], ru[1], (v) => { st.hc = v; }),
        st.shape !== 'vertical' ? slide('Width', 'Width of the seed line / rectangle (mm)', st.sw, 0, rs[1] - rs[0], (v) => { st.sw = v; }) : null,
        st.shape !== 'horizontal' ? slide('Height', 'Height of the seed line / rectangle (mm)', st.sh, 0, ru[1] - ru[0], (v) => { st.sh = v; }) : null,
        slide('Tube', 'Diameter of the streamlines (mm)', st.thick / 1000, 0, 0.002, (v) => { st.thick = v * 1000; }),
        row(h('span', { class: 'muted small rt-slide-label' }, 'Lines'), cnt),
        row(select(colorOpts, st.field, (v) => { st.field = v; changed(); this.renderPanel(); })),
        row(h('label', { class: 'rt-mini', title: 'Animate the lines with the local flow speed (a screenshot shows the current frame)' },
          switchEl(!!st.anim, (v) => { st.anim = v; changed(false); this.renderPanel(); }), 'Animate')),
        st.anim ? this.animBlock(st, changed, row, select) : null);
    });

    // iso-surfaces, e.g. total pressure = 0 shows the wake and the losses
    const isoCards = s.isos.map((iso) => {
      const f = this.field(iso.field);
      const r = this.info.ranges[iso.field] || [iso.value - 1, iso.value + 1];
      const val = h('input', { class: 'input rt-num', value: fmtVal(iso.value), title: 'Iso value' });
      const slider = h('input', { type: 'range', min: 0, max: 1000, step: 1, value: Math.round((iso.value - r[0]) / (r[1] - r[0]) * 1000) });
      slider.addEventListener('input', () => { iso.value = r[0] + (+slider.value / 1000) * (r[1] - r[0]); val.value = fmtVal(iso.value); });
      slider.addEventListener('change', () => changed());
      val.addEventListener('change', () => { const v = parseFloat(val.value); if (isFinite(v)) { iso.value = v; changed(); this.renderPanel(); } });
      return h('div', { class: 'rt-item' + (iso.visible ? '' : ' off') },
        head(iso, 'isos', 'Rename iso-surface'),
        row(select(colorOpts.filter(([v]) => v !== 'none'), iso.field, (v) => {
          iso.field = v;
          const rr = this.info.ranges[v] || [0, 1];
          iso.value = v === 'p0' ? 0 : (rr[0] + rr[1]) / 2;
          changed(); this.renderPanel();
        })),
        row(h('span', { class: 'muted small' }, '='), val, h('span', { class: 'muted small' }, f.unit)),
        slider,
        row(h('span', { class: 'muted small' }, 'Colour'), select(colorOpts, iso.color, (v) => { iso.color = v; changed(); this.renderPanel(); })),
        h('div', { class: 'muted small' }, 'Each new value is calculated once (a few seconds), then it is cached.'));
    });

    const nextId = (list) => Math.max(0, ...list.map((x) => x.id)) + 1;
    const add = btn('Add', { size: 'sm', icon: 'plus', caret: true });
    add.addEventListener('click', () => showMenu(add, [
      { label: 'Section plane', icon: 'layers', onClick: () => {
        const id = nextId(s.planes);
        const c = this.info.car || [[0, 0, 0], [0.05, 0.25, 0.05]];
        s.planes.push({ id, name: 'Plane ' + id, visible: true, axis: 0, pos: (c[0][0] + c[1][0]) / 2, field: (s.planes[0] || {}).field || this.volumeField(), edges: false });
        changed(); this.renderPanel();
      } },
      { label: 'Streamlines', sub: 'Seed line in front of the car', icon: 'wave', onClick: () => { s.streams.push(this.newStream(nextId(s.streams))); changed(); this.renderPanel(); } },
      { label: 'Iso-surface', sub: 'e.g. total pressure = 0: the wake', icon: 'cube', onClick: () => { s.isos.push(this.newIso(nextId(s.isos))); changed(); this.renderPanel(); } },
    ]));

    // colour ranges of the fields in use
    const used = this.usedFields();
    const ranges = used.map((fid) => {
      const f = this.field(fid);
      const r = s.ranges[fid] || (s.ranges[fid] = {});
      const cur = this.rangeOf(fid);
      const lo = h('input', { class: 'input rt-num', value: fmtVal(cur[0]), disabled: !!r.auto });
      const hi = h('input', { class: 'input rt-num', value: fmtVal(cur[1]), disabled: !!r.auto });
      const apply = () => { const a = parseFloat(lo.value), b = parseFloat(hi.value); if (isFinite(a) && isFinite(b) && b > a) { r.min = a; r.max = b; changed(false); } };
      lo.addEventListener('change', apply); hi.addEventListener('change', apply);
      const reset = btn('', { size: 'sm', icon: 'undo', variant: 'ghost', title: 'Default range' });
      reset.addEventListener('click', () => { delete s.ranges[fid]; changed(false); this.renderPanel(); });
      return h('div', { class: 'rt-item' },
        row(h('b', { class: 'rt-name' }, f.label), h('label', { class: 'rt-mini', title: 'Range from the data shown (not comparable between simulations)' },
          switchEl(!!r.auto, (v) => { r.auto = v; changed(false); this.renderPanel(); }), 'Auto'), reset),
        row(lo, h('span', { class: 'muted' }, '–'), hi, h('span', { class: 'muted small' }, f.unit)));
    });

    // comparison
    const dated = (n) => (/^\d{8}/.test(n) ? '1' : '0') + n;
    const others = this.ctx.app.cases.filter((c) => c.name !== this.ctx.name && (c.status === 'finished' || c.status === 'stopped'))
      .map((c) => c.name).sort((a, b) => dated(b).localeCompare(dated(a)));
    if (!this.compare.other) this.compare.other = others.includes(this.ctx.data.meta.origin) ? this.ctx.data.meta.origin : others[0] || null;
    const cmpSel = select(others.map((n) => [n, splitName(n).rest + (n === this.ctx.data.meta.origin ? '  (origin)' : '')]), this.compare.other || '', (v) => {
      this.compare.other = v; this.compare.info = null; this.dropScene('B'); this.sync();
    });
    const modes = [{ label: 'Off', value: 'off' }, { label: 'Peek', value: 'peek' }, { label: 'Wipe', value: 'wipe' }, { label: 'Δ', value: 'diff' }];
    const modeHint = { off: 'Compare the same view with another simulation.', peek: 'Hold the Space bar (or the B button) to see the other simulation.',
      wipe: 'Drag the divider: left this simulation, right the other one.', diff: 'Colour = this minus the other simulation (blue: lower, red: higher).' };
    const diffScale = h('input', { type: 'range', min: 2, max: 60, value: Math.round(this.rv.diffScale * 100) });
    diffScale.addEventListener('input', () => { this.rv.diffScale = +diffScale.value / 100; this.drawBars(); this.rv.redraw(); });
    const cmp = h('div', { class: 'rt-item' },
      row(h('b', { class: 'rt-name' }, 'Compare with')),
      others.length ? row(cmpSel) : h('div', { class: 'muted small' }, 'No other finished simulation.'),
      row(segmented(modes, this.compare.mode, (v) => { this.compare.mode = v; store('res-cmp-mode', v); this.applyCompare(); this.renderPanel(); })),
      h('div', { class: 'muted small' }, modeHint[this.compare.mode]),
      this.compare.mode === 'diff' ? row(h('span', { class: 'muted small' }, 'Scale ±'), diffScale, h('span', { class: 'muted small' }, 'of range')) : null);

    // ParaView for everything the built-in viewer does not do
    const hasPv = !!this.ctx.app.info.paraview;
    const pvBtn = btn('Open in ParaView', { size: 'sm', icon: 'external', disabled: !hasPv });
    pvBtn.addEventListener('click', () => this.ctx.view.open('paraview'));
    const pvCard = h('div', { class: 'rt-item' },
      row(h('b', { class: 'rt-name' }, 'ParaView'), h('span', { style: { flex: 1 } }), pvBtn),
      h('div', { class: 'muted small' }, hasPv ? 'Opens this simulation with your analysis preset (Settings → ParaView state preset).'
        : 'ParaView was not found on this computer.'));

    const scroll = this.panel.scrollTop;
    mount(this.panel,
      h('div', { class: 'rt-section' }, h('span', null, 'Objects'), add),
      carCard, ...planeCards, ...streamCards, ...isoCards,
      used.length ? h('div', { class: 'rt-section' }, h('span', null, 'Colour range')) : null, ...ranges,
      this.ctx.app.can('compare') ? [h('div', { class: 'rt-section' }, h('span', null, 'Compare')), cmp] : null,
      h('div', { class: 'rt-section' }, h('span', null, 'External')), pvCard,
      h('div', { class: 'muted small', style: { padding: '8px 4px' } },
        `Results at iteration ${this.info.time} · ρ = ${this.info.rho} kg/m³` + (this.info.speed ? ` · U∞ = ${fmtVal(this.info.speed)} m/s` : '')));
    this.panel.scrollTop = scroll;
  }

  // area covered by flow lines: well around the car and far into the wake (inside the domain)
  flowRange(axis) {
    const d = this.info.domain, c = this.info.car;
    if (!c) return d ? [d[0][axis], d[1][axis]] : [0, 1];
    const len = Math.max(...[0, 1, 2].map((k) => c[1][k] - c[0][k]));
    let lo = c[0][axis] - (axis === this.flowAxis ? 0.4 : 0.5) * len, hi = c[1][axis] + (axis === this.flowAxis ? 1.2 : 0.5) * len;
    if (d) { lo = Math.max(lo, d[0][axis]); hi = Math.min(hi, d[1][axis]); }
    return [lo, hi];
  }

  // section planes named like the views: Front = across the flow, Top = normal to up, Side = the rest
  viewAxes() {
    const up = 2, fa = this.flowAxis === up ? 1 : this.flowAxis;
    const side = [0, 1, 2].find((k) => k !== up && k !== fa);
    return [{ label: 'Side', axis: side }, { label: 'Top', axis: up }, { label: 'Front', axis: fa }];
  }

  sliderRange(axis) {
    const d = this.info.domain, c = this.info.car;
    if (!c) return d ? [d[0][axis], d[1][axis]] : [0, 1];
    const m = 0.6 * (c[1][axis] - c[0][axis]);
    let lo = c[0][axis] - m, hi = c[1][axis] + m;
    if (axis === this.flowAxis) hi = c[1][axis] + 2 * (c[1][axis] - c[0][axis]);
    if (d) { lo = Math.max(lo, d[0][axis]); hi = Math.min(hi, d[1][axis]); }
    return [lo, hi];
  }

  // ------------------------------------------------------------------ toolbar
  renderToolbar() {
    const views = btn('View', { size: 'sm', icon: 'eye', caret: true });
    views.addEventListener('click', () => showMenu(views, this.viewMenu()));
    const saved = btn('Views', { size: 'sm', icon: 'bookmark', caret: true, title: 'Saved views: camera + everything in the left panel, for all simulations' });
    saved.addEventListener('click', () => showMenu(saved, this.savedMenu()));
    const mirror = btn('Mirror', { size: 'sm', icon: 'compare', title: 'Show both halves of the car', variant: this.state.mirror ? 'primary' : '', disabled: !this.info.mirror });
    mirror.addEventListener('click', () => {
      this.state.mirror = !this.state.mirror; this.saveState();
      this.rv.mirror = this.state.mirror ? this.info.mirror : null; this.rv.redraw(); this.renderToolbar();
    });
    const ortho = btn('Parallel', { size: 'sm', icon: 'cube', variant: this.rv.cam.ortho ? 'primary' : '',
      title: 'Parallel projection (no perspective): e.g. in the side view both wheels lie exactly on top of each other' });
    ortho.addEventListener('click', () => {
      this.rv.cam.ortho = !this.rv.cam.ortho; store('results-camera', this.rv.cam);
      this.rv.redraw(); this.renderToolbar();
    });
    const shot = btn('Screenshot', { size: 'sm', icon: 'save', title: 'Save a clean image (same colours as on screen) to the Screenshots folder' });
    shot.addEventListener('click', () => this.screenshot());
    const shotMenu = btn('', { size: 'sm', icon: 'chevDown', title: 'Resolution, background, batch, folder' });
    shotMenu.addEventListener('click', () => {
      const cur = store('res-shot-res') || '3840x2160', bg = this.shotBgName();
      showMenu(shotMenu, [
        { label: 'Resolution', header: true },
        ...RES.map(([v, l]) => ({ label: l, icon: v === cur ? 'check' : null, onClick: () => store('res-shot-res', v) })),
        '-',
        { label: 'Background', header: true },
        ...[['white', 'White'], ['black', 'Black']].map(([v, l]) => ({ label: l, icon: v === bg ? 'check' : null, onClick: () => store('res-shot-bg', v) })),
        '-',
        ...(this.ctx.app.can('batch_screenshots') ? [{ label: 'Batch screenshot...', sub: 'Same view for several simulations', icon: 'stack', onClick: () => this.batchDialog() }] : []),
        { label: 'Open Screenshots folder', icon: 'folder', onClick: () => api.post('open', { what: 'screenshots' }).catch(toastError) },
      ]);
    });
    const peek = btn('B', { size: 'sm', title: 'Hold to show the other simulation (or hold the Space bar)' });
    peek.addEventListener('mousedown', () => this.peek(true));
    peek.addEventListener('mouseup', () => this.peek(false));
    peek.addEventListener('mouseleave', () => this.peek(false));
    const full = document.fullscreenElement === this.root;
    const fs = btn('', { size: 'sm', icon: 'fit', title: full ? 'Exit full screen (Esc)' : 'Full screen', variant: full ? 'primary' : '' });
    fs.addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); else this.root.requestFullscreen().catch(() => {}); });
    const recOn = !!this.rv.rec;
    const rec = btn(recOn ? 'Stop' : 'Record', { size: 'sm', icon: recOn ? 'stop' : 'record', variant: recOn ? 'danger' : '',
      cls: 'rt-rec' + (recOn ? ' on' : ''), title: recOn ? 'Stop: the video is then rendered and saved' : 'Record a video (Full HD, exactly 60 fps, background as for screenshots): move the camera, press Stop, the video is rendered afterwards' });
    rec.addEventListener('click', () => (this.rv.rec ? this.stopRecording() : this.startRecording()));
    if (recOn) this.recBtn = rec.lastChild;
    const recMenu = btn('', { size: 'sm', icon: 'chevDown', title: 'Camera flight through saved views', disabled: recOn });
    recMenu.addEventListener('click', () => showMenu(recMenu, [
      { label: 'Record', icon: 'record', sub: 'Move the camera yourself, Stop ends it', onClick: () => this.startRecording() },
      { label: 'Flight through saved views...', icon: 'bookmark', sub: 'Smooth camera flight, rendered frame by frame at 60 fps', onClick: () => this.flightDialog() },
    ]));
    mount(this.toolbar, views, saved, ortho, mirror, h('span', { class: 'rt-sep' }),
      this.compare.mode === 'peek' ? peek : null,
      this.ctx.app.can('video') ? h('div', { class: 'btn-group' }, rec, recMenu) : null,
      h('div', { class: 'btn-group' }, shot, shotMenu), fs);
  }

  viewMenu() {
    const box = () => this.carBox();
    return [
      { label: 'Camera', header: true },
      ...[['iso', 'Perspective'], ['top', 'Top'], ['side', 'Side'], ['front', 'Front'], ['rear', 'Rear']].map(([v, l]) => ({
        label: l, onClick: () => { this.rv.setView(v, box()); this.presetName = l; store('results-camera', this.rv.cam); } })),
      { label: 'Fit to car', icon: 'fit', onClick: () => this.rv.fitBox(box()) },
      '-',
      { label: 'Reset objects to default', icon: 'undo', onClick: () => { this.state = this.defaultState(); this.saveState(); this.renderPanel(); this.sync(); } },
    ];
  }

  // saved views: camera (incl. parallel) + everything in the left panel (objects, flow lines,
  // colour ranges, mirror); stored in the config, so they work for every simulation
  savedMenu() {
    const presets = (this.ctx.app.info.config.result_presets || []).slice().sort((a, b) => a.name.localeCompare(b.name));
    return [
      { label: 'Load view', header: true },
      ...(presets.length ? presets.map((p) => ({ label: p.name, icon: p.name === this.presetName ? 'check' : null,
        sub: summary(p.state), onClick: () => this.applyPreset(p) })) : [{ label: 'No saved views yet', disabled: true }]),
      '-',
      { label: 'Save current view...', icon: 'save', onClick: () => this.savePreset() },
      presets.length ? { label: 'Delete a saved view...', icon: 'trash', onClick: () => this.deletePreset() } : null,
      '-',
      presets.length ? { label: 'Export views to file...', icon: 'download', sub: 'Share them with the team / another PC', onClick: () => this.exportPresets() } : null,
      { label: 'Import views from file...', icon: 'upload', onClick: () => this.importPresets() },
    ].filter(Boolean);
  }

  exportPresets() {
    const views = this.ctx.app.info.config.result_presets || [];
    const blob = new Blob([JSON.stringify({ app: 'Flowforge Studio', kind: 'result-views', version: 1, views }, null, 1)], { type: 'application/json' });
    const a = h('a', { href: URL.createObjectURL(blob), download: 'flowforge_studio_views.json' });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast('Views exported', `${views.length} view(s) → flowforge_studio_views.json (Downloads)`, 'ok', 4000);
  }

  importPresets() {
    const inp = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden' });
    inp.addEventListener('change', async () => {
      const f = inp.files[0];
      inp.remove();
      if (!f) return;
      try {
        const data = JSON.parse(await f.text());
        const views = (Array.isArray(data) ? data : data.views || []).filter((v) => v && typeof v.name === 'string' && v.cam && v.state && Array.isArray(v.state.planes));
        if (!views.length) throw new Error('No Flowforge Studio views found in this file.');
        const names = new Set(views.map((v) => v.name));
        const list = (this.ctx.app.info.config.result_presets || []).filter((p) => !names.has(p.name)).concat(views);
        await this.storePresets(list);
        toast('Views imported', `${views.length} view(s) from ${f.name}` + ' (same names were replaced)', 'ok', 5000);
      } catch (e) { toastError(e, 'Import failed'); }
    });
    document.body.appendChild(inp);
    inp.click();
  }

  async savePreset() {
    const own = (this.ctx.app.info.config.result_presets || []).some((p) => p.name === this.presetName);
    const inp = h('input', { class: 'input', placeholder: 'e.g. Floor flow, wake 50 mm', value: own ? this.presetName : '' });
    setTimeout(() => inp.focus(), 50);
    if (!await confirmDialog({ title: 'Save view', message: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } },
      'Stores the camera and everything in the left panel (car, planes with flow lines, streamlines, iso-surfaces, colour ranges, mirror). '
      + 'Saved views work for every simulation. An existing name is overwritten.'), inp), confirmLabel: 'Save' })) return;
    const name = inp.value.trim();
    if (!name) return;
    const list = (this.ctx.app.info.config.result_presets || []).filter((p) => p.name !== name);
    list.push({ name, cam: { ...this.rv.cam, target: this.rv.cam.target.slice() }, state: JSON.parse(JSON.stringify(this.state)) });
    await this.storePresets(list);
    this.presetName = name;
    toast('View saved', name, 'ok', 2500);
  }

  async deletePreset() {
    const list = this.ctx.app.info.config.result_presets || [];
    const sel = h('select', { class: 'input' }, list.map((p) => h('option', { value: p.name }, p.name)));
    if (!await confirmDialog({ title: 'Delete saved view', message: sel, confirmLabel: 'Delete', danger: true })) return;
    await this.storePresets(list.filter((p) => p.name !== sel.value));
  }

  async storePresets(list) {
    try {
      const r = await api.post('config', { updates: { result_presets: list } });
      this.ctx.app.info.config = r.config;
    } catch (e) { toastError(e, 'Could not save the view'); }
  }

  applyPreset(p) {
    this.state = JSON.parse(JSON.stringify(p.state));
    this.state.v = STATE_VERSION;
    this.checkFields(this.state);
    this.saveState();
    Object.assign(this.rv.cam, p.cam, { target: p.cam.target.slice() });
    this.renderToolbar();
    store('results-camera', this.rv.cam);
    this.rv.mirror = this.state.mirror && this.info.mirror ? this.info.mirror : null;
    this.presetName = p.name;
    this.renderPanel(); this.renderToolbar(); this.sync();
  }

  // ------------------------------------------------------------------ data
  palette() { return PALETTE[document.documentElement.dataset.theme === 'light' ? 'light' : 'dark']; }

  layerSpecs(stateOverride) {
    const s = stateOverride || this.state;
    const pal = this.palette();
    const out = [];
    const colours = (cfg, auto) => {
      const solid = cfg.solidColor || auto;
      return { solid, edgeColor: cfg.meshColor ? hexToEdge(cfg.meshColor) : edgesFor(solid, cfg.field) };
    };
    if (s.car.visible) out.push(Object.assign({ key: 'car|' + s.car.field, kind: 'surface', field: s.car.field, cfg: s.car, lit: true }, colours(s.car, pal.car)));
    for (const p of s.planes) {
      if (!p.visible) continue;
      out.push(Object.assign({ key: `plane|${p.axis}|${p.pos.toFixed(7)}|${p.field}`, kind: 'slice', field: p.field, cfg: p, lit: false }, colours(p, pal.plane)));
      const f = p.flow;
      if (f && f.on) {
        // animated: the ribbon is wider than the line to make room for the drops
        const wide = f.pulse ? DROP_WIDE : 1;
        out.push({ key: `flow|${p.axis}|${p.pos.toFixed(7)}|${f.spacing.toFixed(6)}|${(f.width * wide).toFixed(6)}`, kind: 'flow', cfg: p, edges: false,
          field: f.mode === 'speed' ? 'Umag' : 'none', solid: f.color, lit: false, opacity: f.opacity, pulse: f.pulse, wide,
          pulseLen: dropPeriod(f, this.info.speed) });
      }
    }
    for (const st of s.streams || []) {
      if (!st.visible) continue;
      out.push({ key: `stream|${st.shape}|${[st.sc, st.hc, st.sw, st.sh].map((v) => v.toFixed(6)).join('|')}|${st.count}|${st.thick}|${st.field}`, kind: 'stream', field: st.field, cfg: st, lit: true, solid: STREAM_COLOR,
        comet: st.anim ? Object.assign({}, this.animFx(st), { period: (['reveal', 'travel'].includes(this.animFx(st).style) ? 1 : this.animFx(st).spacing) * cometPeriod(this.info.car, this.info.speed) }) : null });
    }
    for (const iso of s.isos || []) {
      if (!iso.visible) continue;
      out.push({ key: `iso|${iso.field}|${iso.value}|${iso.color}`, kind: 'iso', field: iso.color, cfg: iso, lit: true, solid: ISO_COLOR });
    }
    return out;
  }

  async fetchGeom(scene, caseName, spec, rho) {
    const map = this.geoms[scene];
    if (map.has(spec.key)) return map.get(spec.key);
    if (spec.kind === 'flow') {
      const g = await this.flowGeom(caseName, spec.cfg);
      if (this.dead || !g) return null;
      map.set(spec.key, g);
      this.lastKey.set(spec.cfg, spec.key);
      return g;
    }
    const params = { name: caseName, field: spec.field, rho };
    const c = spec.cfg;
    const r = spec.kind === 'surface' ? await api.getBinary('results/surface', params)
      : spec.kind === 'stream' ? await api.getBinary('results/streamlines', Object.assign(params, { shape: c.shape, sc: c.sc, hc: c.hc, sw: c.sw, sh: c.sh, count: c.count, thick: c.thick }))
        : spec.kind === 'iso' ? await api.getBinary('results/iso', Object.assign(params, { field: c.field, value: c.value, color: c.color }))
          : await api.getBinary('results/slice', Object.assign(params, { axis: AXES[c.axis], pos: c.pos }));
    if (this.dead) return null;
    const g = this.rv.upload(r.buffer);
    map.set(spec.key, g);
    this.lastKey.set(spec.cfg, spec.key);
    return g;
  }

  // flow lines of a plane: velocity at the plane corners from the server (cached per plane),
  // lines traced here (cached per spacing), ribbons rebuilt for each width
  async flowGeom(caseName, c) {
    const f = c.flow, dk = `${caseName}|${c.axis}|${c.pos.toFixed(7)}`;
    let d = this.flowData.get(dk);
    if (!d) {
      const r = await api.getBinary('results/planeflow', { name: caseName, axis: AXES[c.axis], pos: c.pos });
      d = { data: parsePlaneFlow(r.buffer), lines: new Map() };
      this.flowData.set(dk, d);
      while (this.flowData.size > 4) this.flowData.delete(this.flowData.keys().next().value);
    }
    const lk = f.spacing.toFixed(6);
    let lines = d.lines.get(lk);
    if (!lines) {
      const [ia, ib] = planeAxes(c.axis);
      await new Promise((r) => setTimeout(r, 0));
      lines = traceLines(d.data, c.axis, [this.flowRange(ia), this.flowRange(ib)], f.spacing, this.info.speed);
      d.lines.set(lk, lines);
      while (d.lines.size > 3) d.lines.delete(d.lines.keys().next().value);
    }
    if (this.dead) return null;
    return this.rv.uploadFlow(ribbons(lines, c.axis, c.pos, f.width * (f.pulse ? DROP_WIDE : 1), dropPeriod(f, this.info.speed)), { kind: 'flow', field: 'Umag' });
  }

  // make the GPU scene match the panel; newest request wins, slow first loads show a notice
  async sync() {
    if (!this.rv || !this.rv.ok) return;
    if (this._syncing) { this._syncAgain = true; this.applyScene(); return; }
    this._syncing = true;
    try { await this.syncOnce(); } finally { this._syncing = false; }
    if (this._syncAgain && !this.dead) { this._syncAgain = false; this.sync(); }
  }

  async syncOnce() {
    const gen = (this._gen = (this._gen || 0) + 1);
    const specs = this.layerSpecs();
    this.activeKeys = new Set(specs.map((s) => s.key));
    this.applyScene();
    const missing = specs.filter((s) => !this.geoms.A.has(s.key));
    const slow = setTimeout(() => this.setBusy('Computing (the first time for a simulation can take up to ~30 s)...'), 900);
    try {
      for (const s of missing) {
        if (gen !== this._gen) return;
        await this.fetchGeom('A', this.ctx.name, s, this.info.rho);
        if (gen === this._gen) this.applyScene();
      }
      this.prune('A', this.activeKeys);
      if (this.compare.mode !== 'off') await this.syncB(gen);
    } catch (e) {
      toastError(e, 'Could not load the results');
    } finally {
      clearTimeout(slow);
      if (gen === this._gen) this.setBusy(null);
    }
  }

  async syncB(gen) {
    if (!this.compare.other) return;
    if (!this.compare.info) this.compare.info = await api.get('results/info', { name: this.compare.other });
    if (!this.compare.info.time) { toast('No results', this.compare.other + ' has no results to compare.', 'warn'); return; }
    // same air density for both, the colour ranges are shared anyway
    for (const s of this.layerSpecs()) {
      if (gen !== this._gen) return;
      await this.fetchGeom('B', this.compare.other, s, this.info.rho);
      if (gen === this._gen) this.applyScene();
    }
    this.prune('B', this.activeKeys);
  }

  prune(scene, keep) {
    const map = this.geoms[scene];
    // the geometry still shown for a layer that is loading anew (see toLayers) stays too
    keep = new Set(keep);
    for (const s of this.layerSpecs()) if (!map.has(s.key) && this.lastKey.has(s.cfg)) keep.add(this.lastKey.get(s.cfg));
    for (const [k, g] of map) if (!keep.has(k)) { this.rv.free(g); map.delete(k); }
  }

  dropScene(scene) {
    for (const g of this.geoms[scene].values()) this.rv.free(g);
    this.geoms[scene].clear();
    this.rv.scenes[scene] = [];
    this.rv.redraw();
  }

  toLayers(scene, specs) {
    return specs.map((s) => ({
      geom: this.geoms[scene].get(s.key) || this.geoms[scene].get(this.lastKey.get(s.cfg)) || null, visible: true, lit: s.lit, solid: s.solid,
      edges: s.edges != null ? s.edges : s.cfg.edges, edgeColor: s.edgeColor, field: s.field,
      opacity: s.opacity, pulse: s.pulse, pulseLen: s.pulseLen, wide: s.wide, comet: s.comet, key: s.key,
      range: s.field !== 'none' ? this.rangeOf(s.field) : null,
    }));
  }

  applyScene() {
    if (!this.rv) return;
    const specs = this.layerSpecs();
    this.activeKeys = new Set(specs.map((s) => s.key));
    this.rv.scenes.A = this.toLayers('A', specs);
    this.rv.scenes.B = this.compare.mode !== 'off' ? this.toLayers('B', specs) : [];
    this.applyCompare(false);
    this.drawBars();
    this.rv.redraw();
  }

  setBusy(text) {
    this.busyText = text;
    if (!this.busy) return;
    this.busy.classList.toggle('hidden', !text);
    if (text) this.busy.lastChild.textContent = text;
  }

  // ------------------------------------------------------------------ comparison
  applyCompare(resync = true) {
    const m = this.compare.mode;
    this.rv.mode = m === 'wipe' ? 'wipe' : m === 'diff' ? 'diff' : 'normal';
    if (m !== 'peek') this.rv.mix = 0;
    this.wiper.classList.toggle('hidden', m !== 'wipe');
    this.wipeA.textContent = splitName(this.ctx.name).rest;
    this.wipeB.textContent = splitName(this.compare.other || '').rest;
    this.positionWipe();
    if (resync) { this.renderToolbar(); if (m === 'off') this.dropScene('B'); else this.sync(); }
    this.drawBars();
    this.rv.redraw();
  }

  peek(on) {
    if (this.compare.mode !== 'peek' || !this.rv.scenes.B.length) return;
    if (this._peekOn === on) return;
    this._peekOn = on;
    const from = this.rv.mix, to = on ? 1 : 0, t0 = performance.now();
    cancelAnimationFrame(this._peekRaf);
    const step = () => {
      const f = Math.min(1, (performance.now() - t0) / 140);
      this.rv.mix = from + (to - from) * f;
      this.rv.redraw();
      if (f < 1) this._peekRaf = requestAnimationFrame(step);
    };
    step();
    this.peekLabel.textContent = on ? 'B: ' + splitName(this.compare.other).rest : '';
    this.peekLabel.classList.toggle('hidden', !on);
  }

  positionWipe() {
    if (!this.wiper || this.wiper.classList.contains('hidden')) return;
    this.wiper.style.left = (this.rv.wipe * 100) + '%';
  }

  // ------------------------------------------------------------------ stage interaction
  bindStage() {
    const c = this.rv.canvas;
    let last = 0;
    c.addEventListener('mousemove', (e) => {
      if (this.rv.dragging()) { this.tip.classList.add('hidden'); return; }
      const now = performance.now();
      if (now - last < 70) return;
      last = now;
      this.hover(e);
    });
    c.addEventListener('mouseleave', () => this.tip.classList.add('hidden'));
    // wipe divider
    let dragging = false;
    this.wiper.addEventListener('mousedown', (e) => { dragging = true; e.preventDefault(); });
    this._wmove = (e) => {
      if (!dragging) return;
      const r = this.stage.getBoundingClientRect();
      this.rv.wipe = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      this.positionWipe(); this.rv.redraw();
    };
    this._wup = () => { dragging = false; };
    window.addEventListener('mousemove', this._wmove);
    window.addEventListener('mouseup', this._wup);
    // Space = peek (not while typing)
    // Space = peek, also right after clicking a button, switch, slider or list in the panel (they
    // keep the keyboard focus); only real text fields (e.g. a rename dialog) keep their Space
    this._key = (e) => {
      if (e.code !== 'Space' || this.compare.mode !== 'peek' || !this.root.isConnected) return;
      const t = e.target || {};
      const textField = t.isContentEditable || t.tagName === 'TEXTAREA'
        || (t.tagName === 'INPUT' && /^(text|search|email|password|url|)$/.test(t.type || '') && !t.classList.contains('rt-num'));
      if (textField || document.querySelector('.modal-backdrop')) return;
      e.preventDefault();
      if (t.blur && t !== document.body) t.blur();
      this.peek(e.type === 'keydown');
    };
    window.addEventListener('keydown', this._key);
    window.addEventListener('keyup', this._key);
  }

  hover(e) {
    const r = this.rv.canvas.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    const scene = this.rv.mix >= 0.5 ? 'B' : (this.rv.mode === 'wipe' && x / r.width > this.rv.wipe ? 'B' : 'A');
    const hit = this.rv.pick(x, y, scene);
    const layer = hit ? this.rv.scenes[scene][hit.layer] : null;
    if (!hit || !layer || layer.field === 'none' || hit.t == null) { this.tip.classList.add('hidden'); return; }
    const f = this.field(layer.field), [lo, hi] = layer.range;
    const v = lo + hit.t * (hi - lo);
    let text = `${f.label}: ${fmtVal(v)} ${f.unit}`;
    if (this.rv.mode === 'diff') {
      const hb = this.rv.pick(x, y, 'B');
      if (hb && hb.t != null && hb.layer === hit.layer) text += `  ·  Δ ${fmtVal((hit.t - hb.t) * (hi - lo))} ${f.unit}`;
    }
    this.tip.textContent = text;
    this.tip.style.left = (x + 14) + 'px';
    this.tip.style.top = (y + 12) + 'px';
    this.tip.classList.remove('hidden');
  }

  // colour bars (screen only, never in screenshots)
  drawBars() {
    clear(this.bars);
    const used = this.usedFields();
    const bar = (title, lo, hi, map, unit) => {
      const cv = h('canvas', { width: 220, height: 12 });
      const ctx = cv.getContext('2d');
      for (let i = 0; i < 220; i++) { const c = colormapAt(map, i / 219); ctx.fillStyle = `rgb(${c[0] * 255},${c[1] * 255},${c[2] * 255})`; ctx.fillRect(i, 0, 1, 12); }
      return h('div', { class: 'rt-bar' }, h('div', { class: 'rt-bar-title' }, title), cv,
        h('div', { class: 'rt-bar-scale' }, h('span', null, fmtVal(lo)), h('span', null, fmtVal((lo + hi) / 2)), h('span', null, fmtVal(hi) + (unit ? ' ' + unit : ''))));
    };
    for (const fid of used) {
      const f = this.field(fid), [lo, hi] = this.rangeOf(fid);
      if (this.rv.mode === 'diff') {
        const d = this.rv.diffScale * (hi - lo);
        this.bars.appendChild(bar('Δ ' + f.label + ' (this − other)', -d, d, 'coolWarm', f.unit));
      } else this.bars.appendChild(bar(f.label, lo, hi, 'rainbowDesat', f.unit));
    }
  }

  // ------------------------------------------------------------------ screenshots
  shotSize() {
    const [w, hgt] = (store('res-shot-res') || '3840x2160').split('x').map(Number);
    return [w, hgt];
  }

  shotBgName() { return SHOT_BG[store('res-shot-bg')] ? store('res-shot-bg') : 'white'; }

  fileParts(caseName) {
    const fields = this.usedFields();
    const mode = this.rv.mode === 'diff' ? 'diff-vs-' + splitName(this.compare.other || '').rest : this.rv.mode === 'wipe' ? 'wipe-vs-' + splitName(this.compare.other || '').rest : null;
    return [stamp(), splitName(caseName).rest, this.presetName || 'view', fields.join('+') || 'geometry', mode];
  }

  async screenshot() {
    const [w, hgt] = this.shotSize();
    this.setBusy('Rendering screenshot...');
    await new Promise((r) => setTimeout(r, 30));
    try {
      // same colours as on screen, only the background is replaced
      const png = this.rv.screenshot(w, hgt, { background: SHOT_BG[this.shotBgName()] });
      const r = await api.post('results/screenshot', { png, parts: this.fileParts(this.ctx.name) });
      toast('Screenshot saved', `Screenshots/${r.file}  (${w} × ${hgt})`, 'ok', 5000);
    } catch (e) { toastError(e, 'Screenshot failed'); } finally { this.setBusy(null); }
  }

  // ------------------------------------------------------------------ video
  // video: Full HD, 60 fps. Live (camera by hand) or a camera flight rendered frame by frame
  async startRecording(flight) {
    if (this.rv.rec) return;
    try {
      await this.rv.beginRecording(1920, 1080, { background: SHOT_BG[this.shotBgName()] });
    } catch (e) { toastError(e, 'Recording not possible'); return; }
    this.recParts = this.fileParts(this.ctx.name);
    this.renderToolbar();
    const fmt = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
    const tick = () => {
      const st = this.rv && this.rv.recording();
      if (!st) return;
      if (this.recBtn) this.recBtn.textContent = (st.rendering ? 'Rendering  ' : 'Stop  ') + fmt(st.t) + (st.total ? ` / ${fmt(st.total)}` : '');
      this.recTimer = setTimeout(tick, 250);
    };
    tick();
    if (flight) {
      let blob = null;
      try { blob = await this.rv.recordFlight(flight); } catch (e) { toastError(e, 'Recording failed'); }
      this.afterRecording(blob);
    }
  }

  async stopRecording() {
    if (!this.rv || !this.rv.rec) return;
    if (this.rv.rec.flight || this.rv.rec.rendering) { this.rv.stopRecording(); return; }   // ends and saves what it has
    let blob = null;
    try { blob = await this.rv.stopRecording(); } catch (e) { toastError(e, 'Recording failed'); }
    this.afterRecording(blob);
  }

  async afterRecording(blob) {
    clearTimeout(this.recTimer);
    if (!this.dead) { this.renderToolbar(); this.applyScene(); }
    if (!blob || !blob.size) { toast('No video', 'Nothing was recorded.', 'warn'); return; }
    const parts = this.recParts || this.fileParts(this.ctx.name);
    if (!this.dead) this.setBusy('Saving video...');
    try {
      const r = await api.upload('results/video', { ext: 'mp4', parts: JSON.stringify(parts) }, blob,
        (p) => { if (!this.dead) this.setBusy(`Saving video... ${Math.round(p * 100)} %`); });
      toast('Video saved', `Screenshots/${r.file}  (${(blob.size / 1048576).toFixed(1)} MB)`, 'ok', 6000);
    } catch (e) {
      // older server (not restarted yet): the browser downloads it instead
      const a = h('a', { href: URL.createObjectURL(blob), download: parts.filter(Boolean).join('_') + '.mp4' });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      toast('Video downloaded', 'Saved to your Downloads folder (restart Flowforge Studio to save videos to the Screenshots folder).', 'warn', 8000);
    } finally { if (!this.dead) this.setBusy(null); }
  }

  // camera flight through saved views (camera only - the objects stay as they are now)
  flightDialog() {
    const presets = (this.ctx.app.info.config.result_presets || []).slice().sort((a, b) => a.name.localeCompare(b.name));
    if (presets.length < 2) { toast('Not enough saved views', 'Save at least two views (Views → Save current view...) for a flight.', 'warn', 6000); return; }
    let order = store('res-flight-order') || [];
    order = order.filter((n) => presets.some((p) => p.name === n));
    const list = h('div', { class: 'rt-batch-list' });
    const draw = () => mount(list, presets.map((p) => {
      const k = order.indexOf(p.name);
      const cb = h('input', { type: 'checkbox' });
      cb.checked = k >= 0;
      cb.addEventListener('change', () => {
        order = cb.checked ? order.concat(p.name) : order.filter((n) => n !== p.name);
        draw(); upd();
      });
      return h('label', { class: 'check-row' }, cb, h('span', null, p.name),
        h('span', { class: 'rt-order' }, k >= 0 ? String(k + 1) : ''));
    }));
    const num = (v, min, max) => h('input', { class: 'input', type: 'number', min, max, step: 0.5, value: v, style: { width: '80px' } });
    const move = num(store('res-flight-move') || 4, 0.5, 60), hold = num(store('res-flight-pause') || 0, 0, 60);
    const back = h('input', { type: 'checkbox' });
    back.checked = !!store('res-flight-back');
    const go = btn('Record flight', { variant: 'primary', icon: 'record' });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const info = h('div', { class: 'muted small' });
    const upd = () => {
      const n = order.length + (back.checked && order.length > 1 ? 1 : 0);
      const t = (+hold.value > 0 ? n * +hold.value : 0) + Math.max(0, n - 1) * (+move.value || 0);
      go.disabled = order.length < 2;
      info.textContent = order.length < 2 ? 'Tick at least two views, in the order of the flight.' : `Video length about ${t.toFixed(1)} s.`;
    };
    [move, hold].forEach((el) => el.addEventListener('input', upd));
    back.addEventListener('change', upd);
    draw(); upd();
    const m = modal({ title: 'Flight through saved views', size: 'medium',
      body: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } },
        'The camera flies smoothly from view to view in the order you tick them. Only the camera moves - '
        + `the objects stay as they are now. Full HD, 60 fps, ${this.shotBgName()} background. Every frame is rendered on its own, `
        + 'so the video is smooth even when the screen stutters (rendering can take longer than the video).'), list,
        h('div', { class: 'row', style: { gap: '16px', marginTop: '14px', flexWrap: 'wrap' } },
          h('label', { class: 'row', style: { gap: '6px' } }, 'Flight', move, h('span', { class: 'muted small' }, 's per view')),
          h('label', { class: 'row', style: { gap: '6px' } }, 'Pause', hold, h('span', { class: 'muted small', title: '0 = one continuous flight that glides through the views without slowing down' }, 's at each view (0 = glide through)')),
          h('label', { class: 'check-row' }, back, h('span', null, 'Back to the first view'))),
        h('div', { style: { marginTop: '10px' } }, info)),
      footer: [cancel, go] });
    cancel.addEventListener('click', () => m.close());
    go.addEventListener('click', () => {
      store('res-flight-order', order); store('res-flight-move', +move.value); store('res-flight-pause', +hold.value); store('res-flight-back', back.checked);
      const cams = order.map((n) => presets.find((p) => p.name === n).cam);
      if (back.checked) cams.push(cams[0]);
      m.close();
      this.startRecording({ cams, move: Math.max(0.5, +move.value || 4), hold: Math.max(0, +hold.value || 0) });
    });
  }

  batchDialog() {
    const all = this.ctx.app.cases.filter((c) => c.status === 'finished' || c.status === 'stopped').map((c) => c.name).sort().reverse();
    const checks = new Map();
    const list = h('div', { class: 'rt-batch-list' }, all.map((n) => {
      const cb = h('input', { type: 'checkbox' });
      cb.checked = n === this.ctx.name || n === this.compare.other;
      checks.set(n, cb);
      return h('label', { class: 'check-row' }, cb, h('span', null, splitName(n).rest), h('span', { class: 'muted small' }, splitName(n).date));
    }));
    const [w, hgt] = this.shotSize();
    const go = btn('Take screenshots', { variant: 'primary', icon: 'save' });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const m = modal({ title: 'Batch screenshot', size: 'medium',
      body: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } },
        `Every selected simulation is rendered with the current camera, planes and colour ranges (${w} × ${hgt}, ${this.shotBgName()} background). `
        + 'Use fixed colour ranges (not "Auto") so the images are directly comparable.'), list),
      footer: [cancel, go] });
    cancel.addEventListener('click', () => m.close());
    go.addEventListener('click', () => {
      const names = [...checks].filter(([, cb]) => cb.checked).map(([n]) => n);
      m.close();
      if (names.length) this.batch(names);
    });
  }

  async batch(names) {
    const [w, hgt] = this.shotSize();
    const specs = this.layerSpecs();
    const bg = SHOT_BG[this.shotBgName()];
    const ranges = Object.fromEntries(specs.filter((s) => s.field !== 'none').map((s) => [s.field, this.rangeOf(s.field)]));
    const group = stamp();
    let done = 0;
    for (const name of names) {
      this.setBusy(`Batch screenshot ${done + 1} / ${names.length}: ${splitName(name).rest} (loading)...`);
      try {
        this.geoms.S.forEach((g) => this.rv.free(g));
        this.geoms.S.clear();
        for (const s of specs) await this.fetchGeom('S', name, s, this.info.rho);
        this.rv.scenes.S = this.toLayers('S', specs).map((l) => Object.assign(l, { range: l.field !== 'none' ? ranges[l.field] : null }));
        this.setBusy(`Batch screenshot ${done + 1} / ${names.length}: ${splitName(name).rest} (rendering)...`);
        await new Promise((r) => setTimeout(r, 20));
        const png = this.rv.screenshot(w, hgt, { background: bg, scene: 'S', mode: 0 });
        const parts = this.fileParts(name);
        parts[0] = group;
        parts[4] = 'batch';
        await api.post('results/screenshot', { png, parts });
        done++;
      } catch (e) { toastError(e, 'Batch screenshot failed for ' + name); }
    }
    this.geoms.S.forEach((g) => this.rv.free(g));
    this.geoms.S.clear();
    this.rv.scenes.S = [];
    this.setBusy(null);
    toast('Batch screenshot finished', `${done} of ${names.length} images saved to the Screenshots folder.`, done === names.length ? 'ok' : 'warn', 7000);
  }

  // ------------------------------------------------------------------ lifecycle
  onTheme() { if (this.rv) { this.applyTheme(); if (this.activeKeys) { this.applyScene(); this.renderPanel(); } } }

  onCaseChanged(d) { this.ctx.data = d; }

  destroy() {
    this.dead = true;
    if (this.rv && this.rv.rec) {
      if (this.rv.rec.flight || this.rv.rec.rendering) this.stopRecording();     // saves what is rendered so far
      else { this.rv.abortRecording(); toast('Recording discarded', 'The tab was left before Stop - the video is rendered after Stop.', 'warn', 6000); }
    }
    if (document.fullscreenElement === this.root) document.exitFullscreen().catch(() => {});
    window.removeEventListener('resize', this._resize);
    document.removeEventListener('fullscreenchange', this._fs);
    window.removeEventListener('mousemove', this._wmove);
    window.removeEventListener('mouseup', this._wup);
    window.removeEventListener('keydown', this._key);
    window.removeEventListener('keyup', this._key);
    if (this.rv) {
      for (const m of Object.values(this.geoms)) for (const g of m.values()) this.rv.free(g);
      this.rv.scenes = { A: [], B: [], S: [] };
      this.rv.destroy();
      this.rv = null;
    }
  }
}
