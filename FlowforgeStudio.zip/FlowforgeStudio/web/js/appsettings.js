// Application settings dialog (paths, force evaluation, behaviour).

import * as api from './api.js';
import { h, mount, icon, btn, toast, toastError, modal, switchEl, segmented, store, applyAccent } from './ui.js';

export function openAppSettings(app) {
  const c = Object.assign({}, app.info.config);
  const field = (label, control, hint) => h('div', { class: 'field' }, h('label', null, label), control, hint ? h('div', { class: 'hint' }, hint) : null);
  const text = (key, ph) => {
    const i = h('input', { class: 'input', value: c[key] || '', placeholder: ph || '' });
    i.addEventListener('input', () => { c[key] = i.value; });
    return i;
  };
  const num = (key, step) => {
    const i = h('input', { class: 'input', type: 'number', step: step || 'any', value: c[key] });
    i.addEventListener('input', () => { c[key] = i.value; });
    return i;
  };
  const testOut = h('div', { class: 'hint' });
  const testBtn = btn('Test', { size: 'sm', icon: 'check' });
  testBtn.addEventListener('click', async () => {
    mount(testOut, h('span', { class: 'row' }, h('span', { class: 'spinner' }), 'Starting the OpenFOAM environment...'));
    try {
      await save(true);
      const r = await api.post('bluecfd/test');
      mount(testOut, h('span', { class: r.ok ? 'ok' : 'bad' }, (r.ok ? '\u2713 ' : '\u2717 ') + r.message));
    } catch (e) { mount(testOut, h('span', { class: 'bad' }, e.message)); }
  });
  const axisSeg = (key, opts) => segmented(opts.map((o) => ({ label: o.toUpperCase(), value: o })), c[key], (v) => { c[key] = v; });
  const headSeg = segmented([{ label: 'pressure + viscous', value: 'total' }, { label: 'pressure only', value: 'pressure' }], c.force_headline, (v) => { c.force_headline = v; });
  const beep = switchEl(c.beep_on_finish, (v) => { c.beep_on_finish = v; });
  const sheetAuto = switchEl(c.sheet_auto !== false, (v) => { c.sheet_auto = v; });
  const partForces = switchEl(c.part_forces !== false, (v) => { c.part_forces = v; });
  const meshPopup = switchEl(store('mesh-popup') !== false, (v) => { store('mesh-popup', v); });
  const winSeg = segmented([{ label: 'Full screen', value: 'fullscreen' }, { label: 'Maximised', value: 'maximized' }, { label: 'Window', value: 'window' }],
    c.window_mode || 'maximized', (v) => { c.window_mode = v; });

  // team colour: replaces the orange accent everywhere in the app (live preview, reverted on Cancel)
  const DEFAULT_ACCENT = '#ff7a1a';
  c.accent = c.accent || '';
  const picker = h('input', { type: 'color', class: 'color-input', value: c.accent || DEFAULT_ACCENT, title: 'Pick your team colour' });
  const hex = h('input', { class: 'input mono', value: c.accent || '', placeholder: 'Flowforge Studio orange', style: { width: '150px' } });
  const resetAccent = btn('Default', { size: 'sm', icon: 'undo', variant: 'ghost' });
  const setAccent = (v, from) => {
    c.accent = v;
    if (from !== 'picker') picker.value = v || DEFAULT_ACCENT;
    if (from !== 'hex') hex.value = v;
    applyAccent(v);
  };
  picker.addEventListener('input', () => setAccent(picker.value.toLowerCase(), 'picker'));
  hex.addEventListener('input', () => {
    let v = hex.value.trim().toLowerCase();
    if (v && v[0] !== '#') v = '#' + v;
    if (!v || /^#[0-9a-f]{6}$/.test(v)) setAccent(v, 'hex');
  });
  resetAccent.addEventListener('click', () => setAccent(''));

  // installed Edge app = window buttons in our own top bar instead of the browser title bar
  const appOut = h('div', { class: 'hint' }, 'Checking ...');
  const appBtn = btn('Install as app', { size: 'sm', icon: 'external' });
  appBtn.style.display = 'none';
  appBtn.addEventListener('click', async () => {
    try {
      await api.post('app/install');
      mount(appOut, 'Click "Install" in the Edge window that just opened.');
    } catch (e) { mount(appOut, h('span', { class: 'bad' }, e.message)); }
  });
  api.get('app/status').then((r) => {
    if (r.installed) mount(appOut, h('span', { class: 'ok' }, '✓ Installed - minimise, maximise and close sit in the Flowforge Studio top bar.'));
    else if (!r.possible) mount(appOut, 'Not available: Microsoft Edge was not found or port 8765 is used by another program.');
    else {
      mount(appOut, 'Installs Flowforge Studio once as an Edge app: no browser title bar, the window buttons move into the Flowforge Studio top bar.');
      appBtn.style.display = '';
    }
  }).catch(() => mount(appOut, ''));

  const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '16px' } },
    h('div', { class: 'card-title' }, icon('folder'), 'Folders'),
    field('Simulations folder', text('sims_dir'), 'Every sub-folder with a system/controlDict is listed as a simulation.'),
    field('blueCFD-Core installation', h('div', { class: 'input-group' }, text('bluecfd_dir', 'C:\\Program Files\\blueCFD-Core-2017'), testBtn), testOut),
    field('ParaView state preset (.pvsm)', text('paraview_state', 'optional'), 'Loaded with the simulation when you click "ParaView". The .foam path inside is replaced automatically.'),
    field('Text editor (optional)', text('editor', 'auto: Notepad++ or Notepad'), 'Used for "open file" buttons.'),
    app.can('forces') ? [h('hr', { class: 'sep' }),
    h('div', { class: 'card-title' }, icon('wind'), 'Force evaluation'),
    h('div', { class: 'grid cols-2' },
      field('Symmetry factor', num('symmetry_factor', '0.5'), '2 = half car simulated, forces doubled.'),
      field('Averaging window [iterations]', num('avg_window', '10'), 'Mean of the last N iterations.')),
    h('div', { class: 'grid cols-2' },
      field('Drag axis', axisSeg('drag_axis', ['auto', 'x', 'y', 'z']), 'auto = direction of the inlet velocity'),
      field('Lift axis', axisSeg('lift_axis', ['x', 'y', 'z']))),
    field('Headline force value', headSeg, 'Your older parse_forces.py evaluation used pressure only.'),
    app.can('part_forces') ? h('label', { class: 'switch-row' }, partForces, h('div', null, h('b', null, 'Forces per part'),
      h('div', { class: 'muted small' }, 'Records drag and lift of every part (nose, wheels, wing, ...) during the solve - shown in the Forces tab. Costs about 5 % solve time. Takes effect with the next solve.'))) : null,
    h('hr', { class: 'sep' }),
    h('div', { class: 'card-title' }, icon('list'), 'Results spreadsheet'),
    field('Spreadsheet file (.ods)', text('results_sheet', 'auto: <simulations folder>/simulation_results.ods'),
      'Created automatically if it does not exist. It always mirrors the simulations folder: rows of deleted simulations are removed.'),
    h('label', { class: 'switch-row' }, sheetAuto, h('div', null, h('b', null, 'Record every finished run automatically'),
      h('div', { class: 'muted small' }, 'If the file is open in LibreOffice, the entry is written as soon as it is closed.')))] : null,
    h('hr', { class: 'sep' }),
    h('div', { class: 'card-title' }, icon('sun'), 'Appearance'),
    app.can('team_color') ? field('Accent colour (team CI)', h('div', { class: 'row' }, picker, hex, resetAccent),
      'Replaces the orange of buttons, tabs, highlights and the drag chart - e.g. with your team colour. Changes are shown right away.') : null,
    field('Window on start', winSeg, 'Full screen hides the title bar and the taskbar. F11 switches between full screen and window at any time. Takes effect the next time Flowforge Studio starts.'),
    field('Window buttons in the top bar', h('div', null, appBtn), appOut),
    h('label', { class: 'switch-row', style: { marginBottom: '10px' } }, meshPopup, h('div', null, h('b', null, 'Show a hint when a mesh is ready'),
      h('div', { class: 'muted small' }, 'Offers to open the mesh view right after meshing.'))),
    h('label', { class: 'switch-row' }, beep, h('div', null, h('b', null, 'Beep when a run finishes'), h('div', { class: 'muted small' }, 'Like the classic autorun script.'))),
    h('hr', { class: 'sep' }),
    h('div', { class: 'card-title' }, icon('check'), 'Licence'),
    h('div', { class: 'kv' },
      h('span', { class: 'k' }, 'Licensed to'), h('span', { class: 'v' }, (app.info.license && app.info.license.name) || '-'),
      h('span', { class: 'k' }, 'Variant'), h('span', { class: 'v' }, app.info.license.features.label),
      h('span', { class: 'k' }, 'Simulations per day'), h('span', { class: 'v' }, app.info.license.features.sims_per_day == null ? 'unlimited' : String(app.info.license.features.sims_per_day)),
      h('span', { class: 'k' }, 'Valid until'), h('span', { class: 'v' }, (app.info.license && app.info.license.expires) || 'unlimited'),
      h('span', { class: 'k' }, 'Machine code'), h('span', { class: 'v mono' }, (app.info.license && app.info.license.machine) || '-')),
    h('div', { class: 'muted small' }, `${app.info.app} ${app.info.version} · settings are stored in FlowforgeStudio/data/config.json`));

  const cancel = btn('Cancel', { variant: 'ghost' });
  const ok = btn('Save', { variant: 'primary', icon: 'save' });
  // closing without saving (Cancel, Esc, click outside) drops the colour preview
  const m = modal({ title: 'Settings', body, footer: [cancel, ok], size: 'medium', onClose: () => applyAccent(app.accent()) });
  cancel.addEventListener('click', () => m.close());

  async function save(silent) {
    const updates = {
      sims_dir: c.sims_dir, bluecfd_dir: c.bluecfd_dir, paraview_state: c.paraview_state, editor: c.editor,
      symmetry_factor: parseFloat(c.symmetry_factor), avg_window: parseInt(c.avg_window, 10),
      drag_axis: c.drag_axis, lift_axis: c.lift_axis, force_headline: c.force_headline, beep_on_finish: c.beep_on_finish, part_forces: c.part_forces !== false,
      results_sheet: c.results_sheet || '', sheet_auto: c.sheet_auto !== false, window_mode: c.window_mode || 'maximized', accent: c.accent || '',
    };
    await api.post('config', { updates });
    await app.reloadInfo();
    if (!silent) toast('Settings saved', '', 'ok', 2000);
  }
  ok.addEventListener('click', async () => {
    try { await save(); m.close(); await app.refresh(); if (app.selected) app.select(app.selected); } catch (e) { toastError(e, 'Could not save'); }
  });
}
