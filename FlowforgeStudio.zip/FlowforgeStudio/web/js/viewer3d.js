// Minimal WebGL STL viewer (no third-party code): Z-up orbit camera, per-part colour,
// transparency, symmetry-plane clipping, floor grid and an axis triad.

import { h } from './ui.js';

// ---------------------------------------------------------------- math (column-major)
export const M4 = {
  ident() { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; return m; },
  mul(a, b) {
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      let s = 0;
      for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
      o[c * 4 + r] = s;
    }
    return o;
  },
  translate(x, y, z) { const m = M4.ident(); m[12] = x; m[13] = y; m[14] = z; return m; },
  scale(s) { const m = M4.ident(); m[0] = m[5] = m[10] = s; return m; },
  rot(axis, deg) {
    const r = deg * Math.PI / 180;
    let c = Math.cos(r), s = Math.sin(r);
    if (Math.abs(c) < 1e-12) c = 0; if (Math.abs(s) < 1e-12) s = 0;
    const m = M4.ident();
    if (axis === 'x') { m[5] = c; m[6] = s; m[9] = -s; m[10] = c; }
    else if (axis === 'y') { m[0] = c; m[2] = -s; m[8] = s; m[10] = c; }
    else { m[0] = c; m[1] = s; m[4] = -s; m[5] = c; }
    return m;
  },
  perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), m = new Float32Array(16);
    m[0] = f / aspect; m[5] = f; m[10] = (far + near) / (near - far); m[11] = -1; m[14] = (2 * far * near) / (near - far);
    return m;
  },
  // parallel projection: halfH = half the visible height at the target
  ortho(halfH, aspect, near, far) {
    const m = new Float32Array(16);
    m[0] = 1 / (halfH * aspect); m[5] = 1 / halfH; m[10] = -2 / (far - near); m[14] = -(far + near) / (far - near); m[15] = 1;
    return m;
  },
  // perspective or parallel projection of a camera {dist, ortho}; the parallel view shows
  // the same size at the target as the perspective one, so switching keeps the framing
  camProj(cam, fovy, aspect, radius, nearMin) {
    if (cam.ortho) {
      const halfH = cam.dist * Math.tan(fovy / 2);
      return M4.ortho(halfH, aspect, cam.dist - radius * 4, cam.dist + radius * 4);
    }
    const near = Math.max(cam.dist - radius * 3, cam.dist * nearMin, 1e-6);
    return M4.perspective(fovy, aspect, near, cam.dist + radius * 4);
  },
  lookAt(e, t, u) {
    let zx = e[0] - t[0], zy = e[1] - t[1], zz = e[2] - t[2];
    let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    let xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx;
    l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    const m = M4.ident();
    m[0] = xx; m[4] = xy; m[8] = xz;
    m[1] = yx; m[5] = yy; m[9] = yz;
    m[2] = zx; m[6] = zy; m[10] = zz;
    m[12] = -(xx * e[0] + xy * e[1] + xz * e[2]);
    m[13] = -(yx * e[0] + yy * e[1] + yz * e[2]);
    m[14] = -(zx * e[0] + zy * e[1] + zz * e[2]);
    return m;
  },
  apply(m, p) {
    return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
      m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
      m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]];
  },
  normal3(m) { return new Float32Array([m[0], m[1], m[2], m[4], m[5], m[6], m[8], m[9], m[10]]); },
};

// Same order as the Python side: translate -> rotations -> scale
export function specMatrix(spec) {
  let m = M4.ident();
  const t = (spec && spec.translate) || [0, 0, 0];
  m = M4.mul(M4.translate(+t[0] || 0, +t[1] || 0, +t[2] || 0), m);
  for (const r of (spec && spec.rotations) || []) {
    const d = +r.deg || 0;
    if (d) m = M4.mul(M4.rot(r.axis || 'x', d), m);
  }
  m = M4.mul(M4.scale(+((spec && spec.scale) || 1)), m);
  return m;
}

export function transformBBox(bb, m) {
  if (!bb) return null;
  const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < 8; i++) {
    const p = M4.apply(m, [bb[i & 1 ? 1 : 0][0], bb[i & 2 ? 1 : 0][1], bb[i & 4 ? 1 : 0][2]]);
    for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], p[k]); mx[k] = Math.max(mx[k], p[k]); }
  }
  return [mn, mx];
}

const VS = `
attribute vec3 aPos; attribute vec3 aNor;
uniform mat4 uModel; uniform mat4 uVP; uniform mat3 uNM;
varying vec3 vN; varying vec3 vW;
void main() { vec4 w = uModel * vec4(aPos, 1.0); vW = w.xyz; vN = uNM * aNor; gl_Position = uVP * w; }`;
const FS = `
precision highp float;
uniform vec3 uColor; uniform float uAlpha; uniform vec3 uEye; uniform float uClip; uniform vec4 uCut;
varying vec3 vN; varying vec3 vW;
void main() {
  if (uClip > 0.5 && vW.x < -1e-7) discard;
  if (dot(uCut.xyz, vW) > uCut.w) discard;
  vec3 n = normalize(vN); vec3 v = normalize(uEye - vW);
  float d = abs(dot(n, v));
  float d2 = abs(dot(n, normalize(vec3(0.35, -0.4, 1.0))));
  vec3 c = uColor * (0.2 + 0.62 * d + 0.25 * d2) + vec3(pow(d, 48.0) * 0.22);
  gl_FragColor = vec4(c, uAlpha);
}`;
const LVS = `attribute vec3 aPos; uniform mat4 uVP; varying vec3 vW; void main(){ vW = aPos; gl_Position = uVP * vec4(aPos, 1.0); }`;
const LFS = `precision highp float; uniform vec4 uColor; uniform vec4 uCut; varying vec3 vW;
void main(){ if (dot(uCut.xyz, vW) > uCut.w) discard; gl_FragColor = uColor; }`;
const NO_CUT = [0, 0, 0, 1];

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '#888888');
  return m ? [parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255] : [0.6, 0.6, 0.6];
}

export class Viewer3D {
  constructor(container, opts = {}) {
    this.opts = Object.assign({ height: 520 }, opts);
    this.canvas = h('canvas');
    this.axes = h('canvas', { class: 'viewer-axes', width: 90, height: 90 });
    this.axes.style.width = '90px'; this.axes.style.height = '90px';
    this.loading = h('div', { class: 'viewer-loading hidden' }, h('div', { class: 'spinner' }), h('span', null, 'Loading geometry...'));
    this.tools = h('div', { class: 'viewer-tools' });
    this.el = h('div', { class: 'viewer' }, this.canvas, this.axes, this.tools, this.loading,
      h('div', { class: 'viewer-hint' }, 'Left drag: rotate  ·  Right drag / Shift: pan  ·  Wheel: zoom'));
    this.el.style.height = typeof this.opts.height === 'number' ? this.opts.height + 'px' : this.opts.height;
    container.appendChild(this.el);
    this.meshes = new Map();
    this.lineSets = new Map();
    this.clip = false;
    this.showPlane = false;
    this.cam = { target: [0, 0, 0], dist: 1, theta: -0.9, phi: 0.45 };
    const gl = this.canvas.getContext('webgl', { antialias: true, alpha: true, premultipliedAlpha: false });
    this.gl = gl;
    if (!gl) { this.el.appendChild(h('div', { class: 'viewer-loading' }, 'WebGL is not available on this PC.')); return; }
    this.prog = this.program(VS, FS);
    this.lprog = this.program(LVS, LFS);
    this.gridBuf = gl.createBuffer();
    this.planeBuf = gl.createBuffer();
    this.dirty = true;
    this.bindMouse();
    this.ro = new ResizeObserver(() => this.redraw());
    this.ro.observe(this.canvas);
    this.frame = this.frame.bind(this);
    this.raf = requestAnimationFrame(this.frame);
  }

  program(vs, fs) {
    const gl = this.gl;
    const mk = (type, src) => {
      const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    return p;
  }

  setLoading(on, text) {
    this.loading.classList.toggle('hidden', !on);
    if (text) this.loading.lastChild.textContent = text;
  }

  addMesh(id, positions, props = {}) {
    if (!this.gl) return;
    const gl = this.gl;
    const pos = positions instanceof Float32Array ? positions : new Float32Array(positions);
    const nor = new Float32Array(pos.length);
    for (let i = 0; i < pos.length; i += 9) {
      const ux = pos[i + 3] - pos[i], uy = pos[i + 4] - pos[i + 1], uz = pos[i + 5] - pos[i + 2];
      const vx = pos[i + 6] - pos[i], vy = pos[i + 7] - pos[i + 1], vz = pos[i + 8] - pos[i + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
      for (let k = 0; k < 3; k++) { nor[i + k * 3] = nx; nor[i + k * 3 + 1] = ny; nor[i + k * 3 + 2] = nz; }
    }
    let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < pos.length; i += 3) {
      for (let k = 0; k < 3; k++) { const v = pos[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
    }
    const pb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, pb); gl.bufferData(gl.ARRAY_BUFFER, pos, gl.STATIC_DRAW);
    const nb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, nb); gl.bufferData(gl.ARRAY_BUFFER, nor, gl.STATIC_DRAW);
    const old = this.meshes.get(id);
    if (old) { gl.deleteBuffer(old.pb); gl.deleteBuffer(old.nb); }
    this.meshes.set(id, Object.assign({ pb, nb, count: pos.length / 3, bbox: [mn, mx], color: '#9aa4b8', alpha: 1,
      visible: true, model: M4.ident(), clip: false }, props));
    this.redraw();
  }

  update(id, props) {
    const m = this.meshes.get(id);
    if (m) { Object.assign(m, props); this.redraw(); }
  }

  remove(id) {
    const m = this.meshes.get(id);
    if (m && this.gl) { this.gl.deleteBuffer(m.pb); this.gl.deleteBuffer(m.nb); }
    this.meshes.delete(id);
    this.redraw();
  }

  clearMeshes() {
    for (const id of [...this.meshes.keys()]) this.remove(id);
    for (const id of [...this.lineSets.keys()]) this.removeLines(id);
  }

  // edge lines (e.g. mesh cell edges), drawn on top of the surfaces
  addLines(id, positions, props = {}) {
    if (!this.gl) return;
    const gl = this.gl;
    const pos = positions instanceof Float32Array ? positions : new Float32Array(positions);
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < pos.length; i += 3) {
      for (let k = 0; k < 3; k++) { const v = pos[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
    }
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, pos, gl.STATIC_DRAW);
    this.removeLines(id);
    this.lineSets.set(id, Object.assign({ buf, count: pos.length / 3, bbox: [mn, mx], color: '#ffffff', alpha: 0.9, visible: true }, props));
    this.redraw();
  }

  updateLines(id, props) { const l = this.lineSets.get(id); if (l) { Object.assign(l, props); this.redraw(); } }

  removeLines(id) {
    const l = this.lineSets.get(id);
    if (l && this.gl) this.gl.deleteBuffer(l.buf);
    this.lineSets.delete(id);
    this.redraw();
  }

  setSymmetry(clip, showPlane) { this.clip = clip; this.showPlane = showPlane; this.redraw(); }

  // section plane: objects with 'cuttable' lose the part between the plane and the camera
  setCut(cut) { this.cut = cut; this.redraw(); }

  cutUniform(obj) {
    if (!this.cut || !obj || !obj.cuttable) return NO_CUT;
    const k = this.cut.axis, n = [0, 0, 0];
    const sgn = this.eye()[k] >= this.cut.pos ? 1 : -1;
    n[k] = sgn;
    return [n[0], n[1], n[2], sgn * this.cut.pos + 1e-6];
  }

  sceneBBox(onlyVisible = true) {
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const m of this.meshes.values()) {
      if (onlyVisible && !m.visible) continue;
      const bb = transformBBox(m.bbox, m.model);
      for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], bb[0][k]); mx[k] = Math.max(mx[k], bb[1][k]); }
    }
    for (const l of this.lineSets.values()) {
      if (onlyVisible && !l.visible) continue;
      for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], l.bbox[0][k]); mx[k] = Math.max(mx[k], l.bbox[1][k]); }
    }
    if (!isFinite(mn[0])) return [[-0.5, -0.5, 0], [0.5, 0.5, 0.5]];
    return [mn, mx];
  }

  // fit to a given box (e.g. only the car instead of the whole flow domain)
  fitBox(mn, mx) { this._focus = [mn, mx]; this.fit(); }

  fit() {
    const [mn, mx] = this._focus || this.sceneBBox();
    this.cam.target = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2];
    const r = Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2 || 1;
    const aspect = (this.canvas.clientWidth || 1) / (this.canvas.clientHeight || 1);
    const half = Math.min(0.4, Math.atan(Math.tan(0.4) * aspect));
    this.cam.dist = r / Math.sin(half) * 0.92;
    this.redraw();
  }

  view(name) {
    const v = { iso: [-0.9, 0.45], front: [-Math.PI / 2, 0.02], side: [0, 0.02], top: [-Math.PI / 2, 1.55], rear: [Math.PI / 2, 0.02] }[name];
    if (v) { this.cam.theta = v[0]; this.cam.phi = v[1]; this.fit(); }
  }

  boxOf(ids) {
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const id of ids) {
      const o = this.lineSets.get(id) || this.meshes.get(id);
      if (!o) continue;
      for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], o.bbox[0][k]); mx[k] = Math.max(mx[k], o.bbox[1][k]); }
    }
    return isFinite(mn[0]) ? [mn, mx] : null;
  }

  redraw() { this.dirty = true; }

  eye() {
    const c = this.cam;
    return [c.target[0] + c.dist * Math.cos(c.phi) * Math.cos(c.theta),
      c.target[1] + c.dist * Math.cos(c.phi) * Math.sin(c.theta),
      c.target[2] + c.dist * Math.sin(c.phi)];
  }

  frame() {
    this.raf = requestAnimationFrame(this.frame);
    if (!this.dirty || !this.gl) return;
    this.dirty = false;
    this.render();
  }

  render() {
    const gl = this.gl;
    const dpr = window.devicePixelRatio || 1;
    const w = this.canvas.clientWidth, hgt = this.canvas.clientHeight;
    if (!w || !hgt) return;
    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(hgt * dpr)) {
      this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(hgt * dpr);
    }
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    const [mn, mx] = this.sceneBBox(false);
    const radius = Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2 || 1;
    const eye = this.eye();
    const vp = M4.mul(M4.camProj(this.cam, 0.8, w / hgt, radius, 1 / 500), M4.lookAt(eye, this.cam.target, [0, 0, 1]));
    this._vp = vp;

    this.drawGrid(vp, mn, mx);

    gl.useProgram(this.prog);
    const loc = (n) => gl.getUniformLocation(this.prog, n);
    gl.uniformMatrix4fv(loc('uVP'), false, vp);
    const tg = this.cam.target;     // parallel view: light from the viewing direction
    gl.uniform3fv(loc('uEye'), this.cam.ortho ? eye.map((v, k) => tg[k] + (v - tg[k]) * 1e4) : eye);
    const aPos = gl.getAttribLocation(this.prog, 'aPos'), aNor = gl.getAttribLocation(this.prog, 'aNor');
    gl.enableVertexAttribArray(aPos); gl.enableVertexAttribArray(aNor);
    const pass = (transparent) => {
      for (const m of this.meshes.values()) {
        if (!m.visible || (m.alpha < 1) !== transparent) continue;
        gl.uniformMatrix4fv(loc('uModel'), false, m.model);
        gl.uniformMatrix3fv(loc('uNM'), false, M4.normal3(m.model));
        gl.uniform3fv(loc('uColor'), hexToRgb(m.color));
        gl.uniform1f(loc('uAlpha'), m.alpha);
        gl.uniform1f(loc('uClip'), (this.clip && m.clip) ? 1 : 0);
        gl.uniform4fv(loc('uCut'), this.cutUniform(m));
        gl.bindBuffer(gl.ARRAY_BUFFER, m.pb); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, m.nb); gl.vertexAttribPointer(aNor, 3, gl.FLOAT, false, 0, 0);
        gl.drawArrays(gl.TRIANGLES, 0, m.count);
      }
    };
    gl.disable(gl.BLEND);
    gl.enable(gl.POLYGON_OFFSET_FILL);
    gl.polygonOffset(1, 1);          // surfaces slightly behind their edge lines
    pass(false);
    gl.disable(gl.POLYGON_OFFSET_FILL);
    if (this.lineSets.size) {
      gl.disableVertexAttribArray(aNor);
      gl.useProgram(this.lprog);
      gl.uniformMatrix4fv(gl.getUniformLocation(this.lprog, 'uVP'), false, vp);
      const la = gl.getAttribLocation(this.lprog, 'aPos');
      gl.enableVertexAttribArray(la);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      for (const l of this.lineSets.values()) {
        if (!l.visible) continue;
        const c = hexToRgb(l.color);
        gl.uniform4fv(gl.getUniformLocation(this.lprog, 'uColor'), [c[0], c[1], c[2], l.alpha]);
        gl.uniform4fv(gl.getUniformLocation(this.lprog, 'uCut'), this.cutUniform(l));
        gl.bindBuffer(gl.ARRAY_BUFFER, l.buf);
        gl.vertexAttribPointer(la, 3, gl.FLOAT, false, 0, 0);
        gl.drawArrays(gl.LINES, 0, l.count);
      }
      gl.useProgram(this.prog);
      gl.enableVertexAttribArray(aNor);
    }
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);
    pass(true);
    gl.disableVertexAttribArray(aNor);
    if (this.showPlane) this.drawPlane(vp, mn, mx);
    gl.depthMask(true);
    gl.disable(gl.BLEND);
    this.drawAxes();
  }

  drawLines(vp, data, color, mode) {
    const gl = this.gl;
    gl.useProgram(this.lprog);
    gl.uniformMatrix4fv(gl.getUniformLocation(this.lprog, 'uVP'), false, vp);
    gl.uniform4fv(gl.getUniformLocation(this.lprog, 'uColor'), color);
    gl.uniform4fv(gl.getUniformLocation(this.lprog, 'uCut'), NO_CUT);
    const a = gl.getAttribLocation(this.lprog, 'aPos');
    gl.bindBuffer(gl.ARRAY_BUFFER, this.gridBuf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(a);
    gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(mode, 0, data.length / 3);
  }

  drawGrid(vp, mn, mx) {
    const gl = this.gl;
    const size = Math.max(mx[0] - mn[0], mx[1] - mn[1]) * 1.4 || 1;
    const cx = (mn[0] + mx[0]) / 2, cy = (mn[1] + mx[1]) / 2;
    const raw = size / 12, mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = (raw / mag < 2 ? 1 : raw / mag < 5 ? 2 : 5) * mag;
    const z = Math.min(0, mn[2]);
    const pts = [];
    const x0 = Math.floor((cx - size / 2) / step) * step, x1 = Math.ceil((cx + size / 2) / step) * step;
    const y0 = Math.floor((cy - size / 2) / step) * step, y1 = Math.ceil((cy + size / 2) / step) * step;
    for (let x = x0; x <= x1 + 1e-9; x += step) pts.push(x, y0, z, x, y1, z);
    for (let y = y0; y <= y1 + 1e-9; y += step) pts.push(x0, y, z, x1, y, z);
    const dark = document.documentElement.dataset.theme !== 'light';
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.drawLines(vp, new Float32Array(pts), dark ? [1, 1, 1, 0.07] : [0, 0, 0, 0.09], gl.LINES);
    // axes through origin
    const L = step * 2;
    this.drawLines(vp, new Float32Array([0, 0, z, L, 0, z]), [0.94, 0.33, 0.31, 0.9], gl.LINES);
    this.drawLines(vp, new Float32Array([0, 0, z, 0, L, z]), [0.3, 0.8, 0.4, 0.9], gl.LINES);
    this.drawLines(vp, new Float32Array([0, 0, z, 0, 0, z + L]), [0.35, 0.55, 1, 0.9], gl.LINES);
    gl.disable(gl.BLEND);
  }

  drawPlane(vp, mn, mx) {
    const gl = this.gl;
    const pad = 0.08 * Math.max(mx[1] - mn[1], mx[2] - mn[2]);
    const y0 = mn[1] - pad, y1 = mx[1] + pad, z0 = Math.min(0, mn[2]), z1 = mx[2] + pad;
    this.drawLines(vp, new Float32Array([0, y0, z0, 0, y1, z0, 0, y1, z1, 0, y0, z0, 0, y1, z1, 0, y0, z1]),
      [1, 0.48, 0.1, 0.10], gl.TRIANGLES);
    this.drawLines(vp, new Float32Array([0, y0, z0, 0, y1, z0, 0, y1, z0, 0, y1, z1, 0, y1, z1, 0, y0, z1, 0, y0, z1, 0, y0, z0]),
      [1, 0.48, 0.1, 0.6], gl.LINES);
  }

  drawAxes() {
    const c = this.axes, ctx = c.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    if (c.width !== 90 * dpr) { c.width = 90 * dpr; c.height = 90 * dpr; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, 90, 90);
    const view = M4.lookAt(this.eye(), this.cam.target, [0, 0, 1]);
    const axes = [['X', [1, 0, 0], '#f0544f'], ['Y', [0, 1, 0], '#4ccc66'], ['Z', [0, 0, 1], '#5a8cff']];
    const proj = axes.map(([n, v, col]) => {
      const x = view[0] * v[0] + view[4] * v[1] + view[8] * v[2];
      const y = view[1] * v[0] + view[5] * v[1] + view[9] * v[2];
      const z = view[2] * v[0] + view[6] * v[1] + view[10] * v[2];
      return { n, x, y, z, col };
    }).sort((a, b) => a.z - b.z);
    ctx.lineWidth = 2.5; ctx.lineCap = 'round';
    ctx.font = 'bold 11px "Segoe UI", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const a of proj) {
      ctx.strokeStyle = a.col; ctx.fillStyle = a.col;
      ctx.beginPath(); ctx.moveTo(45, 45); ctx.lineTo(45 + a.x * 28, 45 - a.y * 28); ctx.stroke();
      ctx.fillText(a.n, 45 + a.x * 38, 45 - a.y * 38);
    }
  }

  bindMouse() {
    const c = this.canvas;
    let drag = null;
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    c.addEventListener('mousedown', (e) => {
      drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey || e.button === 1 };
      e.preventDefault();
    });
    this._move = (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      drag.x = e.clientX; drag.y = e.clientY;
      if (drag.pan) {
        const s = this.cam.dist * 0.0016;
        const t = this.cam.theta, p = this.cam.phi;
        const right = [-Math.sin(t), Math.cos(t), 0];
        const up = [-Math.sin(p) * Math.cos(t), -Math.sin(p) * Math.sin(t), Math.cos(p)];
        for (let k = 0; k < 3; k++) this.cam.target[k] += (-dx * right[k] + dy * up[k]) * s;
      } else {
        this.cam.theta -= dx * 0.008;
        this.cam.phi = Math.max(-1.55, Math.min(1.55, this.cam.phi + dy * 0.008));
      }
      this.redraw();
    };
    this._up = () => { drag = null; };
    window.addEventListener('mousemove', this._move);
    window.addEventListener('mouseup', this._up);
    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cam.dist *= Math.exp(e.deltaY * 0.0012);
      this.redraw();
    }, { passive: false });
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('mousemove', this._move);
    window.removeEventListener('mouseup', this._up);
    if (this.ro) this.ro.disconnect();
    this.clearMeshes();
    const ext = this.gl && this.gl.getExtension('WEBGL_lose_context');
    if (ext) ext.loseContext();
  }
}

export const PART_COLORS = ['#9aa7bd', '#7fb3ff', '#6ee7b7', '#c4b5fd', '#f9a8d4', '#fcd34d', '#93c5fd', '#a7f3d0', '#fdba74', '#cbd5e1', '#86efac', '#f0abfc'];
