// Home page chart: final drag of every simulation in chronological order (one point each),
// plus a "best so far" line. Click a point to hide it.

import { h, clear, splitName, store } from './ui.js';

function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function niceStep(range, target) {
  const raw = range / Math.max(1, target);
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / mag;
  return (n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10) * mag;
}


export class DragProgress {
  constructor(container, opts = {}) {
    this.opts = opts;
    this.points = [];
    this.hidden = new Set(store('home-hidden-points') || []);
    this.hover = -1;
    this.canvas = h('canvas', { class: 'chart-canvas', style: { height: '300px', cursor: 'default' } });
    this.note = h('div', { class: 'muted small', style: { marginTop: '6px', minHeight: '18px' } });
    container.append(this.canvas, this.note);
    this.tooltip = document.getElementById('tooltip');
    this.ro = new ResizeObserver(() => this.draw());
    this.ro.observe(this.canvas);
    this.canvas.addEventListener('mousemove', (e) => this.onMove(e));
    this.canvas.addEventListener('mouseleave', () => { this.hover = -1; this.tooltip.style.display = 'none'; this.draw(); });
    this.canvas.addEventListener('click', (e) => {
      this.onMove(e);   // determine the point under the cursor even without a prior mousemove
      if (this.hover < 0) return;
      this.hidden.add(this.visible()[this.hover].name);
      this.save();
    });
  }

  // in the given order (the leaderboard's sort order)
  setData(cases) {
    this.points = cases.filter((c) => c.results && c.results.drag != null)
      .map((c) => ({ name: c.name, drag: c.results.drag, status: c.status }));
    this.draw();
  }

  visible() { return this.points.filter((p) => !this.hidden.has(p.name)); }

  // show / hide simulations from outside (the leaderboard check boxes)
  setShown(names, shown) {
    for (const n of names) { if (shown) this.hidden.delete(n); else this.hidden.add(n); }
    this.save();
  }

  save() {
    store('home-hidden-points', [...this.hidden]);
    this.hover = -1;
    this.tooltip.style.display = 'none';
    this.draw();
    if (this.opts.onChange) this.opts.onChange();
  }

  renderNote() {
    clear(this.note);
    const n = this.points.filter((p) => this.hidden.has(p.name)).length;
    this.note.append('Each point is the final drag of one simulation, in the order of the leaderboard below. Click a point to hide it, or tick the simulations in the leaderboard.');
    if (n) {
      const a = h('a', null, 'show all');
      a.addEventListener('click', () => { this.hidden.clear(); this.save(); });
      this.note.append(h('span', null, `  ·  ${n} hidden · `), a);
    }
  }

  layout() {
    const dpr = window.devicePixelRatio || 1;
    const w = this.canvas.clientWidth, hh = this.canvas.clientHeight;
    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(hh * dpr)) {
      this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(hh * dpr);
    }
    const pad = { l: 64, r: 20, t: 16, b: 16 };
    return { dpr, w, h: hh, pad, pw: w - pad.l - pad.r, ph: hh - pad.t - pad.b };
  }

  draw() {
    this.renderNote();
    const L = this.layout();
    if (L.pw < 20 || L.ph < 20) return;
    const ctx = this.canvas.getContext('2d');
    ctx.setTransform(L.dpr, 0, 0, L.dpr, 0, 0);
    ctx.clearRect(0, 0, L.w, L.h);
    const pts = this.visible();
    const grid = css('--grid'), gridS = css('--grid-strong'), muted = css('--muted');
    ctx.font = '11px "Segoe UI", system-ui, sans-serif';
    if (!pts.length) {
      ctx.fillStyle = muted; ctx.textAlign = 'center';
      ctx.fillText(this.points.length ? 'All simulations are hidden' : 'No results yet', L.w / 2, L.h / 2);
      this.map = null;
      return;
    }
    let y0 = Math.min(...pts.map((p) => p.drag)), y1 = Math.max(...pts.map((p) => p.drag));
    const span = (y1 - y0) || Math.abs(y1) * 0.1 || 1;
    y0 -= span * 0.12; y1 += span * 0.12;
    const n = pts.length;
    const X = (i) => L.pad.l + (n === 1 ? L.pw / 2 : 14 + (i / (n - 1)) * (L.pw - 28));
    const Y = (v) => L.pad.t + L.ph - ((v - y0) / (y1 - y0)) * L.ph;
    this.map = { X, Y, pts };

    // y grid + labels (x axis intentionally unlabeled)
    const step = niceStep(y1 - y0, Math.max(3, Math.floor(L.ph / 50)));
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (let v = Math.ceil(y0 / step) * step; v <= y1 + 1e-12; v += step) {
      const py = Y(v);
      ctx.strokeStyle = grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(L.pad.l, py + 0.5); ctx.lineTo(L.pad.l + L.pw, py + 0.5); ctx.stroke();
      ctx.fillStyle = muted;
      ctx.fillText(v.toFixed(step < 0.01 ? 3 : 2), L.pad.l - 8, py);
    }
    ctx.strokeStyle = gridS;
    ctx.strokeRect(L.pad.l + 0.5, L.pad.t + 0.5, L.pw, L.ph);
    ctx.save();
    ctx.translate(14, L.pad.t + L.ph / 2); ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center'; ctx.fillStyle = css('--text-2'); ctx.fillText('Drag [N]', 0, 0);
    ctx.restore();

    // best-so-far line (stepped)
    const best = css('--ok');
    ctx.strokeStyle = best; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]);
    ctx.beginPath();
    let b = Infinity;
    pts.forEach((p, i) => {
      const nb = Math.min(b, p.drag);
      if (i === 0) ctx.moveTo(X(i), Y(nb));
      else { ctx.lineTo(X(i), Y(b)); ctx.lineTo(X(i), Y(nb)); }
      b = nb;
    });
    ctx.lineTo(L.pad.l + L.pw, Y(b));
    ctx.stroke();
    ctx.setLineDash([]);

    // thin connecting line + points
    ctx.strokeStyle = css('--faint'); ctx.lineWidth = 1;
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(X(i), Y(p.drag)) : ctx.moveTo(X(i), Y(p.drag))));
    ctx.stroke();
    const accent = css('--accent');
    let runBest = Infinity;
    pts.forEach((p, i) => {
      const isBest = p.drag < runBest;
      runBest = Math.min(runBest, p.drag);
      const r = i === this.hover ? 7 : 5;
      ctx.beginPath(); ctx.arc(X(i), Y(p.drag), r, 0, Math.PI * 2);
      ctx.fillStyle = isBest ? best : accent;
      ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = css('--panel'); ctx.stroke();
    });
    // label of the overall best value
    const bi = pts.reduce((k, p, i) => (p.drag < pts[k].drag ? i : k), 0);
    ctx.fillStyle = best; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    const lx = Math.min(X(bi) + 8, L.pad.l + L.pw - 70);
    ctx.fillText('best ' + pts[bi].drag.toFixed(4) + ' N', lx, Y(pts[bi].drag) - 8);
  }

  onMove(e) {
    if (!this.map) return;
    const r = this.canvas.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    let best = -1, bd = 14 * 14;
    this.map.pts.forEach((p, i) => {
      const dx = this.map.X(i) - mx, dy = this.map.Y(p.drag) - my, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = i; }
    });
    if (best !== this.hover) { this.hover = best; this.draw(); }
    this.canvas.style.cursor = best >= 0 ? 'pointer' : 'default';
    if (best < 0) { this.tooltip.style.display = 'none'; return; }
    const p = this.map.pts[best];
    const { date, rest } = splitName(p.name);
    clear(this.tooltip);
    this.tooltip.append(h('div', { class: 'tt-title' }, rest), h('div', { class: 'tt-row' }, h('span', null, 'Drag'), h('b', null, p.drag.toFixed(4) + ' N')),
      date ? h('div', { class: 'tt-row' }, h('span', null, 'Date'), h('span', null, date)) : null,
      h('div', { class: 'muted small', style: { marginTop: '4px' } }, 'Click to hide'));
    this.tooltip.style.display = 'block';
    this.tooltip.style.left = (e.clientX + 14) + 'px';
    this.tooltip.style.top = (e.clientY + 12) + 'px';
  }
}
