// Lightweight canvas line chart: log/linear axes, legend toggles, hover tooltip,
// drag-to-zoom (x), double-click to reset, shaded band (e.g. averaging window).

import { h, clear } from './ui.js';

export const PALETTE = ['#4d8dff', '#22c55e', '#a78bfa', '#ff7a1a', '#f472b6', '#2dd4bf', '#facc15', '#f87171', '#94a3b8'];

function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

// series colours on a light background: bright tones (yellow, light green, pink) are darkened so
// the lines stay readable on white; on dark backgrounds the colours are used as they are
export function inkColor(c) {
  if (document.documentElement.dataset.theme !== 'light') return c;
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(c || '');
  if (!m) return c;
  let [r, g, b] = [m[1], m[2], m[3]].map((x) => parseInt(x, 16) / 255);
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  const target = 0.52;                                  // max. luminance on white
  if (lum <= target) return c;
  const f = target / lum;
  [r, g, b] = [r, g, b].map((v) => Math.round(v * f * 255));
  return '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
}

function niceStep(range, target) {
  const raw = range / Math.max(1, target);
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / mag;
  const step = n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10;
  return step * mag;
}

function fmtTick(v, step) {
  if (v === 0) return '0';
  const a = Math.abs(v);
  if (a >= 1e5 || a < 1e-3) return v.toExponential(1).replace('e+', 'e');
  const dec = Math.max(0, -Math.floor(Math.log10(step)) + (step / Math.pow(10, Math.floor(Math.log10(step))) === 1 ? 0 : 1));
  return v.toFixed(Math.min(dec, 6));
}

function lowerBound(arr, x) {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m] < x) lo = m + 1; else hi = m; }
  return lo;
}

export class LineChart {
  constructor(container, opts = {}) {
    this.opts = Object.assign({ height: 340, logY: false, xLabel: '', yLabel: '', legend: true,
      yFormat: null, xFormat: null, valueFormat: (v) => (Math.abs(v) < 1e-3 || Math.abs(v) >= 1e5 ? v.toExponential(3) : v.toPrecision(5)) }, opts);
    this.series = [];
    this.xView = null;
    this.yFixed = null;
    this.band = null;
    this.hoverX = null;
    this.drag = null;
    this.legendEl = this.opts.legend ? h('div', { class: 'chart-legend' }) : null;
    this.canvas = h('canvas', { class: 'chart-canvas' });
    this.canvas.style.height = this.opts.height + 'px';
    this.el = h('div', { class: 'chart-wrap' }, this.legendEl, this.canvas);
    container.appendChild(this.el);
    this.tooltip = document.getElementById('tooltip');
    this.ro = new ResizeObserver(() => this.draw());
    this.ro.observe(this.canvas);
    this.bindMouse();
  }

  destroy() { this.ro.disconnect(); window.removeEventListener('mouseup', this._onUp); this.tooltip.style.display = 'none'; }

  setSeries(series) {
    const prev = new Map(this.series.map((s) => [s.name, s.visible]));
    this.series = series.map((s, i) => Object.assign({ color: PALETTE[i % PALETTE.length], width: 1.8 },
      s, { visible: prev.has(s.name) ? prev.get(s.name) : (s.visible !== false) }));
    this.renderLegend();
    this.draw();
  }

  setBand(band) { this.band = band; this.draw(); }
  setYRange(r) { this.yFixed = r; this.draw(); }
  resetZoom() { this.xView = null; this.yFixed = null; this.draw(); }
  setLogY(v) { this.opts.logY = v; this.draw(); }

  renderLegend() {
    if (!this.legendEl) return;
    clear(this.legendEl);
    for (const s of this.series) {
      if (s.legend === false) continue;
      const last = this.lastValue(s);
      const lv = s.format ? (s.y.length ? s.format(s.y.length - 1) : null) : (last !== null ? this.opts.valueFormat(last) : null);
      const item = h('span', { class: 'legend-item' + (s.visible ? '' : ' off'), style: { '--c': inkColor(s.color) } },
        h('i'), s.name, lv !== null ? h('span', { class: 'lv' }, lv) : null);
      item.addEventListener('click', () => {
        s.visible = !s.visible;
        this.renderLegend();
        this.draw();
        if (this.opts.onToggle) this.opts.onToggle(s);
      });
      this.legendEl.appendChild(item);
    }
  }

  lastValue(s) {
    for (let i = s.y.length - 1; i >= 0; i--) if (s.y[i] !== null && s.y[i] !== undefined) return s.y[i];
    return null;
  }

  // ---------------------------------------------------------------- geometry
  layout() {
    const dpr = window.devicePixelRatio || 1;
    const w = this.canvas.clientWidth, hgt = this.canvas.clientHeight;
    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(hgt * dpr)) {
      this.canvas.width = Math.round(w * dpr);
      this.canvas.height = Math.round(hgt * dpr);
    }
    const pad = { l: 66, r: 14, t: 12, b: this.opts.xLabel ? 40 : 26 };
    return { dpr, w, h: hgt, pad, pw: w - pad.l - pad.r, ph: hgt - pad.t - pad.b };
  }

  xDomain() {
    if (this.xView) return this.xView;
    let mn = Infinity, mx = -Infinity;
    for (const s of this.series) {
      if (!s.visible || !s.x.length) continue;
      mn = Math.min(mn, s.x[0]); mx = Math.max(mx, s.x[s.x.length - 1]);
    }
    if (!isFinite(mn)) return [0, 1];
    if (mn === mx) return [mn - 1, mx + 1];
    return [mn, mx];
  }

  yDomain(x0, x1) {
    if (this.yFixed) return this.yFixed;
    // ignore the start-up transient for the automatic y range (unless zoomed in)
    if (!this.xView && this.opts.ySkipFraction) x0 = x0 + (x1 - x0) * this.opts.ySkipFraction;
    let mn = Infinity, mx = -Infinity;
    const log = this.opts.logY;
    for (const s of this.series) {
      if (!s.visible) continue;
      const i0 = Math.max(0, lowerBound(s.x, x0) - 1), i1 = Math.min(s.x.length, lowerBound(s.x, x1) + 1);
      for (let i = i0; i < i1; i++) {
        const v = s.y[i];
        if (v === null || v === undefined || !isFinite(v)) continue;
        if (log && v <= 0) continue;
        if (v < mn) mn = v;
        if (v > mx) mx = v;
      }
    }
    if (!isFinite(mn)) return log ? [1e-6, 1] : [0, 1];
    if (log) {
      const a = Math.floor(Math.log10(mn) * 4) / 4, b = Math.ceil(Math.log10(mx) * 4) / 4;
      return [Math.pow(10, a), Math.pow(10, b === a ? a + 1 : b)];
    }
    if (mn === mx) { const d = Math.abs(mn) * 0.05 || 1; return [mn - d, mx + d]; }
    const pad = (mx - mn) * 0.06;
    return [mn - pad, mx + pad];
  }

  // ---------------------------------------------------------------- drawing
  draw() {
    const L = this.layout();
    if (L.pw <= 10 || L.ph <= 10) return;
    const ctx = this.canvas.getContext('2d');
    ctx.setTransform(L.dpr, 0, 0, L.dpr, 0, 0);
    ctx.clearRect(0, 0, L.w, L.h);
    const [x0, x1] = this.xDomain();
    const [y0, y1] = this.yDomain(x0, x1);
    const log = this.opts.logY;
    const ly0 = log ? Math.log10(y0) : y0, ly1 = log ? Math.log10(y1) : y1;
    const X = (x) => L.pad.l + ((x - x0) / (x1 - x0)) * L.pw;
    const Y = (y) => L.pad.t + L.ph - (((log ? Math.log10(y) : y) - ly0) / (ly1 - ly0)) * L.ph;
    this._map = { X, Y, x0, x1, y0, y1, L };

    const grid = css('--grid'), gridS = css('--grid-strong'), muted = css('--muted'), text2 = css('--text-2');
    ctx.font = '11px "Segoe UI", system-ui, sans-serif';
    ctx.lineWidth = 1;

    // band
    if (this.band && this.band[1] > x0 && this.band[0] < x1) {
      const bx0 = Math.max(L.pad.l, X(this.band[0])), bx1 = Math.min(L.pad.l + L.pw, X(this.band[1]));
      ctx.fillStyle = css('--accent-soft');
      ctx.fillRect(bx0, L.pad.t, bx1 - bx0, L.ph);
      if (this.band[2]) {
        ctx.fillStyle = css('--accent');
        ctx.textAlign = 'right';
        ctx.fillText(this.band[2], bx1 - 6, L.pad.t + 14);
      }
    }

    // y grid
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    if (log) {
      for (let e = Math.floor(ly0); e <= Math.ceil(ly1); e++) {
        for (let m = 1; m < 10; m++) {
          const v = m * Math.pow(10, e);
          if (v < y0 || v > y1) continue;
          const py = Y(v);
          ctx.strokeStyle = m === 1 ? gridS : grid;
          ctx.beginPath(); ctx.moveTo(L.pad.l, py + 0.5); ctx.lineTo(L.pad.l + L.pw, py + 0.5); ctx.stroke();
          if (m === 1) { ctx.fillStyle = muted; ctx.fillText('1e' + e, L.pad.l - 8, py); }
        }
      }
    } else {
      const step = niceStep(y1 - y0, Math.max(3, Math.floor(L.ph / 46)));
      for (let v = Math.ceil(y0 / step) * step; v <= y1 + step * 1e-9; v += step) {
        const py = Y(v);
        ctx.strokeStyle = Math.abs(v) < step * 1e-9 ? gridS : grid;
        ctx.beginPath(); ctx.moveTo(L.pad.l, py + 0.5); ctx.lineTo(L.pad.l + L.pw, py + 0.5); ctx.stroke();
        ctx.fillStyle = muted;
        ctx.fillText(this.opts.yFormat ? this.opts.yFormat(v) : fmtTick(v, step), L.pad.l - 8, py);
      }
    }
    // x grid
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const xs = niceStep(x1 - x0, Math.max(3, Math.floor(L.pw / 90)));
    for (let v = Math.ceil(x0 / xs) * xs; v <= x1 + xs * 1e-9; v += xs) {
      const px = X(v);
      ctx.strokeStyle = grid;
      ctx.beginPath(); ctx.moveTo(px + 0.5, L.pad.t); ctx.lineTo(px + 0.5, L.pad.t + L.ph); ctx.stroke();
      ctx.fillStyle = muted;
      ctx.fillText(this.opts.xFormat ? this.opts.xFormat(v) : fmtTick(v, xs), px, L.pad.t + L.ph + 6);
    }
    ctx.strokeStyle = gridS;
    ctx.strokeRect(L.pad.l + 0.5, L.pad.t + 0.5, L.pw, L.ph);
    if (this.opts.xLabel) {
      ctx.fillStyle = text2;
      ctx.fillText(this.opts.xLabel, L.pad.l + L.pw / 2, L.h - 15);
    }
    if (this.opts.yLabel) {
      ctx.save();
      ctx.translate(13, L.pad.t + L.ph / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = text2;
      ctx.fillText(this.opts.yLabel, 0, 0);
      ctx.restore();
    }

    // series
    ctx.save();
    ctx.beginPath();
    ctx.rect(L.pad.l, L.pad.t, L.pw, L.ph);
    ctx.clip();
    for (const s of this.series) {
      if (!s.visible || !s.x.length) continue;
      if (s.y2) {
        // filled band between y and y2 (e.g. an uncertainty band)
        const i0 = Math.max(0, lowerBound(s.x, x0) - 1), i1 = Math.min(s.x.length, lowerBound(s.x, x1) + 2);
        const idx = [];
        for (let i = i0; i < i1; i++) if (s.y[i] != null && s.y2[i] != null && isFinite(s.y[i]) && isFinite(s.y2[i])) idx.push(i);
        if (idx.length > 1) {
          ctx.beginPath();
          idx.forEach((i, k) => (k ? ctx.lineTo(X(s.x[i]), Y(s.y2[i])) : ctx.moveTo(X(s.x[i]), Y(s.y2[i]))));
          for (let k = idx.length - 1; k >= 0; k--) ctx.lineTo(X(s.x[idx[k]]), Y(s.y[idx[k]]));
          ctx.closePath();
          ctx.fillStyle = inkColor(s.color);
          ctx.globalAlpha = s.alpha || 0.25;
          ctx.fill();
          ctx.globalAlpha = 1;
        }
        continue;
      }
      ctx.strokeStyle = inkColor(s.color);
      ctx.lineWidth = s.width;
      ctx.setLineDash(s.dash || []);
      ctx.globalAlpha = s.alpha || 1;
      const i0 = Math.max(0, lowerBound(s.x, x0) - 1), i1 = Math.min(s.x.length, lowerBound(s.x, x1) + 2);
      const n = i1 - i0;
      ctx.beginPath();
      let pen = false;
      if (n > L.pw * 2) {
        // min/max per pixel column
        let col = -1, cmin = 0, cmax = 0, first = 0;
        const flush = () => {
          if (col < 0) return;
          const py1 = Y(cmin), py2 = Y(cmax);
          if (!pen) { ctx.moveTo(col, Y(first)); pen = true; }
          ctx.lineTo(col, py1); ctx.lineTo(col, py2);
        };
        for (let i = i0; i < i1; i++) {
          const v = s.y[i];
          if (v === null || v === undefined || (log && v <= 0)) continue;
          const px = Math.round(X(s.x[i]));
          if (px !== col) { flush(); col = px; cmin = v; cmax = v; first = v; } else { if (v < cmin) cmin = v; if (v > cmax) cmax = v; }
        }
        flush();
      } else {
        for (let i = i0; i < i1; i++) {
          const v = s.y[i];
          if (v === null || v === undefined || (log && v <= 0)) { pen = false; continue; }
          const px = X(s.x[i]), py = Y(v);
          if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
        }
      }
      ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;

    // hover
    if (this.hoverX !== null && !this.drag) {
      const px = X(this.hoverX);
      ctx.strokeStyle = css('--faint');
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px + 0.5, L.pad.t); ctx.lineTo(px + 0.5, L.pad.t + L.ph); ctx.stroke();
      for (const s of this.series) {
        if (!s.visible || s.y2) continue;
        const i = this.nearest(s, this.hoverX);
        if (i < 0) continue;
        const v = s.y[i];
        if (v === null || v === undefined || (log && v <= 0)) continue;
        ctx.fillStyle = inkColor(s.color);
        ctx.beginPath(); ctx.arc(X(s.x[i]), Y(v), 3.5, 0, Math.PI * 2); ctx.fill();
      }
    }
    // zoom selection
    if (this.drag && Math.abs(this.drag.x1 - this.drag.x0) > 3) {
      ctx.fillStyle = css('--accent-soft');
      ctx.strokeStyle = css('--accent-line');
      const a = Math.min(this.drag.x0, this.drag.x1), b = Math.max(this.drag.x0, this.drag.x1);
      ctx.fillRect(a, L.pad.t, b - a, L.ph);
      ctx.strokeRect(a + 0.5, L.pad.t + 0.5, b - a, L.ph);
    }
    ctx.restore();
  }

  nearest(s, x) {
    if (!s.x.length) return -1;
    let i = lowerBound(s.x, x);
    if (i >= s.x.length) i = s.x.length - 1;
    if (i > 0 && Math.abs(s.x[i - 1] - x) < Math.abs(s.x[i] - x)) i--;
    return i;
  }

  // ---------------------------------------------------------------- interaction
  bindMouse() {
    const c = this.canvas;
    const toX = (e) => {
      const m = this._map; if (!m) return null;
      const r = c.getBoundingClientRect();
      const px = e.clientX - r.left;
      return m.x0 + ((px - m.L.pad.l) / m.L.pw) * (m.x1 - m.x0);
    };
    c.addEventListener('mousemove', (e) => {
      const r = c.getBoundingClientRect();
      if (this.drag) { this.drag.x1 = e.clientX - r.left; this.draw(); return; }
      const x = toX(e);
      const m = this._map;
      if (x === null || x < m.x0 || x > m.x1) { this.hoverX = null; this.tooltip.style.display = 'none'; this.draw(); return; }
      this.hoverX = x;
      this.draw();
      this.showTooltip(e, x);
    });
    c.addEventListener('mouseleave', () => { this.hoverX = null; this.tooltip.style.display = 'none'; if (!this.drag) this.draw(); });
    c.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const r = c.getBoundingClientRect();
      this.drag = { x0: e.clientX - r.left, x1: e.clientX - r.left };
      this.tooltip.style.display = 'none';
    });
    this._onUp = () => {
      if (!this.drag) return;
      const d = this.drag; this.drag = null;
      const m = this._map;
      if (m && Math.abs(d.x1 - d.x0) > 6) {
        const a = Math.min(d.x0, d.x1), b = Math.max(d.x0, d.x1);
        const xa = m.x0 + ((a - m.L.pad.l) / m.L.pw) * (m.x1 - m.x0);
        const xb = m.x0 + ((b - m.L.pad.l) / m.L.pw) * (m.x1 - m.x0);
        this.xView = [Math.max(m.x0, xa), Math.min(m.x1, xb)];
        this.yFixed = null;
        if (this.onZoom) this.onZoom(this.xView);
      }
      this.draw();
    };
    window.addEventListener('mouseup', this._onUp);
    c.addEventListener('dblclick', () => { this.resetZoom(); if (this.onZoom) this.onZoom(null); });
  }

  showTooltip(e, x) {
    const rows = [];
    let xi = null;
    for (const s of this.series) {
      if (!s.visible) continue;
      const i = this.nearest(s, x);
      if (i < 0) continue;
      if (xi === null) xi = s.x[i];
      const v = s.y[i];
      if (v === null || v === undefined) continue;
      if (s.y2 && (Math.abs(s.x[i] - x) > (s.x[s.x.length - 1] - s.x[0]) / 40 || s.y2[i] == null)) continue;
      const txt = s.format ? s.format(i) : s.y2 ? this.opts.valueFormat(v) + ' … ' + this.opts.valueFormat(s.y2[i]) : this.opts.valueFormat(v);
      rows.push(h('div', { class: 'tt-row', style: { '--c': inkColor(s.color) } },
        h('span', null, h('i'), s.name), h('b', null, txt)));
    }
    if (!rows.length) { this.tooltip.style.display = 'none'; return; }
    clear(this.tooltip);
    this.tooltip.appendChild(h('div', { class: 'tt-title' }, (this.opts.xLabel || 'x') + ' ' + (this.opts.xFormat ? this.opts.xFormat(xi) : xi)));
    rows.forEach((r) => this.tooltip.appendChild(r));
    this.tooltip.style.display = 'block';
    const tw = this.tooltip.offsetWidth, th = this.tooltip.offsetHeight;
    let left = e.clientX + 16, top = e.clientY + 14;
    if (left + tw > window.innerWidth - 8) left = e.clientX - tw - 16;
    if (top + th > window.innerHeight - 8) top = e.clientY - th - 14;
    this.tooltip.style.left = left + 'px';
    this.tooltip.style.top = top + 'px';
  }
}
