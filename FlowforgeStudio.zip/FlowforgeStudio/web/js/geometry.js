// Geometry tab and the overview picture of the car.
//
// The STLs are drawn by the Results renderer (ResultView): one neutral colour, the same light and
// background as the Results tab, mirrored at the symmetry plane, comparison with another simulation
// (peek with the Space bar, wipe) and full screen. The overview picture is rendered here as well -
// always from the one camera that all simulations share (server: app/geometry.py) - and stored by
// the server, so the Overview shows it at once without loading any STL.

import * as api from './api.js';
import { h, mount, clear, icon, btn, toast, toastError, showMenu, store, switchEl, segmented, splitName,
  fmtInt, fmtBytes } from './ui.js';
import { ResultView } from './resultview.js';
import { describeTransform } from './detail.js';

const BUDGET = 70000;          // triangles per part in the previews (part of the server's cache key)
const CAR = { dark: '#8e9ab3', light: '#d6d9e0' };          // as the car in the Results tab
const BG = { dark: [0.075, 0.075, 0.085], light: [0.96, 0.97, 0.98] };
const HOVER = '#5b95ff';
const CHANGED = '#ff7a1a';
const THUMB = { w: 1440, h: 810, ss: 2, car: '#b7bfcd' };    // picture size, supersampling, car colour
const VIEWS = [['iso', 'Perspective'], ['front', 'Front'], ['side', 'Side'], ['top', 'Top'], ['rear', 'Rear']];
const STATE_LABEL = { different: 'changed', only_a: 'only here', only_b: 'only in other' };

export const partLabel = (file) => file.replace(/\.stl$/i, '').replace(/_/g, ' ');
const theme = () => (document.documentElement.dataset.theme === 'light' ? 'light' : 'dark');
const stlSig = (stls) => (stls || []).map((s) => `${s.name}|${s.size}|${s.mtime}`).join(';');

// ---------------------------------------------------------------- part data
// Decoded previews (positions + smooth normals), shared by the tab, the overview picture and
// simulations with the same STL: variants copy them with their time stamps.
const partCache = new Map();
const PART_CACHE = 40;

function loadPart(caseName, s) {
  const key = `${s.name}|${s.size}|${s.mtime}`;
  let p = partCache.get(key);
  if (p) { partCache.delete(key); partCache.set(key, p); return p; }       // most recently used last
  p = api.getBinary('stl/preview', { name: caseName, file: s.name, budget: BUDGET }).then((r) => {
    const pos = new Float32Array(r.buffer);
    return { pos, nrm: smoothNormals(pos), triangles: r.triangles };
  });
  p.catch(() => partCache.delete(key));
  partCache.set(key, p);
  while (partCache.size > PART_CACHE) partCache.delete(partCache.keys().next().value);
  return p;
}

// a few at a time: small parts appear while the big body is still being read
async function loadParts(caseName, stls, onPart, limit = 4) {
  const queue = stls.slice();
  const worker = async () => {
    while (queue.length) {
      const s = queue.shift();
      try { onPart(s, await loadPart(caseName, s), null); } catch (e) { onPart(s, null, e); }
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, queue.length) }, worker));
}

// Smooth vertex normals for the decimated triangle soup: equal positions are welded (the preview
// shares its vertices), face normals summed by area. Where a face is bent more than ~37° against
// the vertex normal (a real edge) it keeps its own normal, so edges stay crisp.
function smoothNormals(pos) {
  const nt = pos.length / 9, nv = nt * 3;
  const fn = new Float32Array(nt * 3);
  for (let t = 0; t < nt; t++) {
    const o = t * 9;
    const ux = pos[o + 3] - pos[o], uy = pos[o + 4] - pos[o + 1], uz = pos[o + 5] - pos[o + 2];
    const vx = pos[o + 6] - pos[o], vy = pos[o + 7] - pos[o + 1], vz = pos[o + 8] - pos[o + 2];
    fn[t * 3] = uy * vz - uz * vy; fn[t * 3 + 1] = uz * vx - ux * vz; fn[t * 3 + 2] = ux * vy - uy * vx;
  }
  const bits = new Uint32Array(pos.buffer, pos.byteOffset, pos.length);
  let size = 1;
  while (size < nv * 2) size <<= 1;
  const table = new Int32Array(size).fill(-1);
  const rep = new Int32Array(nv), vid = new Int32Array(nv);
  let uniq = 0;
  for (let c = 0; c < nv; c++) {
    const a = bits[c * 3], b = bits[c * 3 + 1], d = bits[c * 3 + 2];
    let s = (Math.imul(a, 73856093) ^ Math.imul(b, 19349663) ^ Math.imul(d, 83492791)) & (size - 1);
    for (;;) {
      const u = table[s];
      if (u < 0) { table[s] = uniq; rep[uniq] = c; vid[c] = uniq++; break; }
      const r = rep[u] * 3;
      if (bits[r] === a && bits[r + 1] === b && bits[r + 2] === d) { vid[c] = u; break; }
      s = (s + 1) & (size - 1);
    }
  }
  const acc = new Float32Array(uniq * 3);
  for (let c = 0; c < nv; c++) {
    const t = (c / 3) | 0, v = vid[c] * 3;
    acc[v] += fn[t * 3]; acc[v + 1] += fn[t * 3 + 1]; acc[v + 2] += fn[t * 3 + 2];
  }
  const out = new Float32Array(nv * 3);
  for (let c = 0; c < nv; c++) {
    const t = (c / 3) | 0, v = vid[c] * 3;
    let fx = fn[t * 3], fy = fn[t * 3 + 1], fz = fn[t * 3 + 2];
    const fl = Math.hypot(fx, fy, fz) || 1; fx /= fl; fy /= fl; fz /= fl;
    let ax = acc[v], ay = acc[v + 1], az = acc[v + 2];
    const al = Math.hypot(ax, ay, az) || 1; ax /= al; ay /= al; az /= al;
    const smooth = fx * ax + fy * ay + fz * az > 0.8;
    out[c * 3] = smooth ? ax : fx; out[c * 3 + 1] = smooth ? ay : fy; out[c * 3 + 2] = smooth ? az : fz;
  }
  return out;
}

// ---------------------------------------------------------------- overview picture
// The whole car (mirrored) from the shared camera on a transparent background with a soft shadow
// on the ground. Rendered at twice the size and scaled down for smooth edges. items: [{pos, geom}]
// with geom uploaded to rv. Returns a PNG data URL.
function renderThumb(rv, items, info) {
  const W = THUMB.w * THUMB.ss, H = THUMB.h * THUMB.ss;
  const keep = { cam: rv.cam, mirror: rv.mirror, A: rv.scenes.A, B: rv.scenes.B, mode: rv.mode, mix: rv.mix };
  const flat = [];
  try {
    rv.cam = Object.assign({}, info.view, { target: info.view.target.slice() });
    rv.mirror = info.mirror;
    rv.scenes.B = []; rv.mode = 'normal'; rv.mix = 0;
    rv.scenes.A = items.map((it, i) => ({ key: 'c' + i, geom: it.geom, visible: true, solid: THUMB.car, lit: true }));
    // colour and coverage: the same image on black and on white
    const onBlack = rv.shotPixels(W, H, { background: [0, 0, 0], mode: 0 }).px;
    const onWhite = rv.shotPixels(W, H, { background: [1, 1, 1], mode: 0 }).px;
    // shadow: the car pressed flat onto the ground, seen from the same camera
    const z0 = info.car[0][2];
    rv.scenes.A = items.map((it, i) => {
      const p = it.pos.slice();
      for (let k = 2; k < p.length; k += 3) p[k] = z0;
      const g = rv.uploadMesh(p, null);
      flat.push(g);
      return { key: 's' + i, geom: g, visible: true, solid: '#000000', lit: false };
    });
    const shade = rv.shotPixels(W, H, { background: [1, 1, 1], mode: 0 }).px;

    const canvas = (w, hh) => { const c = document.createElement('canvas'); c.width = w; c.height = hh; return c; };
    const car = canvas(W, H), sh = canvas(W, H), all = canvas(W, H);
    const ci = car.getContext('2d').createImageData(W, H), si = sh.getContext('2d').createImageData(W, H);
    for (let i = 0; i < W * H * 4; i += 4) {
      const cover = 1 - (onWhite[i] + onWhite[i + 1] + onWhite[i + 2] - onBlack[i] - onBlack[i + 1] - onBlack[i + 2]) / 765;
      if (cover > 0.003) {
        ci.data[i] = Math.min(255, onBlack[i] / cover); ci.data[i + 1] = Math.min(255, onBlack[i + 1] / cover);
        ci.data[i + 2] = Math.min(255, onBlack[i + 2] / cover); ci.data[i + 3] = Math.round(cover * 255);
      }
      si.data[i + 3] = 255 - shade[i];
    }
    car.getContext('2d').putImageData(ci, 0, 0);
    sh.getContext('2d').putImageData(si, 0, 0);
    const ctx = all.getContext('2d');
    ctx.filter = `blur(${Math.round(H * 0.014)}px)`;
    ctx.globalAlpha = 0.42;
    ctx.drawImage(sh, 0, 0);
    ctx.filter = `blur(${Math.round(H * 0.004)}px)`;      // darker contact shadow right under the car
    ctx.globalAlpha = 0.3;
    ctx.drawImage(sh, 0, 0);
    ctx.filter = 'none';
    ctx.globalAlpha = 1;
    ctx.drawImage(car, 0, 0);
    const out = canvas(THUMB.w, THUMB.h), octx = out.getContext('2d');
    octx.imageSmoothingQuality = 'high';
    octx.drawImage(all, 0, 0, THUMB.w, THUMB.h);
    return out.toDataURL('image/png');
  } finally {
    Object.assign(rv, { cam: keep.cam, mirror: keep.mirror, mode: keep.mode, mix: keep.mix });
    rv.scenes.A = keep.A; rv.scenes.B = keep.B;
    flat.forEach((g) => rv.free(g));
    rv.redraw();
  }
}

// Camera of the overview pictures when there is none yet: front three-quarter view from slightly
// above, framed tightly around this car (its vertices, mirrored) for a 16:9 picture
function fitPictureView(items, mirror, aspect) {
  const theta = -0.85, phi = 0.38, fov = 0.5;
  const d = [Math.cos(phi) * Math.cos(theta), Math.cos(phi) * Math.sin(theta), Math.sin(phi)];    // target -> eye
  const rl = Math.hypot(d[0], d[1]) || 1;
  const r = [-d[1] / rl, d[0] / rl, 0];                                                           // as M4.lookAt
  const u = [d[1] * r[2] - d[2] * r[1], d[2] * r[0] - d[0] * r[2], d[0] * r[1] - d[1] * r[0]];
  const P = [];
  const add = (x, y, z) => P.push(x * r[0] + y * r[1] + z * r[2], x * u[0] + y * u[1] + z * u[2], x * d[0] + y * d[1] + z * d[2]);
  for (const it of items) {
    for (let i = 0; i < it.pos.length; i += 15) {
      const p = [it.pos[i], it.pos[i + 1], it.pos[i + 2]];
      add(p[0], p[1], p[2]);
      if (mirror) { p[mirror[0]] = 2 * mirror[1] - p[mirror[0]]; add(p[0], p[1], p[2]); }
    }
  }
  const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < P.length; i += 3) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], P[i + k]); hi[k] = Math.max(hi[k], P[i + k]); }
  let cx = (lo[0] + hi[0]) / 2, cy = (lo[1] + hi[1]) / 2, dist = 0;
  const cz = (lo[2] + hi[2]) / 2, ty = Math.tan(fov / 2), tx = ty * aspect, margin = 1.12;
  for (let it = 0; it < 5; it++) {
    // distance at which every point fits, then centre the projected extents (perspective)
    dist = 0;
    for (let i = 0; i < P.length; i += 3) {
      const z = P[i + 2] - cz;
      dist = Math.max(dist, z + Math.abs(P[i] - cx) / tx * margin, z + Math.abs(P[i + 1] - cy) / ty * margin);
    }
    let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
    for (let i = 0; i < P.length; i += 3) {
      const w = dist - (P[i + 2] - cz), X = (P[i] - cx) / w, Y = (P[i + 1] - cy) / w;
      x0 = Math.min(x0, X); x1 = Math.max(x1, X); y0 = Math.min(y0, Y); y1 = Math.max(y1, Y);
    }
    cx += (x0 + x1) / 2 * dist; cy += (y0 + y1) / 2 * dist;
  }
  const target = [0, 1, 2].map((k) => cx * r[k] + cy * u[k] + cz * d[k]);
  return { target, dist, theta, phi, fov, ortho: false };
}

// info with the common camera: set from this car if there is none yet
async function ensureView(caseName, info, items) {
  if (info.view) return info;
  await api.post('geometry/view', { view: fitPictureView(items, info.mirror, info.aspect || 16 / 9) });
  return api.get('geometry/info', { name: caseName });
}

const pictures = new Map();       // picture key -> URL (data or object URL)
const making = new Map();         // picture key -> Promise<URL> while it is rendered
const infos = new Map();          // simulation -> {sig, info} of the last geometry/info

async function storePicture(caseName, info, url) {
  pictures.set(info.thumb, url);
  const old = infos.get(caseName);
  infos.set(caseName, { sig: stlSig(info.stls), info: Object.assign({}, info, { states: old && old.info.states }) });
  try { await api.post('geometry/thumb', { name: caseName, key: info.thumb, png: url }); } catch (e) { /* shown anyway; made again next time */ }
}

// renders the picture off screen (own small WebGL view) from the STL previews
function makePicture(caseName, info) {
  const key = info.thumb || 'new:' + caseName;
  if (making.has(key)) return making.get(key);
  const p = (async () => {
    const box = h('div', { style: { position: 'fixed', left: '-10000px', top: '0', width: '480px', height: '270px', pointerEvents: 'none' } });
    document.body.appendChild(box);
    const rv = new ResultView(box);
    try {
      if (!rv.ok) throw new Error('WebGL 2 is not available');
      const items = [];
      await loadParts(caseName, info.stls, (s, d) => { if (d) items.push({ pos: d.pos, geom: rv.uploadMesh(d.pos, d.nrm) }); });
      if (!items.length) throw new Error('No STL could be read');
      const full = await ensureView(caseName, info, items);
      const url = renderThumb(rv, items, full);
      items.forEach((it) => rv.free(it.geom));
      await storePicture(caseName, full, url);
      return url;
    } finally {
      rv.destroy();
      box.remove();
      making.delete(key);
    }
  })();
  making.set(key, p);
  return p;
}

async function pictureUrl(caseName, info) {
  if (info.thumb && pictures.has(info.thumb)) return pictures.get(info.thumb);
  if (info.has_thumb) {
    try {
      const r = await api.getBinary('geometry/thumb', { name: caseName });
      const url = URL.createObjectURL(new Blob([r.buffer], { type: 'image/png' }));
      pictures.set(info.thumb, url);
      return url;
    } catch (e) { /* render it anew */ }
  }
  return makePicture(caseName, info);
}

// ---------------------------------------------------------------- overview card
// view: the DetailView (data, app, showTab)
export function geometryCard(view) {
  const d = view.data;
  const stls = d.stls || [];
  const total = stls.reduce((a, s) => a + (s.size || 0), 0);
  const repl = d.meta.replaced_stls || [];
  const origin = d.meta.origin && view.app.cases.some((c) => c.name === d.meta.origin) ? d.meta.origin : null;
  const lost = d.meta.origin && !origin ? d.meta.origin : null;       // origin set but deleted since
  const open = btn('3D view', { size: 'sm', icon: 'cube' });
  open.addEventListener('click', () => view.showTab('geometry'));
  const pic = h('div', { class: 'geo-pic', title: 'Open the Geometry tab' });
  pic.addEventListener('click', () => view.showTab('geometry'));
  const note = h('div', { class: 'geo-note' });
  const chips = h('div', { class: 'geo-chips' });
  const card = h('div', { class: 'card geo-card' },
    h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('cube'), 'Geometry',
      h('span', { class: 'muted small', style: { fontWeight: 400, marginLeft: '6px' } }, `${stls.length} part${stls.length === 1 ? '' : 's'} · ${fmtBytes(total)}`)), open),
    pic, note, chips,
    d.meta.transform ? h('div', { class: 'stat-sub', style: { marginTop: '8px' } }, 'Transform: ' + describeTransform(d.meta.transform)) : null);

  const fillChips = (states) => {
    mount(chips, stls.map((s) => {
      const st = states && states[s.name];
      const rp = repl.find((x) => x.target === s.name);
      const changed = st === 'different' || st === 'only_a';
      return h('span', { class: 'chip geo-chip' + (changed ? ' changed' : ''),
        title: `${s.name} · ${fmtBytes(s.size)}` + (rp ? `\nreplaced from ${rp.source}` : '') + (changed ? `\n${st === 'only_a' ? 'new' : 'changed'} compared with ${origin}` : '') },
      changed ? icon('alert') : null, partLabel(s.name));
    }));
    if (!origin) {
      mount(note, h('span', { class: 'muted' }, lost ? `The origin ${splitName(lost).rest} no longer exists - nothing to compare with.`
        : 'No origin set - with one (Lineage → set), the parts changed against it are marked here.'));
      return;
    }
    const changed = stls.filter((s) => ['different', 'only_a'].includes(states && states[s.name])).map((s) => partLabel(s.name));
    const gone = Object.entries(states || {}).filter(([, v]) => v === 'only_b').map(([n]) => partLabel(n));
    const link = h('a', null, splitName(origin).rest);
    link.addEventListener('click', () => view.app.select(origin));
    if (!states) mount(note, h('span', { class: 'muted' }, 'Comparing with ', link, '...'));
    else if (!changed.length && !gone.length) mount(note, h('span', { class: 'muted' }, 'Same geometry as its origin ', link));
    else {
      mount(note, h('span', { class: 'geo-changed' }, icon('alert'),
        [changed.length ? `${changed.join(', ')} changed` : null, gone.length ? `${gone.join(', ')} removed` : null].filter(Boolean).join(' · ')),
      h('span', { class: 'muted' }, ' compared with ', link));
    }
  };
  fillChips(null);

  if (!stls.length) { mount(pic, h('div', { class: 'geo-pic-msg' }, 'No STL files in constant/triSurface')); return card; }
  const showUrl = (url) => mount(pic, h('img', { src: url, alt: 'Car geometry', draggable: 'false' }));
  const fail = (msg) => mount(pic, h('div', { class: 'geo-pic-msg' }, icon('alert'), msg));
  // known picture: shown at once (the overview is redrawn often while a simulation runs)
  const known = infos.get(view.name);
  if (known && known.sig === stlSig(stls) && pictures.has(known.info.thumb)) {
    showUrl(pictures.get(known.info.thumb));
    if (known.info.states || !origin) fillChips(known.info.states);
  } else mount(pic, h('div', { class: 'geo-pic-msg' }, h('div', { class: 'spinner' }), 'Loading picture...'));

  (async () => {
    let info;
    try { info = await api.get('geometry/info', { name: view.name, other: origin || undefined }); } catch (e) { fail('Geometry not readable: ' + e.message); return; }
    infos.set(view.name, { sig: stlSig(stls), info });
    fillChips(info.states);
    if (!info.car) { fail('No car geometry found'); return; }
    if (info.thumb && pictures.has(info.thumb)) { showUrl(pictures.get(info.thumb)); return; }
    if (!info.has_thumb) mount(pic, h('div', { class: 'geo-pic-msg' }, h('div', { class: 'spinner' }), 'Rendering picture (once per geometry)...'));
    try { showUrl(await pictureUrl(view.name, info)); } catch (e) { fail('Picture could not be rendered: ' + e.message); }
  })();
  return card;
}

// ---------------------------------------------------------------- Geometry tab
export class GeometryTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx;
    this.hidden = new Set(store('geo-hidden') || []);
    this.geoms = new Map();            // 'A:' / 'B:' + file -> geom (B reuses A where the STL is the same)
    this.items = { A: new Map(), B: new Map() };     // file -> {pos, nrm, triangles}
    this.canCompare = ctx.app.can('compare');
    this.compare = { other: null, mode: (this.canCompare && store('geo-cmp-mode')) || 'off', states: null, highlight: store('geo-cmp-hl') !== false };
    this.hover = null;
    const stls = ctx.data.stls || [];
    if (!stls.length) {
      mount(el, h('div', { class: 'card' }, h('div', { class: 'empty' }, icon('cube', 'xl'), h('h3', null, 'No STL files'),
        h('div', null, 'constant/triSurface contains no STL files.'))));
      return;
    }
    this.build();
    this.init();
  }

  async init() {
    try { this.info = await api.get('geometry/info', { name: this.ctx.name }); } catch (e) { toastError(e); return; }
    if (this.dead) return;
    this.rv.mirror = this.mirrorOn() ? this.info.mirror : null;
    this.renderToolbar();
    this.renderPanel();
    const cam = store('geo-camera');
    if (cam && cam.target) Object.assign(this.rv.cam, cam);
    else if (this.info.view) this.gotoPictureView();
    else if (this.info.car) this.rv.setView('iso', this.carBox());
    await this.loadScene('A', this.ctx.name, this.info.stls);
    if (this.dead) return;
    if (!cam && !this.info.view) this.rv.setView('iso', this.carBox());
    if (this.compare.mode !== 'off') this.loadOther();
    // overview picture missing (new geometry or camera): made now from what is loaded anyway
    if (!this.info.has_thumb && !(this.info.thumb && pictures.has(this.info.thumb))) this.makePicture().catch(() => {});
  }

  loadedItems() {
    return this.info.stls.filter((s) => this.items.A.has(s.name) && this.geoms.has('A:' + s.name))
      .map((s) => ({ pos: this.items.A.get(s.name).pos, geom: this.geoms.get('A:' + s.name) }));
  }

  async makePicture() {
    const items = this.loadedItems();
    if (!items.length || !this.info.car) return;
    const states = this.info.states;
    this.info = Object.assign(await ensureView(this.ctx.name, this.info, items), { states });
    if (this.dead) return;
    if (!this.info.has_thumb) await storePicture(this.ctx.name, this.info, renderThumb(this.rv, items, this.info));
  }

  // ------------------------------------------------------------------ layout
  build() {
    this.panel = h('div', { class: 'rt-panel' });
    this.stage = h('div', { class: 'rt-stage geo-stage' });
    this.root = h('div', { class: 'rt-layout' }, this.panel, this.stage);
    mount(this.el, this.root);
    this.rv = new ResultView(this.stage);
    if (!this.rv.ok) {
      mount(this.stage, h('div', { class: 'empty' }, icon('alert', 'xl'), h('h3', null, 'WebGL 2 is not available'),
        h('div', null, 'Please update the graphics driver or use an up-to-date Edge / Chrome.')));
      return;
    }
    this.applyTheme();
    this.toolbar = h('div', { class: 'rt-toolbar' });
    this.tip = h('div', { class: 'rt-tip hidden' });
    this.busy = h('div', { class: 'rt-busy hidden' }, h('div', { class: 'spinner' }), h('span'));
    this.peekLabel = h('div', { class: 'rt-peek hidden' });
    this.wiper = h('div', { class: 'rt-wipe hidden' }, h('div', { class: 'rt-wipe-handle' }, icon('compare')),
      this.wipeA = h('span', { class: 'rt-wipe-label a' }), this.wipeB = h('span', { class: 'rt-wipe-label b' }));
    this.stage.append(this.toolbar, this.tip, this.busy, this.peekLabel, this.wiper);
    mount(this.panel, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    this.rv.onCamera = () => { clearTimeout(this._camT); this._camT = setTimeout(() => store('geo-camera', this.rv.cam), 400); };
    this.rv.onRender = () => this.positionWipe();
    this.bindStage();
    this.fitHeight();
    this._resize = () => this.fitHeight();
    window.addEventListener('resize', this._resize);
    this._fs = () => { this.root.classList.toggle('rt-fullscreen', document.fullscreenElement === this.root); this.fitHeight(); this.renderToolbar(); };
    document.addEventListener('fullscreenchange', this._fs);
  }

  fitHeight() {
    if (!this.stage) return;
    const full = document.fullscreenElement === this.root;
    const top = this.stage.getBoundingClientRect().top;
    this.stage.style.height = full ? '100vh' : Math.max(480, window.innerHeight - Math.max(top, 120) - 18) + 'px';
    this.panel.style.maxHeight = this.stage.style.height;
    if (this.rv) this.rv.redraw();
  }

  applyTheme() { this.rv.background = BG[theme()]; this.rv.redraw(); }

  mirrorOn() { return !!(this.info && this.info.mirror) && store('geo-mirror') !== false; }

  carBox() {
    const c = this.info && this.info.car;
    if (!c) return this.rv.sceneBox();
    if (!this.rv.mirror) return c;
    const [a, v] = this.rv.mirror, mn = c[0].slice(), mx = c[1].slice();
    mn[a] = Math.min(mn[a], 2 * v - c[1][a]); mx[a] = Math.max(mx[a], 2 * v - c[0][a]);
    return [mn, mx];
  }

  setBusy(text) {
    if (!this.busy) return;
    this.busy.classList.toggle('hidden', !text);
    if (text) this.busy.lastChild.textContent = text;
  }

  // ------------------------------------------------------------------ scenes
  async loadScene(scene, caseName, stls) {
    const gen = this.gen = (this.gen || 0) + 1;
    let done = 0;
    const want = stls.filter((s) => !(scene === 'B' && this.sameAsA(s.name)));
    const label = scene === 'A' ? 'Loading geometry' : 'Loading ' + splitName(caseName).rest;
    if (want.length) this.setBusy(`${label}... 0 / ${want.length}`);
    await loadParts(caseName, want, (s, d, err) => {
      if (this.dead || (scene === 'B' && gen !== this.gen)) return;
      done++;
      this.setBusy(done < want.length ? `${label}... ${done} / ${want.length}` : null);
      if (!d) { toastError(err, 'Could not read ' + s.name); return; }
      this.items[scene].set(s.name, d);
      const key = scene + ':' + s.name;
      if (this.geoms.has(key)) this.rv.free(this.geoms.get(key));
      this.geoms.set(key, this.rv.uploadMesh(d.pos, d.nrm));
      this.applyScene();
      if (scene === 'A') this.renderPanel();
    });
    if (this.dead || (scene === 'B' && gen !== this.gen)) return;
    this.setBusy(null);
    this.applyScene();
    this.renderPanel();
  }

  sameAsA(file) { return this.compare.states && this.compare.states[file] === 'same' && this.geoms.has('A:' + file); }

  changed(file, scene) {
    const st = this.compare.states && this.compare.states[file];
    return this.compare.mode !== 'off' && this.compare.highlight && (st === 'different' || st === (scene === 'A' ? 'only_a' : 'only_b'));
  }

  // layers of both scenes from the loaded parts, colours from theme / hover / changes
  applyScene() {
    if (!this.rv || !this.info) return;
    const base = CAR[theme()];
    const layers = (scene, stls) => stls.map((s) => {
      const geom = scene === 'B' && this.sameAsA(s.name) ? this.geoms.get('A:' + s.name) : this.geoms.get(scene + ':' + s.name);
      if (!geom) return null;
      const solid = this.hover === s.name ? HOVER : this.changed(s.name, scene) ? CHANGED : base;
      return { key: scene + s.name, file: s.name, geom, visible: !this.hidden.has(s.name), solid, lit: true };
    }).filter(Boolean);
    this.rv.scenes.A = layers('A', this.info.stls);
    this.rv.scenes.B = this.compare.mode !== 'off' && this.otherStls ? layers('B', this.otherStls) : [];
    this.rv.redraw();
  }

  // ------------------------------------------------------------------ comparison
  otherChoices() {
    const dated = (n) => (/^\d{8}/.test(n) ? '1' : '0') + n;
    return this.ctx.app.cases.filter((c) => c.name !== this.ctx.name).map((c) => c.name).sort((a, b) => dated(b).localeCompare(dated(a)));
  }

  async loadOther() {
    const others = this.otherChoices();
    if (!this.compare.other || !others.includes(this.compare.other)) {
      const origin = this.ctx.data.meta.origin;
      this.compare.other = others.includes(origin) ? origin : others[0] || null;
    }
    if (!this.compare.other) return;
    const other = this.compare.other;
    this.dropB();
    let r;
    try { r = await api.get('geometry/info', { name: other, other: this.ctx.name }); } catch (e) { toastError(e); return; }
    if (this.dead || other !== this.compare.other) return;
    // states seen from this simulation: swap only_a / only_b
    const flip = { only_a: 'only_b', only_b: 'only_a' };
    this.compare.states = Object.fromEntries(Object.entries(r.states || {}).map(([k, v]) => [k, flip[v] || v]));
    this.otherStls = r.stls;
    this.applyCompare();
    this.renderPanel();
    await this.loadScene('B', other, r.stls);
  }

  dropB() {
    this.gen = (this.gen || 0) + 1;
    for (const [k, g] of [...this.geoms]) if (k.startsWith('B:')) { this.rv.free(g); this.geoms.delete(k); }
    this.items.B.clear();
    this.otherStls = null;
    this.compare.states = null;
    if (this.rv) { this.rv.scenes.B = []; this.rv.redraw(); }
  }

  applyCompare() {
    const m = this.compare.mode;
    this.rv.mode = m === 'wipe' ? 'wipe' : 'normal';
    if (m !== 'peek') { this.rv.mix = 0; this.peekLabel.classList.add('hidden'); }
    this.wiper.classList.toggle('hidden', m !== 'wipe');
    this.wipeA.textContent = splitName(this.ctx.name).rest;
    this.wipeB.textContent = splitName(this.compare.other || '').rest;
    this.positionWipe();
    this.applyScene();
    this.renderToolbar();
  }

  setMode(m) {
    const was = this.compare.mode;
    this.compare.mode = m;
    store('geo-cmp-mode', m);
    if (m === 'off') { this.dropB(); this.applyCompare(); }
    else if (was === 'off' || !this.otherStls) { this.applyCompare(); this.loadOther(); }
    else this.applyCompare();
    this.renderPanel();
  }

  peek(on) {
    if (this.compare.mode !== 'peek' || !this.rv.scenes.B.length || this._peekOn === on) return;
    this._peekOn = on;
    const from = this.rv.mix, to = on ? 1 : 0, t0 = performance.now();
    cancelAnimationFrame(this._peekRaf);
    const step = () => {
      const f = Math.min(1, (performance.now() - t0) / 140);
      this.rv.mix = from + (to - from) * f;
      this.rv.redraw();
      if (f < 1) this._peekRaf = requestAnimationFrame(step);
    };
    step();
    this.peekLabel.textContent = on ? 'B: ' + splitName(this.compare.other).rest : '';
    this.peekLabel.classList.toggle('hidden', !on);
  }

  positionWipe() {
    if (!this.wiper || this.wiper.classList.contains('hidden')) return;
    this.wiper.style.left = (this.rv.wipe * 100) + '%';
  }

  // ------------------------------------------------------------------ panel
  renderPanel() {
    if (!this.info || !this.panel) return;
    const row = (...c) => h('div', { class: 'rt-row' }, ...c);
    const repl = this.ctx.data.meta.replaced_stls || [];
    const cmpOn = this.compare.mode !== 'off' && this.compare.states;
    const names = this.info.stls.map((s) => s.name);
    if (cmpOn) for (const s of this.otherStls || []) if (!names.includes(s.name)) names.push(s.name);
    const own = new Map(this.info.stls.map((s) => [s.name, s]));
    const allOn = this.info.stls.every((s) => !this.hidden.has(s.name));
    const toggleAll = h('a', { class: 'small', title: allOn ? 'Hide all parts' : 'Show all parts' }, allOn ? 'Hide all' : 'Show all');
    toggleAll.addEventListener('click', () => { if (allOn) names.forEach((n) => this.hidden.add(n)); else this.hidden.clear(); this.saveHidden(); });

    const rows = names.map((n) => {
      const s = own.get(n);
      const d = this.items.A.get(n);
      const st = cmpOn ? this.compare.states[n] : null;
      const rp = repl.find((x) => x.target === n);
      const vis = !this.hidden.has(n);
      const eye = h('button', { type: 'button', class: 'geo-eye' + (vis ? '' : ' off'), title: vis ? 'Hide' : 'Show' }, icon('eye'));
      eye.addEventListener('click', (e) => { e.stopPropagation(); if (vis) this.hidden.add(n); else this.hidden.delete(n); this.saveHidden(); });
      const r = h('div', { class: 'geo-part' + (vis ? '' : ' off') + (this.hover === n ? ' hover' : '') + (st && st !== 'same' ? ' changed' : ''),
        title: s ? `${n}\n${d ? fmtInt(d.triangles) + ' triangles, ' : ''}${fmtBytes(s.size)}` + (rp ? `\nreplaced from ${rp.source}` : '') : `${n}\nonly in ${this.compare.other}` },
      eye, h('span', { class: 'nm' }, partLabel(n)),
      st && st !== 'same' ? h('span', { class: 'geo-badge' }, STATE_LABEL[st]) : null,
      h('span', { class: 'sz' }, !s ? '' : d ? fmtInt(d.triangles) : h('span', { class: 'spinner sm' })));
      r.addEventListener('mouseenter', () => this.setHover(n));
      r.addEventListener('mouseleave', () => this.setHover(null));
      r.addEventListener('click', () => { if (vis) this.hidden.add(n); else this.hidden.delete(n); this.saveHidden(); });
      return r;
    });
    const total = this.info.stls.reduce((a, s) => a + s.size, 0);
    const partsCard = h('div', { class: 'rt-item geo-parts' }, ...rows,
      h('div', { class: 'muted small', style: { marginTop: '4px' } }, `${this.info.stls.length} STL files · ${fmtBytes(total)}. Shown simplified (at most ${fmtInt(BUDGET)} triangles per part).`));

    // comparison
    let cmp = null;
    if (this.canCompare) {
      const others = this.otherChoices();
      const sel = h('select', { class: 'input' }, others.map((n) => h('option', { value: n }, splitName(n).rest + (n === this.ctx.data.meta.origin ? '  (origin)' : ''))));
      if (!others.includes(this.compare.other)) this.compare.other = others.includes(this.ctx.data.meta.origin) ? this.ctx.data.meta.origin : others[0] || null;
      sel.value = this.compare.other || '';
      sel.addEventListener('change', () => { this.compare.other = sel.value; if (this.compare.mode !== 'off') this.loadOther(); else this.renderPanel(); });
      const modes = [{ label: 'Off', value: 'off' }, { label: 'Peek', value: 'peek' }, { label: 'Wipe', value: 'wipe' }];
      const hint = { off: 'Show the geometry of another simulation in the same view.', peek: 'Hold the Space bar (or the B button) to see the other simulation.',
        wipe: 'Drag the divider: left this simulation, right the other one.' }[this.compare.mode];
      const diff = cmpOn ? Object.values(this.compare.states).filter((v) => v !== 'same').length : 0;
      cmp = h('div', { class: 'rt-item' },
        row(h('b', { class: 'rt-name' }, 'Compare with')),
        others.length ? row(sel) : h('div', { class: 'muted small' }, 'No other simulation.'),
        row(segmented(modes, this.compare.mode, (v) => this.setMode(v))),
        h('div', { class: 'muted small' }, hint),
        this.compare.mode !== 'off' ? row(h('label', { class: 'rt-mini', style: { color: 'var(--text-2)' } },
          switchEl(this.compare.highlight, (v) => { this.compare.highlight = v; store('geo-cmp-hl', v); this.applyScene(); }), 'Highlight changed parts'),
        h('span', { class: 'spacer' }), cmpOn ? h('span', { class: 'small ' + (diff ? 'geo-changed' : 'muted') }, diff ? `${diff} different` : 'identical') : null) : null);
    }

    // overview picture camera
    const use = btn('Use current view', { size: 'sm', icon: 'eye', title: 'The overview pictures of all simulations are rendered from the camera shown here' });
    use.addEventListener('click', () => this.setPictureView(this.pictureCam()));
    const reset = btn('', { size: 'sm', icon: 'undo', variant: 'ghost', title: 'Back to the standard view (front three-quarter, whole car)' });
    reset.addEventListener('click', () => this.setPictureView(null));
    const goto = btn('Show', { size: 'sm', variant: 'ghost', title: 'Move the camera to the view of the overview pictures' });
    goto.addEventListener('click', () => this.gotoPictureView());
    const picCard = h('div', { class: 'rt-item' },
      row(h('b', { class: 'rt-name' }, 'Overview picture'), goto, reset),
      h('div', { class: 'muted small' }, 'The Overview shows a picture of the car - for every simulation from the same camera, so changes are easy to spot.'),
      row(use));

    const scroll = this.panel.scrollTop;
    mount(this.panel,
      h('div', { class: 'rt-section' }, h('span', null, 'Parts'), toggleAll), partsCard,
      cmp ? [h('div', { class: 'rt-section' }, h('span', null, 'Compare')), cmp] : null,
      h('div', { class: 'rt-section' }, h('span', null, 'Overview')), picCard);
    this.panel.scrollTop = scroll;
  }

  saveHidden() { store('geo-hidden', [...this.hidden]); this.applyScene(); this.renderPanel(); }

  setHover(n) {
    if (this.hover === n) return;
    this.hover = n;
    for (const r of this.panel.querySelectorAll('.geo-part')) r.classList.toggle('hover', r.querySelector('.nm').textContent === (n ? partLabel(n) : null));
    this.applyScene();
  }

  // the visible camera as picture camera: the 16:9 picture keeps the width seen here
  pictureCam() {
    const c = this.rv.cam, aspect = (this.rv.canvas.clientWidth || 16) / (this.rv.canvas.clientHeight || 9);
    const pa = this.info.aspect || 16 / 9;
    return { target: c.target.slice(), dist: c.dist * Math.max(1, aspect / pa), theta: c.theta, phi: c.phi, fov: c.fov, ortho: !!c.ortho };
  }

  gotoPictureView() {
    if (!this.info.view) return;
    const v = this.info.view, aspect = (this.rv.canvas.clientWidth || 16) / (this.rv.canvas.clientHeight || 9);
    // a view narrower than the picture moves back, so the whole picture is seen
    Object.assign(this.rv.cam, v, { target: v.target.slice(), dist: v.dist * Math.max(1, (this.info.aspect || 16 / 9) / aspect) });
    store('geo-camera', this.rv.cam);
    this.rv.redraw();
    this.renderToolbar();
  }

  // v: camera, or null = framed anew around this car from the standard direction
  async setPictureView(v) {
    try {
      await api.post('geometry/view', { view: v });
      this.info = await api.get('geometry/info', { name: this.ctx.name });
      await this.makePicture();
      toast(v ? 'Overview camera set' : 'Overview camera reset', 'The overview pictures of all simulations are rendered anew from this camera when they are shown next.', 'ok', 5000);
      this.renderToolbar();
    } catch (e) { toastError(e); }
  }

  // ------------------------------------------------------------------ toolbar
  renderToolbar() {
    if (!this.toolbar || !this.info) return;
    const views = btn('View', { size: 'sm', icon: 'eye', caret: true });
    views.addEventListener('click', () => showMenu(views, [
      { label: 'Camera', header: true },
      ...VIEWS.map(([v, l]) => ({ label: l, onClick: () => { this.rv.setView(v, this.carBox()); store('geo-camera', this.rv.cam); } })),
      { label: 'Fit to car', icon: 'fit', onClick: () => { this.rv.fitBox(this.carBox()); store('geo-camera', this.rv.cam); } },
      '-',
      { label: 'Overview picture view', icon: 'bookmark', sub: 'The camera of the overview pictures', onClick: () => this.gotoPictureView() },
    ]));
    const ortho = btn('Parallel', { size: 'sm', icon: 'cube', variant: this.rv.cam.ortho ? 'primary' : '',
      title: 'Parallel projection (no perspective): e.g. in the side view both wheels lie exactly on top of each other' });
    ortho.addEventListener('click', () => { this.rv.cam.ortho = !this.rv.cam.ortho; store('geo-camera', this.rv.cam); this.rv.redraw(); this.renderToolbar(); });
    const mirror = btn('Mirror', { size: 'sm', icon: 'compare', title: this.info.mirror ? 'Show both halves of the car' : 'No symmetry plane found',
      variant: this.mirrorOn() ? 'primary' : '', disabled: !this.info.mirror });
    mirror.addEventListener('click', () => {
      store('geo-mirror', !this.mirrorOn());
      this.rv.mirror = this.mirrorOn() ? this.info.mirror : null;
      this.rv.redraw(); this.renderToolbar();
    });
    const peek = btn('B', { size: 'sm', title: 'Hold to show the other simulation (or hold the Space bar)' });
    peek.addEventListener('mousedown', () => this.peek(true));
    peek.addEventListener('mouseup', () => this.peek(false));
    peek.addEventListener('mouseleave', () => this.peek(false));
    const shot = btn('Screenshot', { size: 'sm', icon: 'save', title: 'Save a clean image (resolution and background as in the Results tab) to the Screenshots folder' });
    shot.addEventListener('click', () => this.screenshot());
    const full = document.fullscreenElement === this.root;
    const fs = btn('', { size: 'sm', icon: 'fit', title: full ? 'Exit full screen (Esc)' : 'Full screen', variant: full ? 'primary' : '' });
    fs.addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); else this.root.requestFullscreen().catch(() => {}); });
    mount(this.toolbar, views, ortho, mirror, h('span', { class: 'rt-sep' }), this.compare.mode === 'peek' ? peek : null, shot, fs);
  }

  async screenshot() {
    const [w, hh] = (store('res-shot-res') || '3840x2160').split('x').map(Number);
    const bg = store('res-shot-bg') === 'black' ? [0, 0, 0] : [1, 1, 1];
    this.setBusy('Rendering screenshot...');
    await new Promise((r) => setTimeout(r, 30));
    try {
      const png = this.rv.screenshot(w, hh, { background: bg });
      const d = new Date(), p = (n) => String(n).padStart(2, '0');
      const stamp = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
      const mode = this.rv.mode === 'wipe' ? 'wipe-vs-' + splitName(this.compare.other || '').rest : null;
      const r = await api.post('results/screenshot', { png, parts: [stamp, splitName(this.ctx.name).rest, 'geometry', mode] });
      toast('Screenshot saved', `Screenshots/${r.file}  (${w} × ${hh})`, 'ok', 5000);
    } catch (e) { toastError(e, 'Screenshot failed'); } finally { this.setBusy(null); }
  }

  // ------------------------------------------------------------------ stage interaction
  bindStage() {
    const c = this.rv.canvas;
    let last = 0;
    c.addEventListener('mousemove', (e) => {
      if (this.rv.dragging()) { this.tip.classList.add('hidden'); return; }
      const now = performance.now();
      if (now - last < 60) return;
      last = now;
      this.hoverAt(e);
    });
    c.addEventListener('mouseleave', () => { this.tip.classList.add('hidden'); this.setHover(null); });
    let dragging = false;
    this.wiper.addEventListener('mousedown', (e) => { dragging = true; e.preventDefault(); });
    this._wmove = (e) => {
      if (!dragging) return;
      const r = this.stage.getBoundingClientRect();
      this.rv.wipe = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      this.positionWipe(); this.rv.redraw();
    };
    this._wup = () => { dragging = false; };
    window.addEventListener('mousemove', this._wmove);
    window.addEventListener('mouseup', this._wup);
    // Space = peek, also right after clicking a button or switch in the panel; text fields keep it
    this._key = (e) => {
      if (e.code !== 'Space' || this.compare.mode !== 'peek' || !this.root.isConnected) return;
      const t = e.target || {};
      const textField = t.isContentEditable || t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && /^(text|search|email|password|url|number|)$/.test(t.type || ''));
      if (textField || document.querySelector('.modal-backdrop')) return;
      e.preventDefault();
      if (t.blur && t !== document.body) t.blur();
      this.peek(e.type === 'keydown');
    };
    window.addEventListener('keydown', this._key);
    window.addEventListener('keyup', this._key);
  }

  // part under the mouse: name in a tooltip, highlighted in the view and in the list
  hoverAt(e) {
    const r = this.rv.canvas.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    const scene = this.rv.mix >= 0.5 ? 'B' : (this.rv.mode === 'wipe' && x / r.width > this.rv.wipe ? 'B' : 'A');
    const hit = this.rv.pick(x, y, scene);
    const layer = hit ? this.rv.scenes[scene][hit.layer] : null;
    if (!layer) { this.tip.classList.add('hidden'); this.setHover(null); return; }
    const st = this.compare.states && this.compare.states[layer.file];
    this.tip.textContent = partLabel(layer.file) + (scene === 'B' ? '  ·  B' : '') + (st && st !== 'same' && this.compare.mode !== 'off' ? '  ·  ' + STATE_LABEL[st] : '');
    this.tip.classList.remove('hidden');
    const tw = this.tip.offsetWidth, th = this.tip.offsetHeight;
    this.tip.style.left = (x + 14 + tw > r.width - 8 ? Math.max(8, x - tw - 14) : x + 14) + 'px';
    this.tip.style.top = (y + 12 + th > r.height - 8 ? Math.max(8, y - th - 12) : y + 12) + 'px';
    this.setHover(layer.file);
  }

  // ------------------------------------------------------------------ lifecycle
  onTheme() { if (this.rv && this.rv.ok) { this.applyTheme(); this.applyScene(); } }

  onCaseChanged(d) { this.ctx.data = d; }

  destroy() {
    this.dead = true;
    if (!this.root) return;
    if (document.fullscreenElement === this.root) document.exitFullscreen().catch(() => {});
    window.removeEventListener('resize', this._resize);
    document.removeEventListener('fullscreenchange', this._fs);
    window.removeEventListener('mousemove', this._wmove);
    window.removeEventListener('mouseup', this._wup);
    window.removeEventListener('keydown', this._key);
    window.removeEventListener('keyup', this._key);
    if (this.rv) {
      for (const g of this.geoms.values()) this.rv.free(g);
      this.rv.scenes = { A: [], B: [] };
      this.rv.destroy();
      this.rv = null;
    }
  }
}
