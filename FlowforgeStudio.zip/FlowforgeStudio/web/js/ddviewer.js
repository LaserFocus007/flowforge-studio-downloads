// Deep-dive tutorial viewer (deepdives.html), opened as its own window from the top bar.
// The pages come one at a time from the app server (decrypted there, app/deepdives.py, World licence only)
// and are drawn on canvases with the licensee as watermark. Continuous scrolling with lazy loading,
// contents, page previews, full-text search with highlights, clickable links, zoom, and the reading
// position of each tutorial is remembered.
import * as api from './api.js';
import { h, icon, btn } from './ui.js';

const KEY = 'flowforge-dd-state';
const BASE = 794;                                   // CSS px of an A4 page at 100 %
const STEPS = [0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5];
const PARALLEL = 3;                                 // pages fetched at the same time
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
const store = (s) => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* ignore */ } };
const norm = (s) => s.toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}]+/gu, '');

function fatal(msg) {
  const root = document.getElementById('ddv');
  root.replaceChildren(h('div', { class: 'ddv-msg' }, h('div', null, icon('book', 'xl'), h('p', null, msg))));
}

function watermark(g, w, ht, info) {
  const who = info.licensee || 'Licensed copy';
  const text = `${who} · ${info.machine}`;
  g.save();
  g.globalAlpha = 0.045;
  g.fillStyle = '#8a8d93';                         // mid grey, barely visible on white and on dark pages
  g.font = `600 ${Math.round(w / 42)}px sans-serif`;
  const step = g.measureText(text).width + w / 10;
  g.translate(w / 2, ht / 2);
  g.rotate(-Math.PI / 7);
  let row = 0;
  for (let y = -ht; y < ht; y += w / 5, row++) {
    for (let x = -w * 1.2 + (row % 2 ? step / 2 : 0); x < w * 1.2; x += step) g.fillText(text, x, y);
  }
  g.restore();
  g.save();
  g.globalAlpha = 0.35;
  g.fillStyle = '#6c7077';
  g.font = `${Math.round(w / 95)}px sans-serif`;
  g.textAlign = 'right';
  g.fillText(`Licensed to ${who} · ${info.machine} · not for distribution`, w - w / 30, w / 40);
  g.restore();
}

class Viewer {
  constructor(info) {
    this.info = info;
    this.st = load();
    this.st.pos = this.st.pos || {};
    this.text = {};               // doc id -> words per page (loaded on the first search)
    this.hits = [];
    this.hit = -1;
    this.queue = [];
    this.loading = 0;
    this.seq = 0;
  }

  start() {
    const i = this.info;
    this.docBtns = i.docs.map((d) => {
      const b = btn(d.title, { size: 'sm', variant: 'ghost' });
      b.addEventListener('click', () => this.open(d.id));
      return b;
    });
    const side = btn('', { icon: 'sidebar', variant: 'ghost', title: 'Show or hide the side panel' });
    side.addEventListener('click', () => this.setSide(!this.body.classList.contains('noside') ? false : true));
    this.pn = h('input', { class: 'input ddv-pn', type: 'text', inputmode: 'numeric', title: 'Page' });
    this.of = h('span', { class: 'ddv-of' });
    const prev = btn('', { icon: 'chevLeft', variant: 'ghost', title: 'Previous page (Left arrow)' });
    const next = btn('', { icon: 'chevRight', variant: 'ghost', title: 'Next page (Right arrow)' });
    prev.addEventListener('click', () => this.goTo(this.cur - 1));
    next.addEventListener('click', () => this.goTo(this.cur + 1));
    this.pn.addEventListener('change', () => this.goTo(parseInt(this.pn.value, 10) || 1));
    this.pn.addEventListener('focus', () => this.pn.select());
    const zout = btn('−', { variant: 'ghost', title: 'Zoom out (Ctrl -)' });
    const zin = btn('+', { variant: 'ghost', title: 'Zoom in (Ctrl +)' });
    zout.addEventListener('click', () => this.zoomStep(-1));
    zin.addEventListener('click', () => this.zoomStep(1));
    this.zsel = h('select', { class: 'ddv-zoomsel', title: 'Zoom' },
      h('option', { value: 'width' }, 'Page width'), h('option', { value: 'page' }, 'Whole page'),
      ...STEPS.map((z) => h('option', { value: String(z) }, Math.round(z * 100) + ' %')),
      h('option', { value: 'custom', hidden: true }, ''));
    this.zsel.addEventListener('change', () => this.setZoom(this.zsel.value === 'width' || this.zsel.value === 'page' ? this.zsel.value : parseFloat(this.zsel.value)));
    this.q = h('input', { class: 'input', type: 'search', placeholder: 'Search (Ctrl F)', spellcheck: 'false' });
    this.count = h('span', { class: 'ddv-count' });
    const sprev = btn('', { icon: 'arrowUp', variant: 'ghost', title: 'Previous result (Shift Enter)' });
    const snext = btn('', { icon: 'arrowDown', variant: 'ghost', title: 'Next result (Enter)' });
    sprev.addEventListener('click', () => this.stepHit(-1));
    snext.addEventListener('click', () => this.stepHit(1));
    this.q.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); if (this.lastQ !== this.q.value) this.search(); else this.stepHit(e.shiftKey ? -1 : 1); }
      if (e.key === 'Escape') { this.q.value = ''; this.search(); this.q.blur(); }
    });
    this.q.addEventListener('input', () => { clearTimeout(this.qt); this.qt = setTimeout(() => this.search(), 350); });

    const top = h('div', { class: 'ddv-top' }, side, h('div', { class: 'ddv-docs' }, ...this.docBtns), h('div', { class: 'sp' }),
      prev, this.pn, this.of, next, h('div', { class: 'sep' }), zout, this.zsel, zin, h('div', { class: 'sep' }),
      h('div', { class: 'ddv-search' }, this.q, this.count, sprev, snext));

    this.tabBtns = {};
    const tabs = h('div', { class: 'ddv-tabs' }, ...[['toc', 'Contents'], ['pages', 'Pages'], ['search', 'Search']].map(([k, label]) => {
      const b = btn(label, { size: 'sm', variant: 'ghost' });
      b.addEventListener('click', () => this.setTab(k));
      this.tabBtns[k] = b;
      return b;
    }));
    this.panels = { toc: h('div', { class: 'ddv-panel ddv-toc' }), pages: h('div', { class: 'ddv-panel' }), search: h('div', { class: 'ddv-panel ddv-res' }) };
    this.sideEl = h('aside', { class: 'ddv-side' }, tabs, this.panels.toc, this.panels.pages, this.panels.search);
    this.pagesEl = h('div', { class: 'ddv-pages' });
    this.scroll = h('main', { class: 'ddv-scroll' }, this.pagesEl);
    this.body = h('div', { class: 'ddv-body' }, this.sideEl, this.scroll);
    document.getElementById('ddv').replaceChildren(top, this.body);

    this.scroll.addEventListener('scroll', () => { if (!this.raf) this.raf = requestAnimationFrame(() => { this.raf = 0; this.onScroll(); }); });
    this.scroll.addEventListener('wheel', (e) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      this.zoomStep(e.deltaY < 0 ? 1 : -1);
    }, { passive: false });
    new ResizeObserver(() => { if (typeof this.st.zoom !== 'number' && this.doc) this.layout(); }).observe(this.scroll);
    document.addEventListener('keydown', (e) => this.onKey(e));
    document.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('beforeunload', () => this.savePos(true));

    this.setSide(this.st.side !== false);
    this.setTab(this.st.tab || 'toc');
    const first = this.info.docs.find((d) => d.id === this.st.doc) || this.info.docs[0];
    this.open(first.id);
  }

  // ------------------------------------------------------------ documents and layout
  open(id) {
    if (this.doc) this.savePos(true);
    const d = this.info.docs.find((x) => x.id === id);
    this.doc = d;
    this.st.doc = id;
    this.seq++;
    this.queue = [];
    this.docBtns.forEach((b, k) => b.classList.toggle('active', this.info.docs[k] === d));
    document.title = d.title + ' · Flowforge Studio';
    this.of.textContent = '/ ' + d.pages;
    if (this.io) this.io.disconnect();
    this.io = new IntersectionObserver((es) => es.forEach((e) => {
      const n = +e.target.dataset.n;
      if (e.isIntersecting) this.want(n); else this.release(n);
    }), { root: this.scroll, rootMargin: '1400px 0px' });
    this.pg = d.sizes.map(([w, ht], k) => {
      const ov = h('div', { class: 'ddv-ov' }, ...(d.links[k] || []).map((l) => this.linkEl(l)));
      const el = h('div', { class: 'ddv-pg', 'data-n': String(k + 1) }, h('div', { class: 'ph' }, 'Page ' + (k + 1)), ov);
      return { el, ov, w, h: ht, canvas: null, state: 0 };
    });
    this.pagesEl.replaceChildren(...this.pg.map((p) => p.el));
    this.buildToc();
    this.buildThumbs();
    this.hits = []; this.hit = -1; this.lastQ = null;
    if (this.q.value) this.search(); else { this.count.textContent = ''; this.panels.search.replaceChildren(h('div', { class: 'hint' }, 'Type a word or a phrase in the search box above.')); }
    this.layout(false);
    const pos = this.st.pos[id] || { page: 1, frac: 0 };
    this.goTo(pos.page, pos.frac, true);
    this.pg.forEach((p) => this.io.observe(p.el));
    store(this.st);
  }

  scale() {
    const z = this.st.zoom || 'width';
    if (typeof z === 'number') return z;
    const availW = Math.max(200, this.scroll.clientWidth - 56);
    const fitW = Math.min(availW / BASE, 2.5);
    if (z === 'width') return fitW;
    const [w, ht] = this.doc.sizes[0];
    return Math.min(fitW, (this.scroll.clientHeight - 32) / (BASE * ht / w));
  }

  layout(keep = true) {
    const anchor = keep ? this.position() : null;
    const s = this.scale();
    this.s = s;
    for (const p of this.pg) {
      const W = Math.round(BASE * s);
      p.el.style.width = W + 'px';
      p.el.style.height = Math.round(W * p.h / p.w) + 'px';
      p.el.style.fontSize = p.el.style.height;     // text layer sizes its words relative to the page height
    }
    const z = this.st.zoom || 'width';
    if (typeof z === 'number' && STEPS.includes(z)) this.zsel.value = String(z);
    else if (typeof z === 'number') { const o = this.zsel.querySelector('option[value=custom]'); o.textContent = Math.round(z * 100) + ' %'; this.zsel.value = 'custom'; }
    else this.zsel.value = z;
    if (anchor) this.goTo(anchor.page, anchor.frac, true);
  }

  setZoom(z) {
    this.st.zoom = z;
    store(this.st);
    this.layout();
  }

  zoomStep(dir) {
    const cur = this.s || 1;
    const next = dir > 0 ? STEPS.find((z) => z > cur + 0.01) : [...STEPS].reverse().find((z) => z < cur - 0.01);
    if (next) this.setZoom(next);
  }

  setSide(on) {
    this.body.classList.toggle('noside', !on);
    this.st.side = on;
    store(this.st);
    if (this.doc && typeof this.st.zoom !== 'number') this.layout();
  }

  setTab(k) {
    this.st.tab = k;
    store(this.st);
    for (const [name, el] of Object.entries(this.panels)) el.hidden = name !== k;
    for (const [name, b] of Object.entries(this.tabBtns)) b.classList.toggle('active', name === k);
    if (k === 'pages' && this.thumbEls) this.scrollThumb();
  }

  // ------------------------------------------------------------ position
  top(n) { return this.pg[n - 1].el.offsetTop; }

  position() {
    const y = this.scroll.scrollTop + 1;
    let n = 1;
    for (let k = 0; k < this.pg.length; k++) { if (this.pg[k].el.offsetTop <= y) n = k + 1; else break; }
    const p = this.pg[n - 1].el;
    return { page: n, frac: Math.max(0, Math.min(1, (y - p.offsetTop) / p.offsetHeight)) };
  }

  goTo(n, frac = 0, instant = false) {
    n = Math.max(1, Math.min(this.pg.length, n || 1));
    const p = this.pg[n - 1].el;
    const y = p.offsetTop + frac * p.offsetHeight - (frac ? 40 : 16) * (frac ? 1 : 1);
    this.scroll.scrollTo({ top: Math.max(0, y), behavior: instant ? 'auto' : 'auto' });
    this.onScroll();
  }

  onScroll() {
    if (!this.pg) return;
    const view = this.scroll.scrollTop + this.scroll.clientHeight * 0.3;
    let n = 1;
    for (let k = 0; k < this.pg.length; k++) { if (this.pg[k].el.offsetTop <= view) n = k + 1; else break; }
    if (n !== this.cur) {
      this.cur = n;
      if (document.activeElement !== this.pn) this.pn.value = n;
      this.markToc();
      this.markThumb();
    }
    clearTimeout(this.pt);
    this.pt = setTimeout(() => this.savePos(), 300);
  }

  savePos(now) {
    if (!this.doc || !this.pg) return;
    this.st.pos[this.doc.id] = this.position();
    if (now !== undefined) store(this.st); else store(this.st);
  }

  // ------------------------------------------------------------ pages
  want(n) {
    const p = this.pg[n - 1];
    if (!p || p.state) return;
    p.state = 1;
    this.queue.push(n);
    this.pump();
  }

  release(n) {
    const p = this.pg[n - 1];
    if (!p) return;
    if (p.canvas) { p.canvas.width = 0; p.canvas.height = 0; p.canvas.remove(); p.canvas = null; }
    if (p.tx) { p.tx.remove(); p.tx = null; }
    p.state = 0;
    this.queue = this.queue.filter((k) => k !== n);
  }

  pump() {
    while (this.loading < PARALLEL && this.queue.length) {
      // the page nearest to the current one first
      this.queue.sort((a, b) => Math.abs(a - (this.cur || 1)) - Math.abs(b - (this.cur || 1)));
      const n = this.queue.shift();
      this.loading++;
      this.render(n, this.seq).finally(() => { this.loading--; this.pump(); });
    }
  }

  async render(n, seq) {
    const p = this.pg[n - 1];
    try {
      const r = await api.getBinary('deepdives/page', { doc: this.doc.id, p: n });
      if (seq !== this.seq || p.state !== 1) return;
      const bmp = await createImageBitmap(new Blob([r.buffer], { type: 'image/webp' }));
      if (seq !== this.seq || p.state !== 1) { bmp.close(); return; }
      const c = h('canvas');
      c.width = bmp.width; c.height = bmp.height;
      const g = c.getContext('2d');
      g.drawImage(bmp, 0, 0);
      bmp.close();
      watermark(g, c.width, c.height, this.info);
      p.el.insertBefore(c, p.ov);
      p.canvas = c;
      p.state = 2;
      this.addText(p, n, seq);
    } catch (e) {
      if (seq === this.seq) { p.state = 0; p.el.querySelector('.ph').textContent = 'Page ' + n + ' could not be loaded'; }
    }
  }

  // invisible text layer on top of the page image so words can be selected (and copied) like in any PDF viewer
  async addText(p, n, seq) {
    const doc = this.doc;
    try {
      if (!this.text[doc.id]) {
        this.textLoad = this.textLoad || {};
        this.textLoad[doc.id] = this.textLoad[doc.id] || api.get('deepdives/text', { doc: doc.id }).then((r) => { this.text[doc.id] = r.pages; });
        await this.textLoad[doc.id];
      }
    } catch (e) { if (this.textLoad) delete this.textLoad[doc.id]; return; }
    if (seq !== this.seq || p.state !== 2 || p.tx) return;
    const tx = h('div', { class: 'ddv-tx' });
    for (const w of (this.text[doc.id][n - 1] || [])) {
      const s = h('span', null, w[4] + ' ');
      Object.assign(s.style, { left: w[0] * 100 + '%', top: w[1] * 100 + '%', height: (w[3] - w[1]) * 100 + '%', fontSize: (w[3] - w[1]) * 88 + '%' });
      tx.append(s);
    }
    p.el.insertBefore(tx, p.ov);
    p.tx = tx;
  }

  linkEl(l) {
    const a = h('a', { class: 'ddv-link', title: l.u ? l.u : 'Go to page ' + l.p });
    Object.assign(a.style, { left: l.r[0] * 100 + '%', top: l.r[1] * 100 + '%', width: (l.r[2] - l.r[0]) * 100 + '%', height: (l.r[3] - l.r[1]) * 100 + '%' });
    a.addEventListener('click', (e) => {
      e.preventDefault();
      if (l.u) window.open(l.u, '_blank', 'noopener');
      else this.goTo(l.p, l.y || 0);
    });
    return a;
  }

  // ------------------------------------------------------------ contents and previews
  buildToc() {
    const toc = this.doc.toc || [];
    this.tocEls = toc.map(([lvl, title, page, y]) => {
      const a = h('a', { class: 'l' + lvl }, h('span', null, title), h('span', null, String(page)));
      a.addEventListener('click', (e) => { e.preventDefault(); this.goTo(page, y || 0); });
      return { a, page };
    });
    this.panels.toc.replaceChildren(...(this.tocEls.length ? this.tocEls.map((t) => t.a) : [h('div', { class: 'hint' }, 'No contents for this tutorial.')]));
  }

  markToc() {
    if (!this.tocEls) return;
    let cur = null;
    for (const t of this.tocEls) { if (t.page <= this.cur) cur = t; }
    this.tocEls.forEach((t) => t.a.classList.toggle('cur', t === cur));
  }

  buildThumbs() {
    if (this.tio) this.tio.disconnect();
    const seq = this.seq;
    this.tio = new IntersectionObserver((es) => es.forEach((e) => {
      if (!e.isIntersecting) return;
      const n = +e.target.dataset.n;
      this.tio.unobserve(e.target);
      api.getBinary('deepdives/page', { doc: this.doc.id, p: n, thumb: 1 }).then((r) => {
        if (seq !== this.seq) return;
        const img = h('img', { alt: '', draggable: 'false' });
        img.src = URL.createObjectURL(new Blob([r.buffer], { type: 'image/webp' }));
        e.target.querySelector('.im').append(img);
      }).catch(() => {});
    }), { root: this.panels.pages, rootMargin: '600px 0px' });
    this.thumbEls = this.doc.sizes.map(([w, ht], k) => {
      const el = h('div', { class: 'ddv-thumb', 'data-n': String(k + 1) }, h('div', { class: 'im', style: { aspectRatio: w + ' / ' + ht } }), String(k + 1));
      el.addEventListener('click', () => this.goTo(k + 1));
      return el;
    });
    this.panels.pages.replaceChildren(h('div', { class: 'ddv-thumbs' }, ...this.thumbEls));
    this.thumbEls.forEach((el) => this.tio.observe(el));
  }

  markThumb() {
    if (!this.thumbEls) return;
    this.thumbEls.forEach((el, k) => el.classList.toggle('cur', k + 1 === this.cur));
    if (this.st.tab === 'pages') this.scrollThumb();
  }

  scrollThumb() {
    const el = this.thumbEls && this.thumbEls[(this.cur || 1) - 1];
    if (!el) return;
    const pr = this.panels.pages;
    if (el.offsetTop < pr.scrollTop || el.offsetTop + el.offsetHeight > pr.scrollTop + pr.clientHeight) pr.scrollTop = el.offsetTop - pr.clientHeight / 3;
  }

  // ------------------------------------------------------------ search
  async search() {
    const q = this.q.value.trim();
    this.lastQ = this.q.value;
    this.clearHits();
    const parts = q.split(/\s+/).map(norm).filter(Boolean);
    if (!parts.length) { this.count.textContent = ''; this.panels.search.replaceChildren(h('div', { class: 'hint' }, 'Type a word or a phrase in the search box above.')); return; }
    const doc = this.doc;
    if (!this.text[doc.id]) {
      this.count.textContent = '…';
      try { this.text[doc.id] = (await api.get('deepdives/text', { doc: doc.id })).pages; } catch (e) { this.count.textContent = 'failed'; return; }
      if (this.doc !== doc || this.q.value.trim() !== q) return;
    }
    const pages = this.text[doc.id];
    const hits = [];
    pages.forEach((words, k) => {
      const nw = words.map((w) => norm(w[4]));
      for (let i = 0; i + parts.length <= nw.length; i++) {
        let ok = true;
        for (let j = 0; j < parts.length && ok; j++) {
          const w = nw[i + j], p = parts[j];
          if (parts.length === 1) ok = w.includes(p);
          else if (j === 0) ok = w.endsWith(p);
          else if (j === parts.length - 1) ok = w.startsWith(p);
          else ok = w === p;
        }
        if (ok) {
          const boxes = words.slice(i, i + parts.length).map((w) => w.slice(0, 4));
          const before = words.slice(Math.max(0, i - 6), i).map((w) => w[4]).join(' ');
          const match = words.slice(i, i + parts.length).map((w) => w[4]).join(' ');
          const after = words.slice(i + parts.length, i + parts.length + 8).map((w) => w[4]).join(' ');
          hits.push({ page: k + 1, boxes, before, match, after });
        }
      }
    });
    this.hits = hits;
    this.hit = -1;
    this.count.textContent = hits.length ? `0 / ${hits.length}` : 'none';
    this.drawHits();
    this.resEls = hits.slice(0, 500).map((r, idx) => {
      const a = h('a', null, h('b', null, 'p. ' + r.page), (r.before ? '… ' + r.before + ' ' : ''), h('mark', null, r.match), ' ' + r.after + ' …');
      a.addEventListener('click', (e) => { e.preventDefault(); this.showHit(idx); });
      return a;
    });
    this.panels.search.replaceChildren(...(hits.length ? [h('div', { class: 'hint' }, `${hits.length} result${hits.length === 1 ? '' : 's'} in ${doc.title}`), ...this.resEls]
      : [h('div', { class: 'hint' }, `Nothing found for “${q}” in ${doc.title}.`)]));
    if (hits.length) {
      if (this.st.tab !== 'search' && !this.body.classList.contains('noside')) this.setTab('search');
      // first result at or after the current page
      const k = hits.findIndex((r) => r.page >= (this.cur || 1));
      this.showHit(k < 0 ? 0 : k);
    }
  }

  clearHits() { this.pagesEl.querySelectorAll('.ddv-hit').forEach((e) => e.remove()); }

  drawHits() {
    this.clearHits();
    this.hits.forEach((r, idx) => r.boxes.forEach((b) => {
      const d = h('div', { class: 'ddv-hit' + (idx === this.hit ? ' cur' : '') });
      Object.assign(d.style, { left: b[0] * 100 + '%', top: b[1] * 100 + '%', width: (b[2] - b[0]) * 100 + '%', height: (b[3] - b[1]) * 100 + '%' });
      d.dataset.i = idx;
      this.pg[r.page - 1].ov.append(d);
    }));
  }

  showHit(idx) {
    if (!this.hits.length) return;
    this.hit = (idx + this.hits.length) % this.hits.length;
    const r = this.hits[this.hit];
    this.pagesEl.querySelectorAll('.ddv-hit').forEach((d) => d.classList.toggle('cur', +d.dataset.i === this.hit));
    this.count.textContent = `${this.hit + 1} / ${this.hits.length}`;
    (this.resEls || []).forEach((a, k) => a.classList.toggle('cur', k === this.hit));
    const a = this.resEls && this.resEls[this.hit];
    if (a && this.st.tab === 'search') a.scrollIntoView({ block: 'nearest' });
    const p = this.pg[r.page - 1].el;
    const y = p.offsetTop + r.boxes[0][1] * p.offsetHeight;
    if (y < this.scroll.scrollTop + 40 || y > this.scroll.scrollTop + this.scroll.clientHeight - 80) this.scroll.scrollTop = y - this.scroll.clientHeight / 3;
  }

  stepHit(dir) {
    if (this.lastQ !== this.q.value) { this.search(); return; }
    this.showHit(this.hit + dir);
  }

  // ------------------------------------------------------------ keyboard
  onKey(e) {
    const inInput = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT');
    const k = e.key;
    if ((e.ctrlKey || e.metaKey) && (k === 'f' || k === 'F')) { e.preventDefault(); this.q.focus(); this.q.select(); return; }
    if ((e.ctrlKey || e.metaKey) && (k === 'p' || k === 'P' || k === 's' || k === 'S')) { e.preventDefault(); return; }
    if ((e.ctrlKey || e.metaKey) && (k === '+' || k === '=')) { e.preventDefault(); this.zoomStep(1); return; }
    if ((e.ctrlKey || e.metaKey) && k === '-') { e.preventDefault(); this.zoomStep(-1); return; }
    if ((e.ctrlKey || e.metaKey) && k === '0') { e.preventDefault(); this.setZoom('width'); return; }
    if (inInput) return;
    if (k === 'ArrowRight') { e.preventDefault(); this.goTo(this.cur + 1); }
    else if (k === 'ArrowLeft') { e.preventDefault(); this.goTo(this.cur - 1); }
    else if (k === 'Home') { e.preventDefault(); this.goTo(1); }
    else if (k === 'End') { e.preventDefault(); this.goTo(this.pg.length); }
  }
}

async function boot() {
  if (!api.initToken()) { fatal('Please open the tutorials from Flowforge Studio.'); return; }
  try {
    const inf = await api.get('info');
    document.documentElement.dataset.theme = inf.config && inf.config.theme === 'light' ? 'light' : 'dark';
  } catch (e) { /* keep dark */ }
  let info;
  try { info = await api.get('deepdives'); } catch (e) { fatal('Flowforge Studio is not running: ' + e.message); return; }
  if (!info.installed) { fatal('The deep-dive tutorials are not part of this installation. Download the current version of Flowforge Studio to get them.'); return; }
  if (!info.allowed) { fatal('The deep-dive tutorials 03 and 04 come with the World licence' + (info.trial ? ', not with the 3-day trial.' : '.')); return; }
  new Viewer(info).start();
}

boot();
