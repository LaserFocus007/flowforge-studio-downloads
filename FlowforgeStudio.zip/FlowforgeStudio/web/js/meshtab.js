// Mesh tab: shows the boundary faces of constant/polyMesh (car surfaces, symmetry plane cut)
// and a movable section through the volume mesh.

import * as api from './api.js';
import { h, mount, icon, btn, toastError, fmtInt, segmented, store, colorPick } from './ui.js';
import { Viewer3D } from './viewer3d.js';

const MESH_GROUPS = [
  ['car', 'Car', (p) => p.type === 'wall' && /^wall/.test(p.name), '#ff8a2a', true],
  ['sym', 'Symmetry plane', (p) => p.type === 'symmetryPlane' || /symm/i.test(p.name), '#4d8dff', true],
  ['floor', 'Floor', (p) => /floor|ground/i.test(p.name), '#9aa3b2', false],
  ['domain', 'Domain boundaries', () => true, '#7c7c86', false],
];

const SECTION_COLOR = '#4d8dff';

function emptyState(ic, title, text) {
  return h('div', { class: 'card' }, h('div', { class: 'empty' }, icon(ic, 'xl'), h('h3', null, title), h('div', null, text)));
}

// surface colour under the coloured cell edges: clearly lighter than the dark background,
// clearly darker than the light one, and neutral so the edge colours stay readable
function autoFill() {
  return document.documentElement.dataset.theme !== 'light' ? '#454a56' : '#c3c8d2';
}

// user colours (Display card / group swatches): { surface: '#..', groups: { car: '#..' } }
function userColours() { return store('mesh-colours') || { groups: {} }; }
function fillColor() { return userColours().surface || autoFill(); }

export class MeshTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx; this.loaded = new Set(); this.visible = new Map();
    this.style = store('mesh-style') || 'both';
    mount(el, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    this.init();
  }

  async init() {
    let info;
    try { info = await api.get('mesh/info', { name: this.ctx.name }); } catch (e) { toastError(e); return; }
    if (this.dead) return;
    if (!info.patches.length) {
      const running = this.ctx.data.status === 'running';
      mount(this.el, emptyState('grid', running ? 'Meshing in progress' : 'Not meshed yet',
        running ? 'The mesh appears here as soon as meshing is finished.' : 'Run "Mesh only" or a full run to create the mesh.'));
      return;
    }
    this.patches = info.patches.map((p) => {
      const g = MESH_GROUPS.find((gr) => gr[2](p));
      return Object.assign({}, p, { group: g[0], color: (userColours().groups || {})[g[0]] || g[3] });
    });
    const saved = store('mesh-visible-' + this.ctx.name) || null;
    for (const p of this.patches) {
      const g = MESH_GROUPS.find((gr) => gr[0] === p.group);
      this.visible.set(p.name, saved && p.name in saved ? !!saved[p.name] : g[4]);
    }

    const vc = h('div');
    const list = h('div', { class: 'part-list' });
    for (const [gid, glabel, , color] of MESH_GROUPS) {
      const ps = this.patches.filter((p) => p.group === gid);
      if (!ps.length) continue;
      const allOn = () => ps.every((p) => this.visible.get(p.name));
      const gcb = h('input', { type: 'checkbox' });
      gcb.checked = allOn();
      const rows = ps.map((p) => {
        const cb = h('input', { type: 'checkbox' });
        cb.checked = this.visible.get(p.name);
        cb.addEventListener('change', () => { this.toggle(p, cb.checked); gcb.checked = allOn(); });
        p.cb = cb;
        return h('label', { class: 'part-row', style: { '--c': p.color, cursor: 'pointer', paddingLeft: '24px' } }, cb,
          h('span', { class: 'nm' }, p.name), h('span', { class: 'sz' }, fmtInt(p.nFaces)));
      });
      gcb.addEventListener('change', () => {
        ps.forEach((p) => { p.cb.checked = gcb.checked; this.toggle(p, gcb.checked); });
      });
      const gcol = ps[0].color;
      const pick = colorPick(gcol, (v) => {
        const uc = userColours(); uc.groups = uc.groups || {}; uc.groups[gid] = v; store('mesh-colours', uc);
      }, 'Edge colour of ' + glabel, (v) => {
        for (const p of ps) { p.color = v; this.viewer && this.viewer.updateLines('l:' + p.name, { color: v }); }
        rows.forEach((r) => r.style.setProperty('--c', v));
      });
      this.groupPicks = this.groupPicks || new Map();
      this.groupPicks.set(gid, { pick, rows });
      list.append(h('div', { class: 'part-row', style: { '--c': gcol, fontWeight: 650 } },
        gcb, pick, h('span', { class: 'nm' }, glabel)), ...rows);
    }

    const styleSeg = segmented([{ label: 'Surface + edges', value: 'both' }, { label: 'Edges', value: 'edges' },
      { label: 'Surface', value: 'surface' }], this.style, (v) => { this.style = v; store('mesh-style', v); this.applyStyle(); });
    const pv = btn('Open in ParaView', { size: 'sm', icon: 'external', disabled: !this.ctx.app.info.paraview });
    pv.addEventListener('click', () => this.ctx.view.open('paraview_mesh'));
    const m = info.mesh || {};
    const stats = h('div', { class: 'kv' },
      h('span', { class: 'k' }, 'Cells'), h('span', { class: 'v' }, m.cells ? fmtInt(m.cells) : '-'),
      h('span', { class: 'k' }, 'Hexahedra'), h('span', { class: 'v' }, m.cells && m.hexahedra ? (m.hexahedra / m.cells * 100).toFixed(1) + ' %' : '-'),
      h('span', { class: 'k' }, 'Max non-orthogonality'), h('span', { class: 'v' }, m.max_non_ortho != null ? m.max_non_ortho.toFixed(1) + '°' : '-'),
      h('span', { class: 'k' }, 'checkMesh'), h('span', { class: 'v' }, m.cells ? (m.failed_checks ? m.failed_checks + ' failed' : 'OK') : '-'));

    mount(this.el, h('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 300px', gap: '14px' } }, vc,
      h('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px' } },
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('grid'), 'Mesh')), stats,
          h('div', { style: { marginTop: '12px' } }, pv)),
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('eye'), 'Display')), styleSeg,
          this.colourRow(),
          h('div', { class: 'muted small', style: { marginTop: '8px' } },
            'The symmetry plane shows the cut through the volume mesh - refinement levels and boundary layers are visible there.')),
        this.secCard = h('div', { class: 'card' }),
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('layers'), 'Patches')), list))));

    this.viewer = new Viewer3D(vc, { height: Math.max(480, window.innerHeight - 300) });
    for (const [lbl, v] of [['Iso', 'iso'], ['Side', 'side'], ['Front', 'front'], ['Top', 'top']]) {
      const b = btn(lbl, { size: 'sm' });
      b.addEventListener('click', () => this.viewer.view(v));
      this.viewer.tools.appendChild(b);
    }
    this.viewer.cam.ortho = !!store('mesh-ortho');
    const ortho = btn('Parallel', { size: 'sm', variant: this.viewer.cam.ortho ? 'primary' : '',
      title: 'Parallel projection (no perspective): e.g. in the side view both wheels lie exactly on top of each other' });
    ortho.addEventListener('click', () => {
      this.viewer.cam.ortho = !this.viewer.cam.ortho; store('mesh-ortho', this.viewer.cam.ortho);
      ortho.classList.toggle('btn-primary', this.viewer.cam.ortho); this.viewer.redraw();
    });
    this.viewer.tools.appendChild(ortho);
    const fit = btn('', { size: 'sm', icon: 'fit', title: 'Fit view' });
    fit.addEventListener('click', () => this.viewer.fit());
    this.viewer.tools.appendChild(fit);
    this.viewer.setLoading(true, 'Loading mesh...');
    for (const p of this.patches) if (this.visible.get(p.name)) await this.loadPatch(p);
    if (!this.viewer) return;
    this.viewer.setLoading(false);
    // start zoomed onto the car (with a margin), not onto the whole flow domain
    const car = this.viewer.boxOf(this.patches.filter((p) => p.group === 'car').map((p) => 'l:' + p.name));
    if (car) {
      const pad = 0.25 * Math.max(car[1][1] - car[0][1], car[1][2] - car[0][2]);
      this.viewer.cam.theta = 0; this.viewer.cam.phi = 0.02;
      this.viewer.fitBox(car[0].map((v) => v - pad), car[1].map((v) => v + pad));
    } else this.viewer.view('side');
    const all = btn('Domain', { size: 'sm', title: 'Show the whole flow domain' });
    all.addEventListener('click', () => { this.viewer._focus = null; this.viewer.fit(); });
    const carBtn = btn('Car', { size: 'sm', title: 'Zoom to the car' });
    carBtn.addEventListener('click', () => { if (car) this.viewer.fitBox(car[0], car[1]); });
    this.viewer.tools.prepend(carBtn, all);
    this.car = car;
    this.buildSection();
  }

  // ---------------------------------------------------------------- movable section
  async buildSection() {
    const key = 'mesh-section-' + this.ctx.name;
    const saved = store(key) || {};
    this.sec = { on: !!saved.on, axis: saved.axis != null ? saved.axis : 0, pos: saved.pos || {}, cutAway: saved.cutAway !== false,
      busy: false, want: null, shown: null };
    const save = () => store(key, { on: this.sec.on, axis: this.sec.axis, pos: this.sec.pos, cutAway: this.sec.cutAway });

    const onCb = h('input', { type: 'checkbox' }); onCb.checked = this.sec.on;
    const cutCb = h('input', { type: 'checkbox' }); cutCb.checked = this.sec.cutAway;
    const slider = h('input', { type: 'range', min: 0, max: 2000, step: 1, style: { width: '100%' } });
    const num = h('input', { type: 'number', class: 'input', step: 0.1, style: { width: '110px' } });
    const status = h('span', { class: 'muted small' });
    const controls = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '10px' } });
    let syncInputs = () => {};
    const axisSeg = segmented([{ label: 'Side', value: 0, title: 'Side section (normal to X)' }, { label: 'Top', value: 2, title: 'Top section (normal to Z)' },
      { label: 'Front', value: 1, title: 'Front section (normal to Y, the flow direction)' }],
      this.sec.axis, (v) => { this.sec.axis = v; save(); syncInputs(); this.requestSection(); });
    controls.append(axisSeg, slider,
      h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, num, h('span', { class: 'muted small' }, 'mm'), status),
      h('label', { class: 'part-row', style: { cursor: 'pointer' } }, cutCb, h('span', { class: 'nm' }, 'Hide geometry in front of the section')),
      h('div', { class: 'muted small' }, 'Drag the slider or use the arrow keys on it. The first section per axis takes a few seconds.'));
    mount(this.secCard, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('scissors'), 'Section')),
      h('label', { class: 'part-row', style: { cursor: 'pointer', fontWeight: 650 } }, onCb, h('span', { class: 'nm' }, 'Show section through the volume mesh')),
      controls);
    this.sec.status = status;
    controls.style.display = this.sec.on ? '' : 'none';

    let bounds;
    try { bounds = (await api.get('mesh/bounds', { name: this.ctx.name })).bounds; } catch (e) { toastError(e); return; }
    if (!this.viewer) return;
    const range = (a) => [bounds[0][a], bounds[1][a]];
    const posOf = (a) => {
      const v = this.sec.pos[a];
      if (v != null && v >= range(a)[0] && v <= range(a)[1]) return v;
      return this.car ? (this.car[0][a] + this.car[1][a]) / 2 : (range(a)[0] + range(a)[1]) / 2;
    };
    // the slider spans the car (+50 % margin), not the whole flow domain - the number field reaches everything
    const sliderRange = (a) => {
      const [lo, hi] = range(a);
      if (!this.car) return [lo, hi];
      const m = 0.5 * (this.car[1][a] - this.car[0][a]);
      return [Math.max(lo, this.car[0][a] - m), Math.min(hi, this.car[1][a] + m)];
    };
    syncInputs = () => {
      const a = this.sec.axis, [lo, hi] = sliderRange(a), v = posOf(a);
      slider.value = String(Math.round((v - lo) / (hi - lo) * 2000));
      num.value = (v * 1000).toFixed(2);
    };
    this.sec.posOf = posOf;
    const setPos = (v) => {
      const [lo, hi] = range(this.sec.axis);
      this.sec.pos[this.sec.axis] = Math.min(hi, Math.max(lo, v));
      save();
      this.requestSection();
    };
    slider.addEventListener('input', () => {
      const [lo, hi] = sliderRange(this.sec.axis);
      setPos(lo + (+slider.value / 2000) * (hi - lo));
      num.value = (posOf(this.sec.axis) * 1000).toFixed(2);
    });
    num.addEventListener('change', () => { const v = parseFloat(num.value); if (isFinite(v)) { setPos(v / 1000); syncInputs(); } });
    const applyOn = () => {
      controls.style.display = this.sec.on ? '' : 'none';
      if (this.sec.on) this.requestSection(); else this.removeSection();
    };
    onCb.addEventListener('change', () => { this.sec.on = onCb.checked; save(); applyOn(); });
    cutCb.addEventListener('change', () => { this.sec.cutAway = cutCb.checked; save(); this.applyCut(); });
    syncInputs();
    applyOn();
  }

  applyCut() {
    if (!this.viewer || !this.sec) return;
    const on = this.sec.on && this.sec.cutAway && this.sec.shown;
    this.viewer.setCut(on ? { axis: this.sec.shown.axis, pos: this.sec.shown.pos } : null);
  }

  removeSection() {
    if (!this.viewer) return;
    this.viewer.remove('m:__section'); this.viewer.removeLines('l:__section');
    this.sec.shown = null;
    this.sec.status.textContent = '';
    this.applyCut();
  }

  // only one request at a time; while it runs, the newest wanted position is remembered
  async requestSection() {
    const s = this.sec;
    if (!s || !s.on || !s.posOf) return;
    s.want = { axis: s.axis, pos: s.posOf(s.axis) };
    if (s.busy) return;
    s.busy = true;
    const slow = setTimeout(() => {
      if (this.viewer) this.viewer.setLoading(true, 'Preparing the section (first time for this axis)...');
    }, 900);
    try {
      while (s.want && s.on && this.viewer) {
        const w = s.want; s.want = null;
        s.status.textContent = 'updating...';
        const r = await api.getBinary('mesh/section', { name: this.ctx.name, axis: 'xyz'[w.axis], pos: w.pos });
        if (!this.viewer || !s.on) break;
        const head = new Uint32Array(r.buffer, 0, 2);
        const tris = new Float32Array(r.buffer.slice(8, 8 + head[0] * 4));
        const lines = new Float32Array(r.buffer.slice(8 + head[0] * 4, 8 + (head[0] + head[1]) * 4));
        this.viewer.addMesh('m:__section', tris, { color: fillColor() });
        this.viewer.addLines('l:__section', lines, { color: SECTION_COLOR, alpha: 0.9 });
        s.shown = w;
        s.status.textContent = fmtInt(lines.length / 6) + ' cell edges';
        this.applyStyle();
        this.applyCut();
      }
    } catch (e) {
      toastError(e, 'Could not compute the section');
      s.status.textContent = '';
    } finally {
      clearTimeout(slow);
      s.busy = false;
      if (this.viewer) this.viewer.setLoading(false);
    }
    if (s.want && s.on && this.viewer) this.requestSection();
  }

  async loadPatch(p) {
    if (this.loaded.has(p.name) || !this.viewer) return;
    this.loaded.add(p.name);
    try {
      const r = await api.getBinary('mesh/patch', { name: this.ctx.name, patch: p.name });
      if (!this.viewer) return;
      const head = new Uint32Array(r.buffer, 0, 2);
      const tris = new Float32Array(r.buffer.slice(8, 8 + head[0] * 4));
      const lines = new Float32Array(r.buffer.slice(8 + head[0] * 4, 8 + (head[0] + head[1]) * 4));
      this.viewer.addMesh('m:' + p.name, tris, { color: fillColor(), cuttable: true });
      this.viewer.addLines('l:' + p.name, lines, { color: p.color, alpha: 0.85, cuttable: true });
      this.applyStyle();
    } catch (e) {
      this.loaded.delete(p.name);
      toastError(e, 'Could not load ' + p.name);
    }
  }

  async toggle(p, on) {
    this.visible.set(p.name, on);
    store('mesh-visible-' + this.ctx.name, Object.fromEntries(this.visible));
    if (on && !this.loaded.has(p.name) && this.viewer) {
      this.viewer.setLoading(true, 'Loading ' + p.name + '...');
      await this.loadPatch(p);
      if (this.viewer) this.viewer.setLoading(false);
    }
    this.applyStyle();
  }

  applyStyle() {
    if (!this.viewer) return;
    for (const p of this.patches || []) {
      const on = this.visible.get(p.name);
      this.viewer.update('m:' + p.name, { visible: on && this.style !== 'edges' });
      this.viewer.updateLines('l:' + p.name, { visible: on && this.style !== 'surface' });
    }
    this.viewer.update('m:__section', { visible: this.style !== 'edges' });
    this.viewer.updateLines('l:__section', { visible: this.style !== 'surface' });
  }

  colourRow() {
    const reset = btn('Auto', { size: 'sm', variant: 'ghost', title: 'Back to the automatic colours' });
    reset.addEventListener('click', () => {
      store('mesh-colours', { groups: {} });
      for (const p of this.patches || []) {
        p.color = MESH_GROUPS.find((g) => g[0] === p.group)[3];
        if (this.viewer) this.viewer.updateLines('l:' + p.name, { color: p.color });
      }
      this.onTheme();
      const setPick = (pick, v) => { pick.querySelector('input').value = v; pick.style.setProperty('--c', v); };
      for (const [gid, { pick, rows }] of this.groupPicks || []) {
        const v = MESH_GROUPS.find((g) => g[0] === gid)[3];
        setPick(pick, v); rows.forEach((r) => r.style.setProperty('--c', v));
      }
      setPick(surf, autoFill());
    });
    const setSurface = (v, save) => {
      if (save) { const u = userColours(); u.surface = v; store('mesh-colours', u); }
      if (!this.viewer) return;
      for (const p of this.patches || []) this.viewer.update('m:' + p.name, { color: v });
      this.viewer.update('m:__section', { color: v });
    };
    const surf = colorPick(fillColor(), (v) => setSurface(v, true), 'Surface colour', (v) => setSurface(v, false));
    return h('div', { class: 'rt-colors', style: { marginTop: '10px' } },
      h('span', null, 'Surface colour'), surf,
      h('span', { class: 'grow' }),
      reset);
  }

  onTheme() {
    if (!this.viewer) return;
    for (const p of this.patches || []) this.viewer.update('m:' + p.name, { color: fillColor() });
    this.viewer.update('m:__section', { color: fillColor() });
  }

  onCaseChanged(d) {
    const had = this.ctx.data.has_mesh;
    this.ctx.data = d;
    if (!had && d.has_mesh) {
      if (this.viewer) { this.viewer.destroy(); this.viewer = null; }
      this.loaded.clear();
      this.init();
    }
  }

  destroy() {
    this.dead = true;
    if (this.viewer) { this.viewer.destroy(); this.viewer = null; }
  }
}
