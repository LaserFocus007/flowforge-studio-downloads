// Tabs of the detail view: residuals, forces, logs, settings, geometry, compare.

import * as api from './api.js';
import { h, mount, clear, icon, btn, toast, toastError, showMenu, confirmDialog, fmtBytes, fmtNum, fmtForce,
  fmtCells, fmtInt, esc, switchEl, segmented, debounce, store, statusPill, convergencePill, meanUncertainty, uncOf } from './ui.js';
import { LineChart } from './chart.js';
import { Viewer3D, PART_COLORS } from './viewer3d.js';
import { wheelTable } from './wheelsui.js';
import { PartsPanel } from './partforces.js';
import { CopPanel } from './copview.js';

const RES_COLORS = { Ux: '#4d8dff', Uy: '#22c55e', Uz: '#a78bfa', p: '#ff7a1a', k: '#f472b6', omega: '#2dd4bf', epsilon: '#facc15', nuTilda: '#f87171' };

function emptyState(ic, title, text) {
  return h('div', { class: 'card' }, h('div', { class: 'empty' }, icon(ic, 'xl'), h('h3', null, title), h('div', null, text)));
}

// =====================================================================================
export class ResidualsTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx; this.chart = null; this.busy = false; this.last = 0;
    mount(el, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    this.load();
  }

  async load() {
    if (this.busy) return;
    this.busy = true;
    try {
      const r = await api.get('residuals', { name: this.ctx.name });
      this.last = Date.now();
      this.render(r);
    } catch (e) { toastError(e); } finally { this.busy = false; }
  }

  render(r) {
    if (!r.time.length) {
      if (this.chart) { this.chart.destroy(); this.chart = null; }
      mount(this.el, emptyState('wave', 'No residuals yet', 'Residuals appear here as soon as the solver runs (from logfoam).'));
      return;
    }
    if (!this.chart) {
      const logSw = switchEl(true, (v) => this.chart.setLogY(v));
      const reset = btn('Reset zoom', { size: 'sm', icon: 'fit', variant: 'ghost' });
      reset.addEventListener('click', () => this.chart.resetZoom());
      const card = h('div', { class: 'card' });
      this.info = h('div', { class: 'muted small' });
      card.append(h('div', { class: 'chart-toolbar' },
        h('div', { class: 'card-title' }, icon('wave'), 'Initial residuals'),
        h('div', { class: 'row' }, this.info, h('label', { class: 'switch-row small' }, logSw, 'Log scale'), reset)));
      mount(this.el, card, h('div', { class: 'muted small', style: { marginTop: '8px' } },
        'Drag to zoom, double-click to reset. Click legend entries to hide fields. First solve per iteration is shown (p is solved twice).'));
      this.chart = new LineChart(card, { height: Math.max(360, window.innerHeight - 430), logY: true, xLabel: 'Iteration', yLabel: 'Initial residual',
        xFormat: (v) => String(Math.round(v)), valueFormat: (v) => v.toExponential(2) });
    }
    this.chart.setSeries(r.fields.map((f, i) => ({ name: f.name, x: r.time, y: f.values, color: RES_COLORS[f.name] })));
    const n = r.time.length;
    this.info.textContent = `${fmtInt(Math.round(r.time[n - 1]))} iterations`;
  }

  onTick(running) { if (running && Date.now() - this.last > 5000) this.load(); }
  onCaseChanged() { this.load(); }
  onTheme() { if (this.chart) this.chart.draw(); }
  destroy() { if (this.chart) this.chart.destroy(); }
}

// =====================================================================================
export class ForcesTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx; this.charts = []; this.last = 0; this.busy = false;
    this.window = null;            // null = window of the server statistics (auto or configured)
    this.parts = Object.assign({ mean: true }, store('force-parts') || {});
    mount(el, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    this.load();
  }

  async load() {
    if (this.busy) return;
    this.busy = true;
    try {
      this.f = await api.get('forces', { name: this.ctx.name });
      this.last = Date.now();
      this.render();
    } catch (e) { toastError(e); } finally { this.busy = false; }
  }

  win() {
    const w = this.window || (this.f && this.f.stats && this.f.stats.window) || 250;
    return Math.max(1, Math.min(w, (this.f && this.f.time.length) || w));
  }

  stats(arr) {
    const v = arr.slice(-this.win());
    if (!v.length) return null;
    const mean = v.reduce((a, b) => a + b, 0) / v.length;
    const std = Math.sqrt(v.reduce((a, b) => a + (b - mean) ** 2, 0) / v.length);
    let mn = Infinity, mx = -Infinity;
    for (const x of v) { if (x < mn) mn = x; if (x > mx) mx = x; }
    const sem = meanUncertainty(v);
    return { mean, std, sem, min: mn, max: mx, rel: mean ? std / Math.abs(mean) : null, n: v.length };
  }

  // convergence relative to the overall force level (a lift close to zero would otherwise never 'converge')
  verdictOf(s) {
    if (!s) return null;
    const f = this.f;
    const ref = Math.max(Math.abs(this.stats(f.drag.total).mean), Math.abs(this.stats(f.lift.total).mean), 1e-12);
    return convergencePill((s.sem != null ? s.sem : s.std) / ref);
  }

  render() {
    const f = this.f;
    this.charts.forEach((c) => c.destroy());
    this.charts = [];
    if (this.partsPanel) { this.partsPanel.destroy(); this.partsPanel = null; }
    if (this.copPanel) { this.copPanel.destroy(); this.copPanel = null; }
    if (!f || !f.time || !f.time.length) {
      mount(this.el, emptyState('chart', 'No force data yet', 'Forces are read from postProcessing/forces once the solver has run.'));
      return;
    }
    const t = f.time;
    const n = t.length;
    const win = h('input', { class: 'input', type: 'number', min: 1, value: this.win(), style: { width: '90px' } });
    win.addEventListener('change', () => { this.window = Math.max(1, parseInt(win.value, 10) || 250); this.render(); });
    const autoNote = !this.window && f.stats && f.stats.mode === 'auto' ? h('span', { class: 'muted small' }, '(auto: start-up transient excluded)') : null;
    const meanSw = switchEl(this.parts.mean, (v) => { this.parts.mean = v; store('force-parts', this.parts); this.render(); });
    const zoomBtn = btn('Zoom to window', { size: 'sm', icon: 'target', variant: 'ghost' });
    const resetBtn = btn('Reset', { size: 'sm', icon: 'fit', variant: 'ghost' });
    const xlsBtn = btn('Open in Excel', { size: 'sm', icon: 'table', variant: 'ghost', title: 'All iterations (forces, residuals) and a summary as an .xlsx file - for your own charts' });
    xlsBtn.addEventListener('click', async () => {
      xlsBtn.disabled = true;
      try {
        const r = await api.post('forces/export', { name: this.ctx.name });
        toast('Exported', r.file + ' (folder Exports)', 'ok');
      } catch (e) { toastError(e, 'Export failed'); } finally { xlsBtn.disabled = false; }
    });
    const band = [t[Math.max(0, n - this.win())], t[n - 1], `averaging window (${this.win()} it)`];
    const pct = (x, ref) => (ref ? (100 * x / Math.abs(ref)).toFixed(x / Math.abs(ref) < 0.01 ? 3 : 2) + ' %' : '-');

    // one card per force: a row of aligned key figures (total, its uncertainty, the split) and a large chart
    const forceCard = (q, title, ic) => {
      const s = this.stats(f[q].total), sp = this.stats(f[q].pressure), sv = this.stats(f[q].viscous);
      const unc = s.sem != null ? s.sem : s.std;
      const fig = (label, value, unit, cls) => h('div', { class: 'ff' + (cls ? ' ' + cls : '') },
        h('div', { class: 'ff-k' }, label), h('div', { class: 'ff-v' }, value, unit ? h('small', null, unit) : null));
      const chartBox = h('div', { class: 'ff-chart' });
      const card = h('div', { class: 'card force-card' },
        h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon(ic), title + ' (total)'), this.verdictOf(s)),
        h('div', { class: 'ff-row' },
          fig('Mean', fmtForce(s.mean), 'N', 'main'),
          fig('Uncertainty', '±' + pct(unc, s.mean), null, 'accent'),
          fig('Swings', '±' + pct(s.std, s.mean)),
          fig('Pressure', fmtForce(sp.mean), 'N'),
          fig('Viscous', fmtForce(sv.mean), 'N')),
        chartBox);
      const c = new LineChart(chartBox, { height: 440, legend: false, xLabel: 'Iteration', ySkipFraction: 0.15,
        xFormat: (v) => String(Math.round(v)), valueFormat: (v) => v.toFixed(5) });
      const series = [{ name: 'total', x: t, y: f[q].total, color: q === 'drag' ? (getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#ff7a1a') : (this.ctx.app.info.license.tier === 'national' ? '#f0a030' : '#4d8dff'), width: 1.6 }];
      if (this.parts.mean) series.push(...this.meanSeries(f[q].total));
      c.setSeries(series);
      c.setBand(band);
      this.charts.push(c);
      return { card, c, q };
    };
    const D = forceCard('drag', 'Drag', 'wind'), Lf = forceCard('lift', 'Lift', 'arrowUp');
    mount(this.el,
      h('div', { class: 'chart-toolbar card', style: { padding: '10px 14px', marginBottom: '14px' } },
        h('div', { class: 'row' }, h('span', { class: 'muted small' }, 'Average over last'), win, h('span', { class: 'muted small' }, 'iterations'), autoNote),
        h('div', { class: 'row' }, h('label', { class: 'switch-row small' }, meanSw, 'Running mean ± uncertainty'), zoomBtn, resetBtn, xlsBtn)),
      h('div', { class: 'grid cols-2' }, D.card, Lf.card));
    if (f.parts) {
      this.partsPanel = new PartsPanel(this);
      this.el.appendChild(this.partsPanel.el);
    }
    if (f.pitch && f.cop_geometry) {
      this.copPanel = new CopPanel(this);
      this.el.appendChild(this.copPanel.el);
    }
    // charts are created before mounting: redraw once they have their size
    requestAnimationFrame(() => this.charts.forEach((c) => c.draw()));
    const zoom = () => {
      const i0 = Math.max(0, n - this.win());
      for (const { c, q } of [D, Lf]) {
        let mn = Infinity, mx = -Infinity;
        for (let i = i0; i < n; i++) { mn = Math.min(mn, f[q].total[i]); mx = Math.max(mx, f[q].total[i]); }
        const pad = (mx - mn) * 0.15 || Math.abs(mx) * 0.01 || 1e-3;
        c.xView = [t[Math.max(0, i0 - Math.round(this.win() * 0.1))], t[n - 1]];
        c.setYRange([mn - pad, mx + pad]);
      }
    };
    zoomBtn.addEventListener('click', zoom);
    resetBtn.addEventListener('click', () => { D.c.resetZoom(); Lf.c.resetZoom(); });
  }

  // Running mean of the total force over the averaging window, and the band +- its uncertainty
  // (1 sigma). The swings of the signal itself are large; the mean settles towards one value.
  meanSeries(y) {
    const t = this.f.time, n = t.length, i0 = Math.max(0, n - this.win());
    const mean = new Array(n).fill(null);
    let sum = 0;
    for (let i = i0; i < n; i++) { sum += y[i]; mean[i] = sum / (i - i0 + 1); }
    const bx = [], lo = [], hi = [];
    const step = Math.max(1, Math.floor((n - i0) / 80));
    for (let i = i0 + 19; i < n; i += step) {
      const u = meanUncertainty(y.slice(i0, i + 1));
      if (u == null) continue;
      bx.push(t[i]); lo.push(mean[i] - u); hi.push(mean[i] + u);
    }
    if (bx.length && bx[bx.length - 1] !== t[n - 1]) {
      const u = meanUncertainty(y.slice(i0));
      if (u != null) { bx.push(t[n - 1]); lo.push(mean[n - 1] - u); hi.push(mean[n - 1] + u); }
    }
    const col = getComputedStyle(document.documentElement).getPropertyValue('--text').trim() || '#e5e7eb';
    return [
      { name: '± uncertainty', x: bx, y: lo, y2: hi, color: col, alpha: 0.18,
        format: (i) => '± ' + (100 * (hi[i] - lo[i]) / 2 / Math.abs((hi[i] + lo[i]) / 2)).toFixed(3) + ' %' },
      { name: 'running mean', x: t, y: mean, color: col, width: 2 },
    ];
  }

  onTick(running) { if (running && Date.now() - this.last > 8000) this.load(); }
  onCaseChanged() { this.load(); }
  onTheme() { if (this.f) this.render(); }
  destroy() { this.charts.forEach((c) => c.destroy()); if (this.partsPanel) this.partsPanel.destroy(); if (this.copPanel) this.copPanel.destroy(); }
}

// =====================================================================================
const LINE_RULES = [
  [/FOAM FATAL|FATAL ERROR|job aborted|Segmentation|sigFpe::sigHandler|^\s*ERROR|\bERROR:|aborted the job|Abort requested|ABORTED/, 'l-err'],
  [/^\[\d\d:\d\d:\d\d\] (>|===)/, 'l-step'],
  [/^Time = /, 'l-time'],
  [/WARNING|Warning|warning|failed mesh check|illegal faces/, 'l-warn'],
  [/^End\s*$|Mesh OK\.|Finished meshing|done in|=== finished: (finished|meshed)/, 'l-ok'],
];

export class LogsTab {
  constructor(el, ctx, opts = {}) {
    this.el = el; this.ctx = ctx;
    this.file = (opts && opts.file) || store('log-file') || null;
    this.follow = true; this.wrap = !!store('log-wrap');
    this.offset = null; this.text = ''; this.busy = false; this.search = '';
    this.build();
  }

  build() {
    const logs = this.ctx.data.logs || [];
    if (!logs.length) { mount(this.el, emptyState('log', 'No logs yet', 'Logs appear once meshing or solving has started.')); return; }
    if (!this.file || !logs.find((l) => l.file === this.file)) {
      const pref = this.ctx.data.status === 'running'
        ? (logs.find((l) => l.key === 'logfoam') || logs.find((l) => l.key === 'logsnap') || logs.find((l) => l.key === 'pipeline'))
        : (logs.find((l) => l.key === 'pipeline') || logs.find((l) => l.key === 'logfoam'));
      this.file = (pref || logs[0]).file;
    }
    // the main logs as chips, the many single-utility logs (log.blockMesh, log.decomposePar, ...) in a list
    const pick = (file) => { this.file = file; store('log-file', file); this.offset = null; this.text = ''; this.build(); };
    const tabs = h('div', { class: 'log-tabs' });
    const isMain = (l) => l.label !== l.file || l.file === 'checkMesh';
    const main = logs.filter(isMain);
    const other = logs.filter((l) => !isMain(l));
    for (const l of main) {
      const c = h('span', { class: 'filter' + (l.file === this.file ? ' active' : ''), title: `${l.file} \u00b7 ${fmtBytes(l.size)}` }, l.label);
      c.addEventListener('click', () => pick(l.file));
      tabs.appendChild(c);
    }
    if (other.length) {
      const isOther = other.some((l) => l.file === this.file);
      const sel = h('select', { class: 'input' + (isOther ? ' dirty' : ''), style: { width: 'auto', height: '26px', fontSize: '12px' } },
        h('option', { value: '' }, `Other logs (${other.length})`),
        other.map((l) => h('option', { value: l.file }, `${l.label}  \u00b7  ${fmtBytes(l.size)}`)));
      sel.value = isOther ? this.file : '';
      sel.addEventListener('change', () => { if (sel.value) pick(sel.value); });
      tabs.appendChild(sel);
    }
    const followSw = switchEl(this.follow, (v) => { this.follow = v; if (v) this.scrollEnd(); });
    const wrapSw = switchEl(this.wrap, (v) => { this.wrap = v; store('log-wrap', v); this.view.classList.toggle('wrap', v); });
    const search = h('input', { class: 'input', placeholder: 'Find in log...', style: { width: '200px' }, value: this.search });
    search.addEventListener('input', debounce(() => { this.search = search.value; this.renderText(true); }, 250));
    search.addEventListener('keydown', (e) => { if (e.key === 'Enter') this.nextMatch(e.shiftKey ? -1 : 1); });
    const openBtn = btn('', { size: 'sm', icon: 'external', variant: 'ghost', title: 'Open in editor' });
    openBtn.addEventListener('click', () => this.ctx.view.open('file', { file: this.file }));
    const errBtn = btn('Jump to error', { size: 'sm', icon: 'alert', variant: 'ghost' });
    errBtn.addEventListener('click', () => {
      const e = this.view.querySelector('.l-err');
      if (e) { this.follow = false; followSw.input.checked = false; e.scrollIntoView({ block: 'center' }); } else toast('No errors found in the loaded part of this log', '', 'ok', 2500);
    });
    this.matchInfo = h('span', { class: 'muted small' });
    this.pre = h('pre', { class: 'mono' });
    this.view = h('div', { class: 'log-view' + (this.wrap ? ' wrap' : '') }, this.pre);
    this.view.addEventListener('scroll', () => {
      const atEnd = this.view.scrollHeight - this.view.scrollTop - this.view.clientHeight < 30;
      if (!atEnd && this.follow && this._userScroll) { this.follow = false; followSw.input.checked = false; }
      this._userScroll = true;
    });
    this.truncNote = h('div', { class: 'muted small hidden', style: { marginBottom: '6px' } }, 'Showing the last 400 KB of this log. Open it in the editor for the full file.');
    mount(this.el,
      h('div', { class: 'log-toolbar' }, tabs),
      h('div', { class: 'log-toolbar' }, search, this.matchInfo, h('span', { class: 'spacer' }),
        errBtn, h('label', { class: 'switch-row small' }, followSw, 'Follow'), h('label', { class: 'switch-row small' }, wrapSw, 'Wrap'), openBtn),
      this.truncNote, this.view);
    if (!this._onResize) {
      this._onResize = () => { this.fitHeight(); if (this.follow) this.scrollEnd(); };
      window.addEventListener('resize', this._onResize);
    }
    requestAnimationFrame(() => this.fitHeight());
    this.load();
  }

  async load() {
    if (this.busy || !this.file) return;
    this.busy = true;
    try {
      const r = await api.get('log', { name: this.ctx.name, file: this.file, offset: this.offset });
      if (r.missing) { this.text = ''; this.renderText(true); return; }
      r.text = r.text.split(String.fromCharCode(13)).join('');
      if (this.offset === null || r.reset) { this.text = r.text; this.truncNote.classList.toggle('hidden', !r.truncated); this.renderText(true); }
      else if (r.text) { this.text += r.text; this.appendText(r.text); }
      this.offset = r.offset;
    } catch (e) { /* transient */ } finally { this.busy = false; }
  }

  lineHtml(line) {
    let cls = null;
    for (const [re, c] of LINE_RULES) if (re.test(line)) { cls = c; break; }
    let s = esc(line);
    if (this.search) {
      const q = esc(this.search).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      s = s.replace(new RegExp(q, 'gi'), (m) => `<mark>${m}</mark>`);
    }
    return cls ? `<span class="${cls}">${s}</span>` : s;
  }

  renderText(scroll) {
    const lines = this.text.split('\n');
    this.pre.innerHTML = lines.map((l) => this.lineHtml(l)).join('\n');
    this.updateMatches();
    if (this.search) this.nextMatch(1, true);
    else if (this.follow || scroll) this.scrollEnd();
  }

  appendText(t) {
    const lines = t.split('\n');
    const html = lines.map((l) => this.lineHtml(l)).join('\n');
    this.pre.insertAdjacentHTML('beforeend', html);
    if (this.follow) this.scrollEnd();
  }

  scrollEnd() {
    this.fitHeight();
    this._userScroll = false;
    this.view.scrollTop = this.view.scrollHeight;
    // keep the bottom of the log box on screen (the run panel above can push it down)
    const content = document.getElementById('content');
    const r = this.view.getBoundingClientRect(), c = content.getBoundingClientRect();
    if (r.bottom > c.bottom - 8) content.scrollTop += r.bottom - c.bottom + 16;
  }

  // the log box fills the space below the toolbar, whatever is shown above it
  fitHeight() {
    if (!this.view || !this.view.isConnected) return;
    const content = document.getElementById('content');
    const top = this.view.getBoundingClientRect().top - content.getBoundingClientRect().top + content.scrollTop;
    const h = Math.max(320, content.clientHeight - top - 18);
    if (Math.abs(this.view.offsetHeight - h) > 2) this.view.style.height = h + 'px';
  }

  updateMatches() {
    this.matches = [...this.pre.querySelectorAll('mark')];
    this.matchIdx = -1;
    this.matchInfo.textContent = this.search ? `${this.matches.length} match${this.matches.length === 1 ? '' : 'es'}` : '';
  }

  nextMatch(dir, first = false) {
    if (!this.matches || !this.matches.length) return;
    if (this.matches[this.matchIdx]) this.matches[this.matchIdx].classList.remove('current');
    this.matchIdx = first ? this.matches.length - 1 : (this.matchIdx + dir + this.matches.length) % this.matches.length;
    const m = this.matches[this.matchIdx];
    m.classList.add('current');
    this.follow = false;
    m.scrollIntoView({ block: 'center' });
    this.matchInfo.textContent = `${this.matchIdx + 1} / ${this.matches.length}`;
  }

  onTick(running) {
    this.fitHeight();
    if (running) this.load();
  }
  onCaseChanged(d) {
    const before = JSON.stringify((this.ctx.data.logs || []).map((l) => l.file));
    this.ctx.data = d;
    if (before !== JSON.stringify((d.logs || []).map((l) => l.file))) { this.offset = null; this.text = ''; this.build(); }
  }
  destroy() { if (this._onResize) window.removeEventListener('resize', this._onResize); }
}

// =====================================================================================
function fmtLen(m) { return m < 0.1 ? (m * 1000).toPrecision(3).replace(/\.?0+$/, '') + ' mm' : m.toPrecision(3) + ' m'; }

// "= 0.56 mm" next to a refinement level input (cell size = base / 2^level)
function levelSizeTag(base, levels, ...inputs) {
  const tag = h('span', { class: 'unit', style: { minWidth: '64px' } });
  const upd = () => {
    const ls = levels().filter((l) => Number.isInteger(l) && l >= 0);
    tag.textContent = ls.length ? '= ' + [...new Set(ls.map((l) => fmtLen(base / 2 ** l)))].join(' \u2026 ') : '';
  };
  inputs.forEach((i) => i.addEventListener('input', upd));
  upd();
  return tag;
}

export class SettingsTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx; this.dirty = new Map(); this.inputs = new Map();
    this.load();
  }

  async load() {
    mount(this.el, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    try {
      this.model = await api.get('settings', { name: this.ctx.name });
      this.render();
    } catch (e) { toastError(e); }
  }

  render() {
    this.dirty.clear(); this.inputs.clear(); this.afterRender = [];
    const running = this.ctx.data.status === 'running';
    const nav = h('div', { class: 'settings-nav' });
    const groups = h('div');
    this.navCounts = new Map();
    for (const g of this.model.groups) {
      const cnt = h('span', { class: 'n' });
      this.navCounts.set(g.id, cnt);
      const a = h('a', null, icon(g.icon || 'sliders'), g.title, cnt);
      a.addEventListener('click', () => document.getElementById('sg-' + g.id).scrollIntoView({ behavior: 'smooth', block: 'start' }));
      nav.appendChild(a);
      const fields = h('div', { class: 'settings-fields' });
      let section = null;
      for (const f of g.fields) {
        if (f.section && f.section !== section) { section = f.section; fields.appendChild(h('div', { class: 'settings-sub' }, section)); }
        fields.appendChild(this.fieldEl(f, g, running && !f.live));
      }
      const files = [...new Set(g.fields.map((f) => f.file).filter((x) => x !== '@meta'))];
      const fileLinks = h('div', { class: 'row' }, files.map((file) => {
        const b = btn(file.split('/').pop(), { size: 'sm', variant: 'ghost', icon: 'external', title: 'Open ' + file + ' in the editor' });
        b.addEventListener('click', () => this.ctx.view.open('file', { file }));
        return b;
      }));
      groups.appendChild(h('div', { class: 'card settings-group', id: 'sg-' + g.id },
        h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon(g.icon || 'sliders'), g.title), fileLinks),
        g.info ? h('div', { class: 'muted small', style: { marginBottom: '12px' } }, g.info) : null,
        g.id === 'wheels' ? this.wheelPanel(running) : null,
        fields));
    }
    this.savebar = h('div', { class: 'savebar hidden' });
    mount(this.el,
      running ? h('div', { class: 'callout warn', style: { marginBottom: '14px' } }, icon('alert'), h('div', { class: 'callout-body' },
        'The simulation is running. Only the end time, write interval and the averaging / automatic stop settings can be changed now (they are picked up live).')) : null,
      h('div', { class: 'settings-layout' }, nav, h('div', null, groups, this.savebar)));
    this.afterRender.forEach((fn) => fn());
  }

  // k and omega from turbulence intensity and eddy viscosity ratio
  turbHelper(g) {
    const b = btn('', { size: 'sm', icon: 'wind', variant: 'ghost', title: 'Calculate k and \u03c9 from turbulence intensity and viscosity ratio' });
    b.addEventListener('click', async () => {
      const flowIn = this.inputs.get('flowVelocity');
      const U = flowIn ? Math.hypot(...flowIn.map((i) => Number(i.value))) : 20;
      const nu = g.nu || 1.5e-5;
      const iIn = h('input', { class: 'input', value: store('turb-I') || '0.5' });
      const rIn = h('input', { class: 'input', value: store('turb-r') || '10' });
      const out = h('div', { class: 'mono', style: { marginTop: '12px' } });
      const calc = () => {
        const I = Number(iIn.value) / 100, r = Number(rIn.value);
        const k = 1.5 * (U * I) ** 2, om = k / (r * nu);
        out.textContent = isFinite(k) && isFinite(om) && k > 0 && om > 0 ? `k = ${fmtNum(k, 3)} m\u00b2/s\u00b2   \u03c9 = ${fmtNum(om, 3)} 1/s` : '-';
        return { k, om };
      };
      iIn.addEventListener('input', calc); rIn.addEventListener('input', calc); calc();
      const ok = await confirmDialog({ title: 'Inflow turbulence', confirmLabel: 'Use values',
        message: h('div', null,
          h('p', { class: 'muted', style: { marginTop: 0 } }, `k = 1.5 (U I)\u00b2,  \u03c9 = k / (\u03bd \u00b7 \u03bdt/\u03bd)  with U = ${fmtNum(U, 3)} m/s, \u03bd = ${nu} m\u00b2/s. `
            + 'A car driving through still air: I \u2248 0.1-1 %, \u03bdt/\u03bd \u2248 1-10. Larger values make the incoming air artificially "viscous".'),
          h('div', { class: 'grid cols-2' }, h('div', { class: 'field' }, h('label', null, 'Turbulence intensity I [%]'), iIn),
            h('div', { class: 'field' }, h('label', null, 'Viscosity ratio \u03bdt/\u03bd'), rIn)), out) });
      if (!ok) return;
      store('turb-I', iIn.value); store('turb-r', rIn.value);
      const { k, om } = calc();
      if (!(k > 0 && om > 0)) return;
      for (const [id, v] of [['turbulentKE', k], ['turbulentOmega', om]]) {
        const inp = (this.inputs.get(id) || [])[0];
        if (inp) { inp.value = fmtNum(v, 4); inp.dispatchEvent(new Event('input')); }
      }
    });
    return b;
  }

  fieldEl(f, g, disabled) {
    const set = (val, valid = true) => {
      const changed = JSON.stringify(val) !== JSON.stringify(f.value);
      if (changed && valid) this.dirty.set(f.id, { f, val, g }); else this.dirty.delete(f.id);
      this.updateSavebar();
      return changed;
    };
    let control;
    const mark = (els, changed, valid = true) => els.forEach((e) => { e.classList.toggle('dirty', changed && valid); e.classList.toggle('invalid', !valid); });
    if (f.type === 'int' || f.type === 'float') {
      const inp = h('input', { class: 'input', type: 'text', inputmode: 'decimal', value: f.raw, disabled });
      inp.addEventListener('input', () => {
        const v = inp.value.trim();
        const num = Number(v);
        const valid = v !== '' && isFinite(num) && (f.type === 'float' || Number.isInteger(num));
        mark([inp], set(valid ? num : v, valid), valid);
      });
      control = h('div', { class: 'input-group' }, inp, f.unit ? h('span', { class: 'unit' }, f.unit) : null);
      if (f.omega_helper) control.appendChild(this.omegaHelper(inp));
      if (f.turb_helper) control.appendChild(this.turbHelper(g));
      if (f.level_base) control.appendChild(levelSizeTag(f.level_base, () => [Number(inp.value)], inp));
      this.inputs.set(f.id, [inp]);
    } else if (f.type === 'vec3' || f.type === 'levels') {
      const n = f.type === 'vec3' ? 3 : 2;
      const ins = [];
      for (let i = 0; i < n; i++) {
        const inp = h('input', { class: 'input', type: 'text', value: String(f.value[i]), disabled, title: f.type === 'vec3' ? 'xyz'[i] : ['min', 'max'][i] });
        ins.push(inp);
      }
      const onIn = () => {
        const vals = ins.map((i) => Number(i.value.trim()));
        let valid = ins.every((i) => i.value.trim() !== '') && vals.every((v) => isFinite(v));
        if (f.type === 'levels') valid = valid && vals.every(Number.isInteger) && vals[0] <= vals[1] && vals[0] >= 0;
        mark(ins, set(vals, valid), valid);
      };
      ins.forEach((i) => i.addEventListener('input', onIn));
      control = h('div', { class: 'input-group' }, h('div', { class: f.type === 'vec3' ? 'vec3' : 'levels', style: { flex: 1 } }, ins), f.unit ? h('span', { class: 'unit' }, f.unit) : null);
      if (f.level_base) control.appendChild(levelSizeTag(f.level_base, () => ins.map((i) => Number(i.value)), ...ins));
      this.inputs.set(f.id, ins);
    } else if (f.type === 'cells3') {
      // blockMesh cell counts: whole numbers, with the resulting cell size shown live
      const ins = [0, 1, 2].map((i) => h('input', { class: 'input', type: 'text', inputmode: 'numeric', value: String(f.value[i]), disabled, title: 'xyz'[i] }));
      const info = h('div', { class: 'hint' });
      const extent = () => {
        const dom = (k) => { const a = this.inputs.get('dom_' + 'xyz'[k] + 'min'), b = this.inputs.get('dom_' + 'xyz'[k] + 'max');
          return a && b ? Number(b[0].value) - Number(a[0].value) : (f.extent ? f.extent[k] : NaN); };
        return [0, 1, 2].map(dom);
      };
      const update = () => {
        const n = ins.map((i) => Number(i.value.trim()));
        const valid = ins.every((i) => i.value.trim() !== '') && n.every((v) => Number.isInteger(v) && v >= 1);
        mark(ins, set(n, valid), valid);
        const e = extent();
        if (valid && e.every(isFinite)) {
          const hs = e.map((x, k) => x / n[k]);
          const cubic = Math.max(...hs) / Math.min(...hs) < 1.05;
          info.textContent = (cubic ? `Cells ${fmtLen(Math.max(...hs))}` : `Cells ${hs.map(fmtLen).join(' \u00d7 ')} - not cube-shaped`)
            + ` \u00b7 ${fmtInt(n[0] * n[1] * n[2])} base cells`;
          info.classList.toggle('warn-text', !cubic);
        } else info.textContent = '';
      };
      ins.forEach((i) => i.addEventListener('input', update));
      this.afterRender.push(() => { ['x', 'y', 'z'].forEach((a) => ['min', 'max'].forEach((w) => (this.inputs.get('dom_' + a + w) || []).forEach((i) => i.addEventListener('input', update)))); update(); });
      const fit = btn('', { size: 'sm', icon: 'grid', variant: 'ghost', title: 'Cube-shaped cells from a target size', disabled });
      fit.addEventListener('click', async () => {
        const e = extent();
        const sIn = h('input', { class: 'input', value: e.every(isFinite) ? (Math.max(...e.map((x, k) => x / Number(ins[k].value))) * 1000).toFixed(1) : '18' });
        const ok = await confirmDialog({ title: 'Base cell size', confirmLabel: 'Apply',
          message: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } }, 'The cell counts are chosen so that every base cell is (nearly) a cube of this size. Each refinement level halves it.'),
            h('div', { class: 'field' }, h('label', null, 'Base cell size [mm]'), sIn)) });
        const size = Number(sIn.value) / 1000;
        if (!ok || !(size > 0) || !e.every(isFinite)) return;
        ins.forEach((i, k) => { i.value = String(Math.max(1, Math.round(e[k] / size))); });
        update();
      });
      control = h('div', null, h('div', { class: 'input-group' }, h('div', { class: 'vec3', style: { flex: 1 } }, ins), fit), info);
      this.inputs.set(f.id, ins);
    } else if (f.type === 'choice') {
      const sel = h('select', { class: 'input', disabled }, f.choices.map((c) => h('option', { value: c.value }, c.label)));
      sel.value = f.value;
      const desc = h('div', { class: 'hint' });
      const show = () => { const c = f.choices.find((x) => x.value === sel.value); desc.textContent = c ? c.hint + '  (' + c.value + ')' : ''; };
      sel.addEventListener('change', () => { mark([sel], set(sel.value)); show(); });
      show();
      control = h('div', null, sel, desc);
      this.inputs.set(f.id, [sel]);
    } else if (f.type === 'bool') {
      const sw = switchEl(f.value, (v) => { set(v); });
      if (disabled) sw.input.disabled = true;
      control = h('label', { class: 'switch-row' }, sw, h('span', { class: 'muted small' }, f.value ? 'currently on' : 'currently off'));
    } else if (f.type === 'case') {
      const sel = h('select', { class: 'input', disabled });
      sel.appendChild(h('option', { value: '' }, '\u2014 none (cold start) \u2014'));
      for (const n of this.model.cases) {
        const c = this.ctx.app.byName(n);
        const hasRes = c && (c.status === 'finished' || c.status === 'stopped');
        sel.appendChild(h('option', { value: n, disabled: !hasRes && n !== f.value ? true : null }, n + (hasRes ? '' : ' (no results)')));
      }
      sel.value = f.value || '';
      sel.addEventListener('change', () => { mark([sel], set(sel.value)); });
      control = sel;
      this.inputs.set(f.id, [sel]);
    }
    return h('div', { class: 'field' },
      h('label', null, f.label),
      control,
      f.hint ? h('div', { class: 'hint' }, f.hint) : null);
  }

  // axle position / axis / omega derived from the wheel STLs
  wheelPanel(running) {
    const el = h('div', { class: 'wheel-auto' });
    const out = h('div');
    const sw = switchEl(true, async (v) => {
      try { await api.post('wheels', { name: this.ctx.name, auto: v }); toast(v ? 'Wheels are set automatically' : 'Automatic wheel settings off', v ? 'Before every run the axle position and angular velocity are derived from the wheel geometry.' : 'The values below are used as entered.', 'ok'); } catch (e) { toastError(e); }
    });
    const calc = btn('Check against geometry', { size: 'sm', icon: 'wheel' });
    const apply = btn('Apply values from geometry', { size: 'sm', variant: 'primary', icon: 'check', disabled: true });
    apply.style.display = 'none';
    el.append(h('label', { class: 'switch-row' }, sw, h('span', null, 'Set automatically from the wheel geometry before every run')),
      h('div', { class: 'muted small' }, 'Axle = centre of the tyre tread, axis = flow direction × up, ω = v / R (the contact point moves with the floor). '
        + 'Existing values are only replaced when they differ by more than 1 %.'),
      h('div', { class: 'row' }, calc, apply), out);
    const check = async () => {
      calc.disabled = true;
      mount(out, h('div', { class: 'spinner' }));
      try {
        const r = await api.get('wheels', { name: this.ctx.name });
        sw.input.checked = r.auto;
        if (!r.wheels.length) { mount(out, h('div', { class: 'muted small' }, 'No rotating wheels (rotatingWallVelocity) in 0.org/U.')); return; }
        mount(out, wheelTable(r.wheels));
        const differs = r.wheels.some((w) => w.ok && w.differs);
        apply.style.display = differs ? '' : 'none';
        apply.disabled = !differs || running;
      } catch (e) { mount(out, h('div', { class: 'warn-text small' }, e.message || String(e))); } finally { calc.disabled = false; }
    };
    calc.addEventListener('click', check);
    apply.addEventListener('click', async () => {
      try {
        const r = await api.post('wheels', { name: this.ctx.name, apply: true });
        toast('Wheels updated', 'Updated: ' + (r.changed.join(', ') || 'nothing') + '\nA backup was stored in .flowforgestudio/backups.', 'ok');
        this.load();
      } catch (e) { toastError(e, 'Could not apply'); }
    });
    check();
    return el;
  }

  omegaHelper(target) {
    const b = btn('', { size: 'sm', icon: 'wheel', variant: 'ghost', title: 'Calculate from wheel diameter' });
    b.addEventListener('click', () => {
      const flow = this.model.groups.flatMap((g) => g.fields).find((f) => f.id === 'flowVelocity');
      const v0 = flow ? Math.hypot(...flow.value) : 20;
      const vIn = h('input', { class: 'input', value: v0 });
      const dIn = h('input', { class: 'input', value: store('wheel-d') || 28 });
      const out = h('div', { class: 'stat-value', style: { fontSize: '20px' } });
      const calc = () => { const om = 2 * (+vIn.value) / ((+dIn.value) / 1000); out.textContent = isFinite(om) ? om.toFixed(1) + ' rad/s' : '-'; return om; };
      vIn.addEventListener('input', calc); dIn.addEventListener('input', calc); calc();
      confirmDialog({ title: 'Wheel angular velocity', confirmLabel: 'Use value',
        message: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } }, '\u03c9 = 2 \u00b7 v / D'),
          h('div', { class: 'grid cols-2' }, h('div', { class: 'field' }, h('label', null, 'Speed v [m/s]'), vIn), h('div', { class: 'field' }, h('label', null, 'Wheel diameter D [mm]'), dIn)),
          h('div', { style: { marginTop: '14px' } }, out)) })
        .then((ok) => {
          if (!ok) return;
          store('wheel-d', dIn.value);
          target.value = String(Math.round(calc() * 10) / 10);
          target.dispatchEvent(new Event('input'));
        });
    });
    return b;
  }

  updateSavebar() {
    for (const [gid, el] of this.navCounts) {
      const n = [...this.dirty.values()].filter((d) => d.g.id === gid).length;
      el.textContent = n ? String(n) : '';
    }
    const n = this.dirty.size;
    this.savebar.classList.toggle('hidden', !n);
    if (!n) return;
    const discard = btn('Discard', { variant: 'ghost', icon: 'undo' });
    discard.addEventListener('click', () => this.render());
    const save = btn('Save changes', { variant: 'primary', icon: 'save' });
    save.addEventListener('click', () => this.save());
    const files = [...new Set([...this.dirty.values()].map((d) => d.f.file === '@meta' ? 'Flowforge Studio' : d.f.file.split('/').pop()))];
    mount(this.savebar, h('div', null, h('b', null, `${n} unsaved change${n > 1 ? 's' : ''}`),
      h('span', { class: 'muted small' }, '  \u00b7  ' + files.join(', '))), h('div', { class: 'row' }, discard, save));
  }

  async save() {
    const edits = [...this.dirty.values()].map(({ f, val }) => ({ id: f.id, file: f.file, path: f.path, type: f.type, value: val }));
    try {
      const r = await api.post('settings', { edits }, { name: this.ctx.name });
      toast('Settings saved', 'Changed: ' + r.changed.join(', ') + '\nA backup was stored in .flowforgestudio/backups.', 'ok');
      this.ctx.view.reload();
      this.load();
    } catch (e) { toastError(e, 'Could not save'); }
  }

  onCaseChanged(d) {
    const wasRunning = this.ctx.data.status === 'running';
    this.ctx.data = d;
    if (wasRunning !== (d.status === 'running') && !this.dirty.size) this.render();
  }
  destroy() {}
}

// =====================================================================================
export class GeometryTab {
  constructor(el, ctx) {
    this.el = el; this.ctx = ctx;
    const stls = ctx.data.stls || [];
    if (!stls.length) { mount(el, emptyState('cube', 'No STL files', 'constant/triSurface contains no STL files.')); return; }
    const list = h('div', { class: 'part-list' });
    const vc = h('div');
    const tools = h('div', { class: 'row wrap' });
    mount(el, h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 280px', gap: '14px' } },
      vc, h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('layers'), 'Parts')), list,
        h('hr', { class: 'sep' }), tools)));
    this.viewer = new Viewer3D(vc, { height: Math.max(460, window.innerHeight - 330) });
    for (const [lbl, v] of [['Iso', 'iso'], ['Front', 'front'], ['Side', 'side'], ['Top', 'top']]) {
      const b = btn(lbl, { size: 'sm' });
      b.addEventListener('click', () => this.viewer.view(v));
      this.viewer.tools.appendChild(b);
    }
    const fit = btn('', { size: 'sm', icon: 'fit', title: 'Fit view' });
    fit.addEventListener('click', () => this.viewer.fit());
    this.viewer.tools.appendChild(fit);
    tools.append(h('span', { class: 'muted small' }, 'Previews are decimated for speed. Click a part to show/hide it.'));
    this.load(stls, list);
  }

  async load(stls, list) {
    this.viewer.setLoading(true);
    let first = true;
    let i = 0;
    for (const s of stls) {
      const color = PART_COLORS[i++ % PART_COLORS.length];
      const row = h('div', { class: 'part-row', style: { '--c': color, cursor: 'pointer' } }, h('span', { class: 'sw' }), h('span', { class: 'nm' }, s.name.replace(/\.stl$/i, '')),
        h('span', { class: 'sz' }, h('span', { class: 'spinner' })));
      list.appendChild(row);
      try {
        const r = await api.getBinary('stl/preview', { name: this.ctx.name, file: s.name, budget: 70000 });
        if (!this.viewer) return;
        this.viewer.addMesh(s.name, new Float32Array(r.buffer), { color });
        mount(row.lastChild, fmtInt(r.triangles) + ' tri');
        let vis = true;
        row.addEventListener('click', () => { vis = !vis; this.viewer.update(s.name, { visible: vis }); row.style.opacity = vis ? 1 : 0.4; });
        if (first) { this.viewer.fit(); first = false; }
      } catch (e) { mount(row.lastChild, 'error'); }
    }
    if (this.viewer) { this.viewer.setLoading(false); this.viewer.fit(); }
  }

  onTheme() { if (this.viewer) this.viewer.redraw(); }
  destroy() { if (this.viewer) { this.viewer.destroy(); this.viewer = null; } }
}

// =====================================================================================
export class CompareTab {
  constructor(el, ctx, opts = {}) {
    this.el = el; this.ctx = ctx;
    this.onlyDiff = store('cmp-only') !== false;
    const all = ctx.app.cases.map((c) => c.name).sort((a, b) => a.localeCompare(b));
    const others = all.filter((n) => n !== ctx.name);
    // default: explicit choice > origin > the neighbouring simulation in name order (e.g. param_14 for param_15)
    const idx = all.indexOf(ctx.name);
    const neighbour = idx > 0 ? all[idx - 1] : all[idx + 1];
    this.other = (opts && opts.other) || (ctx.data.meta.origin && others.includes(ctx.data.meta.origin) ? ctx.data.meta.origin : neighbour);
    if (!others.includes(this.other)) this.other = others[0];
    this.sel = h('select', { class: 'input', style: { width: '420px' } }, others.map((n) => h('option', { value: n }, n + (n === ctx.data.meta.origin ? '   (origin)' : ''))));
    this.sel.value = this.other || '';
    this.sel.addEventListener('change', () => { this.other = this.sel.value; store('cmp-other', this.other); this.load(); });
    this.body = h('div');
    const swap = btn('', { size: 'sm', icon: 'refresh', variant: 'ghost', title: 'Reload' });
    swap.addEventListener('click', () => this.load());
    this.meldBtn = btn('Open in Meld', { size: 'sm', icon: 'external', disabled: !ctx.app.info.meld });
    this.meldBtn.addEventListener('click', () => ctx.view.open('meld', { other: this.other }));
    mount(el, h('div', { class: 'card', style: { marginBottom: '14px', padding: '12px 16px' } },
      h('div', { class: 'row wrap' }, h('b', null, ctx.name), h('span', { class: 'muted' }, 'compared with'), this.sel, h('span', { class: 'spacer' }), swap, this.meldBtn)), this.body);
    if (this.other) this.load(); else mount(this.body, emptyState('compare', 'Nothing to compare', 'There is no other simulation.'));
  }

  async load() {
    mount(this.body, h('div', { class: 'empty' }, h('div', { class: 'spinner' }), h('div', null, 'Comparing...')));
    try {
      this.r = await api.get('compare', { a: this.ctx.name, b: this.other });
      this.render();
    } catch (e) { toastError(e); }
  }

  render() {
    const r = this.r;
    const A = 'This', B = 'Other';
    const pct = (a, b) => (a != null && b != null && b !== 0) ? ((a - b) / Math.abs(b) * 100) : null;
    // sa / sb: scatter (std) of the force signals - a difference smaller than that is not meaningful
    const resRow = (label, a, b, fmt, lowerBetter, sa, sb) => {
      const p = pct(a, b);
      const noise = (sa != null && sb != null && a != null && b != null) ? Math.hypot(sa, sb) : null;
      const inNoise = noise != null && Math.abs(a - b) < noise;
      const cls = p == null || Math.abs(p) < 0.05 || inNoise ? 'muted' : lowerBetter == null ? '' : ((p < 0) === lowerBetter ? 'ok' : 'bad');
      const note = inNoise ? h('div', { class: 'small muted', title: 'The difference is smaller than the iteration-to-iteration scatter of the two force signals.' },
        'within scatter (±' + (noise / Math.abs(b) * 100).toFixed(1) + ' %)') : null;
      return h('tr', null, h('td', null, label), h('td', { class: 'num' }, fmt(a)), h('td', { class: 'num' }, fmt(b)),
        h('td', { class: 'num ' + cls }, p == null ? '-' : (p > 0 ? '+' : '') + p.toFixed(2) + ' %', note));
    };
    const ra = r.results.a || {}, rb = r.results.b || {};
    const ma = r.mesh.a || {}, mb = r.mesh.b || {};
    const results = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('trophy'), 'Results')),
      h('table', { class: 'tbl' },
        h('thead', null, h('tr', null, h('th', null, ''), h('th', { class: 'num' }, A), h('th', { class: 'num' }, B), h('th', { class: 'num' }, 'Difference'))),
        h('tbody', null,
          resRow('Drag [N]', ra.drag, rb.drag, fmtForce, true, uncOf(ra), uncOf(rb)),
          resRow('Lift [N]', ra.lift, rb.lift, fmtForce, false, uncOf(ra, 'lift'), uncOf(rb, 'lift')),
          resRow('Drag, pressure only [N]', ra.drag_pressure, rb.drag_pressure, fmtForce, true),
          resRow('Cells', ma.cells, mb.cells, fmtCells, null),
          resRow('Iterations', ra.iterations, rb.iterations, (v) => v == null ? '-' : Math.round(v), null))));

    const diffs = r.settings.filter((s) => !s.same);
    const rows = this.onlyDiff ? diffs : r.settings;
    const onlySw = switchEl(this.onlyDiff, (v) => { this.onlyDiff = v; store('cmp-only', v); this.render(); });
    let lastGroup = null;
    const settings = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('sliders'), `Key settings (${diffs.length} different)`),
        h('label', { class: 'switch-row small' }, onlySw, 'Only differences')),
      rows.length ? h('table', { class: 'tbl' },
        h('thead', null, h('tr', null, h('th', null, 'Setting'), h('th', null, A), h('th', null, B))),
        h('tbody', null, rows.flatMap((s) => {
          const out = [];
          if (s.group !== lastGroup) { lastGroup = s.group; out.push(h('tr', null, h('td', { colspan: 3, class: 'muted small', style: { paddingTop: '14px', fontWeight: 700 } }, s.group))); }
          out.push(h('tr', { class: s.same ? '' : 'diff' }, h('td', null, s.label),
            h('td', { class: 'mono' + (s.same ? '' : ' changed') }, s.a ?? '\u2014'), h('td', { class: 'mono' }, s.b ?? '\u2014')));
          return out;
        }))) : h('div', { class: 'muted' }, 'All key settings are identical.'));

    const geoDiff = r.geometry.filter((g) => g.state !== 'same');
    const geometry = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('cube'), `Geometry (${geoDiff.length} different)`)),
      h('div', { class: 'file-list' }, r.geometry.map((g) => h('div', { class: 'file-row', style: { cursor: 'default' } }, icon('cube'), g.name,
        h('span', { class: 'state ' + g.state }, { same: 'identical', different: 'different', only_a: 'only in this', only_b: 'only in other' }[g.state])))));

    const fileDiff = r.files.filter((f) => f.state !== 'same');
    this.diffEl = h('div');
    const fileList = h('div', { class: 'file-list' });
    for (const f of (fileDiff.length ? fileDiff : r.files)) {
      const row = h('div', { class: 'file-row' }, icon('log'), h('span', { class: 'mono' }, f.file),
        h('span', { class: 'state ' + f.state }, { same: 'identical', different: 'different', only_a: 'only in this', only_b: 'only in other' }[f.state]));
      row.addEventListener('click', () => { fileList.querySelectorAll('.file-row').forEach((x) => x.classList.remove('active')); row.classList.add('active'); this.showDiff(f.file); });
      fileList.appendChild(row);
    }
    const files = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('compare'), `Files (${fileDiff.length} different of ${r.files.length})`)),
      fileDiff.length ? null : h('div', { class: 'muted small', style: { marginBottom: '8px' } }, 'All configuration files are identical.'),
      fileList, this.diffEl);
    mount(this.body, h('div', { class: 'grid cols-2' }, results, geometry), h('div', { style: { marginTop: '14px' } }, settings),
      h('div', { style: { marginTop: '14px' } }, files));
    if (fileDiff.length) fileList.firstChild.click();
  }

  async showDiff(file) {
    mount(this.diffEl, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    try {
      const d = await api.get('diff', { a: this.ctx.name, b: this.other, file });
      if (d.identical) { mount(this.diffEl, h('div', { class: 'muted', style: { padding: '12px' } }, 'Files are identical.')); return; }
      const seg = (parts, cls) => parts ? parts.map(([c, t]) => c ? `<em>${esc(t)}</em>` : esc(t)).join('') : null;
      const tbody = h('tbody');
      for (const row of d.rows) {
        if (row.t === 'hunk') { tbody.appendChild(h('tr', { class: 'hunk' }, h('td', { colspan: 4 }))); continue; }
        const aCls = row.t === 'del' ? 'del' : row.t === 'chg' ? 'chg-a' : row.t === 'ins' ? 'blank' : '';
        const bCls = row.t === 'ins' ? 'ins' : row.t === 'chg' ? 'chg-b' : row.t === 'del' ? 'blank' : '';
        const aHtml = row.sa ? seg(row.sa) : esc(row.a ?? '');
        const bHtml = row.sb ? seg(row.sb) : esc(row.b ?? '');
        tbody.appendChild(h('tr', null,
          h('td', { class: 'ln' }, row.an ?? ''), h('td', { class: 'mono ' + (row.a == null ? 'blank' : aCls), html: aHtml }),
          h('td', { class: 'ln' }, row.bn ?? ''), h('td', { class: 'mono ' + (row.b == null ? 'blank' : bCls), html: bHtml })));
      }
      mount(this.diffEl, h('div', { class: 'row', style: { margin: '12px 0 6px' } }, h('b', { class: 'mono' }, file),
        h('span', { class: 'muted small' }, 'left: this simulation \u00b7 right: ' + this.other)),
      h('div', { class: 'diff-view' }, h('table', { class: 'diff-table' }, h('colgroup', null, h('col', { style: { width: '46px' } }), h('col'), h('col', { style: { width: '46px' } }), h('col')), tbody)));
    } catch (e) { toastError(e); }
  }

  destroy() {}
}
