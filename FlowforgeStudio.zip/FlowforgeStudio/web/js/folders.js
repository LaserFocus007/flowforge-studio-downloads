// Folders of the simulation list. Only in Flowforge Studio: the simulations stay where they are on
// disk, so origin / warm-start links, the queue and scripts keep working (app/folders.py).
// A folder path looks like "Nose cone/URANS"; '' is the top level.

import * as api from './api.js';
import { h, mount, icon, btn, modal, toast, toastError, store, confirmDialog } from './ui.js';

export const folderName = (p) => p.split('/').pop();
export const parentOf = (p) => p.split('/').slice(0, -1).join('/');
export const inside = (p, f) => !!f && (p === f || p.startsWith(f + '/'));
const ORDER = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
const label = (p) => (p ? p.split('/').join(' / ') : 'Top level');

// ---------------------------------------------------------------- open / closed (per PC)
const closedSet = () => new Set(store('folders-closed') || []);
export function isClosed(p) { return closedSet().has(p); }
export function setClosed(p, closed) {
  const s = closedSet();
  if (closed) s.add(p); else s.delete(p);
  store('folders-closed', [...s]);
}
// opens every folder above a simulation, so it can be seen in the list
export function reveal(path) {
  if (!path) return false;
  const s = closedSet();
  let changed = false;
  path.split('/').forEach((_, i, parts) => { if (s.delete(parts.slice(0, i + 1).join('/'))) changed = true; });
  if (changed) store('folders-closed', [...s]);
  return changed;
}
// a renamed / moved folder keeps its open state (and so do the folders below it)
function remapClosed(old, now) {
  store('folders-closed', [...closedSet()].map((p) => (inside(p, old) ? now + p.slice(old.length) : p)));
}

// ---------------------------------------------------------------- tree
// cases come already filtered and sorted; prune: leave out folders without matching simulations
export function buildTree(folders, cases, { prune = false } = {}) {
  const root = { path: '', name: '', kids: new Map(), sims: [] };
  const node = (path) => {
    let n = root;
    for (const seg of path.split('/')) {
      const p = n.path ? n.path + '/' + seg : seg;
      if (!n.kids.has(seg)) n.kids.set(seg, { path: p, name: seg, kids: new Map(), sims: [] });
      n = n.kids.get(seg);
    }
    return n;
  };
  for (const f of folders) node(f);
  for (const c of cases) (c.folder ? node(c.folder) : root).sims.push(c);
  const finish = (n) => {
    n.kids = [...n.kids.values()].sort((a, b) => ORDER.compare(a.name, b.name));
    n.kids.forEach(finish);
    if (prune) n.kids = n.kids.filter((k) => k.n > 0);
    n.n = n.sims.length + n.kids.reduce((a, k) => a + k.n, 0);
    n.running = n.sims.some((c) => c.status === 'running') || n.kids.some((k) => k.running);
    n.queued = n.sims.some((c) => c.queued && c.status !== 'running') || n.kids.some((k) => k.queued);
  };
  finish(root);
  return root;
}

// ---------------------------------------------------------------- server
async function call(app, body, okText) {
  try {
    const r = await api.post('folders', body);
    if (r.folders) app.folders = r.folders;
    if (okText) toast(okText, '', 'ok', 2500);
    await app.refresh();
    return r;
  } catch (e) {
    toastError(e, 'Folder action failed');
    return null;
  }
}

export function moveSims(app, names, folder) {
  if (!names.length) return null;
  reveal(folder);
  return call(app, { action: 'assign', names, folder });
}

export async function moveFolder(app, path, parent) {
  if (inside(parent, path) || parentOf(path) === parent) return null;
  const r = await call(app, { action: 'move', path, parent });
  if (r && r.path) { remapClosed(path, r.path); reveal(parent); }
  return r;
}

// ---------------------------------------------------------------- dialogs
function askName({ title, value = '', okLabel = 'Create', hint }) {
  return new Promise((resolve) => {
    let result = null;
    const inp = h('input', { class: 'input', value, maxlength: 60, style: { fontSize: '14px' } });
    const ok = btn(okLabel, { variant: 'primary', disabled: !value.trim() });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const m = modal({
      title,
      body: h('div', null, h('div', { class: 'field' }, h('label', null, 'Folder name'), inp),
        h('p', { class: 'muted small', style: { marginBottom: 0 } }, hint || 'Folders exist only in Flowforge Studio - the simulations stay where they are on disk, so links between them keep working.')),
      footer: [cancel, ok],
      onClose: () => resolve(result),
    });
    const bad = (v) => !v.trim() || /[/\\:*?"<>|]/.test(v);
    inp.addEventListener('input', () => { ok.disabled = bad(inp.value); inp.classList.toggle('invalid', !!inp.value.trim() && bad(inp.value)); });
    const go = () => { if (!bad(inp.value)) { result = inp.value.trim(); m.close(); } };
    ok.addEventListener('click', go);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    cancel.addEventListener('click', () => m.close());
    setTimeout(() => { inp.focus(); inp.select(); }, 50);
  });
}

export async function newFolder(app, parent = '') {
  const name = await askName({ title: parent ? `New folder in ${label(parent)}` : 'New folder' });
  if (!name) return null;
  const path = parent ? parent + '/' + name : name;
  reveal(path);
  return call(app, { action: 'create', path });
}

export async function renameFolder(app, path) {
  const name = await askName({ title: 'Rename folder', value: folderName(path), okLabel: 'Rename',
    hint: 'If a folder with this name already exists here, the two are merged.' });
  if (!name || name === folderName(path)) return null;
  const r = await call(app, { action: 'rename', path, name });
  if (r && r.path) remapClosed(path, r.path);
  return r;
}

export async function deleteFolder(app, path, count) {
  const parent = parentOf(path);
  const ok = await confirmDialog({
    title: `Delete the folder "${folderName(path)}"?`,
    message: count
      ? `Its ${count} simulation${count === 1 ? '' : 's'} (and any subfolders) move to ${parent ? '"' + label(parent) + '"' : 'the top level'}. Nothing is deleted on disk.`
      : 'The folder is empty. Nothing on disk changes.',
    confirmLabel: 'Delete folder',
  });
  if (!ok) return null;
  return call(app, { action: 'delete', path });
}

// choose a folder: the tree of all folders, '' = top level; resolves null when cancelled
export function pickFolder(app, { title, current = null, exclude = null, okLabel = 'Move here' }) {
  return new Promise((resolve) => {
    let result = null;
    let chosen = current == null ? '' : current;
    const listEl = h('div', { class: 'fpick' });
    const ok = btn(okLabel, { variant: 'primary' });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const add = btn('New folder...', { size: 'sm', variant: 'ghost', icon: 'folderPlus' });
    const render = () => {
      const rows = [''].concat((app.folders || []).slice().sort((a, b) => ORDER.compare(a, b)));
      mount(listEl, rows.filter((p) => !(exclude && inside(p, exclude))).map((p) => {
        const depth = p ? p.split('/').length : 0;
        const row = h('div', { class: 'fpick-row' + (p === chosen ? ' on' : '') + (p === current ? ' current' : ''), style: { paddingLeft: (10 + depth * 18) + 'px' } },
          icon(p ? 'folder' : 'home'), h('span', null, p ? folderName(p) : 'Top level (no folder)'),
          p === current ? h('span', { class: 'muted small' }, 'current') : null);
        row.addEventListener('click', () => { chosen = p; render(); });
        row.addEventListener('dblclick', () => { chosen = p; result = p; m.close(); });
        return row;
      }));
      ok.disabled = chosen === current;
    };
    add.addEventListener('click', async () => {
      const name = await askName({ title: chosen ? `New folder in ${label(chosen)}` : 'New folder' });
      if (!name) return;
      const path = chosen ? chosen + '/' + name : name;
      const r = await call(app, { action: 'create', path });
      if (r) { chosen = r.path; render(); }
    });
    const m = modal({ title, body: listEl, footer: [add, h('span', { class: 'spacer' }), cancel, ok], onClose: () => resolve(result) });
    ok.addEventListener('click', () => { result = chosen; m.close(); });
    cancel.addEventListener('click', () => m.close());
    render();
  });
}

export async function moveDialog(app, names) {
  const folders = new Set(names.map((n) => (app.byName(n) || {}).folder || ''));
  const current = folders.size === 1 ? [...folders][0] : null;
  const what = names.length === 1 ? names[0].replace(/^\d{8}_/, '') : `${names.length} simulations`;
  const dest = await pickFolder(app, { title: `Move ${what} to...`, current });
  if (dest == null) return null;
  const r = await moveSims(app, names, dest);
  if (r) toast('Moved', `${what} → ${label(dest)}`, 'ok', 2500);
  return r;
}

export async function moveFolderDialog(app, path) {
  const dest = await pickFolder(app, { title: `Move "${folderName(path)}" into...`, current: parentOf(path), exclude: path });
  if (dest == null) return null;
  return moveFolder(app, path, dest);
}

export function folderMenuItems(app, node) {
  return [
    { label: 'New subfolder...', icon: 'folderPlus', onClick: () => newFolder(app, node.path) },
    { label: 'Rename...', icon: 'log', onClick: () => renameFolder(app, node.path) },
    { label: 'Move to...', icon: 'move', onClick: () => moveFolderDialog(app, node.path) },
    '-',
    { label: 'Delete folder...', sub: 'Simulations move one level up', icon: 'trash', danger: true, onClick: () => deleteFolder(app, node.path, node.n) },
  ];
}

// menu at the mouse pointer (right click)
export function pointAnchor(e) {
  return { getBoundingClientRect: () => ({ left: e.clientX, right: e.clientX, top: e.clientY, bottom: e.clientY }) };
}
