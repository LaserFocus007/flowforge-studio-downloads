// Forces tab: drag / lift per part of the car, optionally compared with another simulation.

import * as api from './api.js';
import { h, mount, icon, segmented, fmtForce, meanUncertainty, toastError } from './ui.js';
import { LineChart } from './chart.js';
import { PART_COLORS } from './viewer3d.js';

const shortName = (n) => n.replace(/^\d{8}_/, '');
const sumOf = (p, q) => p[q].pressure.map((v, i) => v + p[q].viscous[i]);
let lastCompare = '';            // compare choice carries over to the next simulation opened

function windowStats(time, y, t0) {
  let i0 = 0;
  while (i0 < time.length && time[i0] < t0) i0++;
  const v = y.slice(i0);
  if (!v.length) return null;
  const mean = v.reduce((a, b) => a + b, 0) / v.length;
  const std = Math.sqrt(v.reduce((a, b) => a + (b - mean) ** 2, 0) / v.length);
  return { mean, std, sem: meanUncertainty(v), n: v.length, i0, v };
}

// mean, pressure and viscous share and swings of every part over the averaging window from t0
function partStats(f, q, t0) {
  return (f.parts || []).map((p) => {
    const tot = sumOf(p, q);
    const s = windowStats(p.time, tot, t0);
    if (!s) return null;
    const pr = windowStats(p.time, p[q].pressure, t0);
    return { key: p.key, label: p.label, patches: p.patches, time: p.time, total: tot, t0, ...s, pressure: pr.mean, viscous: s.mean - pr.mean };
  }).filter(Boolean);
}

function spark(s) {
  const w = 120, hgt = 26, v = s.v;
  let mn = Infinity, mx = -Infinity;
  for (const x of v) { if (x < mn) mn = x; if (x > mx) mx = x; }
  const span = mx - mn || Math.abs(mx) || 1;
  const step = Math.max(1, Math.floor(v.length / 120));
  const pts = [];
  for (let i = 0; i < v.length; i += step) pts.push(`${(i / Math.max(1, v.length - 1) * w).toFixed(1)},${(hgt - 2 - (v[i] - mn) / span * (hgt - 4)).toFixed(1)}`);
  const ym = (hgt - 2 - (s.mean - mn) / span * (hgt - 4)).toFixed(1);
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${hgt}`);
  svg.setAttribute('class', 'pf-spark');
  svg.innerHTML = `<line x1="0" x2="${w}" y1="${ym}" y2="${ym}" class="m"/><polyline points="${pts.join(' ')}"/>`;
  const t = document.createElementNS(NS, 'title');
  t.textContent = `Signal in the averaging window: ${fmtForce(mn)} … ${fmtForce(mx)} N (line = mean)`;
  svg.appendChild(t);
  return svg;
}

export class PartsPanel {
  constructor(tab) {
    this.tab = tab;
    if (tab.partQ == null) tab.partQ = 'drag';
    if (tab.partOpen == null) tab.partOpen = new Set();
    if (tab.cmpName == null) tab.cmpName = lastCompare;
    this.el = h('div', { class: 'card pf-card' });
    this.charts = [];
    this.render();
    if (tab.cmpName && (!tab.cmpData || tab.cmpData.name !== tab.cmpName)) this.loadCompare();
  }

  destroy() { this.charts.forEach((c) => c.destroy()); this.charts = []; }

  async loadCompare() {
    const name = this.tab.cmpName;
    if (!name) { this.tab.cmpData = null; this.render(); return; }
    try {
      const f = await api.get('forces', { name });
      if (this.tab.cmpName === name) { this.tab.cmpData = { name, f }; this.render(); }
    } catch (e) { toastError(e); }
  }

  render() {
    this.destroy();
    const tab = this.tab, f = tab.f, q = tab.partQ;
    const n = f.time.length, t0 = f.time[Math.max(0, n - tab.win())];
    const rows = partStats(f, q, t0);
    const total = windowStats(f.time, f[q].total, t0);
    const cmp = tab.cmpData && tab.cmpData.name === tab.cmpName ? tab.cmpData.f : null;
    let cRows = null, cTotal = null;
    if (cmp && cmp.time && cmp.time.length) {
      const c0 = cmp.stats && cmp.stats.start != null ? cmp.stats.start : cmp.time[0];
      cRows = new Map(partStats(cmp, q, c0).map((r) => [r.label.toLowerCase(), r]));
      cTotal = windowStats(cmp.time, cmp[q].total, c0);
    }

    // header: quantity and comparison
    const seg = segmented([{ label: 'Drag', value: 'drag' }, { label: 'Lift', value: 'lift' }], q, (v) => { tab.partQ = v; this.render(); });
    const others = (tab.ctx.app.cases || []).filter((c) => c.name !== tab.ctx.name && c.results && c.results.drag != null)
      .map((c) => c.name).sort((a, b) => shortName(a).localeCompare(shortName(b), undefined, { numeric: true }));
    const sel = h('select', { class: 'input', style: { width: 'auto', maxWidth: '360px', height: '28px', fontSize: '12.5px' } },
      h('option', { value: '' }, 'Compare with … (off)'), others.map((o) => h('option', { value: o }, shortName(o))));
    sel.value = others.includes(tab.cmpName) ? tab.cmpName : '';
    sel.addEventListener('change', () => { tab.cmpName = lastCompare = sel.value; tab.cmpData = null; this.loadCompare(); });
    const head = h('div', { class: 'card-head' },
      h('div', { class: 'card-title' }, icon('layers'), (q === 'drag' ? 'Drag' : 'Lift') + ' by part'),
      h('div', { class: 'row' }, seg, sel));

    if (!rows.length) {
      mount(this.el, head, h('div', { class: 'muted small', style: { padding: '6px 2px' } },
        'No forces per part for this simulation yet. They are recorded from the next solve on (Settings → Force evaluation → Forces per part).'));
      return;
    }

    const colour = new Map(rows.map((r, i) => [r.key, PART_COLORS[(i + 1) % PART_COLORS.length]]));
    const order = rows.slice().sort((a, b) => Math.abs(b.mean) - Math.abs(a.mean));
    const lo = Math.min(0, ...rows.map((r) => r.mean)), hi = Math.max(0, ...rows.map((r) => r.mean));
    const pos = (v) => (100 * (v - lo) / ((hi - lo) || 1));
    const ref = Math.abs(total.mean) || 1;
    const overlap = (f.parts || []).some((p) => p.overlap);
    const deltas = cRows ? order.map((r) => { const o = cRows.get(r.label.toLowerCase()); return o ? r.mean - o.mean : 0; }) : [];
    const dMax = Math.max(1e-12, ...deltas.map(Math.abs), cTotal ? Math.abs(total.mean - cTotal.mean) : 0);

    const deltaCell = (a, b) => {
      if (!b) return h('div', { class: 'pf-d muted' }, '–');
      const d = a.mean - b.mean;
      const u = (a.sem != null && b.sem != null) ? 2 * Math.sqrt(a.sem ** 2 + b.sem ** 2) : null;
      const sig = u != null && Math.abs(d) > u;
      const cls = !sig ? 'noise' : q === 'drag' ? (d < 0 ? 'good' : 'bad') : 'info';
      const rel = b.mean ? ` (${d >= 0 ? '+' : '−'}${Math.abs(100 * d / Math.abs(b.mean)).toFixed(1)} %)` : '';
      const tip = u == null ? 'Too few samples for an uncertainty estimate.'
        : sig ? `Real difference: larger than the statistical noise of both runs (±${fmtForce(u)} N).`
          : `Within the statistical noise of both runs (±${fmtForce(u)} N) - not a real difference.`;
      const w = Math.min(50, 50 * Math.abs(d) / dMax);
      return h('div', { class: 'pf-d ' + cls, title: tip },
        h('div', { class: 'pf-dbar' }, h('span', { style: d < 0 ? { right: '50%', width: w + '%' } : { left: '50%', width: w + '%' } })),
        h('span', { class: 'num' }, (sig || u == null ? '' : '≈ ') + (d >= 0 ? '+' : '−') + fmtForce(Math.abs(d)) + rel));
    };

    const swings = (s) => {
      // lift of a part can be close to zero: its swings are shown in N instead of % of a tiny mean
      if (q === 'lift') return h('div', { class: 'pf-sw', title: 'How much the lift of this part swings in the averaging window (standard deviation, N).' }, '±' + fmtForce(s.std));
      const r = s.mean ? 100 * s.std / Math.abs(s.mean) : 0;
      return h('div', { class: 'pf-sw' + (r > 5 ? ' hi' : r > 2 ? ' mid' : ''), title: 'How much this part\'s force swings in the averaging window (standard deviation). Large swings = unsteady flow at this part.' },
        '±' + r.toFixed(1) + ' %');
    };

    const grid = h('div', { class: 'pf-grid' + (cRows ? ' cmp' : '') });
    grid.append(h('div', { class: 'pf-row pf-hdr' },
      h('div', null, 'Part'), h('div', null, h('span', { class: 'pf-key' }, h('i', { class: 'p' }), 'pressure', h('i', { class: 'v' }), 'friction')),
      h('div', { class: 'r' }, 'Mean [N]'), h('div', { class: 'r' }, 'Share'), h('div', { class: 'r' }, 'Swings'), h('div', null, 'Signal'),
      cRows ? h('div', { title: 'This simulation minus ' + shortName(tab.cmpName) }, 'Δ to compared run') : null));

    for (const r of order) {
      const col = colour.get(r.key);
      const z = pos(0), e = pos(r.mean);
      const bar = h('div', { class: 'pf-bar' }, h('span', { class: 'zero', style: { left: z + '%' } }));
      if (Math.sign(r.pressure) === Math.sign(r.mean) && Math.sign(r.viscous) === Math.sign(r.mean)) {
        const m = pos(r.pressure);
        bar.append(h('span', { class: 'seg p', style: { left: Math.min(z, m) + '%', width: Math.abs(m - z) + '%', background: col } }),
          h('span', { class: 'seg v', style: { left: Math.min(m, e) + '%', width: Math.abs(e - m) + '%', background: col } }));
      } else {
        bar.append(h('span', { class: 'seg p', style: { left: Math.min(z, e) + '%', width: Math.abs(e - z) + '%', background: col } }));
      }
      bar.title = `pressure ${fmtForce(r.pressure)} N · friction ${fmtForce(r.viscous)} N`;
      const open = tab.partOpen.has(r.key);
      const row = h('div', { class: 'pf-row' + (open ? ' open' : ''), title: 'Click to show the curve of this part' },
        h('div', { class: 'pf-name' }, h('span', { class: 'sw', style: { background: col } }), h('span', null, r.label)),
        bar,
        h('div', { class: 'r num', title: r.sem != null ? `uncertainty of the mean ±${fmtForce(r.sem)} N` : '' }, fmtForce(r.mean)),
        h('div', { class: 'r num muted' }, (100 * r.mean / ref).toFixed(1) + ' %'),
        swings(r), spark(r),
        cRows ? deltaCell(r, cRows.get(r.label.toLowerCase())) : null);
      row.addEventListener('click', () => { if (open) tab.partOpen.delete(r.key); else tab.partOpen.add(r.key); this.render(); });
      grid.append(row);
      if (open) grid.append(this.detail(r, col, cRows && cRows.get(r.label.toLowerCase())));
    }

    const sum = rows.reduce((a, r) => a + r.mean, 0);
    const rest = total.mean - sum;
    if (!overlap && Math.abs(rest) > 0.002 * ref) {
      grid.append(h('div', { class: 'pf-row pf-foot' }, h('div', { class: 'pf-name muted' }, 'Not assigned to a part'), h('div'),
        h('div', { class: 'r num muted' }, fmtForce(rest)), h('div', { class: 'r num muted' }, (100 * rest / ref).toFixed(1) + ' %'), h('div'), h('div'), cRows ? h('div') : null));
    }
    grid.append(h('div', { class: 'pf-row pf-foot total' },
      h('div', { class: 'pf-name' }, 'Whole car'), h('div', { class: 'muted small' }, overlap ? 'Parts overlap (groups) - they do not add up to the total.' : ''),
      h('div', { class: 'r num' }, fmtForce(total.mean)), h('div', { class: 'r num muted' }, '100 %'), swings(total), h('div'),
      cRows ? deltaCell(total, cTotal) : null));

    const notes = [`Mean over the same averaging window as above (from iteration ${Math.round(t0)}). Parts are recorded every 5th iteration.`];
    if (cRows) notes.push(`Δ = this simulation minus ${shortName(tab.cmpName)}: green / red = real difference (larger than twice the combined uncertainty), grey ≈ within the noise. It uses its own averaging window.`);
    if (cRows && !cRows.size) notes.push(`${shortName(tab.cmpName)} has no forces per part - only the whole car is compared.`);
    mount(this.el, head, h('div', { class: 'pf-scroll' }, grid), h('div', { class: 'muted small', style: { marginTop: '8px' } }, notes.join(' ')));
    requestAnimationFrame(() => this.charts.forEach((c) => c.draw()));
  }

  // full curve of one part with the running mean over the averaging window (and the compared run's mean)
  detail(r, col, other) {
    const box = h('div', { class: 'pf-detail' });
    const c = new LineChart(box, { height: 220, legend: true, xLabel: 'Iteration', ySkipFraction: 0.15,
      xFormat: (v) => String(Math.round(v)), valueFormat: (v) => v.toFixed(5) });
    const run = new Array(r.time.length).fill(null);
    let s = 0;
    for (let i = r.i0; i < r.time.length; i++) { s += r.total[i]; run[i] = s / (i - r.i0 + 1); }
    const txt = getComputedStyle(document.documentElement).getPropertyValue('--text').trim() || '#e5e7eb';
    const series = [{ name: r.label, x: r.time, y: r.total, color: col, width: 1.5 },
      { name: 'running mean', x: r.time, y: run, color: txt, width: 2 }];
    if (other) series.push({ name: 'mean ' + shortName(this.tab.cmpName), x: [r.time[0], r.time[r.time.length - 1]], y: [other.mean, other.mean], color: '#9ca3af', width: 1.5 });
    c.setSeries(series);
    c.setBand([r.t0, r.time[r.time.length - 1], 'averaging window']);
    this.charts.push(c);
    return box;
  }
}
