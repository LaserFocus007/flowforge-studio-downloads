// Force data of the simulations opened last. Going back to a simulation (or comparing with it)
// shows the remembered data at once; the server is still asked, and the view is only redrawn when
// its answer differs (a running simulation, a changed averaging window, new car data).

import * as api from './api.js';

const MAX = 8;                   // about 0.3 MB each
const cache = new Map();         // name -> { f, sig }
const pending = new Map();       // name -> Promise of { f, sig } (one request per simulation at a time)

export function cachedForces(name) { return cache.get(name) || null; }

export function fetchForces(name) {
  // just fetched (together with the simulation, a moment before its Forces tab asks): no second request
  const fresh = cache.get(name);
  if (fresh && Date.now() - fresh.at < 2000) return Promise.resolve(fresh);
  let p = pending.get(name);
  if (!p) {
    p = api.get('forces', { name }).then((f) => {
      const e = { f, sig: JSON.stringify(f), at: Date.now() };
      cache.delete(name);
      cache.set(name, e);
      if (cache.size > MAX) cache.delete(cache.keys().next().value);
      return e;
    }).finally(() => pending.delete(name));
    pending.set(name, p);
  }
  return p;
}
