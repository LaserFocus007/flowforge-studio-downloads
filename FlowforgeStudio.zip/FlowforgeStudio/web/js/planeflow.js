// Flow lines inside a section plane (like surface LIC / "2D streamlines" in ParaView), traced in
// the browser from the velocity at the plane corners (app/results3d.py plane_flow_payload).
//
// 1. The in-plane velocity is rasterised onto a fine regular grid (only where the plane cuts fluid
//    cells - the car and the wheels stay empty).
// 2. Evenly spaced streamlines (Jobard & Lefer 1997): new seeds are placed one spacing beside the
//    lines already drawn, a line stops when it comes closer than half a spacing to another line
//    (or to itself - closed recirculation loops), leaves the fluid or the flow stops.
// 3. Each line becomes a flat ribbon with tapered ends (its own random phase for the animation). Every vertex carries the speed (for the
//    colour map) and the time of flight along the line (for the animated pulses: they move with
//    the real flow speed, fast outside, slow in the wake).

export function parsePlaneFlow(buf) {
  const hl = new DataView(buf).getUint32(0, true);
  const header = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, hl)));
  let off = 4 + hl;
  const pos = new Float32Array(buf, off, header.nv * 3); off += header.nv * 12;
  const U = new Float32Array(buf, off, header.nv * 3); off += header.nv * 12;
  const tri = new Int32Array(buf, off, header.nt * 3);
  return { header, pos, U, tri };
}

// in-plane axes of a section plane (normal = axis)
export const planeAxes = (axis) => [[1, 2], [0, 2], [0, 1]][axis];

// velocity grid over region [[a0, a1], [b0, b1]] with node spacing h
function rasterise(data, axis, region, h) {
  const [ia, ib] = planeAxes(axis);
  const [[a0, a1], [b0, b1]] = region;
  const nx = Math.max(2, Math.ceil((a1 - a0) / h) + 1), ny = Math.max(2, Math.ceil((b1 - b0) / h) + 1);
  const u = new Float32Array(nx * ny), v = new Float32Array(nx * ny), s = new Float32Array(nx * ny), m = new Uint8Array(nx * ny);
  const { pos, U, tri } = data;
  for (let t = 0; t < tri.length; t += 3) {
    const i0 = tri[t], i1 = tri[t + 1], i2 = tri[t + 2];
    const xa = pos[3 * i0 + ia], ya = pos[3 * i0 + ib], xb = pos[3 * i1 + ia], yb = pos[3 * i1 + ib], xc = pos[3 * i2 + ia], yc = pos[3 * i2 + ib];
    const gx0 = Math.max(0, Math.ceil((Math.min(xa, xb, xc) - a0) / h)), gx1 = Math.min(nx - 1, Math.floor((Math.max(xa, xb, xc) - a0) / h));
    const gy0 = Math.max(0, Math.ceil((Math.min(ya, yb, yc) - b0) / h)), gy1 = Math.min(ny - 1, Math.floor((Math.max(ya, yb, yc) - b0) / h));
    if (gx0 > gx1 || gy0 > gy1) continue;
    const det = (yb - yc) * (xa - xc) + (xc - xb) * (ya - yc);
    if (Math.abs(det) < 1e-30) continue;
    const eps = -1e-6;
    for (let gy = gy0; gy <= gy1; gy++) {
      const y = b0 + gy * h;
      for (let gx = gx0; gx <= gx1; gx++) {
        const x = a0 + gx * h;
        const l0 = ((yb - yc) * (x - xc) + (xc - xb) * (y - yc)) / det;
        const l1 = ((yc - ya) * (x - xc) + (xa - xc) * (y - yc)) / det;
        const l2 = 1 - l0 - l1;
        if (l0 < eps || l1 < eps || l2 < eps) continue;
        const k = gy * nx + gx;
        let A = 0, B = 0, C = 0;
        for (const [l, i] of [[l0, i0], [l1, i1], [l2, i2]]) {
          const ux = U[3 * i], uy = U[3 * i + 1], uz = U[3 * i + 2];
          A += l * U[3 * i + ia]; B += l * U[3 * i + ib]; C += l * Math.hypot(ux, uy, uz);
        }
        u[k] = A; v[k] = B; s[k] = C; m[k] = 1;
      }
    }
  }
  return { nx, ny, h, a0, b0, u, v, s, m };
}

// bilinear sample; null outside the fluid (all four nodes must be fluid)
function sample(g, x, y, out) {
  const fx = (x - g.a0) / g.h, fy = (y - g.b0) / g.h;
  const ix = Math.floor(fx), iy = Math.floor(fy);
  if (ix < 0 || iy < 0 || ix >= g.nx - 1 || iy >= g.ny - 1) return false;
  const k = iy * g.nx + ix, m = g.m;
  if (!m[k] || !m[k + 1] || !m[k + g.nx] || !m[k + g.nx + 1]) return false;
  const tx = fx - ix, ty = fy - iy;
  const w00 = (1 - tx) * (1 - ty), w10 = tx * (1 - ty), w01 = (1 - tx) * ty, w11 = tx * ty;
  const n = g.nx;
  out[0] = g.u[k] * w00 + g.u[k + 1] * w10 + g.u[k + n] * w01 + g.u[k + n + 1] * w11;
  out[1] = g.v[k] * w00 + g.v[k + 1] * w10 + g.v[k + n] * w01 + g.v[k + n + 1] * w11;
  out[2] = g.s[k] * w00 + g.s[k + 1] * w10 + g.s[k + n] * w01 + g.s[k + n + 1] * w11;
  return true;
}

// evenly spaced lines; returns [{x: [], y: [], s: [], t: []}] in plane coordinates
export function traceLines(data, axis, region, spacing, uRef) {
  const span = Math.max(region[0][1] - region[0][0], region[1][1] - region[1][0]);
  let h = spacing / 4;
  const area = (region[0][1] - region[0][0]) * (region[1][1] - region[1][0]);
  if (area / (h * h) > 3e6) h = Math.sqrt(area / 3e6);
  const g = rasterise(data, axis, region, h);
  const dsep = spacing, dtest = 0.5 * spacing, step = Math.min(h, dsep / 5);
  const vmin = 2e-3 * (uRef || 1);
  const maxPts = Math.ceil(4 * span / step);
  // spatial bins of size dsep holding [x, y, line, signed index]
  const bw = dsep, bx = Math.ceil((region[0][1] - region[0][0]) / bw) + 1, by = Math.ceil((region[1][1] - region[1][0]) / bw) + 1;
  const bins = new Array(bx * by);
  const binOf = (x, y) => {
    const i = Math.floor((x - region[0][0]) / bw), j = Math.floor((y - region[1][0]) / bw);
    return i < 0 || j < 0 || i >= bx || j >= by ? -1 : j * bx + i;
  };
  const addPt = (x, y, line, idx) => { const b = binOf(x, y); if (b >= 0) (bins[b] || (bins[b] = [])).push(x, y, line, idx); };
  const selfGap = Math.ceil(2.5 * dsep / step);
  const free = (x, y, d, line, idx) => {
    const i = Math.floor((x - region[0][0]) / bw), j = Math.floor((y - region[1][0]) / bw), d2 = d * d;
    for (let jj = j - 1; jj <= j + 1; jj++) {
      if (jj < 0 || jj >= by) continue;
      for (let ii = i - 1; ii <= i + 1; ii++) {
        if (ii < 0 || ii >= bx) continue;
        const b = bins[jj * bx + ii];
        if (!b) continue;
        for (let q = 0; q < b.length; q += 4) {
          // own line: only points far back along the line count (closed loops), the index is
          // signed (backward half negative) so |idx - other| is the distance along the line
          if (b[q + 2] === line && Math.abs(idx - b[q + 3]) < selfGap) continue;
          const dx = b[q] - x, dy = b[q + 1] - y;
          if (dx * dx + dy * dy < d2) return false;
        }
      }
    }
    return true;
  };
  const tmp = new Float64Array(3), tmp2 = new Float64Array(3);
  const lines = [];
  const trace = (x0, y0, id) => {
    const half = (dir) => {
      const X = [], Y = [], S = [], T = [];
      let x = x0, y = y0, t = 0;
      for (let n = 1; n < maxPts; n++) {
        if (!sample(g, x, y, tmp)) break;
        const sp = Math.hypot(tmp[0], tmp[1]);
        if (sp < vmin) break;
        // midpoint step of fixed length along the in-plane direction
        const mx = x + 0.5 * dir * step * tmp[0] / sp, my = y + 0.5 * dir * step * tmp[1] / sp;
        if (!sample(g, mx, my, tmp2)) break;
        const sp2 = Math.hypot(tmp2[0], tmp2[1]);
        if (sp2 < vmin) break;
        const nx = x + dir * step * tmp2[0] / sp2, ny = y + dir * step * tmp2[1] / sp2;
        if (!free(nx, ny, dtest, id, dir * n)) break;
        t += step / sp2;
        x = nx; y = ny;
        X.push(x); Y.push(y); S.push(tmp2[2]); T.push(dir * t);
        addPt(x, y, id, dir * n);
      }
      return { X, Y, S, T };
    };
    if (!sample(g, x0, y0, tmp)) return null;
    const s0 = tmp[2];
    addPt(x0, y0, id, 0);
    const f = half(1), b = half(-1);
    return { x: b.X.reverse().concat([x0], f.X), y: b.Y.reverse().concat([y0], f.Y), s: b.S.reverse().concat([s0], f.S), t: b.T.reverse().concat([0], f.T) };
  };
  // candidate seeds: beside existing lines first, then a shuffled coarse grid
  const grid = [];
  for (let j = 0; j * dsep <= region[1][1] - region[1][0]; j++) {
    for (let i = 0; i * dsep <= region[0][1] - region[0][0]; i++) grid.push([region[0][0] + (i + 0.5) * dsep, region[1][0] + (j + 0.5) * dsep]);
  }
  let r = 12345;
  const rnd = () => { r = (r * 1103515245 + 12345) & 0x7fffffff; return r / 0x7fffffff; };
  for (let i = grid.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [grid[i], grid[j]] = [grid[j], grid[i]]; }
  const minLen = Math.ceil(1.5 * dsep / step);
  const tryLine = (x, y) => {
    if (!sample(g, x, y, tmp) || Math.hypot(tmp[0], tmp[1]) < vmin || !free(x, y, dsep, -1, 0)) return null;
    const id = lines.length;
    const L = trace(x, y, id);
    if (!L) return null;
    lines.push(L);           // short ones stay in the bins (keep the spacing) but are not drawn
    return L.x.length >= minLen ? L : null;
  };
  const queue = [];
  let gi = 0;
  for (;;) {
    let L = null;
    while (!L && queue.length) {
      const src = queue.shift();
      for (let k = 0; k < src.x.length && !L; k += 2) {
        const k1 = Math.min(src.x.length - 1, k + 1), k0 = Math.max(0, k - 1);
        const tx = src.x[k1] - src.x[k0], ty = src.y[k1] - src.y[k0], tl = Math.hypot(tx, ty) || 1;
        for (const side of [1, -1]) {
          L = tryLine(src.x[k] - side * dsep * ty / tl, src.y[k] + side * dsep * tx / tl);
          if (L) { queue.unshift(src); break; }
        }
      }
    }
    while (!L && gi < grid.length) L = tryLine(grid[gi][0], grid[gi++][1]);
    if (!L) break;
    queue.push(L);
  }
  return lines.filter((L) => L.x.length >= minLen);
}

// flat ribbons: 6 vertices per segment; aVal = speed, aLine = (time of flight, across -1..1)
export function ribbons(lines, axis, planePos, width, jitter = 0) {
  const [ia, ib] = planeAxes(axis);
  let nseg = 0;
  for (const L of lines) nseg += L.x.length - 1;
  const P = new Float32Array(nseg * 18), V = new Float32Array(nseg * 6), A = new Float32Array(nseg * 12);
  let o = 0;
  const hw = width / 2, taper = 4 * width;
  let li = 0;
  for (const L of lines) {
    // own phase per line (time of flight offset) so the animated drops do not march in rows
    const shift = jitter * ((Math.sin(++li * 12.9898) * 43758.5453) % 1 + 1) % jitter || 0;
    const n = L.x.length;
    const arc = new Float64Array(n);
    for (let i = 1; i < n; i++) arc[i] = arc[i - 1] + Math.hypot(L.x[i] - L.x[i - 1], L.y[i] - L.y[i - 1]);
    const len = arc[n - 1];
    const side = [];
    for (let i = 0; i < n; i++) {
      const i0 = Math.max(0, i - 1), i1 = Math.min(n - 1, i + 1);
      const tx = L.x[i1] - L.x[i0], ty = L.y[i1] - L.y[i0], tl = Math.hypot(tx, ty) || 1;
      const e = Math.min(1, arc[i] / taper, (len - arc[i]) / taper);
      const w = hw * (0.15 + 0.85 * e * e * (3 - 2 * e));
      side.push([-ty / tl * w, tx / tl * w]);
    }
    const put = (i, sgn) => {
      const p = [0, 0, 0];
      p[axis] = planePos; p[ia] = L.x[i] + sgn * side[i][0]; p[ib] = L.y[i] + sgn * side[i][1];
      P.set(p, o * 3); V[o] = L.s[i]; A[2 * o] = L.t[i] + shift; A[2 * o + 1] = sgn; o++;
    };
    for (let i = 0; i < n - 1; i++) { put(i, -1); put(i, 1); put(i + 1, 1); put(i, -1); put(i + 1, 1); put(i + 1, -1); }
  }
  return { pos: P, val: V, line: A, n: o };
}
