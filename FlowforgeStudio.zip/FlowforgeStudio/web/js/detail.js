// Detail view of one simulation: header, actions, live run panel and tabs.

import * as api from './api.js';
import { h, mount, clear, icon, btn, toast, toastError, showMenu, confirmDialog, fmtAgo, fmtDuration,
  fmtForce, fmtCells, fmtDate, fmtBytes, fmtInt, fmtNum, splitName, STATUS, statusPill, store, modal, debounce,
  convergence, convergencePill, relUnc, uncOf, renderMarkdown } from './ui.js';
import { runMenuItems } from './app.js';
import { ResidualsTab, ForcesTab, LogsTab, SettingsTab, GeometryTab, CompareTab } from './tabs.js';
import { MeshTab } from './meshtab.js';
import { ResultsTab } from './resultstab.js';

// in workflow order: set up -> mesh -> run -> evaluate; logs last
const TABS = [
  ['overview', 'Overview', 'home'],
  ['geometry', 'Geometry', 'cube'],
  ['settings', 'Settings', 'sliders'],
  ['mesh', 'Mesh', 'grid'],
  ['residuals', 'Residuals', 'wave'],
  ['forces', 'Forces', 'chart'],
  ['results', 'Results', 'eye'],
  ['compare', 'Compare', 'compare'],
  ['logs', 'Logs', 'log'],
];

export class DetailView {
  constructor(container, name, app) {
    this.container = container;
    this.name = name;
    this.app = app;
    this.data = null;
    this.tab = store('tab') || 'overview';
    this.tabObj = null;
    this.timers = [];
    this.destroyed = false;
    this.root = h('div', { class: 'page' });
    this.headEl = h('div');
    this.runEl = h('div');
    this.tabsEl = h('div', { class: 'tabs' });
    this.bodyEl = h('div', { class: 'tab-body' });
    this.root.append(this.headEl, this.runEl, this.tabsEl, this.bodyEl);
    container.appendChild(this.root);
    mount(this.headEl, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
    this.reload(true);
    this.timers.push(setInterval(() => this.poll(), 2000));
  }

  destroy() {
    this.destroyed = true;
    this.timers.forEach(clearInterval);
    if (this.tabObj && this.tabObj.destroy) this.tabObj.destroy();
  }

  get running() { return this.data && this.data.status === 'running'; }

  async reload(first = false) {
    try {
      const d = await api.get('case', { name: this.name });
      if (this.destroyed) return;
      const prevSig = this.data ? this.sig(this.data) : null;
      this.data = d;
      this.lastFull = Date.now();
      if (first || prevSig !== this.sig(d)) {
        this.renderHead();
        this.renderTabs();
        if (first) this.showTab(this.tab);
        else if (this.tabObj && this.tabObj.onCaseChanged) this.tabObj.onCaseChanged(d);
        else if (this.tab === 'overview') {
          // do not throw away notes that are being written - redraw once they are done
          if (this.notesEditing) this.overviewStale = true; else this.showTab('overview');
        }
      }
      this.renderRun(null);
    } catch (e) {
      if (this.destroyed) return;
      if (e.status === 404) {
        mount(this.headEl, h('div', { class: 'empty' }, icon('alert', 'xl'), h('h3', null, 'Simulation not found'), h('div', null, e.message)));
        clear(this.runEl); clear(this.tabsEl); clear(this.bodyEl);
      } else toastError(e);
    }
  }

  sig(d) {
    // car data (Forces tab balance) is saved while typing - it must not reload the open tab
    const meta = d.meta ? Object.assign({}, d.meta, { vehicle: undefined }) : d.meta;
    return JSON.stringify([d.status, d.error, d.queued, d.has_mesh, d.result_times, meta, d.mesh && d.mesh.cells,
      d.results && d.results.drag, d.state && d.state.job_id, d.state && d.state.status, (d.logs || []).length, d.control]);
  }

  async poll() {
    if (this.destroyed || !this.data) return;
    if (this.running) {
      try {
        const p = await api.get('progress', { name: this.name });
        if (this.destroyed) return;
        if (p.status !== 'running') { this.reload(); return; }
        this.data.state = p.state;
        this.renderRun(p);
        if (this.tabObj && this.tabObj.onTick) this.tabObj.onTick(true);
      } catch (e) { /* transient */ }
      if (Date.now() - this.lastFull > 15000) this.reload();
    } else {
      if (this.tabObj && this.tabObj.onTick) this.tabObj.onTick(false);
      if (Date.now() - this.lastFull > 8000) this.reload();
    }
  }

  onCasesUpdated() {
    const c = this.app.byName(this.name);
    if (c && this.data && (c.status !== this.data.status || c.queued !== this.data.queued)) this.reload();
  }

  onThemeChanged() { if (this.tabObj && this.tabObj.onTheme) this.tabObj.onTheme(); }

  // ------------------------------------------------------------------ header
  renderHead() {
    const d = this.data;
    const { date, rest } = splitName(d.name);
    const status = d.status;
    const chips = [];
    const goTo = (n) => { if (this.app.byName(n)) this.app.select(n); else toast('Simulation not found', n + ' is not in the simulations folder.', 'warn'); };
    const sameWarm = d.meta.map_source && d.meta.map_source === d.meta.origin;
    if (d.meta.origin) {
      const ch = h('span', { class: 'chip link' + (sameWarm ? ' warm-chip' : ''), title: d.meta.origin + (sameWarm
        ? '\nCopied from this simulation and warm-started from its flow field (mapFields)' : '\nCopied from this simulation') },
        icon(sameWarm ? 'flame' : 'link'), sameWarm ? 'From + warm start ' : 'From ', h('b', null, splitName(d.meta.origin).rest));
      ch.addEventListener('click', () => goTo(d.meta.origin));
      chips.push(ch);
    } else {
      chips.push(h('span', { class: 'chip', title: 'This simulation was not created with Flowforge Studio' }, icon('link'), 'Origin ', h('b', null, 'unknown')));
    }
    if (d.meta.map_source && !sameWarm) {
      const w = h('span', { class: 'chip link warm-chip', title: d.meta.map_source + '\nWarm start: the flow field is initialised from this simulation (mapFields)' },
        icon('flame'), 'Warm start ', h('b', null, splitName(d.meta.map_source).rest));
      w.addEventListener('click', () => goTo(d.meta.map_source));
      chips.push(w);
    }
    if (d.results && d.results.drag != null) {
      const conv = convergence(relUnc(d.results));
      chips.push(h('span', { class: 'chip', title: 'Mean drag over ' + d.results.window + ' iterations (full car), \u00b1 = uncertainty of the mean' }, icon('wind'), 'Drag ',
        h('b', null, fmtForce(d.results.drag) + ' N'), conv ? h('span', { class: 'chip-conv ' + conv.cls, title: conv.label }, '\u00b1' + conv.pct) : null));
    }
    if (d.mesh && d.mesh.cells) chips.push(h('span', { class: 'chip' }, icon('grid'), h('b', null, fmtCells(d.mesh.cells)), ' cells'));
    if (d.control && d.control.endTime != null) chips.push(h('span', { class: 'chip' }, icon('target'), 'End ', h('b', null, d.control.endTime), ' it'));
    chips.push(h('span', { class: 'chip', title: 'CPU cores meshing / solving' }, icon('stack'), h('b', null, `${d.cores.mesh} / ${d.cores.solve}`), ' cores'));

    const busy = status === 'running' || d.queued;
    const actions = h('div', { class: 'actions' });
    const mainLabel = status === 'meshed' ? 'Solve' : (status === 'finished' || status === 'stopped') ? 'Re-run' : 'Run';
    const mainMode = status === 'meshed' ? 'solve' : 'full';
    if (status === 'running') {
      if (!d.external) {
        const pauseBtn = btn('Pause', { icon: 'pause', title: 'Saves the current iteration and pauses the queue; Resume continues exactly there. While meshing, it pauses once the mesh is done.' });
        pauseBtn.addEventListener('click', () => this.pause(pauseBtn));
        actions.append(pauseBtn);
      }
      const stopBtn = btn('Stop', { variant: 'danger', icon: 'stop', caret: true });
      stopBtn.addEventListener('click', () => this.stopMenu(stopBtn));
      actions.append(stopBtn);
    } else if (d.queued && d.state && d.state.paused) {
      const resume = btn('Resume', { variant: 'primary', icon: 'play', title: 'Continue from the saved iteration (resumes the queue)' });
      resume.addEventListener('click', async () => {
        resume.disabled = true;
        try { await api.post('queue', { action: 'resume' }); toast('Resumed', 'It continues from the saved iteration.', 'ok'); this.app.refresh(); } catch (e) { toastError(e, 'Could not resume'); resume.disabled = false; }
      });
      actions.append(resume);
    } else {
      const g = h('div', { class: 'btn-group' });
      const main = btn(d.queued ? 'Queued' : mainLabel, { variant: 'primary', icon: 'play', disabled: busy });
      main.addEventListener('click', () => this.app.run([this.name], mainMode));
      const more = btn('', { variant: 'primary', icon: 'chevDown', disabled: busy, title: 'More run options' });
      more.addEventListener('click', () => showMenu(more, runMenuItems([this.name])));
      g.append(main, more);
      actions.append(g);
    }
    const folder = btn('', { icon: 'folder', title: 'Open folder in Explorer' });
    folder.addEventListener('click', () => this.open('explorer'));
    const term = btn('', { icon: 'terminal', title: 'Open blueCFD-Core terminal here' });
    term.addEventListener('click', () => this.open('terminal'));
    const moreBtn = btn('', { icon: 'dots', title: 'More' });
    moreBtn.addEventListener('click', () => showMenu(moreBtn, [
      { label: 'New simulation from this...', sub: 'Copy setup, swap STLs', icon: 'copy', onClick: () => this.app.openWizard(this.name) },
      { label: 'Rename...', sub: 'Also updates origin / warm-start references and the spreadsheet', icon: 'log', disabled: busy, onClick: () => this.rename() },
      ...(this.app.can('compare') ? [{ label: 'Compare with...', icon: 'compare', onClick: () => this.showTab('compare') }] : []),
      '-',
      { label: 'Clean up...', sub: 'Delete results and mesh, keep settings and forces', icon: 'broom', disabled: busy, onClick: () => this.clean('cleanup') },
      { label: 'Delete simulation...', sub: 'Removes the whole folder, cannot be undone', icon: 'trash', danger: true, disabled: busy, onClick: () => this.deleteSim() },
    ]));
    actions.append(folder, term, moreBtn);

    const warn = d.name.includes(' ') ? h('div', { class: 'warn-inline' }, icon('alert'),
      'The folder name contains a space - OpenFOAM scripts may fail. Prefer underscores.') : null;

    const titleEl = h('h1', { title: busy ? '' : 'Double-click to rename' }, rest, statusPill(status), d.queued && status !== 'running' ? statusPill('queued', 'Queued') : null);
    if (!busy) titleEl.addEventListener('dblclick', () => this.rename());
    mount(this.headEl, h('div', { class: 'detail-head st-' + status },
      h('div', { class: 'detail-title' },
        titleEl,
        h('div', { class: 'date-tag', title: 'Folder: ' + d.path }, [date, d.meta.created ? 'created ' + fmtDate(d.meta.created) : null].filter(Boolean).join('  \u00b7  ')),
        warn),
      actions,
      // full width below title + buttons, so the chips are not squeezed next to the action buttons
      h('div', { class: 'meta-row' }, chips)));
  }

  // delete the whole simulation (asks once; no Recycle Bin)
  async deleteSim() {
    let info;
    try { info = await api.post('delete', { name: this.name }); } catch (e) { toastError(e); return; }
    const name = this.name;
    const kids = info.dependents || [];
    const ok = await confirmDialog({
      title: 'Delete this simulation?',
      message: h('div', null,
        h('p', { style: { marginTop: 0 } }, 'The whole folder ', h('b', null, name), ` (${fmtBytes(info.size)}) is deleted from disk: settings, STLs, mesh, results, forces and logs. `,
          'It does not go to the Recycle Bin and cannot be undone.'),
        kids.length ? h('div', { class: 'callout warn' }, icon('alert'), h('div', { class: 'callout-body' },
          `${kids.length} other simulation${kids.length === 1 ? ' was' : 's were'} made from this one (${kids.slice(0, 4).join(', ')}${kids.length > 4 ? ', ...' : ''}). `,
          'They keep working, only the "From" / warm-start link points to nothing then.')) : null),
      confirmLabel: 'Delete simulation', danger: true,
    });
    if (!ok) return;
    try {
      const r = await api.post('delete', { name, confirm: true });
      if (r.errors && r.errors.length) toast(r.deleted ? 'Deleted, with warnings' : 'Could not delete everything', r.errors.slice(0, 5).join(', '), 'warn', 12000);
      else toast('Simulation deleted', `${name} · ${fmtBytes(r.freed)} freed`, 'ok');
      this.app.select(null);
      await this.app.refresh();
    } catch (e) { toastError(e, 'Could not delete'); }
  }

  // notes as Markdown: shown formatted, click to edit (the text field grows with the text)
  notesBox(d) {
    const box = h('div', { class: 'notes-box' });
    const view = () => {
      const md = d.meta.notes || '';
      const el = md.trim()
        ? h('div', { class: 'md-notes', title: 'Click to edit', html: renderMarkdown(md, { breaks: true }) })
        : h('div', { class: 'md-notes empty' }, 'Notes about this variant (what changed, why, conclusions) - click to write. Markdown works: **bold**, *italic*, # heading, - list, `code`.');
      el.addEventListener('click', () => { if (!window.getSelection().toString()) edit(); });
      mount(box, el);
      if (this.overviewStale) { this.overviewStale = false; this.showTab('overview'); }
    };
    const edit = () => {
      const ta = h('textarea', { class: 'input notes-edit', placeholder: 'Markdown: **bold**, *italic*, # heading, - list, - [ ] to do, `code`' });
      ta.value = d.meta.notes || '';
      const grow = () => { ta.style.height = 'auto'; ta.style.height = (ta.scrollHeight + 2) + 'px'; };
      // saved while typing too (switching the tab or the simulation does not lose anything)
      const save = async () => {
        if (ta.value === (d.meta.notes || '')) return;
        try { await api.post('meta', { name: this.name, notes: ta.value }); d.meta.notes = ta.value; } catch (e) { toastError(e); }
      };
      const saveSoon = debounce(save, 1200);
      ta.addEventListener('input', () => { grow(); saveSoon(); });
      ta.addEventListener('keydown', (e) => { if (e.key === 'Escape' || (e.key === 'Enter' && e.ctrlKey)) { e.preventDefault(); ta.blur(); } });
      ta.addEventListener('blur', async () => {
        this.notesEditing = false;
        await save();
        view();
      });
      mount(box, ta, h('div', { class: 'muted small', style: { marginTop: '4px' } }, 'Saved automatically · Esc or Ctrl+Enter to finish'));
      this.notesEditing = true;
      grow();
      ta.focus();
    };
    view();
    return box;
  }

  stopMenu(anchor) {
    const st = this.data.state || {};
    const cur = st.steps && st.current != null ? st.steps[st.current] : null;
    const inSolve = (cur && cur.id === 'solve') || (this.data.external && /Solv/.test(this.data.detail || ''));
    showMenu(anchor, [
      { label: 'Stop & save results', sub: inSolve ? 'Solver writes the current state, then finishes normally' : 'Only possible while the solver runs', icon: 'save', disabled: !inSolve, onClick: () => this.stop('writenow') },
      { label: 'Abort immediately', sub: 'Kills all processes; current step is lost', icon: 'stop', danger: true, disabled: this.data.external, onClick: () => this.stop('abort') },
    ]);
  }

  async pause(b) {
    b.disabled = true;
    try {
      await api.post('queue', { action: 'pause_now' });
      toast('Pausing', 'The solver saves the current iteration and stops (meshing is finished first). Resume continues from there.', 'ok', 7000);
    } catch (e) { toastError(e, 'Could not pause'); b.disabled = false; }
  }

  async stop(how) {
    if (how === 'abort') {
      const ok = await confirmDialog({ title: 'Abort this run?', message: 'All processes of this run are terminated. Unsaved progress of the current step is lost.', confirmLabel: 'Abort run', danger: true });
      if (!ok) return;
    }
    try {
      const r = await api.post('stop', { name: this.name, how });
      toast(how === 'abort' ? 'Abort requested' : 'Stop & save requested', r.message || '', 'ok');
    } catch (e) { toastError(e, 'Could not stop'); }
  }

  async rename() {
    const old = this.name;
    const inp = h('input', { class: 'input', value: old, style: { fontSize: '14px' } });
    const msg = h('div', { class: 'hint' });
    const ok = btn('Rename', { variant: 'primary' });
    const cancel = btn('Cancel', { variant: 'ghost' });
    const m = modal({
      title: 'Rename simulation',
      body: h('div', null,
        h('div', { class: 'field' }, h('label', null, 'New folder name'), inp, msg),
        h('p', { class: 'muted small', style: { marginBottom: 0 } },
          'The folder is renamed and all references are updated: origin and warm-start links of other simulations, '
          + 'go_map.txt, the run queue and the results spreadsheet. Close ParaView, Explorer or terminal windows that use this folder first.')),
      footer: [cancel, ok],
    });
    cancel.addEventListener('click', () => m.close());
    let valid = false;
    const check = debounce(async () => {
      if (inp.value.trim() === old) { valid = false; mount(msg, ''); ok.disabled = true; return; }
      try {
        const r = await api.post('wizard/validate', { name: inp.value });
        valid = r.ok;
        inp.classList.toggle('invalid', !r.ok);
        mount(msg, r.ok ? h('span', { class: 'ok' }, '\u2713 Name is available') : h('span', { class: 'bad' }, r.error));
        ok.disabled = !r.ok;
      } catch (e) { /* ignore */ }
    }, 200);
    inp.addEventListener('input', () => {
      if (inp.value.includes(' ')) { const p = inp.selectionStart; inp.value = inp.value.replace(/ /g, '_'); inp.setSelectionRange(p, p); }
      ok.disabled = true; check();
    });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter' && valid) ok.click(); });
    ok.disabled = true;
    setTimeout(() => { inp.focus(); inp.select(); }, 50);
    ok.addEventListener('click', async () => {
      ok.disabled = true;
      try {
        const r = await api.post('rename', { name: old, new_name: inp.value.trim() });
        m.close();
        // carry over per-simulation view preferences
        const mv = store('mesh-visible-' + old);
        if (mv) store('mesh-visible-' + r.name, mv);
        toast('Simulation renamed', r.changes.join('\n'), 'ok', 7000);
        await this.app.refresh();
        this.app.select(r.name);
      } catch (e) {
        toastError(e, 'Could not rename');
        ok.disabled = false;
      }
    });
  }

  async open(what, extra = {}) {
    try {
      const r = await api.post('open', Object.assign({ name: this.name, what }, extra));
      if (r.message) toast(r.message, '', 'ok', 3000);
    } catch (e) { toastError(e); }
  }

  async clean(what) {
    try {
      const prev = await api.post('clean', { name: this.name, what });
      if (!prev.items.length) { toast('Nothing to remove', what === 'results' ? 'This simulation has no results.' : 'There are no results or mesh to remove.', 'info'); return; }
      const list = h('div', { style: { maxHeight: '260px', overflow: 'auto', border: '1px solid var(--border)', borderRadius: '10px', padding: '6px 10px' } },
        h('table', { class: 'tbl' }, h('tbody', null, prev.items.slice().sort((a, b) => b.size - a.size).map((i) =>
          h('tr', null, h('td', { class: 'mono small' }, i.path), h('td', { class: 'num muted' }, fmtBytes(i.size)))))));
      const ok = await confirmDialog({
        title: what === 'results' ? 'Delete all results?' : 'Clean up results and mesh?',
        message: what === 'results'
          ? `This removes the mesh, all time steps, logs and force data (${fmtBytes(prev.total)}). Settings and STL files are kept. This cannot be undone.`
          : `This removes the flow fields and the mesh (${fmtBytes(prev.total)}). Settings, STLs, forces, residuals, logs and notes are kept, so the drag values and charts stay. `
            + 'The Results and Mesh views, Continue solving and using it as warm-start source need a Re-run afterwards.',
        details: list, confirmLabel: what === 'results' ? 'Delete results' : 'Clean up', danger: true,
      });
      if (!ok) return;
      const r = await api.post('clean', { name: this.name, what, confirm: true });
      if (r.errors && r.errors.length) toast('Some items could not be removed', r.errors.join('\n'), 'warn', 9000);
      else toast(what === 'results' ? 'Results deleted' : 'Cleaned up', `${fmtBytes(r.freed)} freed`, 'ok');
      this.usage = null;
      await this.app.refresh();
      this.reload();
    } catch (e) { toastError(e); }
  }

  // ------------------------------------------------------------------ run panel
  renderRun(progress) {
    const d = this.data;
    const st = d.state || {};
    const running = d.status === 'running';
    if (!running && !(st.steps && st.steps.length)) { clear(this.runEl); return; }
    if (d.external && running) {
      const p = progress || {};
      mount(this.runEl, this.runPanel({ title: d.detail || 'Running (started outside Flowforge Studio)', running: true,
        solver: p.solver || (d.progress && d.progress.kind === 'solve' ? { current: d.progress.current, end: d.progress.end, fraction: d.progress.fraction, eta: d.progress.eta } : null),
        snappy: p.snappy, steps: null }));
      return;
    }
    let title, kind;
    const cur = st.current != null && st.steps ? st.steps[st.current] : null;
    if (running) {
      title = cur ? `${cur.phase === 'mesh' ? 'Meshing' : 'Solving'} — ${cur.label}` : 'Starting...';
      kind = 'running';
    } else if (st.status === 'error') {
      const failed = (st.steps || []).find((s) => s.status === 'failed' || s.status === 'aborted');
      title = failed ? `Last run ${failed.status === 'aborted' ? 'aborted' : 'failed'} at: ${failed.label}` : 'Last run failed';
      kind = 'error';
    } else {
      title = `Last run: ${STATUS[st.status] ? STATUS[st.status].label.toLowerCase() : st.status}`;
      kind = 'done';
    }
    const p = progress || {};
    let solver = p.solver, snappy = p.snappy;
    if (!progress && running && d.progress) {
      if (d.progress.kind === 'solve') solver = { current: d.progress.current, end: d.progress.end, fraction: d.progress.fraction, eta: d.progress.eta };
    }
    mount(this.runEl, this.runPanel({ title, running, kind, state: st, cur, solver: cur && cur.id === 'solve' ? solver : null, snappy: cur && cur.id === 'snappy' ? snappy : null, steps: st.steps }));
  }

  runPanel({ title, running, kind, state, cur, solver, snappy, steps }) {
    const st = state || {};
    const stats = h('div', { class: 'runpanel-stats' });
    const prior = st.prior && st.prior.runs ? st.prior : null;
    const totalTip = prior ? `${prior.runs + 1} runs together (continued) - this run alone: ` +
      fmtDuration(((st.ended || Date.now() / 1000) - st.started)) + '. Pauses in between are not counted.' : null;
    let frac = null, indet = false;
    if (running) {
      if (solver && solver.current != null) {
        frac = solver.fraction;
        stats.append(h('span', null, 'Iteration ', h('b', null, `${Math.round(solver.current)} / ${solver.end}`)));
        if (solver.sec_per_it) stats.append(h('span', null, h('b', null, solver.sec_per_it.toFixed(2)), ' s/it'));
        if (solver.eta != null) stats.append(h('span', null, 'Remaining ', h('b', null, fmtDuration(solver.eta))));
      } else if (snappy) {
        frac = snappy.fraction;
        stats.append(h('span', null, 'Phase ', h('b', null, snappy.phase)));
        if (snappy.detail) stats.append(h('span', null, snappy.detail));
      } else if (steps && steps.length && cur) {
        const i = steps.indexOf(cur);
        frac = null; indet = true;
        stats.append(h('span', null, 'Step ', h('b', null, `${i + 1} / ${steps.length}`)));
      } else { indet = true; }
      if (st.started) {
        const el = Date.now() / 1000 - st.started;
        stats.append(h('span', null, 'Elapsed ', h('b', null, fmtDuration(el))));
        if (prior) stats.append(h('span', { title: totalTip }, 'Total ', h('b', null, fmtDuration(el + prior.total))));
      }
    } else if (st.started && st.ended) {
      // a continued run shows the time of all runs together (only the time they were running)
      stats.append(h('span', prior ? { title: totalTip } : null, 'Duration ', h('b', null, fmtDuration(st.ended - st.started + (prior ? prior.total : 0)))));
      stats.append(h('span', null, 'Ended ', h('b', null, fmtAgo(st.ended))));
      if (st.mode) stats.append(h('span', null, h('b', null, this.app.info.modes[st.mode] || st.mode)));
    }
    // a finished run only needs the phase durations; the individual steps are one click away
    const compact = !running && kind === 'done' && steps && !steps.some((s) => s.status === 'warning');
    let stepsEl = steps ? this.stepChips(steps) : null;
    if (compact) {
      const phases = [];
      for (const ph of ['mesh', 'solve']) {
        const ss = steps.filter((s) => s.phase === ph && s.started);
        const before = prior ? prior[ph] || 0 : 0;
        const t = (ss.length ? Math.max(...ss.map((s) => s.ended || s.started)) - Math.min(...ss.map((s) => s.started)) : 0) + before;
        if (ss.length || before > 0) phases.push(h('span', null, ph === 'mesh' ? 'Mesh ' : 'Solve ', h('b', null, fmtDuration(t))));
      }
      stats.prepend(...phases);
      const toggle = h('a', { class: 'small' }, this.showSteps ? 'Hide steps' : 'Show steps');
      toggle.addEventListener('click', () => { this.showSteps = !this.showSteps; this.renderRun(null); });
      stats.append(toggle);
      if (!this.showSteps) stepsEl = null;
    }
    const icn = running ? h('div', { class: 'spinner', style: { color: 'var(--st-running)', width: '16px', height: '16px' } })
      : kind === 'error' ? icon('alert', 'lg') : icon('check', 'lg');
    const stCls = running ? 'st-running' : kind === 'error' ? 'st-error' : 'st-finished';
    // older runs stored "checkMesh: 1 failed mesh check(s)" for the usual few skewed layer faces -
    // not worth a warning (newer runs only warn for other failed checks and name them)
    const warns = running ? [] : (st.warnings || []).filter((w) => !/^checkMesh: 1 failed mesh check\(s\)$/.test(w));
    return h('div', { class: 'runpanel ' + stCls },
      h('div', { class: 'runpanel-top' },
        h('div', { class: 'runpanel-title', style: { color: running ? null : 'var(--st)' } }, icn, h('span', { style: { color: 'var(--text)' } }, title)),
        stats),
      running ? h('div', { class: 'bigbar running' + (indet || frac == null ? ' indet' : '') }, h('i', { style: { width: Math.round((frac || 0) * 100) + '%' } })) : null,
      stepsEl,
      warns.length ? h('div', { class: 'warn-inline' }, icon('alert'), warns.join(' · ')) : null);
  }

  stepChips(steps) {
    const el = h('div', { class: 'steps' });
    let phase = null;
    for (const s of steps) {
      if (s.phase !== phase) {
        phase = s.phase;
        el.appendChild(h('span', { class: 'phase' }, phase === 'mesh' ? 'Mesh' : 'Solve'));
      }
      let ic = null;
      if (s.status === 'done') ic = icon('check');
      else if (s.status === 'warning') ic = icon('alert');
      else if (s.status === 'running') ic = h('span', { class: 'spinner' });
      else if (s.status === 'failed' || s.status === 'aborted') ic = icon('x');
      const dur = s.started ? ((s.ended || Date.now() / 1000) - s.started) : null;
      el.appendChild(h('span', { class: 'step ' + s.status, title: s.note || s.status }, ic, s.label,
        dur != null && s.status !== 'skipped' ? h('span', { class: 't' }, fmtDuration(dur)) : null));
    }
    return el;
  }

  // ------------------------------------------------------------------ tabs
  renderTabs() {
    clear(this.tabsEl);
    for (const [id, label, ic] of TABS) {
      if (!this.allowedTab(id)) continue;
      const t = h('div', { class: 'tab' + (this.tab === id ? ' active' : '') }, icon(ic), label,
        (id === 'logs' && this.running) ? h('span', { class: 'tab-dot' }) : null);
      t.addEventListener('click', () => this.showTab(id));
      this.tabsEl.appendChild(t);
    }
  }

  allowedTab(id) { return (id !== 'forces' && id !== 'compare') || this.app.can(id); }

  showTab(id, opts) {
    if (!this.allowedTab(id)) id = 'overview';
    this.notesEditing = false;
    if (this.tabObj && this.tabObj.destroy) this.tabObj.destroy();
    this.tabObj = null;
    this.tab = id;
    store('tab', id);
    this.renderTabs();
    // keep the scroll position: hold the old height until the new tab has rendered its content
    const scroller = this.container;
    const keepTop = scroller.scrollTop;
    // position of the tab bar in scroll coordinates (measured on the non-sticky body below it)
    const tabsTop = this.bodyEl.getBoundingClientRect().top - scroller.getBoundingClientRect().top
      + scroller.scrollTop - this.tabsEl.offsetHeight;
    this.bodyEl.style.minHeight = this.bodyEl.offsetHeight + 'px';
    clearTimeout(this._releaseHeight);
    this._releaseHeight = setTimeout(() => { this.bodyEl.style.minHeight = ''; }, 2500);
    // every tab gets its own container: late async results of a previous tab land in a detached element
    clear(this.bodyEl);
    const pane = h('div');
    this.bodyEl.appendChild(pane);
    this.pane = pane;
    if (!this.data) return;
    const ctx = { name: this.name, data: this.data, app: this.app, view: this };
    if (id === 'overview') this.renderOverview();
    else if (id === 'residuals') this.tabObj = new ResidualsTab(pane, ctx);
    else if (id === 'forces') this.tabObj = new ForcesTab(pane, ctx);
    else if (id === 'logs') this.tabObj = new LogsTab(pane, ctx, opts);
    else if (id === 'settings') this.tabObj = new SettingsTab(pane, ctx);
    else if (id === 'geometry') this.tabObj = new GeometryTab(pane, ctx);
    else if (id === 'mesh') this.tabObj = new MeshTab(pane, ctx);
    else if (id === 'results') this.tabObj = new ResultsTab(pane, ctx);
    else if (id === 'compare') this.tabObj = new CompareTab(pane, ctx, opts);
    // stay where the user was; if they had scrolled past the tab bar, keep the tab bar at the top
    scroller.scrollTop = keepTop > tabsTop ? tabsTop : keepTop;
  }

  openCompare(other) { this.showTab('compare', { other }); }
  openLog(file) { this.showTab('logs', { file }); }

  // ------------------------------------------------------------------ overview
  renderOverview() {
    const d = this.data;
    const parts = [];
    if (d.status === 'error' && d.error) {
      const logBtn = btn('Open log', { size: 'sm', icon: 'log' });
      logBtn.addEventListener('click', () => this.openLog(d.logs.find((l) => l.key === 'pipeline') ? '.flowforgestudio/pipeline.log' : (d.logs[0] || {}).file));
      const first = d.error.split('\n')[0];
      const rest = d.error.split('\n').slice(1).join('\n').trim();
      parts.push(h('div', { class: 'callout error', style: { marginBottom: '14px' } }, icon('alert', 'lg'),
        h('div', { class: 'callout-body' }, h('div', { class: 'callout-title' }, first),
          rest ? h('pre', { class: 'excerpt mono' }, rest) : null,
          h('div', { class: 'row', style: { marginTop: '10px' } }, logBtn))));
    }
    if (d.external && d.status === 'running') {
      parts.push(h('div', { class: 'callout', style: { marginBottom: '14px' } }, icon('info', 'lg'),
        h('div', { class: 'callout-body' }, h('div', { class: 'callout-title' }, 'This run was started outside Flowforge Studio'),
          h('div', { class: 'muted' }, 'Progress and logs are shown live. To abort it, use its terminal.'))));
    }

    const r = d.results;
    const resCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('wind'), 'Forces'),
        r && r.drag ? convergencePill(relUnc(r)) : null),
      r && r.drag != null ? h('div', { class: 'grid cols-2', style: { gap: '10px' } },
        h('div', { class: 'stat' }, h('div', { class: 'stat-sub' }, 'Drag'), h('div', { class: 'stat-value' }, fmtForce(r.drag), h('small', null, 'N')),
          h('div', { class: 'stat-sub', title: 'Uncertainty of the mean (statistical, 1 sigma). The drag itself swings by \u00b1' + fmtNum(r.drag_std, 2) + ' N around it.' },
            '± ' + fmtNum(uncOf(r), 2) + ' N' + (r.drag ? ` (${(relUnc(r) * 100).toFixed(2)} %)` : ''))),
        h('div', { class: 'stat' }, h('div', { class: 'stat-sub' }, 'Lift'), h('div', { class: 'stat-value' }, fmtForce(r.lift), h('small', null, 'N')),
          h('div', { class: 'stat-sub' }, '± ' + fmtNum(uncOf(r, 'lift'), 2) + ' N'))) : h('div', { class: 'muted' }, 'No force data yet.'),
      r && r.drag != null ? h('div', { class: 'stat-sub', style: { marginTop: '10px' } },
        `${r.window_mode === 'auto' && r.window_start != null ? `Mean of iterations ${Math.round(r.window_start)}\u2013${Math.round(r.iterations)} (start-up transient excluded)` : `Mean of the last ${r.window} iterations`}, ${r.headline === 'total' ? 'pressure + friction' : 'pressure only'}. \u00b1 = uncertainty of the mean. Without friction: ${fmtForce(r.drag_pressure)} / ${fmtForce(r.lift_pressure)} N`) : null);

    const m = d.mesh;
    const meshCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('grid'), 'Mesh'),
        m ? (m.failed_checks ? h('span', { class: 'pill st-running' }, `${m.failed_checks} failed check${m.failed_checks > 1 ? 's' : ''}`) : h('span', { class: 'pill st-ok' }, 'Mesh OK')) : null),
      m && m.cells ? h('div', null,
        h('div', { class: 'stat' }, h('div', { class: 'stat-value' }, fmtCells(m.cells), h('small', null, 'cells'))),
        h('div', { class: 'kv', style: { marginTop: '10px' } },
          h('span', { class: 'k' }, 'Hexahedra'), h('span', { class: 'v' }, m.hexahedra ? `${(m.hexahedra / m.cells * 100).toFixed(1)} %` : '-'),
          h('span', { class: 'k' }, 'Polyhedra'), h('span', { class: 'v' }, m.polyhedra != null ? fmtInt(m.polyhedra) : '-'),
          h('span', { class: 'k' }, 'Max non-orthogonality'), h('span', { class: 'v' }, m.max_non_ortho != null ? m.max_non_ortho.toFixed(1) + '°' : '-'),
          h('span', { class: 'k' }, 'Max skewness'), h('span', { class: 'v' }, m.max_skewness != null ? m.max_skewness.toFixed(2) : '-')))
        : h('div', { class: 'muted' }, d.has_mesh ? 'Meshed (no checkMesh output).' : 'Not meshed yet.'));

    const runCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('clock'), 'Run')),
      h('div', { class: 'kv' },
        h('span', { class: 'k' }, 'Status'), h('span', { class: 'v' }, statusPill(d.status)),
        h('span', { class: 'k' }, 'Iterations'), h('span', { class: 'v' }, (d.result_times.length ? d.result_times[d.result_times.length - 1] : '-') + ' / ' + (d.control.endTime ?? '-')),
        h('span', { class: 'k' }, 'Start'), h('span', { class: 'v' }, d.meta.map_source
          ? h('span', { class: 'warm-text', title: 'Initialised from ' + d.meta.map_source }, icon('flame'), ' warm start') : 'cold'),
        h('span', { class: 'k' }, 'Solver'), h('span', { class: 'v' }, d.control.application || '-'),
        h('span', { class: 'k' }, 'CPU cores'), h('span', { class: 'v' }, d.cores.mesh === d.cores.solve ? String(d.cores.solve) : `${d.cores.mesh} mesh / ${d.cores.solve} solve`)),
      d.runtime_log.length ? h('div', { class: 'stat-sub', style: { marginTop: '10px' } }, d.runtime_log[d.runtime_log.length - 1].replace('Simulation finished: ', 'Last: ')) : null);

    const usageVal = h('div', { class: 'muted' }, h('div', { class: 'spinner' }));
    const diskCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('hdd'), 'Disk')), usageVal);
    this.loadUsage(usageVal);

    parts.push(h('div', { class: this.app.can('forces') ? 'grid cols-4' : 'grid cols-3' }, this.app.can('forces') ? resCard : null, meshCard, runCard, diskCard));

    // lineage + notes
    const children = this.app.cases.filter((c) => c.origin === this.name);
    const lineage = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('link'), 'Lineage')),
      h('div', { class: 'kv', style: { gridTemplateColumns: 'auto minmax(0, 1fr)' } },
        h('span', { class: 'k' }, 'Created from'),
        h('span', { style: { textAlign: 'right', overflowWrap: 'anywhere' } }, d.meta.origin ? this.caseLink(d.meta.origin) : h('span', { class: 'muted' }, 'unknown '),
          (() => { const a = h('a', { class: 'small', title: 'Set the origin manually' }, d.meta.origin ? ' (change)' : '(set)'); a.addEventListener('click', () => this.setOrigin()); return a; })()),
        h('span', { class: 'k' }, 'Used as origin by'),
        h('span', { style: { textAlign: 'right', overflowWrap: 'anywhere' } }, children.length ? children.map((c, i) => [i ? ', ' : '', this.caseLink(c.name)]) : h('span', { class: 'muted' }, 'none')),
        d.meta.map_source ? [h('span', { class: 'k' }, 'Initialised from'), h('span', { style: { textAlign: 'right', overflowWrap: 'anywhere' } }, this.caseLink(d.meta.map_source))] : null));
    const notesCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('log'), 'Notes')), this.notesBox(d));

    const repl = d.meta.replaced_stls || [];
    const geoCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('cube'), `Geometry (${d.stls.length} STL)`),
        (() => { const b = btn('3D view', { size: 'sm', icon: 'eye' }); b.addEventListener('click', () => this.showTab('geometry')); return b; })()),
      h('table', { class: 'tbl' }, h('tbody', null, d.stls.map((s) => {
        const rp = repl.find((x) => x.target === s.name);
        return h('tr', null, h('td', null, s.name, rp ? h('div', { class: 'muted small' }, `replaced from ${rp.source}`) : null),
          h('td', { class: 'num muted' }, fmtBytes(s.size)));
      }))),
      d.meta.transform ? h('div', { class: 'stat-sub', style: { marginTop: '8px' } }, 'Transform: ' + describeTransform(d.meta.transform)) : null);

    parts.push(h('div', { class: 'grid cols-3', style: { marginTop: '14px' } }, lineage, notesCard, geoCard));
    mount(this.pane, ...parts);
  }

  async setOrigin() {
    const sel = h('select', { class: 'input' }, h('option', { value: '' }, '— unknown —'),
      this.app.cases.map((c) => c.name).filter((n) => n !== this.name).sort().reverse().map((n) => h('option', { value: n }, n)));
    sel.value = this.data.meta.origin || '';
    const ok = await confirmDialog({ title: 'Origin of this simulation', confirmLabel: 'Save',
      message: h('div', null, h('p', { class: 'muted', style: { marginTop: 0 } }, 'Which simulation was this one copied from? Used for the lineage and as the default in Compare.'), sel) });
    if (!ok) return;
    try { await api.post('meta', { name: this.name, origin: sel.value || null }); await this.app.refresh(); this.reload(); } catch (e) { toastError(e); }
  }

  caseLink(name) {
    const a = h('a', null, name);
    a.addEventListener('click', () => this.app.select(name));
    return a;
  }

  async loadUsage(el) {
    try {
      const u = this.usage || await api.get('usage', { name: this.name });
      this.usage = u;
      const cleanBtn = btn('Clean up', { size: 'sm', icon: 'broom', disabled: !u.cleanup || this.running || this.data.queued,
        title: 'Deletes results and mesh; settings, forces, residuals and notes stay' });
      cleanBtn.addEventListener('click', () => this.clean('cleanup'));
      const rest = Math.max(0, u.total - u.cleanup);
      mount(el, h('div', null,
        h('div', { class: 'stat' }, h('div', { class: 'stat-value', style: { color: 'var(--text)' } }, fmtBytes(u.total))),
        h('div', { class: 'kv', style: { marginTop: '10px' } },
          h('span', { class: 'k', title: 'Flow fields of all time steps (and processor folders)' }, 'Results'), h('span', { class: 'v' }, fmtBytes(u.fields)),
          h('span', { class: 'k' }, 'Mesh'), h('span', { class: 'v' }, fmtBytes(u.mesh)),
          h('span', { class: 'k', title: 'Settings, STLs, forces, residuals, logs, notes - kept by Clean up' }, 'STLs, settings & forces'), h('span', { class: 'v' }, fmtBytes(rest))),
        u.cleaned && !u.cleanup ? h('div', { class: 'stat-sub', style: { marginTop: '8px' } }, 'Cleaned up ' + fmtAgo(u.cleaned) + ' - Re-run builds mesh and results again.') : null,
        h('div', { style: { marginTop: '10px' } }, cleanBtn)));
    } catch (e) { mount(el, h('span', { class: 'muted' }, '-')); }
  }
}

export function describeTransform(t) {
  if (!t) return 'none';
  const parts = [];
  const tr = t.translate || [0, 0, 0];
  if (tr.some((v) => +v)) parts.push(`translate (${tr.join(' ')})`);
  for (const r of t.rotations || []) if (+r.deg) parts.push(`rotate ${r.axis.toUpperCase()} ${r.deg}°`);
  if (t.scale && +t.scale !== 1) parts.push(`scale ×${t.scale}`);
  if (t.cut) parts.push('cut at x = 0');
  return parts.join(' → ') || 'none';
}
