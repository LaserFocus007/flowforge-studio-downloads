// "Update now": download (signed, checked), install, restart and reconnect - see app/updates.py.

import * as api from './api.js';
import { h, btn, modal, toast, store } from './ui.js';

const mb = (n) => (n / 1e6).toFixed(1);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// once after a restart: tell the user how the update went
export function updateResultNotice(info) {
  const r = info && info.update_result;
  if (!r || store('update-result-seen') === String(r.at)) return;
  store('update-result-seen', String(r.at));
  if (r.ok && r.to === info.version) toast(`Updated to version ${r.to}`, 'Your licence, settings and simulations were kept.', 'ok', 8000);
  else if (!r.ok) toast('The update was not installed', r.message || 'The previous version is still in use.', 'error', 12000);
}

// the dialog: notice of the new version, then progress until the new version is running
export function openUpdate(info, { onLater } = {}) {
  const u = info.update;
  if (!u) return null;
  const own = info.version;
  const status = h('p', { class: 'muted', style: { marginBottom: 0 } });
  const fill = h('div', { style: { height: '100%', width: '0%', background: 'var(--accent)', borderRadius: '4px', transition: 'width .3s' } });
  const bar = h('div', { style: { height: '8px', borderRadius: '4px', background: 'var(--accent-soft)', overflow: 'hidden', margin: '14px 0 4px', display: 'none' } }, fill);
  const later = btn('Later', { variant: 'ghost' });
  const go = u.installable ? btn('Update now', { variant: 'primary' })
    : h('a', { class: 'btn btn-primary', href: u.url, target: '_blank', rel: 'noopener' }, 'Download');
  const intro = u.installable
    ? `Update now downloads the new version${u.size ? ` (${mb(u.size)} MB)` : ''}, checks that it really comes from us and installs it. Flowforge Studio then restarts by itself. Your licence, settings and simulations stay as they are.`
    : 'Close Flowforge Studio, unpack the new download and start it. Your licence key, simulations and settings stay in the data folder and the simulations folder - copy the data folder over from your old installation.';
  const m = modal({
    title: `Flowforge Studio ${u.version} is available`,
    body: h('div', null,
      h('p', { style: { marginTop: 0 } }, `You are using version ${own}.`),
      u.note ? h('p', null, u.note) : null,
      h('p', { class: 'muted' }, intro),
      bar, status),
    footer: [later, go],
    onClose: () => { if (onLater) onLater(); },
  });
  later.addEventListener('click', () => m.close());
  if (!u.installable) return m;

  const say = (text, kind) => { status.textContent = text; status.className = kind === 'error' ? 'bad' : 'muted'; };
  const busy = (on) => { go.disabled = on; later.disabled = on; };

  async function install() {
    busy(true);
    say('Installing...');
    try {
      await api.post('update/install');
    } catch (e) {
      busy(false);
      go.querySelector('span').textContent = 'Install now';
      say(e.message, 'error');
      return;
    }
    // from here the app restarts: no "connection lost" banner, the window reconnects by itself
    window.__flowforgeUpdating = true;
    bar.style.display = 'none';
    say('Installing the new version. Flowforge Studio restarts by itself - please keep this window open. This takes about half a minute.');
    const t0 = Date.now();
    await sleep(3000);
    while (Date.now() - t0 < 240000) {
      try {
        const i = await api.get('info');
        if (i.version !== own) { location.reload(); return; }
        const r = i.update_result;
        if (r && !r.ok && r.at * 1000 > t0 - 5000) {
          window.__flowforgeUpdating = false;
          store('update-result-seen', String(r.at));
          busy(false);
          go.hidden = true;
          say(`The update could not be installed: ${r.message}`, 'error');
          return;
        }
      } catch (e) { /* restarting */ }
      await sleep(1500);
    }
    window.__flowforgeUpdating = false;
    say('Flowforge Studio did not come back. Please start "Flowforge Studio.bat" again.', 'error');
  }

  go.addEventListener('click', async () => {
    if (go.querySelector('span').textContent === 'Install now') { install(); return; }
    busy(true);
    bar.style.display = '';
    say('Downloading...');
    try {
      let p = await api.post('update/download');
      while (p.state === 'downloading' || p.state === 'unpacking') {
        fill.style.width = (p.total ? Math.min(100, 100 * p.done / p.total) : 0).toFixed(1) + '%';
        say(p.state === 'unpacking' ? 'Checked. Unpacking...' : `Downloading... ${mb(p.done)} of ${mb(p.total)} MB`);
        await sleep(400);
        p = await api.get('update');
      }
      if (p.state === 'error') throw new Error(p.error);
      fill.style.width = '100%';
      await install();
    } catch (e) {
      busy(false);
      bar.style.display = 'none';
      say(e.message, 'error');
    }
  });
  return m;
}
