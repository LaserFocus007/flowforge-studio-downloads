// Forces tab: balance of the car in the side view - line of action of the aerodynamic force, the
// centre of the side area and, with mass / centre of mass / thrust, the wheel loads in three cases:
// standstill, coasting (no thrust, slowing down by the drag) and under thrust.

import * as api from './api.js';
import { h, icon, btn, fmtForce, segmented, debounce, toastError } from './ui.js';

const silhouettes = new Map();   // case|stls|axes -> Promise<[{tris: Float32Array, bbox}]>

// the server projects the car onto the side plane: 2D triangles (drag, lift) and their bounding
// box [[d0, l0], [d1, l1]] - computed once per geometry and cached on disk
function loadSilhouette(name, stls, drag, lift, cachedOnly) {
  const key = [name, stls.join(','), drag, lift].join('|');
  if (silhouettes.has(key)) return silhouettes.get(key);
  const pr = api.getBinary('forces/silhouette', { name, files: stls.join(','), drag, lift, cached: cachedOnly ? 1 : null })
    .then((r) => (r.bbox ? [{ tris: new Float32Array(r.buffer), bbox: r.bbox }] : null))
    .catch(() => null);
  // only results are kept: a cache miss (cachedOnly) can be asked for again with the button
  pr.then((v) => { if (v) { silhouettes.set(key, pr); if (silhouettes.size > 12) silhouettes.delete(silhouettes.keys().next().value); } });
  return pr;
}

// side view as a bitmap of 0.2 mm, filled in plain JS: a canvas path with this many triangles blocks
// the browser for many seconds (the bitmap takes milliseconds and is kept with the silhouette).
// Also gives the centre of the side area (rule-of-thumb centre of pressure for side wind).
function sideRaster(sil) {
  if (!sil || !sil.length) return null;
  if (sil.raster) return sil.raster;
  let d0 = Infinity, l0 = Infinity, d1 = -Infinity, l1 = -Infinity;
  for (const p of sil) { d0 = Math.min(d0, p.bbox[0][0]); l0 = Math.min(l0, p.bbox[0][1]); d1 = Math.max(d1, p.bbox[1][0]); l1 = Math.max(l1, p.bbox[1][1]); }
  const RES = Math.max(0.0002, Math.max(d1 - d0, l1 - l0) / 2000);   // full-size cars: coarser
  const w = Math.ceil((d1 - d0) / RES) + 2, hh = Math.ceil((l1 - l0) / RES) + 2;
  if (!(w > 2 && hh > 2)) return null;
  const filled = new Uint8Array(w * hh);
  let xa = 0, xb = 0;
  const cross = (px, py, qx, qy, yc) => {
    if ((py <= yc) === (qy <= yc)) return;
    const x = px + (yc - py) / (qy - py) * (qx - px);
    if (x < xa) xa = x;
    if (x > xb) xb = x;
  };
  for (const p of sil) {
    const t = p.tris;
    for (let i = 0; i < t.length; i += 6) {
      const ax = (t[i] - d0) / RES + 1, ay = (l1 - t[i + 1]) / RES + 1, bx = (t[i + 2] - d0) / RES + 1, by = (l1 - t[i + 3]) / RES + 1;
      const cx = (t[i + 4] - d0) / RES + 1, cy = (l1 - t[i + 5]) / RES + 1;
      const y0 = Math.max(0, Math.ceil(Math.min(ay, by, cy) - 0.5)), y1 = Math.min(hh - 1, Math.floor(Math.max(ay, by, cy) - 0.5));
      for (let y = y0; y <= y1; y++) {
        const yc = y + 0.5;
        xa = Infinity; xb = -Infinity;
        cross(ax, ay, bx, by, yc); cross(bx, by, cx, cy, yc); cross(cx, cy, ax, ay, yc);
        const from = Math.max(0, Math.ceil(xa - 0.5)), to = Math.min(w - 1, Math.floor(xb - 0.5));
        for (let x = from, o = y * w + from; x <= to; x++, o++) filled[o] = 1;
      }
    }
  }
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = hh;
  const c = canvas.getContext('2d');
  const img = c.createImageData(w, hh);
  let n = 0, sx = 0, sy = 0;
  for (let y = 0, o = 0; y < hh; y++) {
    for (let x = 0; x < w; x++, o++) {
      if (filled[o]) { n++; sx += x; sy += y; img.data[4 * o + 3] = 255; }
    }
  }
  if (!n) return null;
  c.putImageData(img, 0, 0);
  const cop = { d: d0 + (sx / n + 0.5 - 1) * RES, l: l1 - (sy / n + 0.5 - 1) * RES, area: n * RES * RES };
  sil.raster = { canvas, w, h: hh, left: d0 - RES, top: l1 + RES, res: RES, cop };
  return sil.raster;
}

const css = (v, fb) => getComputedStyle(document.documentElement).getPropertyValue(v).trim() || fb;
const mm = (v) => (v * 1000).toFixed(1);
const G = 9.81;

const CASES = [
  { id: 'stand', label: 'Standstill', tip: 'The car standing on the track with a full cartridge: weight only (air forces if a speed is entered, no acceleration).' },
  { id: 'coast', label: 'Coasting', tip: 'No thrust: the car slows down by its drag.' },
  { id: 'thrust', label: 'Under thrust', tip: 'The cartridge pushes: thrust, air forces and the acceleration.' },
];
// car data: [key, label, unit, hint] - the same in every case
const CAR_FIELDS = [
  ['mass_g', 'Mass', 'g', 'Mass of the car without the CO2 cartridge.'],
  ['com_mm', 'CoM behind nose', 'mm', 'Centre of mass of the car without the cartridge: distance behind the nose.'],
  ['com_h_mm', 'CoM height', 'mm', 'Centre of mass of the car without the cartridge: height above the ground.'],
];
// per case: one value per property
const CASE_FIELDS = [
  ['cartridge_g', 'Cartridge', 'g', 'Mass of the CO2 cartridge in this case. It sits in the CO2 chamber and moves the centre of mass.', null],
  ['speed', 'Speed', 'm/s', 'Speed for the air forces (they grow with the square of the speed). Empty = simulation speed.', null],
  ['thrust_n', 'Thrust', 'N', 'Thrust of the CO2 cartridge.', 'thrust'],
  ['thrust_h_mm', 'Thrust height', 'mm', 'Height of the thrust line above the ground. Empty = axis of the CO2 chamber.', 'thrust'],
  ['thrust_deg', 'Thrust angle', '°', 'Angle of the thrust to the ground: + = points upwards (lifts the tail), − = downwards. Empty = 0°.', 'thrust'],
];
const DEFAULT_CAR = { mass_g: 48.5 };
const DEFAULT_CASES = { stand: { cartridge_g: 20, speed: 0 }, coast: { cartridge_g: 12, speed: 20 }, thrust: { cartridge_g: 17, speed: 5, thrust_n: 8 } };
let viewMode = 'thrust';           // chosen case, kept while switching simulations

// stored car data -> {car values, cases: {aero, coast, thrust}}; older flat entries are converted
function vehicleFrom(v) {
  v = v || {};
  const out = Object.assign({}, DEFAULT_CAR, { cases: JSON.parse(JSON.stringify(DEFAULT_CASES)) });
  for (const [k] of CAR_FIELDS) if (v[k] != null) out[k] = v[k];
  const legacy = {
    stand: { cartridge_g: v.cartridge_g },
    coast: { cartridge_g: v.cartridge_empty_g, speed: v.speed },
    thrust: { cartridge_g: v.cartridge_thrust_g, speed: v.speed_thrust, thrust_n: v.thrust_n, thrust_h_mm: v.thrust_h_mm },
  };
  for (const c of CASES) {
    const src = Object.assign({}, legacy[c.id], (v.cases || {})[c.id] || {});
    for (const [k, val] of Object.entries(src)) if (val != null) out.cases[c.id][k] = val;
  }
  return out;
}

export class CopPanel {
  constructor(tab) {
    this.tab = tab;
    const f = tab.f, g = f.cop_geometry;
    this.veh = vehicleFrom(g.vehicle);
    this.vehSource = g.vehicle_source;
    this.el = h('div', { class: 'card cop-card' });
    this.canvas = h('canvas', { class: 'cop-canvas' });
    this.aero();
    this.build();
    // redraw only when the width changes (the height follows from it - avoids a resize loop)
    this.ro = new ResizeObserver(() => { if (this.canvas.clientWidth !== this.drawnW) this.draw(); });
    this.ro.observe(this.canvas);
    // the side view is shown right away when the server has it in its cache; a new geometry takes
    // the server a few seconds, so it is only made when asked for (button in the card)
    this.silArgs = [tab.ctx.name, g.stls, f.drag_axis, f.lift_axis];
    loadSilhouette(...this.silArgs, true).then((sil) => { if (sil) this.gotSilhouette(sil); else this.showLoadButton(); });
    this.save = debounce(() => this.saveVehicle(), 700);
  }

  destroy() { if (this.ro) this.ro.disconnect(); }

  gotSilhouette(sil) {
    this.sil = sil;
    this.raster = sideRaster(sil);
    this.cop = this.raster ? this.raster.cop : null;
    this.silBar.replaceChildren();
    this.update();
  }

  showLoadButton() {
    const b = btn('Load side view', { size: 'sm', icon: 'download' });
    b.addEventListener('click', async () => {
      b.disabled = true;
      b.lastChild.textContent = 'Loading …';
      const sil = await loadSilhouette(...this.silArgs, false);
      if (sil && sil.length) this.gotSilhouette(sil);
      else { b.disabled = false; b.lastChild.textContent = 'Load side view'; toastError(new Error('The side view could not be made.')); }
    });
    this.silBar.replaceChildren(b, h('div', { class: 'muted small' },
      'Needed for the wheel loads and the centre of pressure. Takes a few seconds once per geometry, then it is stored.'));
    this.update();
  }

  // ---------------------------------------------------------------- aerodynamics (averaging window)
  aero() {
    const tab = this.tab, f = tab.f, g = f.cop_geometry;
    const ground = g.ground || 0;
    const D = f.drag.total, L = f.lift.total, P = f.pitch.total;
    // moment about the point on the ground below the origin
    const Pg = P.map((p, i) => p + ground * D[i]);
    const wh = g.wheels.slice().sort((a, b) => (a.d - b.d) * g.flow_sign);
    const a = { ground, wheels: wh, D: tab.stats(D), L: tab.stats(L), Pg: tab.stats(Pg) };
    if (wh.length >= 2) {
      const front = wh[0], rear = wh[wh.length - 1], span = front.d - rear.d;
      // vertical aerodynamic force per axle (+ = lifts it): lift plus the pitching moment of the drag
      a.front = tab.stats(Pg.map((p, i) => (p - rear.d * L[i]) / span));
      a.rear = tab.stats(Pg.map((p, i) => (front.d * L[i] - p) / span));
    }
    this.a = a;
  }

  extent() {
    const s = this.sil;
    if (!s || !s.length) return null;
    let mn = Infinity, mx = -Infinity;
    for (const p of s) { mn = Math.min(mn, p.bbox[0][0]); mx = Math.max(mx, p.bbox[1][0]); }
    const fs = this.tab.f.cop_geometry.flow_sign >= 0 ? 1 : -1;
    return { nose: fs > 0 ? mn : mx, tail: fs > 0 ? mx : mn, len: mx - mn };
  }

  // ---------------------------------------------------------------- car balance
  // Wheel loads from the equilibrium of forces and pitching moments (d'Alembert: the acceleration
  // acts as an inertial force at the centre of mass). Ground forces act at ground level; the
  // tether line and rolling resistance are left out.
  balance() {
    const a = this.a, g = this.tab.f.cop_geometry, v = this.veh, fs = g.flow_sign >= 0 ? 1 : -1;
    const ex = this.extent();
    if (!a.front || !ex || !(v.mass_g > 0) || v.com_mm == null || v.com_h_mm == null) return null;
    const nose = ex.nose;
    const mc = v.mass_g / 1000, dc = nose + fs * v.com_mm / 1000, hc = v.com_h_mm / 1000;
    const autoH = g.thrust_l != null ? g.thrust_l - a.ground : hc;
    const dk = g.cartridge_d != null ? g.cartridge_d : dc;      // the cartridge sits in the CO2 chamber
    const dT = g.thrust_d != null ? g.thrust_d : ex.tail;       // nozzle at the rear end of the chamber
    const df = a.wheels[0].d, dr = a.wheels[a.wheels.length - 1].d;
    const vs = g.speed || 0;
    const solve = (id) => {
      const p = v.cases[id];
      const thrust = id === 'thrust' ? (p.thrust_n || 0) : 0;
      const hT = id === 'thrust' && p.thrust_h_mm != null ? p.thrust_h_mm / 1000 : autoH;
      const ang = (id === 'thrust' ? (p.thrust_deg || 0) : 0) * Math.PI / 180;
      // car plus cartridge
      const mk = (p.cartridge_g || 0) / 1000, m = mc + mk, W = m * G;
      const dG = (mc * dc + mk * dk) / m, hG = (mc * hc + mk * autoH) / m;
      // air forces scale with the square of the speed (simulated at vs)
      const speed = p.speed != null ? p.speed : vs, k = vs ? (speed / vs) ** 2 : 1;
      const Fd = k * a.D.mean, Fl = k * a.L.mean, Pg = k * a.Pg.mean;
      // thrust along the car (forward) and upwards, acting at the nozzle (dT, hT)
      const Tx = thrust * Math.cos(ang), Tz = thrust * Math.sin(ang);
      const MT = dT * Tz + fs * Tx * hT;                    // its pitching moment about the ground origin
      // standstill: no acceleration (a drag would be held at the ground); otherwise inertial force = -m a
      const Id = id === 'stand' ? 0 : fs * Tx - Fd;
      const Q = -(Pg - W * dG + MT - hG * Id);
      const Nv = W - Fl - Tz;                               // what the wheels carry together
      const Nf = (Q - dr * Nv) / (df - dr);
      // the same car standing still (reference for the percentages)
      const N0f = W * (dG - dr) / (df - dr);
      const airF = k * a.front.mean, airR = k * a.rear.mean;
      return { id, Nf, Nr: Nv - Nf, N0f, N0r: W - N0f, airF, airR, acc: id === 'stand' ? 0 : (Tx - fs * Fd) / m,
        T: thrust, Tx, Tz, ang, hT, dT, Fd, Fl, k, speed, m, W, dG, hG, cart: p.cartridge_g || 0 };
    };
    const out = { nose, len: ex.len, fs };
    for (const c of CASES) out[c.id] = solve(c.id);
    return out;
  }

  // ---------------------------------------------------------------- layout
  build() {
    this.carBox = h('div', { class: 'cop-group' });
    this.caseBox = h('div', { class: 'cop-group' });
    this.srcNote = h('div', { class: 'muted small' });
    this.silBar = h('div', { class: 'cop-silbar' });
    this.copNote = h('div', { class: 'cop-sum' });
    this.table = h('div', { class: 'cop-table' });
    this.modeSeg = segmented(CASES.map((c) => ({ label: c.label, value: c.id, title: c.tip })), viewMode, (val) => this.setMode(val));
    this.fillCar();
    this.fillCase();
    this.el.append(
      h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('target'), 'Balance & centre of pressure'), this.modeSeg),
      h('div', { class: 'cop-body' },
        h('div', { class: 'cop-side' }, this.carBox, this.caseBox, this.srcNote),
        h('div', { class: 'cop-main' }, this.silBar, this.canvas, this.copNote)),
      this.table,
      h('div', { class: 'muted small', style: { marginTop: '8px' } },
        'Dashed line: line of action of the air force (drag + lift), mean over the same averaging window as above. Diamond: centre of the side area (CoP for side wind). '
        + 'Wheel loads from the balance of forces and pitching moments; the acceleration acts as an inertial force at the centre of mass. '
        + 'Ground forces at ground level; tether line and rolling resistance are left out.'));
    this.update();
  }

  setMode(id) {
    viewMode = id;
    this.modeSeg.set(id);
    this.fillCase();
    this.update();
  }

  field([key, label, unit, hint], obj, placeholder) {
    const inp = h('input', { class: 'input', type: 'number', step: 'any', value: obj[key] != null ? obj[key] : '', placeholder: placeholder || '' });
    inp.addEventListener('input', () => {
      const x = parseFloat(inp.value);
      obj[key] = inp.value === '' || !isFinite(x) ? null : x;
      this.vehSource = 'this';
      if (!this.pending) this.pending = requestAnimationFrame(() => { this.pending = 0; this.update(); });
      this.save();
    });
    return h('label', { class: 'cop-in', title: hint }, h('span', null, label), inp, h('span', { class: 'unit' }, unit));
  }

  fillCar() {
    this.carBox.replaceChildren(h('div', { class: 'cop-gtitle' }, 'Car', h('small', null, 'without cartridge · all cases')),
      ...CAR_FIELDS.map((f) => this.field(f, this.veh)));
  }

  fillCase() {
    const g = this.tab.f.cop_geometry, c = CASES.find((x) => x.id === viewMode);
    const obj = this.veh.cases[viewMode];
    const ph = { speed: g.speed ? `${+g.speed.toFixed(1)} sim` : '', thrust_h_mm: g.thrust_l != null ? `${mm(g.thrust_l - (g.ground || 0))} CO2` : '', thrust_deg: '0' };
    this.caseBox.replaceChildren(h('div', { class: 'cop-gtitle' }, c.label, h('small', null, 'stored per case')),
      ...CASE_FIELDS.filter((f) => !f[4] || f[4] === viewMode).map((f) => this.field(f, obj, ph[f[0]])));
  }

  update() {
    this.b = this.balance();
    const src = { origin: 'Car data taken from the origin simulation - change a value to store it for this one.',
      default: 'Car data: the last values you entered - change a value to store it for this simulation.' }[this.vehSource] || '';
    this.srcNote.textContent = src;
    this.fillCop();
    this.fillTable();
    this.draw();
  }

  // side-area centre of pressure against the centre of mass: behind it = the car turns back into
  // the wind like an arrow (stable), in front of it = it turns further away
  margin(st) {
    const b = this.b;
    return b && this.cop ? b.fs * (this.cop.d - st.dG) : null;
  }

  fillCop() {
    const cp = this.cop, b = this.b, ex = this.extent();
    if (!cp || !ex) { this.copNote.replaceChildren(); return; }
    const parts = [h('span', { class: 'cop-dia' }), h('b', null, 'Centre of pressure (side area) '),
      `${mm(Math.abs(cp.d - ex.nose))} mm behind the nose · ${mm(cp.l - this.a.ground)} mm high`];
    if (b) {
      const mg = this.margin(b[viewMode]), ok = mg > 0;
      parts.push(h('span', { class: 'cop-pill ' + (ok ? 'ok' : 'bad') },
        `${mm(Math.abs(mg))} mm ${ok ? 'behind' : 'in front of'} the CoM · ${ok ? 'stable' : 'unstable'} in side wind`));
    }
    parts.push(h('span', { class: 'muted small cop-approx' }, 'Approximation: centre of the side area, not from the CFD - '
      + 'it assumes the same side force on every part of the side. A run at an angle to the flow gives the real point.'));
    this.copNote.replaceChildren(h('div', { title: 'Centre of the side view area of the car (rule of thumb for where a side force acts). '
      + 'It assumes the same side force on every square millimetre - a CFD run at an angle to the flow would give the real point.' }, ...parts));
  }

  fillTable() {
    const b = this.b;
    if (!b) {
      this.table.replaceChildren(h('div', { class: 'muted small cop-hint' },
        !this.a.front ? 'No wheel axles found (rotating wheels in 0.org/U) - wheel loads cannot be calculated.'
          : !this.sil ? 'Load the side view to see the wheel loads.'
            : 'Enter the mass and the centre of mass of the car to see the wheel loads.'));
      return;
    }
    const sgn = (x) => (x >= 0 ? '+' : '−') + fmtForce(Math.abs(x));
    const load = (N, N0) => {
      const off = N <= 0, pct = 100 * N / N0;
      return h('div', { class: 'r num ' + (off ? 'bad' : pct < 25 ? 'warn' : '') }, h('b', null, fmtForce(N) + ' N'),
        h('small', null, off ? 'lifts off' : `${pct.toFixed(0)} % of standing`));
    };
    const rows = [
      ['Front wheels', (s) => load(s.Nf, s.N0f), 'Load on the front wheels (ground force).'],
      ['Rear wheels', (s) => load(s.Nr, s.N0r), 'Load on the rear wheels (ground force).'],
      ['Air on the axles', (s) => h('div', { class: 'r num muted' }, `${sgn(s.airF)} / ${sgn(s.airR)} N`),
        'Vertical air force front / rear at this speed (+ = lifts): the lift plus the pitching moment of the drag.'],
      ['Speed · acceleration', (s) => h('div', { class: 'r num muted' }, `${+s.speed.toFixed(1)} m/s · ${s.acc ? (s.acc / G).toFixed(2) + ' g' : '–'}`)],
      ['Mass', (s) => h('div', { class: 'r num muted' }, `${(s.m * 1000).toFixed(1)} g (cartridge ${s.cart} g)`)],
      ['Centre of mass', (s) => h('div', { class: 'r num muted' }, `${mm(Math.abs(s.dG - b.nose))} mm behind nose · ${mm(s.hG)} mm high`)],
    ];
    if (this.cop) {
      rows.push(['CoP to CoM', (s) => {
        const mg = this.margin(s), ok = mg > 0;
        return h('div', { class: 'r num ' + (ok ? 'good' : 'bad') }, h('b', null, `${mm(Math.abs(mg))} mm ${ok ? 'behind' : 'in front'}`),
          h('small', null, `${(100 * Math.abs(mg) / b.len).toFixed(1)} % of the length`));
      }, 'Distance of the centre of the side area behind the centre of mass: behind = stable in side wind.']);
    }
    const grid = h('div', { class: 'cop-grid', style: { gridTemplateColumns: `170px repeat(${CASES.length}, minmax(150px, 1fr))` } });
    grid.append(h('div', { class: 'hdr' }));
    for (const c of CASES) {
      const s = b[c.id];
      const t = c.id === 'thrust' ? `${c.label} · ${s.T} N${s.ang ? ` at ${+(s.ang * 180 / Math.PI).toFixed(1)}°` : ''}` : c.label;
      const hd = h('div', { class: 'r hdr' + (c.id === viewMode ? ' active' : ''), title: c.tip + ' Click to show it in the view.' }, t);
      hd.addEventListener('click', () => this.setMode(c.id));
      grid.append(hd);
    }
    for (const [label, fn, tip] of rows) {
      grid.append(h('div', { class: 'lbl', title: tip || null }, label));
      for (const c of CASES) {
        const cell = fn(b[c.id]);
        if (c.id === viewMode) cell.classList.add('active');
        grid.append(cell);
      }
    }
    const note = this.tab.f.cop_geometry.cartridge_d == null
      ? h('div', { class: 'muted small cop-hint' }, 'No CO2 chamber found - the cartridge is assumed at the centre of mass of the car.') : null;
    this.table.replaceChildren(...[note, grid].filter(Boolean));
  }

  async saveVehicle() {
    const v = { cases: {} };
    for (const [k] of CAR_FIELDS) v[k] = this.veh[k] != null ? this.veh[k] : null;
    for (const c of CASES) {
      v.cases[c.id] = {};
      for (const [k] of CASE_FIELDS) v.cases[c.id][k] = this.veh.cases[c.id][k] != null ? this.veh.cases[c.id][k] : null;
    }
    try {
      await api.post('meta', { name: this.tab.ctx.name, vehicle: v });
      this.tab.f.cop_geometry.vehicle = v;
      this.tab.f.cop_geometry.vehicle_source = 'this';
    } catch (e) { toastError(e); }
  }

  // ---------------------------------------------------------------- drawing
  draw() {
    const cv = this.canvas, a = this.a, b = this.b, g = this.tab.f.cop_geometry;
    const W = cv.clientWidth;
    if (!W) return;
    this.drawnW = W;
    const sil = this.sil || [];
    // world box: car (or wheels) plus room for the arrows
    let d0 = Infinity, d1 = -Infinity, l1 = -Infinity;
    for (const p of sil) { d0 = Math.min(d0, p.bbox[0][0]); d1 = Math.max(d1, p.bbox[1][0]); l1 = Math.max(l1, p.bbox[1][1]); }
    if (!isFinite(d0)) { for (const w of a.wheels) { d0 = Math.min(d0, w.d - 0.03); d1 = Math.max(d1, w.d + 0.03); l1 = Math.max(l1, w.l * 2); } }
    if (!isFinite(d0)) { d0 = -0.1; d1 = 0.1; l1 = 0.05; }
    const len = d1 - d0, padD = len * 0.12, top = Math.max(l1 - a.ground, len * 0.12) + len * 0.14;
    const BOT = 110, MAXH = 380;                 // pixels below the ground: wheel load arrows and labels
    const s = Math.min((W - 2) / (len + 2 * padD), (MAXH - BOT) / top);
    const H = Math.round(top * s + BOT);
    const ox = (W - (len + 2 * padD) * s) / 2;     // centred when the height limit applies
    const dpr = window.devicePixelRatio || 1;
    if (cv.style.height !== H + 'px') cv.style.height = H + 'px';
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    const c = cv.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, W, H);
    const flip = g.flow_sign >= 0 ? 1 : -1;
    const X = (d) => ox + (flip > 0 ? (d - d0 + padD) : (d1 + padD - d)) * s;
    const Y = (l) => (top - (l - a.ground)) * s;
    const muted = css('--muted', '#8d8d97');

    // ground and directions
    c.strokeStyle = muted; c.lineWidth = 1;
    c.beginPath(); c.moveTo(0, Y(a.ground) + 0.5); c.lineTo(W, Y(a.ground) + 0.5); c.stroke();
    c.font = '400 11px system-ui, sans-serif'; c.fillStyle = muted;
    c.fillText('← driving direction · air flow →', 6, 14);

    // silhouette: the bitmap, scaled and coloured once per size
    const sk = [W, H, dpr, this.raster ? 1 : 0, css('--border-strong', '')].join('|');
    if (this.silKey !== sk) {
      this.silKey = sk;
      this.silImg = document.createElement('canvas');
      this.silImg.width = cv.width; this.silImg.height = cv.height;
      if (this.raster) {
        const sc = this.silImg.getContext('2d'), r = this.raster;
        sc.setTransform(dpr, 0, 0, dpr, 0, 0);
        sc.translate(X(r.left), Y(r.top));
        sc.scale((X(r.left + r.w * r.res) - X(r.left)) / r.w, (Y(r.top - r.h * r.res) - Y(r.top)) / r.h);
        sc.drawImage(r.canvas, 0, 0);
        sc.setTransform(1, 0, 0, 1, 0, 0);
        sc.globalCompositeOperation = 'source-in';
        sc.fillStyle = css('--border-strong', '#3a3a42');
        sc.fillRect(0, 0, cv.width, cv.height);
      }
    }
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(this.silImg, 0, 0); c.restore();
    this.drawOverlay(c, { H, X, Y, s, padD, d0, d1, flip, a, st: b ? b[viewMode] : null });
  }

  drawOverlay(c, { H, X, Y, s, padD, d0, d1, flip, a, st }) {
    const BOT = H - Y(a.ground);
    const muted = css('--muted', '#8d8d97'), text = css('--text', '#e5e7eb'), accent = css('--accent', '#ff7a1a');
    const blue = css('--st-stopped', '#6ea8ff'), red = css('--st-error', '#ff6b6b'), green = css('--ok', '#4ade80');
    const label = (t, x, y, col, align = 'center') => {
      c.font = '600 11.5px system-ui, sans-serif'; c.fillStyle = col;
      const w = c.measureText(t).width;
      c.fillText(t, align === 'center' ? x - w / 2 : align === 'right' ? x - w : x, y);
    };
    const arrow = (x1, y1, x2, y2, col, w, dash) => {
      const an = Math.atan2(y2 - y1, x2 - x1), hl = 8;
      c.strokeStyle = col; c.fillStyle = col; c.lineWidth = w;
      if (dash) c.setLineDash([4, 3]);
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2 - Math.cos(an) * hl * 0.6, y2 - Math.sin(an) * hl * 0.6); c.stroke();
      c.setLineDash([]);
      c.beginPath(); c.moveTo(x2, y2);
      c.lineTo(x2 - hl * Math.cos(an - 0.4), y2 - hl * Math.sin(an - 0.4));
      c.lineTo(x2 - hl * Math.cos(an + 0.4), y2 - hl * Math.sin(an + 0.4)); c.closePath(); c.fill();
    };

    // wheel axles
    c.strokeStyle = text; c.lineWidth = 1.2;
    for (const w of a.wheels) {
      const x = X(w.d), y = Y(w.l);
      c.beginPath(); c.moveTo(x - 4, y); c.lineTo(x + 4, y); c.moveTo(x, y - 4); c.lineTo(x, y + 4); c.stroke();
    }

    // arrow length grows with the square root of the force (thrust and weight differ 20x)
    const k = st ? st.k : 1;
    const Dm = k * a.D.mean, Lm = k * a.L.mean, Pm = k * (a.Pg.mean - a.ground * a.D.mean);
    const fmax = Math.max(Math.hypot(Dm, Lm), st ? st.W : 0, st ? st.T : 0, st ? Math.abs(st.Nf) : 0, st ? Math.abs(st.Nr) : 0,
      !st && a.front ? Math.abs(a.front.mean) : 0, 1e-9);
    const LEN = Math.min(90, BOT - 25);
    const alen = (F) => 12 + (LEN - 12) * Math.sqrt(Math.abs(F) / fmax);

    // air force: line of action r_lift = (r_drag * F_lift - pitch) / F_drag; the resultant ends at the nose
    if (Dm) {                                     // no air force at standstill
      const lineL = (d) => (d * Lm - Pm) / Dm;
      const dl = d0 - padD, dr = d1 + padD;
      c.strokeStyle = accent; c.lineWidth = 2; c.setLineDash([7, 5]);
      c.beginPath(); c.moveTo(X(dl), Y(lineL(dl))); c.lineTo(X(dr), Y(lineL(dr))); c.stroke();
      c.setLineDash([]);
      const fl = Math.hypot(Dm, Lm) || 1, A = alen(fl);
      const dN = flip > 0 ? d0 : d1;
      const x1 = X(dN), y1 = Y(lineL(dN)), x0 = x1 - (Dm / fl) * flip * A, y0 = y1 + (Lm / fl) * A;
      arrow(x0, y0, x1, y1, accent, 2.5);
      label(`air ${fmtForce(fl)} N`, x0, y0 - 8, accent, 'left');
    }

    if (st) {
      const xg = X(st.dG), yg = Y(a.ground + st.hG);
      if (st.T > 0) {
        // thrust from the nozzle, pointing forward (and up / down by its angle)
        const xt = X(st.dT), yT = Y(a.ground + st.hT), L2 = alen(st.T);
        c.strokeStyle = green; c.lineWidth = 1; c.setLineDash([2, 3]);
        c.beginPath(); c.moveTo(xt + 30 * Math.cos(st.ang), yT + 30 * Math.sin(st.ang));
        c.lineTo(xt - 2 * L2 * Math.cos(st.ang), yT - 2 * L2 * Math.sin(st.ang)); c.stroke(); c.setLineDash([]);
        arrow(xt, yT, xt - L2 * Math.cos(st.ang), yT - L2 * Math.sin(st.ang), green, 3);
        label(`thrust ${st.T} N`, xt - L2 / 2, yT - 9 - L2 * Math.sin(st.ang) / 2, green);
      }
      // weight and inertial force at the centre of mass
      arrow(xg, yg, xg, yg + alen(st.W), text, 2);
      label(`weight ${fmtForce(st.W)} N`, xg + 6, yg + alen(st.W) + 12, text, 'left');
      if (Math.abs(st.acc) > 1e-6) {
        const dir = st.acc >= 0 ? 1 : -1;          // +1 = accelerating forward -> inertial force backwards (downstream)
        const F = st.m * Math.abs(st.acc);
        arrow(xg, yg, xg + dir * alen(F), yg, muted, 2, true);
        label(`inertia ${fmtForce(F)} N`, xg + dir * alen(F) / 2, yg - 9, muted);
      }
      this.comMarker(c, xg, yg, text);
      // wheel loads (ground pushes up; red = the wheels lift off)
      for (const [w, N] of [[a.wheels[0], st.Nf], [a.wheels[a.wheels.length - 1], st.Nr]]) {
        const x = X(w.d), yG = Y(a.ground), col = N > 0 ? blue : red;
        if (N > 0) arrow(x, yG + alen(N), x, yG, col, 2.5); else arrow(x, yG, x, yG + alen(N), col, 2.5);
        label((N > 0 ? '' : '−') + fmtForce(Math.abs(N)) + ' N' + (N > 0 ? '' : ' · lifts off'), x, yG + alen(N) + 14, col);
      }
    } else if (a.front) {
      // no car data yet: only the air load per axle (+ = lifts)
      for (const [w, sx] of [[a.wheels[0], a.front], [a.wheels[a.wheels.length - 1], a.rear]]) {
        const x = X(w.d), yG = Y(a.ground), L2 = alen(sx.mean);
        if (sx.mean >= 0) arrow(x, yG, x, yG - L2, blue, 2); else arrow(x, yG - L2, x, yG, blue, 2);
        label((sx.mean >= 0 ? '+' : '−') + fmtForce(Math.abs(sx.mean)) + ' N', x, yG + 15, blue);
      }
    }
    // centre of the side area: diamond
    if (this.cop) {
      const x = X(this.cop.d), y = Y(this.cop.l), col = css('--st-queued', '#b9a2ff');
      c.fillStyle = col; c.strokeStyle = css('--panel', '#16161a'); c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(x, y - 7); c.lineTo(x + 7, y); c.lineTo(x, y + 7); c.lineTo(x - 7, y); c.closePath(); c.fill(); c.stroke();
      label('CoP', x, y - 11, col);
    }
  }

  comMarker(c, xg, yg, text) {
    c.fillStyle = css('--panel', '#16161a'); c.strokeStyle = text; c.lineWidth = 1.5;
    c.beginPath(); c.arc(xg, yg, 6, 0, 2 * Math.PI); c.fill(); c.stroke();
    c.fillStyle = text;
    c.beginPath(); c.moveTo(xg, yg); c.arc(xg, yg, 6, -Math.PI / 2, 0); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(xg, yg); c.arc(xg, yg, 6, Math.PI / 2, Math.PI); c.closePath(); c.fill();
  }
}
