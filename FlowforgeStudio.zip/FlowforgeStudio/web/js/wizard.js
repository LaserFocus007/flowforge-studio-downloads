// "New simulation" wizard: origin -> name -> geometry (swap STLs) -> orientation -> create.

import * as api from './api.js';
import { h, mount, clear, icon, btn, toast, toastError, modal, fmtBytes, fmtInt, fmtForce, splitName,
  statusPill, switchEl, segmented, debounce, confirmDialog } from './ui.js';
import { Viewer3D, specMatrix, transformBBox, PART_COLORS } from './viewer3d.js';
import { describeTransform } from './detail.js';
import { wheelTable } from './wheelsui.js';

const STEPS = [
  ['origin', 'Origin'],
  ['name', 'Name & notes'],
  ['geometry', 'Geometry'],
  ['orient', 'Orientation'],
  ['create', 'Create'],
];

function today() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

export function openWizard(app, preOrigin) {
  const W = {
    step: 0,
    origin: preOrigin && app.byName(preOrigin) ? preOrigin : null,
    name: '', nameError: null, nameOk: false, notes: '', warm: false, warmSource: null,
    staging: null, originData: null,
    uploads: new Map(),          // stagedName -> {name,size,triangles,bbox,progress,error,uploading}
    repl: new Map(),             // target -> stagedName
    transform: { translate: [0, 0, 0], rotations: [], scale: 0.001, cut: true },
    showOrigin: true, showReplaced: true,
    viewer: null, created: null, creating: false,
  };

  const stepsEl = h('div', { class: 'wiz-steps' });
  const contentEl = h('div', { class: 'wiz-content' });
  const footEl = h('div', { class: 'modal-foot' });
  const m = modal({
    title: 'New simulation', size: 'wide',
    body: h('div', { class: 'wiz' }, stepsEl, h('div', { class: 'wiz-main' }, contentEl, footEl)),
    onClose: () => {
      if (W.viewer) { W.viewer.destroy(); W.viewer = null; }
      if (W.staging && !W.created) api.post('wizard/discard', { id: W.staging }).catch(() => {});
    },
  });
  m.body.style.padding = '0';
  m.body.style.overflow = 'hidden';

  api.post('wizard/start').then((r) => { W.staging = r.id; }).catch((e) => toastError(e));

  const hasRepl = () => W.repl.size > 0;
  const visibleSteps = () => STEPS.map((s, i) => ({ id: s[0], label: s[1], i, skip: s[0] === 'orient' && !hasRepl() }));

  function go(i) {
    if (W.viewer && STEPS[i][0] !== 'orient') { W.viewer.destroy(); W.viewer = null; }
    W.step = i;
    render();
  }
  function next() {
    let i = W.step + 1;
    if (STEPS[i] && STEPS[i][0] === 'orient' && !hasRepl()) i++;
    go(i);
  }
  function back() {
    let i = W.step - 1;
    if (STEPS[i] && STEPS[i][0] === 'orient' && !hasRepl()) i--;
    go(Math.max(0, i));
  }

  function render() {
    clear(stepsEl);
    for (const s of visibleSteps()) {
      const cls = s.i === W.step ? 'active' : s.i < W.step ? 'done' : '';
      const el = h('div', { class: `wiz-step ${cls}${s.skip ? ' skip' : ''}` },
        h('span', { class: 'num' }, s.i < W.step && !s.skip ? icon('check') : String(s.i + 1)), s.label);
      if (s.i < W.step && !W.created && !s.skip) el.addEventListener('click', () => go(s.i));
      stepsEl.appendChild(el);
    }
    const id = STEPS[W.step][0];
    contentEl.style.overflow = '';
    ({ origin: renderOrigin, name: renderName, geometry: renderGeometry, orient: renderOrient, create: renderCreate })[id]();
  }

  function footer(nextLabel, nextEnabled, onNext) {
    const cancel = btn('Cancel', { variant: 'ghost' });
    cancel.addEventListener('click', () => m.close());
    const backBtn = btn('Back', { icon: 'chevRight', cls: 'flip' });
    backBtn.querySelector('svg').style.transform = 'rotate(180deg)';
    backBtn.addEventListener('click', back);
    const nx = btn(nextLabel, { variant: 'primary', disabled: !nextEnabled });
    nx.addEventListener('click', onNext || next);
    mount(footEl, cancel, h('span', { class: 'grow' }), W.step > 0 ? backBtn : null, nx);
    return nx;
  }

  // ---------------------------------------------------------------- step 1: origin
  function renderOrigin() {
    const search = h('input', { class: 'input', placeholder: 'Filter...', style: { maxWidth: '320px' } });
    const grid = h('div', { class: 'origin-grid' });
    const draw = () => {
      clear(grid);
      const q = search.value.toLowerCase();
      const list = app.cases.slice().sort((a, b) => b.name.localeCompare(a.name)).filter((c) => !q || c.name.toLowerCase().includes(q));
      for (const c of list) {
        const { date, rest } = splitName(c.name);
        const card = h('div', { class: 'origin-card' + (W.origin === c.name ? ' selected' : '') },
          h('div', { class: 'nm' }, rest),
          h('div', { class: 'sub' }, statusPill(c.status), date ? h('span', null, date) : null,
            c.results && c.results.drag != null ? h('span', null, `drag ${fmtForce(c.results.drag)} N`) : null));
        card.addEventListener('click', () => { W.origin = c.name; W.originData = null; W.repl.clear(); draw(); footer('Next', true); });
        card.addEventListener('dblclick', () => { W.origin = c.name; W.originData = null; next(); });
        grid.appendChild(card);
      }
    };
    search.addEventListener('input', draw);
    draw();
    mount(contentEl, h('h3', null, 'Which simulation should be the starting point?'),
      h('p', { class: 'lead' }, 'All settings, scripts and STL files are copied from the origin - without any results, meshes or logs.'),
      h('div', { style: { marginBottom: '12px' } }, search), grid);
    footer('Next', !!W.origin);
    setTimeout(() => { const s = grid.querySelector('.selected'); if (s) s.scrollIntoView({ block: 'center' }); }, 30);
  }

  // ---------------------------------------------------------------- step 2: name
  function suggestName() {
    const rest = splitName(W.origin).rest;
    const base = `${today()}_${rest}`;
    let n = base, k = 2;
    while (app.byName(n)) n = `${base}_${k++}`;
    return n;
  }

  function renderName() {
    if (!W.name) W.name = suggestName();
    const inp = h('input', { class: 'input', value: W.name, style: { fontSize: '15px', height: '38px' } });
    const msg = h('div', { class: 'hint' });
    const validate = debounce(async () => {
      try {
        const r = await api.post('wizard/validate', { name: inp.value });
        W.nameOk = r.ok; W.nameError = r.error;
        inp.classList.toggle('invalid', !r.ok);
        mount(msg, r.ok ? h('span', { class: 'ok' }, '✓ Name is available') : h('span', { class: 'bad' }, r.error));
        footer('Next', r.ok);
      } catch (e) { /* ignore */ }
    }, 250);
    inp.addEventListener('input', () => {
      if (inp.value.includes(' ')) { const p = inp.selectionStart; inp.value = inp.value.replace(/ /g, '_'); inp.setSelectionRange(p, p); }
      W.name = inp.value; W.nameOk = false; footer('Next', false); validate();
    });
    validate();
    const notes = h('textarea', { class: 'input', rows: 4, placeholder: 'What is different in this variant? (optional)' });
    notes.value = W.notes;
    notes.addEventListener('input', () => { W.notes = notes.value; });
    // ---- initialisation: cold start or warm start from another simulation's results
    const withResults = app.cases.filter((c) => c.status === 'finished' || c.status === 'stopped').map((c) => c.name)
      .sort((a, b) => b.localeCompare(a));
    if (!W.warmSource) W.warmSource = withResults.includes(W.origin) ? W.origin : (withResults[0] || null);
    const srcSel = h('select', { class: 'input' }, withResults.map((n) => h('option', { value: n }, n + (n === W.origin ? '   (origin)' : ''))));
    if (W.warmSource) srcSel.value = W.warmSource;
    srcSel.addEventListener('change', () => { W.warmSource = srcSel.value; });
    // the iterations stay those of the origin (changeable later in Settings)
    const warmBox = h('div', { style: { marginTop: '14px' } },
      h('div', { class: 'field' }, h('label', null, 'Start from the results of'), srcSel,
        h('div', { class: 'hint' }, 'The flow field is mapped onto the new mesh (mapFields) before solving.')));
    const coldText = h('div', { class: 'muted small', style: { marginTop: '10px' } },
      'The solver starts from the uniform initial conditions in 0.org.');
    const showInit = () => {
      warmBox.classList.toggle('hidden', !W.warm);
      coldText.classList.toggle('hidden', W.warm);
    };
    const initSeg = segmented([{ label: 'Cold start', value: false }, { label: 'Warm start', value: true }], W.warm,
      (v) => { W.warm = v; showInit(); });
    if (!withResults.length) initSeg.querySelectorAll('button')[1].disabled = true;
    ensureOriginData().then(showInit).catch(() => showInit());
    showInit();
    mount(contentEl, h('h3', null, 'Name the new simulation'),
      h('p', { class: 'lead' }, 'The folder is created next to your other simulations. Tip: start with the date so the list stays sorted.'),
      h('div', { class: 'field', style: { maxWidth: '680px' } }, h('label', null, 'Folder name'), inp, msg),
      h('div', { class: 'field', style: { maxWidth: '680px', marginTop: '18px' } }, h('label', null, 'Notes'), notes),
      h('div', { class: 'card', style: { maxWidth: '680px', marginTop: '18px' } },
        h('div', { class: 'row', style: { justifyContent: 'space-between' } },
          h('div', null, h('b', null, 'Initialisation'),
            h('div', { class: 'muted small' }, 'A warm start reuses a converged flow field and needs far fewer iterations.')),
          initSeg),
        coldText, warmBox,
        !withResults.length ? h('div', { class: 'muted small', style: { marginTop: '8px' } }, 'Warm start needs a simulation with results.') : null));
    inp.focus();
    inp.setSelectionRange(inp.value.length, inp.value.length);
  }

  // ---------------------------------------------------------------- step 3: geometry
  async function ensureOriginData() {
    if (W.originData && W.originData.name === W.origin) return W.originData;
    W.originData = await api.get('case', { name: W.origin });
    return W.originData;
  }

  function stemOf(n) { return n.replace(/\.stl$/i, '').toLowerCase(); }

  async function uploadFiles(files, forcedTarget) {
    if (!W.staging) { toast('Please wait', 'Preparing upload area...', 'warn'); return; }
    const stls = W.originData.stls.map((s) => s.name);
    for (const file of files) {
      if (!/\.stl$/i.test(file.name)) { toast('Skipped ' + file.name, 'Only .stl files can be used.', 'warn'); continue; }
      const staged = file.name.replace(/\.stl$/i, '.stl');
      const target = forcedTarget || stls.find((s) => stemOf(s) === stemOf(file.name)) || null;
      const up = { name: staged, size: file.size, progress: 0, uploading: true, error: null, target };
      W.uploads.set(staged, up);
      if (target) {
        for (const [t, s] of W.repl) if (s === staged && t !== target) W.repl.delete(t);
        W.repl.set(target, staged);
      }
      renderGeometry();
      try {
        const r = await api.upload('wizard/upload', { id: W.staging, name: file.name }, file, (p) => { up.progress = p; updateBars(); });
        Object.assign(up, r, { uploading: false, progress: 1 });
      } catch (e) {
        up.uploading = false; up.error = e.message;
        for (const [t, s] of W.repl) if (s === staged) W.repl.delete(t);
        toastError(e, 'Upload failed: ' + file.name);
      }
      if (STEPS[W.step][0] === 'geometry') renderGeometry();
    }
  }

  function updateBars() {
    contentEl.querySelectorAll('[data-up]').forEach((el) => {
      const u = W.uploads.get(el.dataset.up);
      if (u) el.firstChild.style.width = Math.round(u.progress * 100) + '%';
    });
  }

  async function renderGeometry() {
    if (!W.originData || W.originData.name !== W.origin) {
      mount(contentEl, h('div', { class: 'empty' }, h('div', { class: 'spinner' })));
      try { await ensureOriginData(); } catch (e) { toastError(e); return; }
    }
    const fileIn = h('input', { type: 'file', accept: '.stl,.STL', multiple: true, class: 'hidden' });
    fileIn.addEventListener('change', () => { uploadFiles([...fileIn.files], fileIn._target); fileIn.value = ''; fileIn._target = null; });
    const drop = h('div', { class: 'dropzone' }, icon('upload', 'xl'),
      h('div', null, h('b', null, 'Drop your new STL files here'), ' or click to choose'),
      h('div', { class: 'small', style: { marginTop: '4px' } }, 'Files are matched to the existing parts by name (e.g. wall_body.STL → wall_body.stl). Export them from the CAD assembly with the global coordinate system.'));
    drop.addEventListener('click', () => { fileIn._target = null; fileIn.click(); });
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); uploadFiles([...e.dataTransfer.files]); });

    const rows = W.originData.stls.map((s) => {
      const staged = W.repl.get(s.name);
      const up = staged ? W.uploads.get(staged) : null;
      const rep = btn(staged ? 'Change' : 'Replace...', { size: 'sm', icon: 'upload' });
      rep.addEventListener('click', () => { fileIn._target = s.name; fileIn.click(); });
      const rev = staged ? btn('', { size: 'sm', icon: 'undo', variant: 'ghost', title: 'Keep the original' }) : null;
      if (rev) rev.addEventListener('click', () => { W.repl.delete(s.name); renderGeometry(); });
      let status;
      if (!up) status = h('span', { class: 'muted' }, 'keep original');
      else if (up.error) status = h('span', { class: 'bad' }, 'upload failed');
      else if (up.uploading) status = h('div', null, h('span', { class: 'newfile' }, icon('upload'), up.name), h('div', { class: 'upbar', dataset: { up: up.name } }, h('i', { style: { width: Math.round(up.progress * 100) + '%' } })));
      else status = h('span', { class: 'newfile' }, icon('check'), up.name, h('span', { class: 'muted small', style: { fontWeight: 400 } }, ` · ${fmtInt(up.triangles)} triangles · ${fmtBytes(up.size)}`));
      return h('tr', { class: 'stl-row' }, h('td', null, h('b', null, s.name)), h('td', { class: 'num muted' }, fmtBytes(s.size)), h('td', null, status),
        h('td', { class: 'right nowrap' }, rep, rev));
    });

    const assigned = new Set(W.repl.values());
    const loose = [...W.uploads.values()].filter((u) => !assigned.has(u.name) && !u.error);
    const looseEl = loose.length ? h('div', { class: 'callout warn', style: { marginTop: '14px' } }, icon('alert'),
      h('div', { class: 'callout-body' }, h('div', { class: 'callout-title' }, 'Uploaded files without a matching part'),
        h('div', { class: 'muted small', style: { marginBottom: '8px' } }, 'Choose which existing part each file replaces. (Adding completely new parts requires editing snappyHexMeshDict.)'),
        loose.map((u) => {
          const sel = h('select', { class: 'input', style: { width: '260px' } }, h('option', { value: '' }, '— choose part —'),
            W.originData.stls.map((s) => h('option', { value: s.name }, s.name)));
          sel.addEventListener('change', () => { if (sel.value) { W.repl.set(sel.value, u.name); renderGeometry(); } });
          return h('div', { class: 'row', style: { marginBottom: '6px' } }, h('span', { class: 'mono', style: { minWidth: '240px' } }, u.name), icon('chevRight'), sel);
        }))) : null;

    const uploading = [...W.uploads.values()].some((u) => u.uploading);
    mount(contentEl, fileIn, h('h3', null, 'Which parts do you want to replace?'),
      h('p', { class: 'lead' }, `The origin has ${W.originData.stls.length} STL files. Parts you do not replace are copied unchanged. Skip this step to create an identical copy (e.g. for a settings variation).`),
      drop,
      h('div', { class: 'card', style: { marginTop: '14px', padding: '6px 10px' } },
        h('table', { class: 'tbl' }, h('thead', null, h('tr', null, h('th', null, 'Part'), h('th', { class: 'num' }, 'Size'), h('th', null, 'New file'), h('th', null, ''))),
          h('tbody', null, rows))),
      looseEl);
    footer(uploading ? 'Uploading...' : hasRepl() ? 'Next: orientation' : 'Next (no changes)', !uploading);
  }

  // ---------------------------------------------------------------- step 4: orientation
  function renderOrient() {
    const T = W.transform;
    const controls = h('div', { class: 'orient-controls' });
    const vc = h('div', { style: { minHeight: '0', display: 'flex', flexDirection: 'column' } });
    mount(contentEl, h('div', { class: 'orient' }, controls, vc));
    contentEl.style.overflow = 'hidden';

    const checksEl = h('div', { class: 'card', style: { padding: '12px 14px' } });
    const update = () => { applyTransform(); renderChecks(checksEl); };

    // scale
    const scaleMode = T.scale === 0.001 ? 'mm' : T.scale === 1 ? 'none' : 'custom';
    const scaleIn = h('input', { class: 'input', value: T.scale, style: { width: '100px' }, disabled: scaleMode !== 'custom' });
    scaleIn.addEventListener('input', () => { const v = parseFloat(scaleIn.value); if (v > 0) { T.scale = v; update(); } });
    const scaleSeg = segmented([{ label: 'mm → m', value: 'mm' }, { label: 'none', value: 'none' }, { label: 'custom', value: 'custom' }], scaleMode, (v) => {
      scaleIn.disabled = v !== 'custom';
      if (v === 'mm') T.scale = 0.001; else if (v === 'none') T.scale = 1; else T.scale = parseFloat(scaleIn.value) || 1;
      scaleIn.value = T.scale; update();
    });
    // translate
    const tr = T.translate.map((v, i) => {
      const inp = h('input', { class: 'input', value: v, title: 'xyz'[i] });
      inp.addEventListener('input', () => { const n = parseFloat(inp.value); T.translate[i] = isFinite(n) ? n : 0; update(); });
      return inp;
    });
    // rotations
    const rotList = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
    const drawRot = () => {
      clear(rotList);
      T.rotations.forEach((r, idx) => {
        const ax = segmented(['x', 'y', 'z'].map((a) => ({ label: a.toUpperCase(), value: a })), r.axis, (v) => { r.axis = v; update(); });
        const ang = segmented([90, 180, 270].map((a) => ({ label: a + '°', value: a })), r.deg, (v) => { r.deg = v; degIn.value = v; update(); });
        const degIn = h('input', { class: 'input', value: r.deg, style: { width: '62px' }, title: 'Custom angle (degrees)' });
        degIn.addEventListener('input', () => { const n = parseFloat(degIn.value); if (isFinite(n)) { r.deg = n; ang.set(n); update(); } });
        const del = btn('', { size: 'sm', icon: 'x', variant: 'ghost', title: 'Remove rotation' });
        del.addEventListener('click', () => { T.rotations.splice(idx, 1); drawRot(); update(); });
        rotList.appendChild(h('div', { class: 'rot-row' }, h('span', { class: 'muted small' }, `${idx + 1}.`), ax, ang, degIn, del));
      });
    };
    drawRot();
    const addRot = btn('Add rotation', { size: 'sm', icon: 'plus' });
    addRot.addEventListener('click', () => { T.rotations.push({ axis: 'x', deg: 90 }); drawRot(); update(); });
    const cutSw = switchEl(T.cut, (v) => { T.cut = v; update(); });
    const origSw = switchEl(W.showOrigin, (v) => { W.showOrigin = v; applyTransform(); });
    const replSw = switchEl(W.showReplaced, (v) => { W.showReplaced = v; applyTransform(); });

    controls.append(
      h('div', null, h('h3', null, 'Orientation & scale'),
        h('p', { class: 'lead', style: { marginBottom: '6px' } }, 'Align the new parts with the existing car. Order: translate → rotate → scale (like adjust_geometry.py).')),
      h('div', { class: 'field' }, h('label', null, icon('scale'), 'Scale'), h('div', { class: 'row' }, scaleSeg, scaleIn)),
      h('div', { class: 'field' }, h('label', null, icon('move'), 'Translate (in CAD units, before scaling)'), h('div', { class: 'vec3' }, tr)),
      h('div', { class: 'field' }, h('label', null, icon('rotate'), 'Rotations (right-hand rule, applied in order)'), rotList, h('div', null, addRot)),
      h('label', { class: 'switch-row' }, cutSw, h('div', null, h('b', null, 'Cut at symmetry plane x = 0'), h('div', { class: 'muted small' }, 'Keeps the half with x ≥ 0 (half-car simulation)'))),
      h('div', { class: 'card', style: { padding: '10px 12px' } },
        h('label', { class: 'switch-row small', style: { marginBottom: '6px' } }, origSw, 'Show unchanged parts of the origin'),
        h('label', { class: 'switch-row small' }, replSw, h('span', null, 'Show the replaced original parts ', h('span', { style: { color: '#4d8dff' } }, '(blue, transparent)')))),
      checksEl);

    W.viewer = new Viewer3D(vc, { height: '100%' });
    W.viewer.el.style.flex = '1';
    for (const [lbl, v] of [['Iso', 'iso'], ['Front', 'front'], ['Side', 'side'], ['Top', 'top']]) {
      const b = btn(lbl, { size: 'sm' }); b.addEventListener('click', () => W.viewer.view(v)); W.viewer.tools.appendChild(b);
    }
    loadViewer(update);
    footer('Next', true, async () => {
      if (W.worst === 'bad') {
        const ok = await confirmDialog({ title: 'The plausibility check found a problem',
          message: 'At least one new part does not fit the original (see the red entries). Continue anyway?',
          confirmLabel: 'Continue anyway', danger: true });
        if (!ok) return;
      }
      next();
    });
  }

  async function loadViewer(update) {
    const v = W.viewer;
    v.setLoading(true, 'Loading geometry...');
    const replaced = new Set(W.repl.keys());
    const jobs = [];
    for (const s of W.originData.stls) {
      jobs.push(api.getBinary('stl/preview', { name: W.origin, file: s.name, budget: replaced.has(s.name) ? 60000 : 40000 })
        .then((r) => ({ kind: replaced.has(s.name) ? 'old' : 'keep', id: 'o:' + s.name, r })));
    }
    for (const [target, staged] of W.repl) {
      jobs.push(api.getBinary('stl/preview', { staging: W.staging, file: staged, budget: 80000 }).then((r) => ({ kind: 'new', id: 'n:' + target, r })));
    }
    const results = await Promise.allSettled(jobs);
    if (W.viewer !== v) return;
    for (const res of results) {
      if (res.status !== 'fulfilled') continue;
      const { kind, id, r } = res.value;
      const props = kind === 'new' ? { color: '#ff8a2a', clip: true } : kind === 'old' ? { color: '#4d8dff', alpha: 0.28 } : { color: '#a3adbf' };
      v.addMesh(id, new Float32Array(r.buffer), Object.assign(props, { kind, bboxRaw: r.bbox }));
    }
    v.setLoading(false);
    update();
    v.view('iso');
  }

  function applyTransform() {
    const v = W.viewer;
    if (!v) return;
    const mat = specMatrix(W.transform);
    for (const [id, m] of v.meshes) {
      if (m.kind === 'new') v.update(id, { model: mat });
      else if (m.kind === 'keep') v.update(id, { visible: W.showOrigin });
      else if (m.kind === 'old') v.update(id, { visible: W.showReplaced });
    }
    v.setSymmetry(W.transform.cut, W.transform.cut);
  }

  function renderChecks(el) {
    const v = W.viewer;
    const mat = specMatrix(W.transform);
    const lines = [];
    let worst = 'ok';
    for (const [target, staged] of W.repl) {
      const up = W.uploads.get(staged);
      const orig = v && v.meshes.get('o:' + target);
      if (!up || !up.bbox || !orig) continue;
      let nb = transformBBox(up.bbox, mat);
      const ob = orig.bboxRaw || orig.bbox;
      const crossesPlane = nb[0][0] < -1e-4 && nb[1][0] > 1e-4;
      if (W.transform.cut) nb = [[Math.max(0, nb[0][0]), nb[0][1], nb[0][2]], [Math.max(0, nb[1][0]), nb[1][1], nb[1][2]]];
      const size = (b) => [0, 1, 2].map((k) => b[1][k] - b[0][k]);
      const sn = size(nb), so = size(ob);
      const ratio = Math.max(...so) > 0 ? Math.max(...sn) / Math.max(...so) : 1;
      const cn = [0, 1, 2].map((k) => (nb[0][k] + nb[1][k]) / 2), co = [0, 1, 2].map((k) => (ob[0][k] + ob[1][k]) / 2);
      const off = Math.hypot(cn[0] - co[0], cn[1] - co[1], cn[2] - co[2]);
      const rel = off / (Math.max(...so) || 1);
      // orientation: compare sorted extents per axis
      const axisMismatch = [0, 1, 2].some((k) => so[k] > 0 && sn[k] > 0 && (Math.max(sn[k], so[k]) / Math.min(sn[k], so[k])) > 1.6);
      let st = 'ok', msg;
      // the origin is a half model (all parts at x >= 0) but the new part is not cut
      const originIsHalf = [...v.meshes.values()].filter((mm) => mm.kind !== 'new').every((mm) => (mm.bboxRaw || mm.bbox)[0][0] > -1e-4);
      if (!W.transform.cut && crossesPlane && originIsHalf) { st = 'bad'; msg = 'crosses the symmetry plane, but the car is a half model - enable "Cut at symmetry plane x = 0"'; }
      else if (ratio > 5 || ratio < 0.2) { st = 'bad'; msg = `size is ${ratio.toFixed(ratio > 5 ? 0 : 3)}× the original - check the scale`; }
      else if (axisMismatch) { st = 'warn'; msg = 'proportions per axis differ - check the rotation'; }
      else if (rel > 0.25) { st = 'warn'; msg = `centre is ${(off * 1000).toFixed(0)} mm away from the original - check rotation / translation`; }
      else msg = `matches the original (size ${(ratio * 100).toFixed(0)} %, offset ${(off * 1000).toFixed(1)} mm)`;
      if (st === 'bad' || (st === 'warn' && worst === 'ok')) worst = st;
      lines.push(h('div', { class: 'check-row' }, icon(st === 'ok' ? 'check' : 'alert', st === 'ok' ? 'ok' : st === 'bad' ? 'bad' : 'warnc'),
        h('span', null, h('b', null, target.replace(/\.stl$/i, '')), ': ', msg)));
    }
    W.worst = lines.length ? worst : 'ok';
    mount(el, h('div', { class: 'card-title', style: { marginBottom: '8px' } }, icon('target'), 'Plausibility check'),
      lines.length ? lines : h('div', { class: 'muted small' }, 'Loading...'),
      h('div', { class: 'muted small', style: { marginTop: '8px' } }, worst === 'ok' && lines.length ? 'Looks good. Orange parts should sit exactly on the blue originals.' : 'Orange = new part, blue = original part being replaced.'));
  }

  // ---------------------------------------------------------------- step 5: create
  function renderCreate() {
    contentEl.style.overflow = '';
    if (W.created) return renderDone();
    const repl = [...W.repl.entries()];
    const sum = h('div', { class: 'summary-list' },
      h('span', { class: 'k' }, 'Origin'), h('span', null, h('b', null, W.origin)),
      h('span', { class: 'k' }, 'New folder'), h('span', null, h('b', { class: 'mono' }, W.name)),
      h('span', { class: 'k' }, 'Notes'), h('span', null, W.notes || h('span', { class: 'muted' }, '—')),
      h('span', { class: 'k' }, 'Replaced parts'), h('span', null, repl.length ? repl.map(([t, s]) => h('div', null, h('b', null, t), h('span', { class: 'muted' }, ' ← ' + s))) : h('span', { class: 'muted' }, 'none (identical geometry)')),
      repl.length ? [h('span', { class: 'k' }, 'Transform'), h('span', null, describeTransform(W.transform))] : null,
      h('span', { class: 'k' }, 'Initialisation'), h('span', null, W.warm && W.warmSource
        ? h('span', null, h('b', null, 'Warm start'), ` from ${W.warmSource}`)
        : 'cold start'));
    const prog = h('div', { class: 'hidden', style: { marginTop: '22px' } },
      h('div', { class: 'bigbar running' }, h('i', { style: { width: '0%' } })), h('div', { class: 'muted small', style: { marginTop: '8px' } }, 'Starting...'));
    mount(contentEl, h('h3', null, 'Ready to create'), h('p', { class: 'lead' }, 'Please review. Nothing is started automatically - you can run the simulation afterwards.'),
      h('div', { class: 'card' }, sum), prog);
    const nx = footer('Create simulation', !W.creating, async () => {
      W.creating = true; nx.disabled = true;
      prog.classList.remove('hidden');
      try {
        const r = await api.post('wizard/create', {
          origin: W.origin, name: W.name, notes: W.notes, staging: W.staging,
          replacements: Object.fromEntries(W.repl), transform: W.transform,
          map_source: W.warm && W.warmSource ? W.warmSource : '',
        });
        const poll = async () => {
          const t = await api.get('task', { id: r.task });
          prog.querySelector('i').style.width = Math.round(t.progress * 100) + '%';
          prog.lastChild.textContent = t.message;
          if (!t.done) { setTimeout(poll, 400); return; }
          W.creating = false;
          if (t.error) { toastError(new Error(t.error), 'Could not create the simulation'); renderCreate(); return; }
          W.created = t.result;
          await app.refresh();
          render();
        };
        poll();
      } catch (e) { W.creating = false; toastError(e, 'Could not create the simulation'); renderCreate(); }
    });
  }

  function renderDone() {
    const r = W.created;
    const open = btn('Open simulation', { variant: 'ghost', icon: 'chevRight' });
    open.addEventListener('click', () => { m.close(); app.select(r.name); });
    const run = btn('Run now (mesh + solve)', { variant: 'primary', icon: 'play' });
    run.addEventListener('click', () => { m.close(); app.select(r.name); app.run([r.name], 'full'); });
    const settings = btn('Review settings first', { icon: 'sliders' });
    settings.addEventListener('click', () => { m.close(); app.select(r.name); setTimeout(() => app.detail && app.detail.showTab('settings'), 50); });
    mount(contentEl, h('div', { style: { textAlign: 'center', paddingTop: '40px' } },
      h('div', { class: 'big-check' }, icon('check')),
      h('h3', null, 'Simulation created'),
      h('p', { class: 'lead' }, h('b', { class: 'mono' }, r.name), ` · ${r.files} files copied` + (r.stls.length ? ` · ${r.stls.length} STL processed` : '')),
      r.stls.length ? h('div', { class: 'card', style: { maxWidth: '640px', margin: '0 auto 20px', textAlign: 'left' } },
        h('table', { class: 'tbl' }, h('tbody', null, r.stls.map((s) => h('tr', null, h('td', null, s.target),
          h('td', { class: 'num muted' }, `${fmtInt(s.triangles_in)} → ${fmtInt(s.triangles_out)} triangles`)))))) : null,
      r.wheels && r.wheels.rows && r.wheels.rows.length ? h('div', { class: 'card', style: { maxWidth: '640px', margin: '0 auto 20px', textAlign: 'left' } },
        h('div', { class: 'card-head' }, h('div', { class: 'card-title' }, icon('wheel'), 'Wheels (derived from the geometry)')),
        wheelTable(r.wheels.rows, r.wheels.changed),
        h('div', { class: 'muted small', style: { marginTop: '8px' } },
          r.wheels.changed.length ? 'Axle position and angular velocity were updated to match the new wheel geometry.'
            : 'The wheel settings already match the geometry.')) : null,
      r.wheels && r.wheels.error ? h('div', { class: 'callout warn', style: { maxWidth: '640px', margin: '0 auto 20px' } }, icon('alert'),
        h('div', { class: 'callout-body' }, 'The wheels could not be analysed: ' + r.wheels.error)) : null,
      h('div', { class: 'row', style: { justifyContent: 'center' } }, settings, open, run)));
    mount(footEl, h('span', { class: 'grow' }), (() => { const c = btn('Close', { variant: 'ghost' }); c.addEventListener('click', () => { m.close(); app.select(r.name); }); return c; })());
  }

  render();
}
