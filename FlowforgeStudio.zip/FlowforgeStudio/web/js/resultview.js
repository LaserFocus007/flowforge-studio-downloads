// WebGL 2 renderer for the Results tab: coloured surfaces and section planes, mesh edges drawn
// in the shader (resolution independent - a 4K screenshot looks like the screen, only sharper),
// mirroring at the symmetry plane, and the comparison modes (peek, wipe, difference).
// No third-party code; runs on any GPU with WebGL 2 (integrated graphics are enough).

import { M4 } from './viewer3d.js';
import { mp4 } from './mp4mux.js';

// ParaView-style "Rainbow Desaturated" and a cool-warm diverging map for differences
export const COLORMAPS = {
  rainbowDesat: [[0, 0.278431, 0.278431, 0.858824], [0.143, 0, 0, 0.360784], [0.285, 0, 1, 1], [0.429, 0, 0.501961, 0],
    [0.571, 1, 1, 0], [0.714, 1, 0.380392, 0], [0.857, 0.419608, 0, 0], [1, 0.878431, 0.301961, 0.301961]],
  coolWarm: [[0, 0.231, 0.298, 0.753], [0.5, 0.865, 0.865, 0.865], [1, 0.706, 0.016, 0.150]],
};

export function colormapAt(name, t) {
  const pts = COLORMAPS[name];
  t = Math.min(1, Math.max(0, t));
  for (let i = 1; i < pts.length; i++) {
    if (t <= pts[i][0]) {
      const a = pts[i - 1], b = pts[i], f = (t - a[0]) / ((b[0] - a[0]) || 1);
      return [a[1] + f * (b[1] - a[1]), a[2] + f * (b[2] - a[2]), a[3] + f * (b[3] - a[3])];
    }
  }
  const l = pts[pts.length - 1];
  return [l[1], l[2], l[3]];
}

const SCENE_VS = `#version 300 es
in vec3 aPos; in float aVal; in float aMask; in vec3 aNrm; in vec2 aLine;
uniform mat4 uVP; uniform mat4 uModel; uniform float uHaloR;
out vec3 vW; out float vVal; flat out int vMask; out vec3 vBary; out vec3 vN; out vec2 vLine;
void main() {
  vec4 w = uModel * vec4(aPos + aNrm * uHaloR, 1.0);   // uHaloR > 0: glow shell around the tubes
  vW = w.xyz; vVal = aVal; vMask = int(aMask + 0.5); vN = mat3(uModel) * aNrm; vLine = aLine;
  int k = gl_VertexID % 3;
  vBary = k == 0 ? vec3(1.0, 0.0, 0.0) : (k == 1 ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0));
  gl_Position = uVP * w;
}`;

const SCENE_FS = `#version 300 es
precision highp float;
precision highp int;
in vec3 vW; in float vVal; flat in int vMask; in vec3 vBary; in vec3 vN; in vec2 vLine;
uniform int uMode;            // 0 colour, 1 encoded value (for picking / differences)
uniform bool uFlow; uniform float uOpacity; uniform bool uPulse; uniform float uPulseLen; uniform float uTime; uniform float uWide;
uniform sampler2D uLut;
uniform vec2 uRange; uniform bool uHasVal; uniform vec3 uSolid; uniform float uLit; uniform vec3 uEye;
uniform bool uEdges; uniform vec4 uEdgeColor; uniform float uEdgeWidth; uniform float uLayer; uniform bool uHasNrm;
uniform bool uTrail; uniform bool uBlack; uniform int uLook; uniform float uGain; uniform float uGuide;
uniform int uStyle; uniform float uAnimT; uniform float uTail; uniform float uTMax; uniform bool uOnLight;
uniform bool uTravel;
out vec4 o;
// ---- animated streamlines: vLine = (time of flight, random number of the line). uAnimT counts
// periods (uPulseLen = time of flight between two trails), so everything travels with the local
// flow speed: slow in the wake, fast over the wings. Each style returns the brightness I (0..1) and
// core, the white-hot part.
float hash(float n) { return fract(sin(n * 127.1) * 43758.5453); }
float vnoise(float x) { float i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hash(i), hash(i + 1.0), f); }
float animate(out float core) {
  float r = vLine.y, s = vLine.x / uPulseLen - uAnimT;      // s: periods behind the travelling pattern
  core = 0.0;
  if (uStyle == 1) {
    // particles: many small sparks per line, each with its own brightness, some missing
    float k = 0.7 + 0.6 * fract(r * 7.31);
    float u = s * 6.0 / k + r * 13.0, id = floor(u), ph = fract(u);
    float on = step(0.35, hash(id + r * 91.0));
    float x = (1.0 - ph) / max(uTail * 0.6, 0.02);
    if (x >= 1.0 || on == 0.0) return 0.0;
    float head = smoothstep(0.0, 0.08, 1.0 - ph);
    core = exp(-x * 6.0) * head;
    return head * pow(1.0 - x, 1.5) * (0.45 + 0.55 * hash(id * 1.7 + r));
  }
  if (uStyle == 2) {
    // smoke: soft billowing strands, as in a wind tunnel
    float n = 0.65 * vnoise(s * 2.2 + r * 17.0) + 0.35 * vnoise(s * 5.1 + r * 31.0);
    return smoothstep(0.25, 0.85, n) * (0.25 + 0.75 * uTail);
  }
  if (uStyle == 4) {
    // reveal: the lines draw themselves from far upstream, glow on and fade out, then again
    float cyc = uTMax * 1.3;
    float F = mod(uAnimT * uPulseLen, cyc);
    if (vLine.x > F) return 0.0;
    float behind = (F - vLine.x) / uPulseLen;
    core = exp(-behind * 30.0);
    float g = F / cyc;
    return (0.22 + 0.78 * exp(-behind / max(uTail * 1.5, 0.05))) * (1.0 - smoothstep(0.8, 1.0, g));
  }
  // trails: long light streaks, every line with its own phase and spacing (no rows)
  float k = 0.7 + 0.6 * fract(r * 7.31);
  float ph = fract(s / k + r);
  float x = (1.0 - ph) / max(uTail, 0.02);
  if (x >= 1.0) return 0.0;
  float head = smoothstep(0.0, 0.015, 1.0 - ph);
  core = exp(-x * 28.0) * head;
  return head * pow(1.0 - x, 2.6);
}
// colour of the light: 1 ice (deep blue in slow flow .. white in fast flow), 2 ember, 3 mono;
// on a light background deeper, saturated tones (ink instead of light)
vec3 lookColor(float t, vec3 field) {
  t = clamp(t, 0.0, 1.0);
  if (uOnLight) {
    if (uLook == 1) return mix(vec3(0.05, 0.12, 0.55), vec3(0.0, 0.55, 0.95), smoothstep(0.1, 0.9, t));
    if (uLook == 2) return mix(vec3(0.55, 0.04, 0.02), vec3(0.95, 0.42, 0.02), smoothstep(0.1, 0.9, t));
    if (uLook == 3) return vec3(0.16, 0.18, 0.22);
    return field * 0.85;
  }
  if (uLook == 1) return mix(mix(vec3(0.04, 0.22, 0.95), vec3(0.2, 0.72, 1.0), smoothstep(0.0, 0.6, t)), vec3(0.88, 0.96, 1.0), smoothstep(0.62, 1.0, t));
  if (uLook == 2) return mix(mix(vec3(0.75, 0.06, 0.02), vec3(1.0, 0.42, 0.06), smoothstep(0.0, 0.6, t)), vec3(1.0, 0.86, 0.62), smoothstep(0.62, 1.0, t));
  if (uLook == 3) return vec3(0.92, 0.94, 1.0);
  return field;
}
void main() {
  float t = (vVal - uRange.x) / max(uRange.y - uRange.x, 1e-30);
  if (uMode == 1) {
    if (!uHasVal) { o = vec4(0.0, 0.0, 0.0, uLayer); return; }
    float e = clamp((t + 1.0) / 3.0, 0.0, 1.0) * 65535.0;
    o = vec4(floor(e / 256.0) / 255.0, mod(e, 256.0) / 255.0, 1.0, uLayer);
    return;
  }
  // travel: the normal streamlines grow from far upstream to the end, stay complete for a moment,
  // then start again; the growing front has a light tip
  float tip = 0.0;
  if (uTravel) {
    float cyc = uTMax * 1.5;
    float F = mod(uAnimT * uPulseLen, cyc);
    if (vLine.x > F) discard;
    tip = F < uTMax * 1.02 ? exp(-(F - vLine.x) / (uPulseLen * 0.04)) : 0.0;
  }
  if (uBlack) { o = vec4(0.0); return; }   // glow buffer: solid things only hide what is behind
  vec3 base = uHasVal ? texture(uLut, vec2(clamp(t, 0.0, 1.0), 0.5)).rgb : uSolid;
  if (uTrail) {
    // light on top of a faint glimmer of the whole line; premultiplied (colour * a, a): added
    // on dark backgrounds, laid over like ink on light ones - never a solid tube
    float core, I = animate(core);
    float d = abs(dot(normalize(vN), normalize(uEye - vW)));
    vec3 lc = lookColor(uHasVal ? t : 0.75, base);
    vec3 spark = uLook == 1 ? vec3(0.1, 0.72, 1.0) : uLook == 2 ? vec3(1.0, 0.55, 0.1) : uLook == 3 ? vec3(0.0) : lc;
    vec3 hot = uOnLight ? mix(lc, spark, 0.6 * core) : mix(lc, vec3(1.0), 0.8 * core);
    float shape = uStyle == 2 ? pow(d, 2.0) : 0.35 + 0.65 * d * d;
    float a = clamp((I * uGain + uGuide) * shape, 0.0, 1.0);
    vec3 c = (hot * I * uGain + lc * uGuide) * shape;
    o = uOnLight ? vec4(hot * a, a) : vec4(c, a);
    return;
  }
  if (uFlow) {
    // flow-line ribbon: smooth edges at any resolution and a slightly rounded look. The ribbon is
    // uWide times the line width (room for the drops); the line itself uses the inner part.
    float as = abs(vLine.y);
    float a = as * uWide;
    float fa = 1.0 - a;
    float cover = clamp(fa / max(fwidth(fa), 1e-5) + 0.5, 0.0, 1.0);
    vec3 c = base * (0.78 + 0.22 * sqrt(max(0.0, 1.0 - min(a, 1.0) * min(a, 1.0))));
    if (!uPulse) { o = vec4(c, uOpacity * cover); return; }
    // animated: soft light streaks travelling with the time of flight (fast flow = fast streaks):
    // rounded bright head, the body keeps the line width and fades out smoothly in the line colour,
    // over a faint guide line
    float ph = fract(vLine.x / uPulseLen - uTime);
    float x = (1.0 - ph) / 0.55;                       // 0 at the head .. 1 at the end of the streak
    float xc = clamp(x, 0.0, 1.0);
    const float hc = 0.05;                              // rounded head
    float q = (hc - min(xc, hc)) / hc;
    float w = sqrt(max(0.0, 1.0 - q * q)) * (x < 1.0 ? 1.0 : 0.0) / uWide;
    float f = w - as;
    float body = clamp(f / max(fwidth(f), 1e-5) + 0.5, 0.0, 1.0);
    float fade = pow(1.0 - xc, 2.2);
    float r = min(a, 1.0);
    vec3 sc = mix(base, vec3(1.0), 0.35 * fade * fade) * (0.8 + 0.2 * sqrt(max(0.0, 1.0 - r * r)));
    float sa = body * fade;
    float guide = cover * 0.16;
    o = sa >= guide ? vec4(sc, uOpacity * sa) : vec4(base, uOpacity * guide);
    return;
  }
  // smooth normals where the geometry has them (streamline tubes), else the facet normal
  vec3 n = uHasNrm ? normalize(vN) : normalize(cross(dFdx(vW), dFdy(vW)));
  float d = abs(dot(n, normalize(uEye - vW)));
  vec3 col = base * mix(1.0, 0.28 + 0.72 * d, uLit) + vec3(pow(d, 40.0) * 0.18 * uLit);
  col = mix(col, vec3(1.0), 0.65 * tip);
  if (uEdges && vMask != 0) {
    vec3 fw = max(fwidth(vBary), vec3(1e-6));
    float e = 1e9;
    if ((vMask & 2) != 0) e = min(e, vBary.x / fw.x);
    if ((vMask & 4) != 0) e = min(e, vBary.y / fw.y);
    if ((vMask & 1) != 0) e = min(e, vBary.z / fw.z);
    float a = 1.0 - smoothstep(uEdgeWidth * 0.5 - 0.5, uEdgeWidth * 0.5 + 0.5, e);
    col = mix(col, uEdgeColor.rgb, a * uEdgeColor.a);
  }
  o = vec4(col, 1.0);
}`;

// bloom: separable Gaussian blur (9 taps folded into 5 linear samples); uDir = 0 copies
const BLUR_FS = `#version 300 es
precision highp float;
in vec2 vUv;
uniform sampler2D uT; uniform vec2 uDir; uniform float uGain;
out vec4 o;
void main() {
  vec4 s = texture(uT, vUv) * 0.227027;
  s += (texture(uT, vUv + uDir * 1.384615) + texture(uT, vUv - uDir * 1.384615)) * 0.316216;
  s += (texture(uT, vUv + uDir * 3.230769) + texture(uT, vUv - uDir * 3.230769)) * 0.070270;
  o = min(s * uGain, vec4(1.0));
}`;

const COMP_VS = `#version 300 es
out vec2 vUv;
void main() { vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); vUv = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }`;

const COMP_FS = `#version 300 es
precision highp float;
in vec2 vUv;
uniform int uMode;            // 1 blend, 2 wipe, 3 difference
uniform sampler2D uA; uniform sampler2D uB; uniform sampler2D uVA; uniform sampler2D uVB; uniform sampler2D uDiffLut;
uniform float uMix; uniform float uWipe; uniform float uDiffScale;
out vec4 o;
float dec(vec4 c) { return (c.r * 255.0 * 256.0 + c.g * 255.0) / 65535.0 * 3.0 - 1.0; }
void main() {
  vec4 a = texture(uA, vUv), b = texture(uB, vUv);
  if (uMode == 1) { o = mix(a, b, uMix); return; }
  if (uMode == 2) { o = vUv.x < uWipe ? a : b; return; }
  vec4 va = texture(uVA, vUv), vb = texture(uVB, vUv);
  float g = dot(a.rgb, vec3(0.299, 0.587, 0.114));
  if (va.b > 0.5 && vb.b > 0.5 && abs(va.a - vb.a) < 0.002) {
    float d = (dec(va) - dec(vb)) / uDiffScale;
    o = vec4(texture(uDiffLut, vec2(clamp(0.5 + 0.5 * d, 0.0, 1.0), 0.5)).rgb, 1.0);
  } else {
    o = vec4(mix(vec3(g), a.rgb, 0.25), 1.0);
  }
}`;

// colour of the streamline light trails (see lookColor in the shader)
const LOOKS = { field: 0, ice: 1, ember: 2, mono: 3 };
const STYLES = { trails: 0, particles: 1, smoke: 2, reveal: 4 };

function hexRgb(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  return m ? [parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255] : [0.5, 0.5, 0.5];
}

export function parsePayload(buf) {
  const hl = new DataView(buf).getUint32(0, true);
  const header = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, hl)));
  const n = header.n;
  let off = 4 + hl;
  const pos = new Float32Array(buf, off, n * 3); off += n * 12;
  let val = null;
  if (header.hasValues) { val = new Float32Array(buf, off, n); off += n * 4; }
  let nrm = null;
  if (header.hasNormals) { nrm = new Float32Array(buf, off, n * 3); off += n * 12; }
  let time = null;
  if (header.hasTime) { time = new Float32Array(buf, off, n * 2); off += n * 8; }
  const mask = new Float32Array(buf, off, n);
  return { header, pos, val, nrm, time, mask };
}

export class ResultView {
  constructor(container) {
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'rv-canvas';
    container.appendChild(this.canvas);
    const gl = this.canvas.getContext('webgl2', { antialias: true, alpha: false, preserveDrawingBuffer: false });
    this.gl = gl;
    this.ok = !!gl;
    if (!gl) return;
    this.prog = this.program(SCENE_VS, SCENE_FS);
    this.comp = this.program(COMP_VS, COMP_FS);
    this.blur = this.program(COMP_VS, BLUR_FS);
    this.emptyVao = gl.createVertexArray();
    this.lut = this.lutTexture('rainbowDesat');
    this.diffLut = this.lutTexture('coolWarm');
    this.scenes = { A: [], B: [] };
    this.mirror = null;
    this.mode = 'normal';
    this.mix = 0;
    this.wipe = 0.5;
    this.diffScale = 0.25;          // fraction of the colour range that is full blue / red
    this.edgePx = 1;
    this.background = [0.07, 0.07, 0.08];
    this.cam = { target: [0, 0, 0], dist: 1, theta: -0.85, phi: 0.5, fov: 0.6 };
    this.box = [[-0.5, -0.5, 0], [0.5, 0.5, 0.5]];
    this.targets = {};
    this.dirty = true;
    this.bindMouse();
    this.ro = new ResizeObserver(() => this.redraw());
    this.ro.observe(this.canvas);
    this.frame = this.frame.bind(this);
    this.raf = requestAnimationFrame(this.frame);
  }

  // ------------------------------------------------------------------ GL helpers
  program(vs, fs) {
    const gl = this.gl;
    const mk = (type, src) => {
      const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs));
    gl.bindAttribLocation(p, 0, 'aPos'); gl.bindAttribLocation(p, 1, 'aVal'); gl.bindAttribLocation(p, 2, 'aMask'); gl.bindAttribLocation(p, 3, 'aNrm'); gl.bindAttribLocation(p, 4, 'aLine');
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    p.loc = {};
    const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < n; i++) { const u = gl.getActiveUniform(p, i); p.loc[u.name] = gl.getUniformLocation(p, u.name); }
    return p;
  }

  lutTexture(name) {
    const gl = this.gl;
    const data = new Uint8Array(256 * 4);
    for (let i = 0; i < 256; i++) {
      const c = colormapAt(name, i / 255);
      data.set([c[0] * 255, c[1] * 255, c[2] * 255, 255], i * 4);
    }
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }

  // geometry from a server payload (see app/results3d.py)
  upload(buf) {
    const gl = this.gl;
    const { header, pos, val, nrm, time, mask } = parsePayload(buf);
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const mkBuf = (data, loc, size) => {
      const b = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
      return b;
    };
    const bufs = [mkBuf(pos, 0, 3), mkBuf(mask, 2, 1)];
    if (val) bufs.push(mkBuf(val, 1, 1)); else { gl.disableVertexAttribArray(1); gl.vertexAttrib1f(1, 0); }
    if (nrm) bufs.push(mkBuf(nrm, 3, 3)); else { gl.disableVertexAttribArray(3); gl.vertexAttrib3f(3, 0, 0, 1); }
    if (time) bufs.push(mkBuf(time, 4, 2)); else gl.disableVertexAttribArray(4);
    gl.bindVertexArray(null);
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < pos.length; i += 3) {
      for (let k = 0; k < 3; k++) { const v = pos[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
    }
    return { vao, bufs, count: header.n, header, hasValues: !!val, hasNormals: !!nrm, hasTime: !!time, bbox: [mn, mx], min: header.min, max: header.max };
  }

  // flow-line ribbons in a section plane (built in planeflow.js)
  uploadFlow(r, header) {
    const gl = this.gl;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const mkBuf = (data, loc, size) => {
      const b = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
      return b;
    };
    const bufs = [mkBuf(r.pos, 0, 3), mkBuf(r.val, 1, 1), mkBuf(r.line, 4, 2)];
    gl.disableVertexAttribArray(2); gl.vertexAttrib1f(2, 0);
    gl.disableVertexAttribArray(3);
    gl.bindVertexArray(null);
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < r.pos.length; i += 3) {
      for (let k = 0; k < 3; k++) { const v = r.pos[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
    }
    for (const v of r.val) { if (v < lo) lo = v; if (v > hi) hi = v; }
    return { vao, bufs, count: r.n, header, hasValues: true, hasNormals: false, flow: true,
      bbox: r.n ? [mn, mx] : null, min: isFinite(lo) ? lo : 0, max: isFinite(hi) ? hi : 0 };
  }

  free(geom) {
    if (!geom || !this.gl) return;
    if (this.rec) { this.rec.deferred.push(geom); return; }      // the video may still need it
    geom.bufs.forEach((b) => this.gl.deleteBuffer(b));
    this.gl.deleteVertexArray(geom.vao);
  }

  target(name, w, h, kind) {
    // kind 'color': multisampled renderbuffer resolved into a texture; 'value': plain RGBA8 texture
    const gl = this.gl;
    let t = this.targets[name];
    if (t && t.w === w && t.h === h) return t;
    if (t) this.freeTarget(t);
    t = { w, h };
    const samples = kind === 'color' ? Math.min(4, gl.getParameter(gl.MAX_SAMPLES)) : 0;
    t.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    t.resolve = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.resolve);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.tex, 0);
    t.depth = gl.createRenderbuffer();
    if (samples > 0) {
      t.fb = gl.createFramebuffer();
      t.color = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, t.color);
      gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, gl.RGBA8, w, h);
      gl.bindRenderbuffer(gl.RENDERBUFFER, t.depth);
      gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, gl.DEPTH_COMPONENT24, w, h);
      gl.bindFramebuffer(gl.FRAMEBUFFER, t.fb);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, t.color);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, t.depth);
    } else {
      gl.bindRenderbuffer(gl.RENDERBUFFER, t.depth);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, t.depth);
      t.fb = t.resolve;
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.targets[name] = t;
    return t;
  }

  freeTarget(t) {
    const gl = this.gl;
    gl.deleteTexture(t.tex); gl.deleteRenderbuffer(t.depth);
    if (t.color) gl.deleteRenderbuffer(t.color);
    if (t.fb !== t.resolve) gl.deleteFramebuffer(t.fb);
    gl.deleteFramebuffer(t.resolve);
  }

  // ------------------------------------------------------------------ camera
  eye() {
    const c = this.cam;
    return [c.target[0] + c.dist * Math.cos(c.phi) * Math.cos(c.theta),
      c.target[1] + c.dist * Math.cos(c.phi) * Math.sin(c.theta),
      c.target[2] + c.dist * Math.sin(c.phi)];
  }

  viewProj(w, h) {
    const [mn, mx] = this.sceneBox();
    const radius = Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2 || 1;
    return M4.mul(M4.camProj(this.cam, this.cam.fov, w / h, radius, 1 / 1000), M4.lookAt(this.eye(), this.cam.target, [0, 0, 1]));
  }

  sceneBox() {
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const l of [...this.scenes.A, ...this.scenes.B]) {
      if (!l.geom || !l.geom.bbox) continue;
      for (const bb of this.mirrored(l.geom.bbox)) {
        for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], bb[0][k]); mx[k] = Math.max(mx[k], bb[1][k]); }
      }
    }
    return isFinite(mn[0]) ? [mn, mx] : this.box;
  }

  mirrored(bb) {
    if (!this.mirror) return [bb];
    const [a, c] = this.mirror;
    const m0 = bb[0].slice(), m1 = bb[1].slice();
    m0[a] = 2 * c - bb[1][a]; m1[a] = 2 * c - bb[0][a];
    return [bb, [m0, m1]];
  }

  // look at a box from a named direction (flow along +y, z up)
  setView(name, box) {
    const v = { iso: [-0.85, 0.5], top: [-Math.PI / 2, 1.5], side: [Math.PI, 0.03], front: [-Math.PI / 2, 0.08], rear: [Math.PI / 2, 0.08] }[name];
    if (v) { this.cam.theta = v[0]; this.cam.phi = v[1]; }
    this.fitBox(box || this.sceneBox());
  }

  fitBox([mn, mx], margin = 1.05) {
    this.cam.target = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2];
    const r = Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2 || 1;
    const aspect = (this.canvas.clientWidth || 1) / (this.canvas.clientHeight || 1);
    const half = Math.min(this.cam.fov / 2, Math.atan(Math.tan(this.cam.fov / 2) * aspect));
    this.cam.dist = r / Math.sin(half) * margin;
    this.redraw();
  }

  // ------------------------------------------------------------------ drawing
  redraw() { this.dirty = true; }

  frame() {
    this.raf = requestAnimationFrame(this.frame);
    if (this.offline) return;                   // recordFlight() renders meanwhile
    const now = performance.now() / 1000, dt = Math.min(0.1, now - (this.lastFrame || now));
    this.lastFrame = now;
    this.tickClocks(dt);
    if (this.flight) this.stepFlight(now);
    if (this.rec) this.logFrame(now);
    if (this.animating() || this.flight) this.dirty = true;
    if (!this.dirty || !this.gl) return;
    this.dirty = false;
    this.renderToScreen();
    if (this.onRender) this.onRender();
  }

  animating() {
    const sc = this.mix >= 1 && this.scenes.B.length ? [this.scenes.B] : this.compositeMode() ? [this.scenes.A, this.scenes.B] : [this.scenes.A];
    return sc.some((ls) => ls.some((l) => l.visible && l.geom && ((l.geom.flow && l.pulse) || (l.geom.hasTime && l.comet))));
  }

  // glow: the bloom buffer - everything solid in black, only the light trails
  drawLayers(layers, vp, eye, valueMode, edgeScale, bg, glow = false) {
    const gl = this.gl, p = this.prog, L = p.loc;
    gl.useProgram(p);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.BLEND);
    if (valueMode || glow) gl.clearColor(0, 0, 0, 0); else gl.clearColor(bg[0], bg[1], bg[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(L.uVP, false, vp);
    // parallel view: light from the viewing direction, not from a point in front of the car
    const t = this.cam.target;
    gl.uniform3fv(L.uEye, this.cam.ortho ? eye.map((v, k) => t[k] + (v - t[k]) * 1e4) : eye);
    gl.uniform1i(L.uMode, valueMode ? 1 : 0);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.lut); gl.uniform1i(L.uLut, 0);
    const models = [M4.ident()];
    if (this.mirror) {
      const [a, c] = this.mirror, m = M4.ident();
      m[a * 5] = -1; m[12 + a] = 2 * c;
      models.push(m);
    }
    gl.uniform1i(L.uFlow, 0);
    gl.uniform1i(L.uTrail, 0);
    gl.uniform1i(L.uBlack, glow ? 1 : 0);
    const onLight = bg[0] + bg[1] + bg[2] > 1.5 || (glow && this.onLight);
    if (!glow) this.onLight = onLight;
    gl.uniform1i(L.uOnLight, onLight ? 1 : 0);
    gl.uniform1f(L.uHaloR, 0);
    gl.uniform1f(L.uTime, (this.simTime != null ? this.simTime : performance.now() / 1000) * 0.9);
    const cometOn = (l) => this.cometOn(l, valueMode);
    // opaque layers first, then the flow lines blended on top (pulled towards the camera so
    // they never fight with the plane they lie in); not in the value buffers (picking / Δ)
    const flowPass = (l) => l.geom && l.geom.flow;
    const drawOne = (l, i) => {
      if (!l.geom || !l.visible) return;
      const colored = l.geom.hasValues && l.range;
      gl.uniform1i(L.uHasVal, colored ? 1 : 0);
      gl.uniform2f(L.uRange, colored ? l.range[0] : 0, colored ? l.range[1] : 1);
      gl.uniform3fv(L.uSolid, hexRgb(l.solid || '#1f2f8f'));
      gl.uniform1f(L.uLit, l.lit ? 1 : 0);
      gl.uniform1i(L.uHasNrm, l.geom.hasNormals ? 1 : 0);
      gl.uniform1i(L.uEdges, l.edges ? 1 : 0);
      gl.uniform4fv(L.uEdgeColor, l.edgeColor || [0.1, 0.1, 0.12, 0.55]);
      gl.uniform1f(L.uEdgeWidth, Math.max(0.6, this.edgePx * edgeScale));
      gl.uniform1f(L.uLayer, (i + 1) / 255);
      const travel = this.travelOn(l, valueMode);
      gl.uniform1i(L.uTravel, travel ? 1 : 0);
      if (travel) {
        gl.uniform1f(L.uAnimT, (this.clocks && this.clocks[l.key]) || 0);
        gl.uniform1f(L.uPulseLen, l.comet.period || 1);
        gl.uniform1f(L.uTMax, l.geom.header.tmax || 0.05);
      }
      if (l.geom.flow) {
        gl.uniform1i(L.uFlow, 1);
        gl.uniform1f(L.uOpacity, l.opacity != null ? l.opacity : 1);
        gl.uniform1i(L.uPulse, l.pulse && !this.shooting ? 1 : 0);
        gl.uniform1f(L.uPulseLen, l.pulseLen || 1);
        gl.uniform1f(L.uWide, l.wide || 1);
      }
      gl.bindVertexArray(l.geom.vao);
      for (const m of models) {
        gl.uniformMatrix4fv(L.uModel, false, m);
        gl.drawArrays(gl.TRIANGLES, 0, l.geom.count);
      }
      if (l.geom.flow) gl.uniform1i(L.uFlow, 0);
      gl.uniform1i(L.uTravel, 0);
    };
    // animated streamlines are light only (drawn below), no solid tubes
    layers.forEach((l, i) => { if (!flowPass(l) && !cometOn(l)) drawOne(l, i); });
    gl.uniform1i(L.uBlack, 0);
    // streamline light trails, added on top of the faint guide tubes (hidden behind the car)
    const trails = layers.filter((l) => l.visible && cometOn(l));
    if (trails.length) {
      gl.enable(gl.BLEND);
      // dark: light adds up; light background: laid over (premultiplied); glow buffer: summed
      if (onLight && !glow) gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); else gl.blendFunc(gl.ONE, gl.ONE);
      gl.depthMask(false);
      gl.uniform1i(L.uTrail, 1);
      for (const l of trails) {
        const a = l.comet;
        gl.uniform1i(L.uStyle, STYLES[a.style] || 0);
        gl.uniform1f(L.uAnimT, (this.clocks && this.clocks[l.key]) || 0);
        gl.uniform1f(L.uTail, a.tail != null ? a.tail : 0.75);
        gl.uniform1f(L.uTMax, l.geom.header.tmax || 0.05);
        gl.uniform1f(L.uGain, (glow ? 1.0 : 0.85) * (a.style === 'smoke' ? 0.55 : 1));
        gl.uniform1f(L.uGuide, glow ? 0.0 : (a.guide != null ? a.guide : 0.09) * (onLight ? 1.6 : 1));
        // smoke: a soft wider shell around the line
        gl.uniform1f(L.uHaloR, a.style === 'smoke' ? 2.5 * (l.geom.header.radius || 0.0005) : 0);
        const colored = l.geom.hasValues && l.range;
        gl.uniform1i(L.uHasVal, colored ? 1 : 0);
        gl.uniform2f(L.uRange, colored ? l.range[0] : 0, colored ? l.range[1] : 1);
        gl.uniform3fv(L.uSolid, hexRgb(l.solid || '#1f2f8f'));
        gl.uniform1f(L.uPulseLen, a.period || 1);
        gl.uniform1i(L.uLook, LOOKS[a.look] || 0);
        gl.bindVertexArray(l.geom.vao);
        for (const m of models) {
          gl.uniformMatrix4fv(L.uModel, false, m);
          gl.drawArrays(gl.TRIANGLES, 0, l.geom.count);
        }
      }
      gl.uniform1i(L.uTrail, 0);
      gl.uniform1f(L.uHaloR, 0);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }
    if (!valueMode && !glow && layers.some(flowPass)) {
      gl.enable(gl.BLEND);
      gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false);
      gl.enable(gl.POLYGON_OFFSET_FILL);
      gl.polygonOffset(-2, -64);
      layers.forEach((l, i) => { if (flowPass(l)) drawOne(l, i); });
      gl.disable(gl.POLYGON_OFFSET_FILL);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }
    gl.bindVertexArray(null);
  }

  // render a scene ('A' / 'B') into a named target, colour or encoded values
  renderTarget(name, scene, w, h, valueMode, edgeScale, bg) {
    const gl = this.gl;
    const t = this.target(name, w, h, valueMode ? 'value' : 'color');
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.fb);
    gl.viewport(0, 0, w, h);
    this.drawLayers(this.scenes[scene], this.viewProj(w, h), this.eye(), valueMode, edgeScale, bg);
    if (t.fb !== t.resolve) {
      gl.bindFramebuffer(gl.READ_FRAMEBUFFER, t.fb);
      gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, t.resolve);
      gl.blitFramebuffer(0, 0, w, h, 0, 0, w, h, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    }
    return t;
  }

  composite(mode, w, h, edgeScale, bg, tag = '') {
    const gl = this.gl;
    const a = this.renderTarget(tag + 'cA', 'A', w, h, false, edgeScale, bg);
    const b = this.renderTarget(tag + 'cB', 'B', w, h, false, edgeScale, bg);
    let va = null, vb = null;
    if (mode === 3) {
      va = this.renderTarget(tag + 'vA', 'A', w, h, true, edgeScale, bg);
      vb = this.renderTarget(tag + 'vB', 'B', w, h, true, edgeScale, bg);
    }
    return () => {
      const p = this.comp, L = p.loc;
      gl.useProgram(p);
      gl.disable(gl.DEPTH_TEST);
      gl.viewport(0, 0, w, h);
      const bind = (unit, tex, loc) => { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(loc, unit); };
      bind(0, a.tex, L.uA); bind(1, b.tex, L.uB);
      bind(2, (va || a).tex, L.uVA); bind(3, (vb || b).tex, L.uVB); bind(4, this.diffLut, L.uDiffLut);
      gl.uniform1i(L.uMode, mode);
      gl.uniform1f(L.uMix, this.mix); gl.uniform1f(L.uWipe, this.wipe); gl.uniform1f(L.uDiffScale, this.diffScale * 3);
      gl.bindVertexArray(this.emptyVao);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindVertexArray(null);
    };
  }

  size() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(this.canvas.clientWidth * dpr)), h = Math.max(1, Math.round(this.canvas.clientHeight * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    return [w, h, dpr];
  }

  compositeMode() {
    if (this.mode === 'diff' && this.scenes.B.length) return 3;
    if (this.mode === 'wipe' && this.scenes.B.length) return 2;
    if (this.mix > 0 && this.mix < 1 && this.scenes.B.length) return 1;
    return 0;
  }

  // animated streamlines drawn as light (all styles but travel)
  cometOn(l, valueMode = false) { return this.animOn(l, valueMode) && l.comet.style !== 'travel'; }
  travelOn(l, valueMode = false) { return this.animOn(l, valueMode) && l.comet.style === 'travel'; }
  animOn(l, valueMode) { return !valueMode && !this.shooting && !!l.comet && !!l.geom && l.geom.hasTime; }

  renderToScreen() {
    const gl = this.gl;
    const [w, h] = this.size();
    const edgeScale = h / 900;
    const mode = this.compositeMode();
    if (mode === 0) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, w, h);
      const scene = this.mix >= 1 && this.scenes.B.length ? 'B' : 'A';
      const layers = this.scenes[scene], vp = this.viewProj(w, h), eye = this.eye();
      // light trails need the dark: a deep black stage, also in the light theme
      const lit = layers.some((l) => l.visible && this.cometOn(l));
      const dark = this.background[0] + this.background[1] + this.background[2] < 1.5;
      this.drawLayers(layers, vp, eye, false, edgeScale, lit && dark ? [0.02, 0.02, 0.028] : this.background);
      const glow = Math.max(0, ...layers.filter((l) => l.visible && this.cometOn(l)).map((l) => l.comet.glow != null ? l.comet.glow : 1));
      if (lit && glow > 0) this.bloom(layers, vp, eye, w, h, edgeScale, glow);
      return;
    }
    const draw = this.composite(mode, w, h, edgeScale, this.background);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    draw();
  }

  // glow around the light trails: trails alone (solid things in black, so the car hides them) at
  // half resolution, blurred twice with a growing radius, added onto the screen
  bloom(layers, vp, eye, w, h, edgeScale, strength = 1, out = null, spread = 1, tag = '') {
    const gl = this.gl;
    const gw = Math.max(1, w >> 1), gh = Math.max(1, h >> 1);
    const a = this.target(tag + 'glowA', gw, gh, 'value'), b = this.target(tag + 'glowB', gw, gh, 'value');
    for (const t of [a, b]) {
      gl.bindTexture(gl.TEXTURE_2D, t.tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, a.fb);
    gl.viewport(0, 0, gw, gh);
    this.drawLayers(layers, vp, eye, false, edgeScale, [0, 0, 0], true);
    const p = this.blur, L = p.loc;
    gl.useProgram(p);
    gl.disable(gl.DEPTH_TEST);
    gl.bindVertexArray(this.emptyVao);
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(L.uT, 0);
    const pass = (src, dst, dx, dy, gain) => {
      dx *= spread; dy *= spread;
      gl.bindFramebuffer(gl.FRAMEBUFFER, dst ? dst.fb : out);
      gl.viewport(0, 0, dst ? gw : w, dst ? gh : h);
      gl.bindTexture(gl.TEXTURE_2D, src.tex);
      gl.uniform2f(L.uDir, dx / gw, dy / gh);
      gl.uniform1f(L.uGain, gain);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    };
    pass(a, b, 1, 0, 1); pass(b, a, 0, 1, 1);
    pass(a, b, 2.5, 0, 1); pass(b, a, 0, 2.5, 1);
    gl.enable(gl.BLEND);
    if (this.onLight) gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); else gl.blendFunc(gl.ONE, gl.ONE);
    pass(a, null, 0, 0, (this.onLight ? 1.1 : 1.8) * strength);
    gl.disable(gl.BLEND);
    gl.bindVertexArray(null);
  }

  // value under the mouse: {layer index, encoded value} or null
  pick(cx, cy, scene = 'A') {
    if (!this.gl) return null;
    const gl = this.gl;
    const [w, h, dpr] = this.size();
    const t = this.renderTarget('pick', scene, w, h, true, h / 900, this.background);
    const px = new Uint8Array(4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.resolve);
    gl.readPixels(Math.round(cx * dpr), Math.round(h - cy * dpr - 1), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (!px[3]) return null;
    const layer = Math.round(px[3]) - 1;
    if (px[2] < 128) return { layer, value: null };
    const e = (px[0] * 256 + px[1]) / 65535;
    return { layer, t: e * 3 - 1 };
  }

  // largest image the GPU can render, same aspect
  fitMax(w, h) {
    const max = this.gl.getParameter(this.gl.MAX_RENDERBUFFER_SIZE);
    if (w > max || h > max) { const s = max / Math.max(w, h); w = Math.floor(w * s); h = Math.floor(h * s); }
    return [w, h];
  }

  // offscreen rendering at any resolution with a light background; returns a PNG data URL
  screenshot(w, h, opts = {}) {
    const gl = this.gl;
    [w, h] = this.fitMax(w, h);
    const fb = this.shotFrame(w, h, opts);
    const px = new Uint8Array(w * h * 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.freeShot();
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(w, h);
    const row = w * 4;
    for (let y = 0; y < h; y++) img.data.set(px.subarray((h - 1 - y) * row, (h - y) * row), y * row);
    for (let i = 3; i < img.data.length; i += 4) img.data[i] = 255;
    ctx.putImageData(img, 0, 0);
    this.redraw();
    return c.toDataURL('image/png');
  }

  // big offscreen buffers are not kept
  freeShot() {
    for (const k of Object.keys(this.targets)) if (k[0] === 'x') { this.freeTarget(this.targets[k]); delete this.targets[k]; }
  }

  // renders the current view offscreen (w × h, own background) like a screenshot; returns the
  // framebuffer holding the image (bottom row first)
  shotFrame(w, h, opts = {}) {
    const gl = this.gl;
    const bg = opts.background || [1, 1, 1];
    const edgeScale = h / 900;
    const mode = opts.mode != null ? opts.mode : this.compositeMode();
    const layers = this.scenes[opts.scene || 'A'];
    // animated streamlines: the image shows the frame on screen right now (light trails with
    // their glow, travel half grown); otherwise still flow lines without the pulses
    const anim = mode === 0 && layers.some((l) => l.visible && this.animOn(l));
    this.shooting = !anim;
    let fb;
    if (anim) {
      const lit = layers.some((l) => l.visible && this.cometOn(l));
      const dark = bg[0] + bg[1] + bg[2] < 1.5;
      const t = this.renderTarget('xshot', opts.scene || 'A', w, h, false, edgeScale, lit && dark ? [0.02, 0.02, 0.028] : bg);
      const glow = Math.max(0, ...layers.filter((l) => l.visible && this.cometOn(l)).map((l) => l.comet.glow != null ? l.comet.glow : 1));
      // same glow size relative to the image as on screen
      if (lit && glow > 0) this.bloom(layers, this.viewProj(w, h), this.eye(), w, h, edgeScale, glow, t.resolve, h / this.size()[1], 'x');
      fb = t.resolve;
    } else if (mode === 0) {
      fb = this.renderTarget('xshot', opts.scene || 'A', w, h, false, edgeScale, bg).resolve;
    } else {
      const draw = this.composite(mode, w, h, edgeScale, bg, 'x');
      const out = this.target('xshotOut', w, h, 'value');
      gl.bindFramebuffer(gl.FRAMEBUFFER, out.fb);
      draw();
      fb = out.resolve;
    }
    this.shooting = false;
    return fb;
  }

  // ------------------------------------------------------------------ video
  // videos are rendered like screenshots (w × h, own background), encoded to H.264 with WebCodecs
  // at 60 fps and written as MP4 (mp4mux.js). Always rendered frame by frame offline, exactly 1/60 s
  // apart, however slow the GPU is: a flight directly, a live recording from its log after Stop.
  async beginRecording(w, h, opts) {
    if (!window.VideoEncoder) throw new Error('This browser cannot encode videos (WebCodecs missing).');
    [w, h] = this.fitMax(w, h);
    w &= ~1; h &= ~1;
    let cfg = null;
    for (const codec of ['avc1.64002a', 'avc1.4d002a', 'avc1.42002a', 'avc1.640033']) {
      const c = { codec, width: w, height: h, bitrate: Math.round(w * h * 60 * 0.2), framerate: 60, avc: { format: 'avc' } };
      try { if ((await VideoEncoder.isConfigSupported(c)).supported) { cfg = c; break; } } catch (e) { /* next */ }
    }
    if (!cfg) throw new Error('No H.264 video encoder available.');
    const r = { w, h, opts, samples: [], avcC: null, err: null, n: 0, t0: null, time: 0, total: null,
      log: [], deferred: [], px: new Uint8Array(w * h * 4) };
    r.enc = new VideoEncoder({
      output: (chunk, meta) => {
        const desc = meta && meta.decoderConfig && meta.decoderConfig.description;
        if (desc && !r.avcC) r.avcC = new Uint8Array(desc.buffer ? desc.buffer.slice(desc.byteOffset, desc.byteOffset + desc.byteLength) : desc.slice(0));
        const d = new Uint8Array(chunk.byteLength);
        chunk.copyTo(d);
        r.samples.push({ d, ts: chunk.timestamp, key: chunk.type === 'key' });
      },
      error: (e) => { r.err = e; },
    });
    r.enc.configure(cfg);
    this.rec = r;
    this.redraw();
  }

  // seconds recorded so far (flight: video time) and the length of a flight
  recording() { return this.rec ? { t: this.rec.time, total: this.rec.total, rendering: !!this.rec.rendering } : null; }

  // one frame: rendered like a screenshot, flipped (GL rows are bottom first) into a plain buffer
  recRender(r) {
    const gl = this.gl;
    const src = this.shotFrame(r.w, r.h, r.opts);
    const t = this.target('xflip', r.w, r.h, 'value');
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, src);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, t.fb);
    gl.blitFramebuffer(0, 0, r.w, r.h, 0, r.h, r.w, 0, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.fb);
  }

  recEncode(r, ts) {
    const f = new VideoFrame(r.px, { format: 'RGBX', codedWidth: r.w, codedHeight: r.h, timestamp: ts, duration: Math.round(1e6 / 60) });
    r.enc.encode(f, { keyFrame: r.n % 120 === 0 });
    f.close();
    r.n++;
  }

  // live recording, once per screen frame: only notes what is shown (camera, animation clocks,
  // scene) - the video is rendered from this log after Stop, so the view stays fluid meanwhile
  logFrame(now) {
    const r = this.rec, c = this.cam;
    if (r.t0 == null) r.t0 = now;
    r.time = now - r.t0;
    r.log.push({ t: r.time, p: [c.target[0], c.target[1], c.target[2], c.theta, c.phi, Math.log(c.dist), c.fov], ortho: c.ortho,
      clocks: Object.assign({}, this.clocks), A: this.scenes.A, B: this.scenes.B, mirror: this.mirror, mode: this.mode, mix: this.mix, wipe: this.wipe });
  }

  // renders the log offline: exactly 60 frames per second, the camera between the logged poses
  // (lightly smoothed, so the steps of the mouse do not show)
  async renderLog(r) {
    const log = r.log, n = log.length;
    if (n < 2) return this.finishRecording();
    const N = Math.round(log[n - 1].t * 60);
    // resample to the 60 fps grid
    const at = [];
    let i = 0;
    for (let k = 0; k <= N; k++) {
      const t = k / 60;
      while (i < n - 2 && log[i + 1].t <= t) i++;
      const a = log[i], b = log[i + 1], s = Math.max(0, Math.min(1, (t - a.t) / ((b.t - a.t) || 1)));
      at.push({ a, b, s, p: a.p.map((v, m) => v + (b.p[m] - v) * s) });
    }
    const poses = at.map((_, k) => {
      const h = Math.min(2, k, N - k);
      return at[k].p.map((_v, m) => { let sum = 0; for (let q = k - h; q <= k + h; q++) sum += at[q].p[m]; return sum / (2 * h + 1); });
    });
    r.rendering = true;
    r.total = N / 60;
    r.time = 0;
    const gl = this.gl;
    const end = { cam: Object.assign({}, this.cam, { target: this.cam.target.slice() }), clocks: this.clocks, A: this.scenes.A, B: this.scenes.B,
      mirror: this.mirror, mode: this.mode, mix: this.mix, wipe: this.wipe };
    this.offline = true;
    const base = performance.now() / 1000;
    try {
      for (let k = 0; k <= N && !r.cancel && !r.err; k++) {
        const { a, b, s } = at[k], v = poses[k];
        Object.assign(this.cam, { target: [v[0], v[1], v[2]], theta: v[3], phi: v[4], dist: Math.exp(v[5]), fov: v[6], ortho: a.ortho });
        const clocks = {};
        for (const key of Object.keys(a.clocks)) clocks[key] = key in b.clocks ? a.clocks[key] + (b.clocks[key] - a.clocks[key]) * s : a.clocks[key];
        this.clocks = clocks;
        this.scenes.A = a.A; this.scenes.B = a.B;
        this.mirror = a.mirror; this.mode = a.mode; this.mix = a.mix; this.wipe = a.wipe;
        this.simTime = base + k / 60;
        this.recRender(r);
        gl.readPixels(0, 0, r.w, r.h, gl.RGBA, gl.UNSIGNED_BYTE, r.px);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        this.recEncode(r, Math.round(k * 1e6 / 60));
        r.time = k / 60;
        if (k % 3 === 0) this.renderToScreen();
        while (r.enc.encodeQueueSize > 3) await new Promise((res) => setTimeout(res, 2));
        await new Promise((res) => setTimeout(res, 0));
      }
    } finally {
      this.offline = false;
      this.simTime = null;
      this.lastFrame = null;
      Object.assign(this.cam, end.cam);
      this.clocks = end.clocks;
      this.scenes.A = end.A; this.scenes.B = end.B;
      this.mirror = end.mirror; this.mode = end.mode; this.mix = end.mix; this.wipe = end.wipe;
    }
    return this.finishRecording();
  }

  // camera flight, rendered offline at exactly 60 fps (animations advance 1/60 s per frame);
  // the screen shows a preview meanwhile. Resolves to the video when done or cancelled.
  async recordFlight(flight) {
    const r = this.rec, gl = this.gl;
    r.flight = true;
    r.total = flightLength(flight);
    this.offline = true;
    const base = performance.now() / 1000;
    try {
      for (let k = 0; !r.cancel && !r.err; k++) {
        const t = k / 60;
        if (t > r.total + 1e-6) break;
        this.setCam(flightCam(flight, t));
        if (k) this.tickClocks(1 / 60);
        this.simTime = base + t;
        this.recRender(r);
        gl.readPixels(0, 0, r.w, r.h, gl.RGBA, gl.UNSIGNED_BYTE, r.px);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        this.recEncode(r, Math.round(k * 1e6 / 60));
        r.time = t;
        if (k % 3 === 0) this.renderToScreen();
        while (r.enc.encodeQueueSize > 3) await new Promise((res) => setTimeout(res, 2));
        await new Promise((res) => setTimeout(res, 0));
      }
    } finally {
      this.offline = false;
      this.simTime = null;
      this.lastFrame = null;
    }
    return this.finishRecording();
  }

  // ends a live recording; resolves to the video (Blob)
  stopRecording() {
    const r = this.rec;
    if (!r) return Promise.resolve(null);
    if (r.flight || r.rendering) { r.cancel = true; return Promise.resolve(null); }   // the running render delivers it
    return this.renderLog(r);
  }

  // a live recording that can no longer be rendered (the tab is closing)
  abortRecording() {
    const r = this.rec;
    if (!r) return;
    this.rec = null;
    try { r.enc.close(); } catch (e) { /* already closed */ }
    r.deferred.forEach((g) => this.free(g));
    this.freeShot();
  }

  async finishRecording() {
    const r = this.rec;
    this.rec = null;
    r.deferred.forEach((g) => this.free(g));
    this.freeShot();
    this.redraw();
    if (r.enc.state !== 'closed') { try { await r.enc.flush(); } catch (e) { r.err = r.err || e; } r.enc.close(); }
    if (r.err && !r.samples.length) throw r.err;
    if (!r.samples.length || !r.avcC) return null;
    return mp4(r.samples, r.avcC, r.w, r.h);
  }

  tickClocks(dt) {
    this.clocks = this.clocks || {};
    for (const l of [...this.scenes.A, ...this.scenes.B]) {
      if (l.comet && l.key) this.clocks[l.key] = (this.clocks[l.key] || 0) + dt * 0.9 * (l.comet.speed || 1);
    }
  }

  // ------------------------------------------------------------------ camera flight
  // live flight (no recording): `hold` s at each camera, `move` s (eased) to the next
  fly(cams, move, hold, done) {
    this.flight = { cams: cams.map((c) => Object.assign({}, c, { target: c.target.slice() })), move, hold, t0: performance.now() / 1000, done };
    this.redraw();
  }

  stepFlight(now) {
    const f = this.flight, t = now - f.t0;
    this.setCam(flightCam(f, t));
    if (t >= flightLength(f)) { this.flight = null; if (f.done) f.done(); }
  }

  setCam(c) {
    Object.assign(this.cam, c, { target: c.target.slice() });
    if (this.onCamera) this.onCamera();
  }

  // ------------------------------------------------------------------ mouse
  bindMouse() {
    const c = this.canvas;
    let drag = null;
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    c.addEventListener('mousedown', (e) => {
      drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey || e.button === 1 };
      e.preventDefault();
    });
    this._move = (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      drag.x = e.clientX; drag.y = e.clientY;
      if (drag.pan) {
        const s = this.cam.dist * 0.0012;
        const t = this.cam.theta, p = this.cam.phi;
        const right = [-Math.sin(t), Math.cos(t), 0];
        const up = [-Math.sin(p) * Math.cos(t), -Math.sin(p) * Math.sin(t), Math.cos(p)];
        for (let k = 0; k < 3; k++) this.cam.target[k] += (-dx * right[k] + dy * up[k]) * s;
      } else {
        this.cam.theta -= dx * 0.008;
        this.cam.phi = Math.max(-1.55, Math.min(1.55, this.cam.phi + dy * 0.008));
      }
      this.redraw();
      if (this.onCamera) this.onCamera();
    };
    this._up = () => { drag = null; };
    window.addEventListener('mousemove', this._move);
    window.addEventListener('mouseup', this._up);
    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cam.dist *= Math.exp(e.deltaY * 0.0012);
      this.redraw();
      if (this.onCamera) this.onCamera();
    }, { passive: false });
    this.dragging = () => !!drag;
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('mousemove', this._move);
    window.removeEventListener('mouseup', this._up);
    if (this.ro) this.ro.disconnect();
    if (!this.gl) return;
    for (const l of [...this.scenes.A, ...this.scenes.B]) if (l.geom) this.free(l.geom);
    for (const t of Object.values(this.targets)) this.freeTarget(t);
    const ext = this.gl.getExtension('WEBGL_lose_context');
    if (ext) ext.loseContext();
  }
}

// ---------------------------------------------------------------- camera flight
// The cameras are joined by one smooth curve (Catmull-Rom spline through target, angles, log
// distance and field of view), so the camera glides through each view without a kink.
// Pause 0: one continuous flight - speeds up at the start, constant speed, slows down only at
// the end. Pause > 0: eases into each view, waits, eases out again.
function flightKeys(f) {
  if (f._keys) return f._keys;
  let theta = f.cams[0].theta;
  f._keys = f.cams.map((c, i) => {
    if (i) {
      let d = (c.theta - f.cams[i - 1].theta) % (2 * Math.PI);     // the short way round
      if (d > Math.PI) d -= 2 * Math.PI;
      if (d < -Math.PI) d += 2 * Math.PI;
      theta += d;
    }
    return [c.target[0], c.target[1], c.target[2], theta, c.phi, Math.log(c.dist), c.fov];
  });
  return f._keys;
}

// camera on the curve: segment i (from view i to i+1), s 0..1
function splineCam(f, i, s) {
  const K = flightKeys(f), n = K.length;
  const P = (k) => K[Math.max(0, Math.min(n - 1, k))];
  const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
  const s2 = s * s, s3 = s2 * s;
  const v = p1.map((_, k) => 0.5 * (2 * p1[k] + (p2[k] - p0[k]) * s + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * s2
    + (3 * p1[k] - p0[k] - 3 * p2[k] + p3[k]) * s3));
  const a = f.cams[Math.min(n - 1, i)], b = f.cams[Math.min(n - 1, i + 1)];
  return Object.assign({}, a, {
    target: [v[0], v[1], v[2]], theta: v[3], phi: Math.max(-1.55, Math.min(1.55, v[4])),
    dist: Math.exp(v[5]), fov: v[6], ortho: s < 0.5 ? a.ortho : b.ortho,
  });
}

function flightLength(f) {
  const n = f.cams.length;
  return (f.hold > 0 ? n * f.hold : 0) + (n - 1) * f.move;
}

// camera of a flight at time t
function flightCam(f, t) {
  const n = f.cams.length;
  if (!(f.hold > 0)) {
    // continuous: smooth start and end (a fifth of the time each), constant speed in between
    const T = flightLength(f), x = Math.max(0, Math.min(1, t / T)), r = Math.min(0.2, 0.5);
    const vmax = 1 / (1 - r);
    const p = x < r ? vmax * x * x / (2 * r) : x > 1 - r ? 1 - vmax * (1 - x) * (1 - x) / (2 * r) : vmax * (x - r / 2);
    const u = p * (n - 1), i = Math.min(n - 2, Math.floor(u));
    return splineCam(f, i, u - i);
  }
  for (let i = 0; i < n - 1; i++) {
    if (t < f.hold) return f.cams[i];
    t -= f.hold;
    if (t < f.move) { const s = t / f.move; return splineCam(f, i, s * s * (3 - 2 * s)); }
    t -= f.move;
  }
  return f.cams[n - 1];
}
