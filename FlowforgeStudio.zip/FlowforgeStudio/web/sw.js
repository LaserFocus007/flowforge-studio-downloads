// Service worker of the installed app: when the window is opened (Start menu, taskbar) while the
// local Flowforge Studio server is not running, show the start page instead of the browser's error page.
// It starts the server through the flowforgestudio: link and reconnects. Nothing else is cached.

const CACHE = 'flowforgestudio-start-v2';
const FILES = ['/offline.html', '/img/icon-192.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys()
    .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  if (e.request.mode !== 'navigate') return;          // API and files: always the network
  e.respondWith(fetch(e.request).catch(() => caches.match('/offline.html')));
});
