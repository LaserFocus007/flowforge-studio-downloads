# Changelog

All changes to Flowforge Studio since the tutorials (01–04, 24 Oct 2026) were created.
The tutorials describe the state *before* the entries below.

## Unreleased

## 1.2.1 (20.11.2026)

### Added
- **Deep-dive tutorials in the app (World)** - the new *Tutorials* button in the top bar opens
  tutorials 03 (Settings & Adjustments) and 04 (Theory) in their own window: continuous scrolling,
  contents with the current section marked, page previews, full-text search with highlights and a
  result list, clickable links of the contents pages, zoom (page width, whole page, 50-250 %, Ctrl +
  wheel) and keyboard navigation. The window is moved by its top bar, like the main window. Each
  tutorial reopens where you stopped reading. Every page carries the licensee and the machine code as a
  very faint watermark; printing and saving are blocked. The tutorials ship
  only as an encrypted pack (`content/deepdives.ffpack`, built by `FlowforgeStudio_vendor/build_deepdives.py`),
  never as a PDF; pages are decrypted one at a time and only with a World licence on this PC (new
  feature `deepdives`). Regional and National see what the tutorials contain and that they come with
  World. `make_release.py` stops if the pack is missing or older than the PDFs, or if a deep-dive PDF
  ends up in the release.

## 1.2.0 (20.11.2026)

### Added
- **Swing per cell in the Results tab** - new colour fields *Pressure swing* (car surface and planes) and *Velocity swing* (planes, iso-surfaces): how much the flow swings in every cell over the iterations (from iteration 150 on), so the place where the flow does not settle is visible. Recorded during the solve with an OpenFOAM `fieldAverage` object (`system/flowforgeSwing`), switched on per simulation in its Settings tab -> *Run control* -> *Swing per cell* (off by default, a few % solve time and about 90 MB per million cells). Only runs made with the option on have these fields.
- **Upgrade the licence in the settings** - "Upgrade licence" (Settings > Licence) takes a new key
  for the same PC and switches to it without reinstalling: Regional to National or World, National
  to World, or a renewed key of the same variant. A key of a lower variant than the current one is
  refused. Simulations and settings stay as they are.
- **Notice of a new version** - once at start and then once a day the app reads a small
  `version.json` from the public download repository and, if the version there is higher, shows
  a dialog with the download link (once per version) and a note in the settings. Notification
  only, nothing is installed. Nothing about the user or PC is sent. Can be switched off in the
  settings ("Look for a new version"). EULA section 9 (Datenschutz) names this one exception.
- **Variants Regional, National and World** - the variant is part of the licence key and sets the
  colour of the app and what is available. Regional: results as pictures, no force values, no
  comparison. National: forces and comparison, without *Drag by part* and *Balance*. World:
  everything, plus batch screenshots, video recording and the team colour. Regional and National
  run 3 simulations per day (full and solve-only runs, unless they fail or are aborted); further
  runs wait in the queue and start on the next day. Keys issued earlier count as World.
- **Python is included** in the download, it no longer has to be installed.
- **Forces tab: balance & centre of pressure** – new card below *Drag by part*, for three cases
  chosen with *Standstill* / *Coasting* (no thrust, slowing down by the drag) / *Under
  thrust* (buttons, or click a column of the table):
  - Left: the car data (mass without cartridge, default 48.5 g; centre of mass behind the nose
    and its height - the same for all cases) and the values of the chosen case, one field per
    property and stored per case: cartridge mass (defaults 20 / 12 / 17 g; it sits in the CO2
    chamber and moves the centre of mass), speed for the air forces (defaults 0 / 20 / 5 m/s;
    scaled with the square of the speed), and under thrust the thrust
    (default 8 N), its height (default: axis of the CO2 chamber) and optionally its angle to
    the ground (acting at the nozzle). Saved with the simulation while typing; variants take
    them from their origin, new ones from the last values entered.
  - Right: side view with the car's silhouette, the line of action of the air force (drag +
    lift), thrust, weight, inertial force at the centre of mass and the load on each wheel pair
    (red = lifts off).
  - Centre of pressure for side wind as the centre of the side view area (the usual rule of
    thumb; purple diamond) and its distance to the centre of mass: green when it is behind it
    (stable), red in front of it (unstable), with a note that it is an approximation.
  - Table for all three cases: front / rear wheel load (and % of standing still), vertical air
    force per axle, speed and acceleration, mass and centre of mass, CoP to CoM. Wheel loads
    from the balance of forces and pitching moments (acceleration as inertial force at the
    centre of mass; tether line and rolling resistance left out).
  - Uses the moments OpenFOAM already writes with the forces, so it works for existing runs too.
- **Forces tab: drag and lift by part** – new card below the two charts: one row per part (nose,
  wheels, wing, body, ...) sorted by size, with a bar split into pressure and friction, mean,
  share of the whole car, swings (red = unsteady flow at this part) and a small signal curve over
  the averaging window. Click a row for the full curve of that part with its running mean.
  *Compare with …* adds the difference to another simulation per part and for the whole car:
  green / red when it is larger than twice the combined uncertainty of both runs (a real
  difference), grey "≈" when it is within the noise. Shows at a glance whether a gain comes
  from the part that was changed or from a swing somewhere else (e.g. the front wheel).
  - Recorded automatically from the next solve on: before solving, `system/flowforgeParts` (one
    forces object per car patch, every 5th iteration, about 5 % solve time) is written and
    included in `controlDict`. Cases with their own force objects for parts are left alone (and
    read as well). Off switch: Settings → *Force evaluation* → *Forces per part* (new config key
    `part_forces`).
- **Record videos in the Results tab** - *Record* next to *Screenshot*: records the 3D view as an
  MP4 video (Full HD, 60 fps, H.264 via WebCodecs, own MP4 writer), rendered like a screenshot (background white / black from
  the screenshot menu, no buttons or colour bar), animated streamlines included. Move the camera
  meanwhile (planes moved during the recording are recorded too); the recording only notes what is
  shown, and after *Stop* the video is rendered frame by frame at exactly 60 fps (*Rendering 0:03 /
  0:09* on the button, another click ends it early and saves what is done) and saved to the
  Screenshots folder. The camera is lightly smoothed, so the steps of the mouse do not show.
  *Flight through saved views...* (arrow next to *Record*): tick saved views in the order of the
  flight, set flight and pause time and optionally back to the first view; the camera flies
  along one smooth curve through all views (spline, angles the short way round) and the recording
  stops by itself. Pause 0 (default) = one continuous flight that glides through the views and
  only speeds up at the start and slows down at the end; pause > 0 = stops at each view. The flight is
  rendered frame by frame offline, exactly 1/60 s apart (animations included), so the video is
  smooth at 60 fps however slow the GPU is; the button shows the progress (video time / length). Only the camera
  moves, the objects stay as they are. Leaving the tab while rendering saves what is done; leaving it
  during a recording before *Stop* discards it. Needs a
  restart of Flowforge Studio once (new server endpoint); before that the video is downloaded.
  *Preview* in the flight dialog flies through the views live in the viewer, with the program around
  it and without making a video; clicking the view or scrolling ends the flight.

### Fixed
- **Meshing no longer stops with "Multiple outside loops"** - when two parts almost touch (e.g. a halo resting on the body), fine meshes can trap single cells in the narrow gap between them; snappyHexMesh (OpenFOAM 5) then aborted just before adding the wall layers. Meshing now removes these trapped cells (no flow passes through them) and adds the layers again on the snapped mesh. The run log notes how many cells were removed; geometry and settings stay unchanged.
- **Dashboard keeps its scroll position** - ticking a box in the leaderboard (or sorting, or new results
  arriving) rebuilt the page and jumped back to the top; the position is now restored after each rebuild.
- **A running simulation no longer dies when Windows briefly locks a status file** - the heartbeat of the runner could fail with "Access is denied" and took the whole run down without writing any results. Server and runner now use separate temporary files, and a locked file is retried for up to 5 s.
- **Opening a simulation no longer waits for the Results preparation of another one** - while the
  server prepared the Results tab of a simulation in the background (about 25 s), everything else
  was slowed down badly: opening the next simulation or its Forces tab took 5 to 17 s instead of
  0.1 to 0.5 s - exactly when clicking through two or three simulations to compare them. The
  preparation now runs in small pieces, pauses while any other request is answered and stops
  when another simulation is to be prepared; it starts after 2.5 s on a simulation (was 1.2 s).
  Measured with a preparation running: Forces data in 0.015 s (median) and at most 0.5 s, before
  0.5 s (median) and up to 12 s. The preparation itself takes as long as before.
- **Forces tab no longer freezes the program** - the side view of the balance card was built as one
  canvas path of about 80 000 triangles, which blocked the page for more than 10 seconds each time it
  was drawn. It is now a bitmap (0.2 mm) filled once in well under 0.1 s. The air-force line and arrow
  are left out when the speed is 0.
- **Lineage card** - long simulation names wrap inside the card instead of running into the Notes card.
- **Tooltips stay on screen** - the tooltip of the Drag progress chart and the value shown when hovering
  the Results view switch to the other side of the cursor near the right and bottom edges.
- **Pages use the full window width** - the content was limited to 1500 px, which left wide empty
  margins on large screens with the simulation list hidden.

### Changed
- **New Flowforge CFD logo and app icon** - the top bar shows the new "F" mark of the Flowforge CFD
  brand (the front part follows the light / dark theme), with "by evolut1on simulations" in orange.
  New program icon (white F with orange F on a dark tile) for the browser tab, the installed app,
  notifications and the start page. Installed apps pick up the new icon after the next start.
- **Brand fonts** - text in Ubuntu, headings (titles, card and tab titles, key figures) in Oxanium,
  as on flowforgecfd.com. Both fonts are included in `web/fonts/` with their licences (see NOTICE.md).
- **Drag progress tooltip** - shows drag, uncertainty (± drag), cells, iterations and simulation time
  (time spent solving, all runs together) instead of the date.
- **Remaining time is an estimate of the automatic stop** - it used to count down to endTime (e.g. 2000
  iterations), although the run stops as soon as the mean drag is known to the set uncertainty. Now,
  with the stop on *uncertainty of the mean drag* and averaging *auto*, the time left is estimated from
  the data: the uncertainty falls with 1/sqrt(averaged iterations), so the iterations still missing
  follow from the current uncertainty, the target and the minimum to average (median of the judgement
  at six points of the run, so it does not jump). It is shown as `~1h 05m` (tooltip: expected stop
  iteration, current uncertainty, latest end at endTime) in the Remaining field, the sidebar indicator
  and the Overview; the estimate is capped by endTime. The progress bar follows: its end is the
  expected stop, not endTime (so it moves when the estimate changes). While it cannot be predicted (too few iterations
  averaged, no stop criterion, signal-swings stop, fixed averaging window) it shows `up to 1h 49m` (the
  endTime limit). Backtest on finished runs: usually within about +-30 % after 300-400 iterations, far
  off during the first 150-250.
- **Part names without `wall_` and without `left`** - the parts are now called `body`, `CO2`,
  `front_wheel`, `front_wheel_support`, `halo_helmet`, `hubcaps`, `nose_cone`, `rear_wheel`,
  `rear_wheel_support` and `rear_wing` (before: `wall_body`, `wall_front_left_wheel`, ...). The program
  no longer assumes any prefix: names are shown as they are, the Mesh tab's *Car* group is taken from
  the STLs (the same rule as in the Results tab), the car's bounding box uses all STLs. STL files for
  new simulations are matched by these names (`body.STL` -> `body.stl`).
  **All existing simulations were converted once** (also the finished ones): STL / eMesh / feature
  edge files renamed; names in `snappyHexMeshDict`, `controlDict`, `forcesParts`,
  `surfaceFeatureExtractDict`, `0.org/*`, the mesh's `boundary` file and in every written field
  (only the dictionary part from `boundaryField` on, the values are untouched). The wildcards
  `"wall.*"` (boundary conditions) and `"wall_.*"` (layers) became one regular expression of the new
  names. Logs and old log text keep the old names. Checked with OpenFOAM on a converted copy
  (`simpleFoam -postProcess`: forces and y+ identical to the original run) and with
  `surfaceFeatureExtract` on a queued simulation. The ParaView preset in the simulation folder was
  converted too. A simulation that is not converted (e.g. copied from an old backup) still works,
  but the names of the old and the new ones differ in Compare and when mapping a warm start.
- **README removed** - installation and setup are covered by the tutorials.
- **Forces tab opens faster, at once for simulations seen before** - the force data of the last 8
  simulations is remembered in the window: going back to one, or choosing it in *Compare with*,
  shows it immediately (the server is still asked and the view is redrawn only if something
  changed). The force data is requested together with the simulation instead of after it, and
  the server no longer reads unchanged force files again (they were read twice per opening and
  every 8 s while a simulation was open).
- **Results tab opens much faster** - (1) the slab index of the volume mesh (needed for the first
  section plane per direction, also in the Mesh tab) is built with C-level loops in small pieces:
  about 10 s instead of about 30 s for a 1.6 M cell mesh, and the server stays responsive
  meanwhile; (2) when a simulation with results stays open for a moment (any tab), the server
  prepares its Results tab in the background - mesh, index and the layers of the last scene
  (planes, surface, streamlines, iso-surfaces) - so opening Results then takes about 1-2 s
  instead of about 30 s. Only the newest opened simulation is prepared.
- **Moving a section plane is faster and live** - the plane follows while you drag the slider
  (before: only after letting go, and requests piled up); one request at a time, then straight
  the newest position. The plane stays visible at its old position until the new one is there
  (before: it vanished meanwhile). Server side about 0.8 s instead of 1.4 s for small moves
  (cell centres kept per mesh, triangle corners gathered in C) - same output byte for byte.
- **New simulation → Warm start has no *Iterations* field any more** - it suggested 40 % of the
  origin's iterations, which made no sense when the origin was a warm start itself. The new
  simulation keeps the origin's iterations (changeable in Settings as before).
- **New look "Carbon"** - deep neutral blacks in the dark theme, a bright neutral light theme,
  vivid accent and status colours in both: finished = orange, running = amber, queued = violet,
  meshed = cyan, stopped = blue, error = red; green only for real "good" signals (converged, mesh
  OK, best result). Card titles carry their icon on a small coloured chip (forces orange, mesh
  cyan, run / lineage violet, disk / geometry amber). Sidebar: carbon in the dark theme,
  "frosted" white in the light theme; the status is a small coloured chip, the selected
  simulation is tinted in the accent. White cards with a soft shadow in the light theme, readable
  accent / status text on white, clearly marked active segment buttons, bright chart colours
  darkened on white, lighter dialog backdrop. Accent tones follow a custom accent colour everywhere: buttons,
  links, tabs, sliders, *Finished* status, the run panel, the forces icon chip, the selected
  simulation and the pipeline steps in the log. (Warm start and warnings stay amber, data colours
  in the 3D views and charts stay as they are.)
- **New sliders** - light rail, the filled part in the accent colour and a white knob with an
  accent ring (before: dark default sliders, ugly in the light theme).
- **Streamlines are traced backwards too** – from the seeds also against the flow (up to 1.5
  car lengths upstream), so they come from far ahead instead of starting just in front of the car.
- **Clean up removes results and mesh** (Overview → Disk, and *More → Clean up*): all time steps
  with the flow fields, processor folders and the mesh go; settings, STLs, forces, residuals, logs
  and notes stay, so drag values, charts, the spreadsheet and the status *Finished* remain. The
  disk card lists *Results*, *Mesh* and what stays (*STLs, settings & forces*) separately (the old "removable
  intermediate data" was almost always 0 B). Re-run builds mesh and results again.
- **Section planes are called Side / Top / Front** (Mesh and Results tab) instead of X / Y / Z;
  the tooltip names the axis.
- **Notes (Overview tab) are Markdown** – shown formatted (**bold**, *italic*, headings, lists,
  `- [ ]` to-dos, `code`, line breaks kept); click to edit. The text field grows with the text,
  saved automatically while typing (Esc / Ctrl+Enter to finish). A running simulation no longer
  redraws the overview while you write.
- **Continued runs show the total time** – after *Continue solving* (following a stop, an abort or
  a crash) the run panel shows *Duration* / *Solve* / *Mesh* for all runs together; *Elapsed*
  while running also shows the *Total*. Only the time the runs were actually running counts, not
  the pause in between. The tooltip shows the time of the last run alone. The `runtime_log` line
  (and with it the minutes in the results spreadsheet) has the total too ("… over 2 runs").
- **New logo** – same motif (dark tile, three orange flow lines), redrawn cleaner: smooth line
  ends, one gradient. Top bar, browser tab, notifications and the installed app icon
  (`web/img/logo.svg`, `icon-192.png`, `icon-512.png`); the source is in `blueCFD_directory/Flowforge_Logo`.
- **All internal names renamed** (the product name is now Flowforge Studio everywhere). Old data is
  migrated automatically on the first start, nothing has to be done by hand:
  - the per-case folder `.apexstudio` is now `.flowforgestudio`, and the `controlDict` entries
    `apexAveraging`, `apexMinAveraging`, `apexStopAtUncertainty`, `apexStopAtSwings`, `apexStopMode`,
    `apexStopTarget` are now `flowforgeAveraging`, `flowforgeMinAveraging`, ... (variants copied from
    older cases are converted when the case is first listed; a case that is running is converted later)
  - licence keys start with `FLOWFORGE1.` from now on. **Existing keys keep working** (the old format
    is still accepted; the machine code does not change)
  - the Windows start link is now `flowforgestudio:` (the old one is removed on the next start);
    browser settings (sort order, selected tab, ...) are carried over from the old names
  - comments written into `controlDict` and `README.md` of the example cases say Flowforge Studio
- **Renamed to Flowforge Studio** (was Apex Studio): window title, top bar, installed app,
  messages, start files (`Flowforge Studio.bat`, `tools\Flowforge Studio (debug console).bat`),
  README, EULA, NOTICE. Internal names stay unchanged so existing installs, cases and licences
  keep working: the `.apexstudio` folder in each case, the `apex…` entries in `controlDict`, the
  `apexstudio:` start link and the licence key format (`APEX1.…`). The installed app picks up the
  new name by itself; Edge may ask once to confirm it.
- **Program folder renamed** from `ApexStudio` to `FlowforgeStudio`. Settings, queue and logs in
  `data\` move with it. Paths are derived from the folder's location, and the start link for the
  installed app is re-registered on the next start, so nothing else needs to be changed - only old
  desktop shortcuts or pinned `.bat` files pointing at `ApexStudio\` have to be recreated.
- **Top bar** shows "by evolut1on simulations" next to the product name (was "evolut1on").
- **Top bar** shows only the product name; the "evolut1on" line next to it is gone.

### Added
- **Animated streamlines** - *Results -> Streamlines -> Animate*, five styles, all moving at the
  local flow speed (slow in the wake, fast over the wings):
  *Light trails* (long glowing streaks with a white-hot head), *Particles* (sparks of different
  brightness), *Smoke* (soft billowing strands as in a wind tunnel), *Travel* (the normal
  streamlines in the field colours grow from far upstream to the end with a light tip, stay a
  moment, then again) and *Reveal* (the lines draw themselves from far upstream, glow and fade, again).
  Colours *Ice*, *Ember*, *Mono* or the field colours; sliders for speed (0.01× to 4×, logarithmic - very slow motion possible), spacing, length / size,
  glow (soft bloom) and the brightness of the whole lines; all live. Dark theme: light on a deep
  black stage; light theme: deep ink colours with a coloured glow on the light background.
  A screenshot shows the frame on screen at that moment, with the glow (scaled to the image
  size): on a black background like the dark theme, on white in the ink colours.
- **"Delete results" removed from the More menu** – *Clean up* does the same job (results and mesh)
  and keeps forces and settings; *Delete simulation* removes everything.
- **Delete a whole simulation** – *More (...) → Delete simulation...*: removes the complete
  folder after a confirmation (no Recycle Bin, cannot be undone). The dialog shows the size
  and warns when other simulations were made from it (their "From" / warm-start link then points
  to nothing). Not possible while it runs or is queued. The results spreadsheet keeps the row
  until the next *Sync*.
- **Leaderboard: choose what the drag progress chart shows** – a check box in front of every
  simulation (and one in the header for all / none). Unticked rows are greyed out and their points
  leave the chart; clicking a point in the chart unticks it there too. Remembered.
- **Leaderboard: own sort button** with the same options as the sidebar (newest / oldest first,
  name A–Z / Z–A, last activity, lowest drag, *My order*), chosen independently of the sidebar;
  *My order* is the same drag & drop order as in the sidebar; the leaderboard rows can be dragged
  too (switches the leaderboard to *My order*). Default: oldest first. The drag
  progress chart shows the points in the leaderboard's order. (Replaces sorting by clicking the
  column headers.)
- **Pause and resume a run** – *Pause* next to *Stop* (and *Pause now* in the queue): the solver
  saves the current iteration (like *Stop & save*) and the queue pauses; the run is put back at the
  top of the queue as *Continue solving*. *Resume* (on the simulation or in the queue) continues
  exactly there, the total run time leaves out the pause. During meshing it pauses once the mesh
  is finished (snappyHexMesh cannot be interrupted). The queue's pause button now offers
  *Pause now* or *Pause after the current run* (the old behaviour).
- **Sidebar: sort by name** – *Name A–Z* / *Name Z–A* in the sort menu. Sorts by the name as
  shown (without the date in front), numbers in natural order (`param_9` before `param_10`).
- **Sidebar: own order by drag & drop** – drag a simulation up or down in the list (an orange
  line shows where it lands). This switches the sort menu to *My order (drag & drop)*, starting
  from the order shown before; it is remembered. New simulations appear at the top.
- **Forces tab: "Open in Excel"** – button in the chart toolbar that exports a real `.xlsx`
  workbook to `<simulations folder>\Exports\<simulation>_forces.xlsx` and opens it.
  - *Summary*: mean values, uncertainty, swings, pressure / friction share, averaging window,
    number of iterations.
  - *Forces*: every iteration with drag and lift (total, pressure, friction, already ×2 for the
    whole car) and a 0/1 column "Averaged" that marks the iterations in the mean.
  - *Residuals*: initial residual of every equation per iteration.
  - Numbers are stored as numbers (no comma / point issues in German Excel). If the file is still
    open in Excel, `_2`, `_3`, … is written instead.
- **Accent colour (team CI)** – Settings → *Appearance*: colour picker, hex field and *Default*
  button. Recolours buttons, active tabs, switches, highlights, focus rings, progress bars and the
  drag curve; the text on coloured buttons switches between black and white automatically.
  Preview is live, *Cancel* / *Esc* reverts, *Save* stores it in `config.json` (`accent`).
  The logo, the result colour maps, status colours (green / yellow / red) and the part colours in
  the mesh and wizard views stay unchanged.
- **Results tab: flow lines in section planes** – new *Flow* switch on every plane card
  (2D streamlines in the plane, like "Surface LIC" in ParaView): vortices, separation and
  recirculation become visible directly in the section.
  - *Solid* (any colour, default white) or *Speed* (coloured by |U| with the field's colour range).
  - *Spacing* (mm, evenly spaced lines, closed vortices drawn as rings), *Width* (mm, smooth
    edges, tapered ends, scales with the screenshot resolution), *Opacity*.
  - *Animate*: soft light streaks (rounded bright head, tail fading out in the line colour, each
    line with its own phase) travel along the lines with the real local flow speed, over a faint
    guide line (screen only; screenshots show the plain lines).
  - Works on X / Y / Z planes, with *Mirror*, in the comparison modes, in saved views and in
    batch screenshots. First display of a new plane ≈ 10 s (mesh cut), afterwards 1–2 s.
  - Note: the lines show only the part of the flow that lies in the plane – for the 3D path use
    the regular *Streamlines*.

### Fixed
- Opening the Forces tab froze Flowforge Studio for several seconds (sidebar not clickable): the
  side view of the balance card read all car STLs in full (about 5 s for an 80 MB body). The
  silhouette is now made once per geometry (about 2 s), stored in `data/cache/silhouette` and
  reused by every simulation with the same STLs (a few milliseconds); only one is made at a time.
  A side view that is already stored is shown right away; a new geometry is only made when you
  click *Load side view* in the balance card, so the Forces tab never waits for it.
- Typing car data in the balance card reloaded the whole Forces tab after every save (slow, and
  the text field lost the focus).
- **Streamlines no longer stop in mid-air** – at refinement level changes the cell search
  could go round in circles and gave up, so many lines ended at the front wing or somewhere in
  the free stream. Now nearly all lines run past the car.
- **Queue drawer** started below the slim top bar of the installed app (gap at the top).
- A run that hit its iteration cap (End time) below the write interval wrote no results and
  failed at *Reconstruct* ("No times selected"). The write interval is now set to the end time
  automatically before solving and whenever the end time is lowered in the settings.
- Section planes (Results tab and mesh viewer) that lie almost exactly on a layer of mesh points
  showed extra zig-zag lines and "islands" across the cells (snapping and smoothing move the
  points of a layer slightly and unevenly, so the plane cut faces lying almost parallel to it
  along random lines). The cut lines of these flat faces are no longer drawn, so the mesh lines
  follow the real cell outlines; the plane position stays exactly as set.
- Results tab: section planes showed colour patches ("islands") at the same places – the plane
  showed the cells just above a wavy layer in some patches and those just below in others. The
  value at the plane is now interpolated linearly between each cut cell and its neighbour on the
  other side of the plane (by the distance of the cell centres), so the colours are continuous
  and slightly more accurate. Also used for the flow lines. First display of a new plane takes
  about 1–3 s longer.

### Changed
- Forces tab: the line "Drag = Y · lift = Z · ×2 (symmetry) · N iterations" below the toolbar was
  removed (saves space).
- checkMesh: a handful of highly skewed faces (≤ 100, the only failed check) no longer shows a
  warning - snappyHexMesh layer meshes always have a few (2-5 of millions). Other failed checks
  still warn and are now named in the warning. Older runs no longer show the old warning either.
- Simulation list: the status filter chips (All / Running / Finished / Meshed / Fresh / Error)
  were removed; the list always shows all simulations (search and sort stay).
- Simulation header: the *View mesh* and *View results* buttons were removed (the Mesh and
  Results tabs are one click away). *Open in ParaView* moved into the Results tab (new box
  *External* at the bottom of the left panel); the Mesh tab keeps its own ParaView button.
- Simulation list: default sort is now *Last activity* (most recently run or changed first);
  *Newest first* / *Oldest first* and the other sorts remain in the sort menu. The list is always
  open when Flowforge Studio starts - hiding it (button or Ctrl+B) lasts until the app is closed.
- Results tab: saved views have their own **Views** button in the toolbar (before: hidden at the
  bottom of the *View* menu). A view stores the camera (incl. *Parallel*) and everything in the
  left panel – car, planes with flow lines, streamlines, iso-surfaces, colour ranges, *Mirror* –
  and works for every simulation. New: *Export views to file…* / *Import views from file…*
  (`flowforge_studio_views.json`) to share views with the team or another PC; the menu shows a short
  summary per view and the name of the loaded view is suggested when saving again (overwrite).
- Simulation list: *Newest first* / *Oldest first* (formerly "(name)") sort by the date in the
  folder name and then by the real creation time, so several simulations of the same day appear
  in the order they were created (not alphabetically). Simulations not created by Flowforge Studio
  use the creation time of their folder.
- Settings dialog has a new *Appearance* section.
- Forces tab: the drag curve follows the accent colour.

### Technical
- New: `app/silhouette.py`, `GET /api/forces/silhouette` (2D side view of the car, cached on disk).
- New: `web/js/copview.js`; `/api/forces` also returns `pitch` (moment about the lateral axis through
  the origin, moments are now read from forces.dat) and `cop_geometry` (ground, wheel axles, flow speed, CO2 thrust line,
  car STLs, car data). `POST /api/meta` accepts `vehicle`; new config key `vehicle_default`.
- New: `app/partforces.py` (set-up and reading of the forces per part), `web/js/partforces.js`;
  `/api/forces` returns the part series in `parts`.
- New: `app/xlsx.py` (minimal .xlsx writer, standard library only), `web/js/planeflow.js`
  (rasterising, evenly spaced streamline tracing after Jobard & Lefer, ribbon geometry).
- New API endpoints: `POST /api/forces/export`, `GET /api/results/planeflow`.
- New config key `accent` (`#rrggbb`, empty = Flowforge Studio orange), validated on save.
- `web/js/resultview.js`: second, blended render pass for flow-line ribbons (polygon offset so
  they never flicker with the plane), continuous redraw only while an animation is on.
- **Flowforge Studio must be restarted once** after updating (server files changed).
