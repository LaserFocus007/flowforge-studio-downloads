# Notices

## Own code

All source code of Flowforge Studio (`app/`, `web/`, start scripts, logo and icons) was written for this
product. No third-party libraries, icon sets or other assets are used by it, apart from the two fonts listed below:

- The backend uses only the Python standard library.
- Charts, the 3D viewer and the icons are implemented in the `web/` folder itself.
- Fonts: Oxanium (headings) and Ubuntu (text), included in `web/fonts/`; code uses the installed Cascadia Mono / Consolas.

## Software included in the download

| Software | Licence | Use |
| --- | --- | --- |
| Python (folder `runtime/`, unmodified) | PSF License, see `runtime/LICENSE.txt` | runs Flowforge Studio |
| Nuitka runtime code (inside the compiled `app` file) | Apache License 2.0 | the Python code of Flowforge Studio is compiled with Nuitka (Copyright Kay Hayen) |
| Oxanium font (`web/fonts/oxanium-var.woff2`) | SIL Open Font License 1.1, see `web/fonts/OFL.txt` | headings (Copyright 2019 The Oxanium Project Authors) |
| Ubuntu font (`web/fonts/ubuntu-*.woff2`) | Ubuntu Font Licence 1.0, see `web/fonts/UFL.txt` | text (Copyright 2010, 2011 Canonical Ltd.) |

## Software that Flowforge Studio uses but does not include

These programs must be installed by the user. Flowforge Studio only starts them as separate programs.

| Software | Licence | Use |
| --- | --- | --- |
| blueCFD-Core / OpenFOAM | GNU GPL v3 | meshing and solving, started as external programs |
| MS-MPI | Microsoft licence (installed with blueCFD-Core) | parallel runs, started by blueCFD-Core |
| ParaView | BSD 3-Clause | optional, started as external program |
| Microsoft Edge / Google Chrome | vendor licences | displays the user interface |
| Notepad++, Meld | GPL | optional, started as external programs |

Do not bundle blueCFD-Core, OpenFOAM or ParaView with Flowforge Studio without checking their licence
terms; the intended setup is that the customer installs them separately (as in the tutorial).

## Trademarks

OpenFOAM(R) is a registered trademark of OpenCFD Limited, producer and distributor of the
OpenFOAM software via www.openfoam.com. blueCFD(R) is a registered trademark of blueCAPE Lda.
This offering is not approved or endorsed by OpenCFD Limited or blueCAPE Lda.
Windows and Microsoft Edge are trademarks of Microsoft Corporation.
