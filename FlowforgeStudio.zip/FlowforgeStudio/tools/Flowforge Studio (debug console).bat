@echo off
rem Starts Flowforge Studio with a visible console - use this if the normal start does not work.
setlocal
cd /d "%~dp0.."
if exist "runtime\python.exe" (runtime\python.exe -c "from app import main; main.run()" --stay %* & goto :end)
where py >nul 2>nul && (py -3 -c "from app import main; main.run()" --stay %* & goto :end)
python -c "from app import main; main.run()" --stay %*
:end
echo.
echo Flowforge Studio stopped. Logs: data\app.log and data\runner.log
pause
