"""Installs a downloaded Flowforge Studio update. Started by the app ("Update now"), runs from the
downloaded copy in data/update/new with its own bundled Python, so no program file is in use.

  1. wait until nothing runs from the installed runtime any more (the app has closed, no simulation)
  2. move the old program files to data/update/backup (a rename on the same drive, quick)
  3. copy the new program files in
  4. start the new version and check that it answers
If a step fails, the old program files are put back and the old version is started again.
The data folder (licence, settings, queue) is never touched. Standard library only.
"""

import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request
from ctypes import wintypes

KEEP = {"data"}
# program files of versions before update_manifest.json existed
FALLBACK = ["CHANGELOG.md", "EULA.md", "Flowforge Studio.bat", "NOTICE.md", "content", "runtime", "tools",
            "tutorials", "web", "update_manifest.json"]
DETACHED_PROCESS = 0x00000008
CREATE_NEW_PROCESS_GROUP = 0x00000200
CREATE_BREAKAWAY_FROM_JOB = 0x01000000

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)
k32.OpenProcess.restype = wintypes.HANDLE
k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
k32.CloseHandle.argtypes = [wintypes.HANDLE]
k32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
k32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
psapi.EnumProcesses.argtypes = [ctypes.POINTER(wintypes.DWORD), wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]


def plain(p):
    p = os.path.abspath(p)
    return p[4:] if p.startswith("\\\\?\\") else p


def image_path(pid):
    h = k32.OpenProcess(0x1000, False, pid)            # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(32768)
        n = wintypes.DWORD(len(buf))
        return buf.value if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)) else None
    finally:
        k32.CloseHandle(h)


def users_of(folder):
    """Processes started from a program inside this folder (other than this helper)."""
    arr = (wintypes.DWORD * 8192)()
    got = wintypes.DWORD()
    if not psapi.EnumProcesses(arr, ctypes.sizeof(arr), ctypes.byref(got)):
        return []
    prefix = plain(folder).lower().rstrip("\\") + "\\"
    out = []
    for pid in arr[:got.value // ctypes.sizeof(wintypes.DWORD)]:
        if pid in (0, os.getpid()):
            continue
        img = image_path(pid)
        if img and plain(img).lower().startswith(prefix):
            out.append(pid)
    return out


def spawn(args, cwd):
    base = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    for flags in (base | CREATE_BREAKAWAY_FROM_JOB, base):
        try:
            return subprocess.Popen(args, cwd=cwd, creationflags=flags, close_fds=True,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            continue
    raise RuntimeError("could not start " + args[0])


def retry(fn, tries=40, pause=0.25):
    """File operations on Windows fail briefly when a virus scanner or the indexer holds a file."""
    for i in range(tries):
        try:
            return fn()
        except OSError:
            if i == tries - 1:
                raise
            time.sleep(pause)


def remove(path):
    if os.path.isdir(path) and not os.path.islink(path):
        retry(lambda: shutil.rmtree(path))
    elif os.path.lexists(path):
        retry(lambda: os.remove(path))


def copy(src, dst):
    if os.path.isdir(src):
        shutil.copytree(src, dst)
    else:
        shutil.copy2(src, dst)


def manifest_items(root):
    try:
        with open(os.path.join(root, "update_manifest.json"), encoding="utf-8") as f:
            items = json.load(f)["items"]
        return [i for i in items if isinstance(i, str) and i and "/" not in i and "\\" not in i and i not in ("..", ".")]
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--install", required=True)
    ap.add_argument("--new", required=True)
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--port", type=int, default=0, help="port of the closed app: the open window reconnects there")
    ap.add_argument("--from", dest="old", default="")
    ap.add_argument("--to", dest="ver", default="")
    ap.add_argument("--wait", type=float, default=90.0, help="seconds to wait for the app to close")
    ap.add_argument("--check", type=float, default=120.0, help="seconds the new version gets to answer")
    a = ap.parse_args()
    inst, new = plain(a.install), plain(a.new)
    upd = os.path.join(inst, "data", "update")
    backup = os.path.join(upd, "backup")
    os.makedirs(upd, exist_ok=True)
    logf = open(os.path.join(upd, "apply.log"), "a", encoding="utf-8")

    def say(msg):
        logf.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
        logf.flush()

    def result(ok, message=""):
        with open(os.path.join(upd, "result.json"), "w", encoding="utf-8") as f:
            json.dump({"ok": ok, "from": a.old, "to": a.ver, "at": time.time(), "message": message}, f)
        say(("DONE: " if ok else "FAILED: ") + (message or "updated %s -> %s" % (a.old, a.ver)))

    def start(where, check):
        """Start Flowforge Studio from 'where'; with check: wait until it answers (True) or give up (False)."""
        exe = os.path.join(where, "runtime", "pythonw.exe")
        server = os.path.join(where, "data", "server.json")
        p = spawn([exe, "-c", "from app import main; main.run()", "--no-window"] + (["--port", str(a.port)] if a.port else []), where)
        if not check:
            return True
        end = time.time() + a.check
        while time.time() < end:
            time.sleep(0.5)
            if p.poll() is not None:
                say("the new version exited with code %s" % p.returncode)
                return False
            try:
                with open(server, encoding="utf-8") as f:
                    info = json.load(f)
                if info.get("pid") != p.pid:
                    continue
                req = urllib.request.Request("http://127.0.0.1:%d/api/ping" % info["port"], data=b"{}", headers={
                    "X-Studio-Token": info["token"], "Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=5) as r:
                    if r.status == 200:
                        return True
            except Exception:
                pass
        say("the new version did not answer within %d s" % a.check)
        try:
            p.kill()
        except Exception:
            pass
        return False

    say("update %s -> %s, install %s" % (a.old, a.ver, inst))
    moved, copied = [], []

    def roll_back(why):
        say("rolling back: " + why)
        for name in copied:
            try:
                remove(os.path.join(inst, name))
            except Exception:
                say("could not remove new %s: %s" % (name, traceback.format_exc(limit=1)))
        for name in reversed(moved):
            try:
                retry(lambda: os.replace(os.path.join(backup, name), os.path.join(inst, name)))
            except Exception:
                say("could not restore %s: %s" % (name, traceback.format_exc(limit=1)))
        try:
            start(inst, False)
        except Exception:
            say("could not restart the old version: " + traceback.format_exc())
        result(False, why + " The previous version was restored.")

    try:
        # 1. the app (and any simulation) must have closed: nothing may run from the installed runtime
        runtime = os.path.join(inst, "runtime")
        end = time.time() + a.wait
        while users_of(runtime) and time.time() < end:
            time.sleep(0.5)
        busy = users_of(runtime)
        if busy:
            say("still running from the program folder: %s" % busy)
            if a.pid and a.pid not in busy:
                start(inst, False)           # the app itself has closed: bring it back
            result(False, "Flowforge Studio or a simulation was still running, so nothing was changed.")
            return 1

        new_items = [i for i in os.listdir(new) if i not in KEEP]
        old_items = manifest_items(inst)
        if old_items is None:
            old_items = FALLBACK + [f for f in os.listdir(inst) if f.startswith("app.") and f.lower().endswith(".pyd")]
        names = sorted({i for i in set(old_items) | set(new_items) if i not in KEEP and os.path.lexists(os.path.join(inst, i))})

        # 2. old program files -> backup
        if os.path.lexists(backup):
            remove(backup)
        os.makedirs(backup)
        try:
            for name in names:
                retry(lambda: os.replace(os.path.join(inst, name), os.path.join(backup, name)))
                moved.append(name)
        except Exception as e:
            roll_back("A program file could not be moved (%s)." % e)
            return 1

        # 3. new program files in
        try:
            for name in new_items:
                copied.append(name)
                copy(os.path.join(new, name), os.path.join(inst, name))
        except Exception as e:
            roll_back("The new files could not be copied (%s)." % e)
            return 1

        # 4. the new version must start and answer
        if not start(inst, True):
            for pid in users_of(runtime):     # whatever the failed start left behind
                try:
                    h = k32.OpenProcess(0x0001, False, pid)       # PROCESS_TERMINATE
                    if h:
                        k32.TerminateProcess(h, 1)
                        k32.CloseHandle(h)
                except Exception:
                    pass
            time.sleep(1.0)
            roll_back("The new version did not start.")
            return 1
        result(True)
        return 0
    except Exception:
        say(traceback.format_exc())
        if moved:
            roll_back("Unexpected error.")
        else:
            result(False, "Unexpected error, nothing was changed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
