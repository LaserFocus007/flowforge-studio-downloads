"""Started through the flowforgestudio: link when the installed app (Start menu / taskbar icon) is opened
while Flowforge Studio is not running: starts the local server without opening a second window - the
app window is already open and connects as soon as the server answers (see web/offline.html)."""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, ROOT)
sys.argv = [sys.argv[0], "--no-window"]

from app import main  # noqa: E402

main.run()
