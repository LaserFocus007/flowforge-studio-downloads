# Endbenutzer-Lizenzvertrag (EULA) für Flowforge Studio

Version 1.0, Stand 09.11.2026

Lizenzgeber: **Timo Brendle, evolut1on simulations, Erminoldstraße 106, 81735, timo.brendle@mail.de** (im Folgenden „Lizenzgeber“).

Lizenznehmer ist die natürliche oder juristische Person, auf die der Lizenzschlüssel ausgestellt ist (im Folgenden „Lizenznehmer“).

Durch das Aktivieren der Software mit einem Lizenzschlüssel und das Bestätigen dieses Vertrags erklärt sich der Lizenznehmer mit den folgenden Bedingungen einverstanden.

## 1. Vertragsgegenstand

1. Gegenstand dieses Vertrags ist die Software „Flowforge Studio“ einschließlich Programmdateien, Benutzeroberfläche, Dokumentation und Updates, die der Lizenzgeber zur Verfügung stellt (im Folgenden „Software“).
2. Die Software ist eine Bedienoberfläche zur Verwaltung, Ausführung und Auswertung von Strömungssimulationen. Sie enthält selbst keine Simulationssoftware.
3. Drittsoftware wie blueCFD-Core, OpenFOAM, MS-MPI, ParaView oder ein Webbrowser ist nicht Bestandteil der Software. Sie wird vom Lizenznehmer selbst beschafft und installiert und unterliegt ausschließlich den Lizenzbedingungen ihrer jeweiligen Rechteinhaber. OpenFOAM® ist eine eingetragene Marke der OpenCFD Limited, blueCFD® eine eingetragene Marke der blueCAPE Lda. Die Software wird von diesen Unternehmen weder unterstützt noch empfohlen. Mitgeliefert wird die unveränderte Python-Laufzeitumgebung der Python Software Foundation; für sie gelten die Lizenzbedingungen der Python Software Foundation (siehe NOTICE.md).
4. Der Funktionsumfang der Software richtet sich nach der Variante (Regional, National oder World), die im Lizenzschlüssel hinterlegt ist. Ein Wechsel der Variante erfolgt durch einen neuen Lizenzschlüssel.

## 2. Nutzungsrecht

1. Der Lizenzgeber räumt dem Lizenznehmer gegen Zahlung der vereinbarten Vergütung ein einfaches (nicht ausschließliches), nicht übertragbares und nicht unterlizenzierbares Recht ein, die Software auf **einem einzigen Rechner** zu nutzen. Gemeint ist der Rechner, für dessen Rechner-Code der Lizenzschlüssel ausgestellt wurde.
2. Das Nutzungsrecht gilt unbefristet, sofern im Lizenzschlüssel kein Ablaufdatum angegeben ist. Ist ein Ablaufdatum angegeben, endet es mit diesem Datum.
3. Innerhalb der Organisation des Lizenznehmers (z. B. eines Teams) darf die Software von mehreren Personen genutzt werden, jedoch nur auf dem lizenzierten Rechner.
4. Ein Wechsel des Rechners (z. B. bei einem Hardwaretausch oder einer Neuinstallation von Windows) ist nach Absprache mit dem Lizenzgeber möglich. Der Lizenzgeber stellt dafür einen neuen Lizenzschlüssel aus. Der bisherige Schlüssel darf danach nicht weiter genutzt werden.
5. Der Lizenznehmer darf eine Sicherungskopie der Software anlegen, soweit dies für die vertragsgemäße Nutzung erforderlich ist (§ 69d Abs. 2 UrhG).

## 3. Einschränkungen

Soweit gesetzlich nicht ausdrücklich etwas anderes erlaubt ist (insbesondere §§ 69d, 69e UrhG), ist es dem Lizenznehmer untersagt:

1. die Software, den Lizenzschlüssel oder Kopien davon an Dritte weiterzugeben, zu verkaufen, zu vermieten, zu verleihen oder Dritten öffentlich zugänglich zu machen;
2. die Lizenzprüfung, den Lizenzschlüssel oder andere technische Schutzmaßnahmen zu umgehen, zu entfernen, zu deaktivieren oder zu verändern, oder Dritte dazu zu veranlassen, auch mithilfe automatisierter Werkzeuge oder KI-Systemen;
3. die Software zu verändern, zu bearbeiten, zu übersetzen, zu dekompilieren oder zurückzuentwickeln, oder abgeleitete Werke zu erstellen;
4. die Software oder Teile davon in eigene oder fremde Produkte zu übernehmen oder ein konkurrierendes Produkt auf ihrer Grundlage zu entwickeln;
5. Urheberrechtsvermerke, Markenzeichen, Lizenzangaben oder den angezeigten Lizenznehmernamen zu entfernen oder zu verändern.

## 4. Rechte am Werk

1. Alle Rechte an der Software, insbesondere Urheber-, Marken- und sonstige Schutzrechte, verbleiben beim Lizenzgeber. Der Lizenznehmer erwirbt nur die in diesem Vertrag ausdrücklich genannten Nutzungsrechte.
2. Mit der Software erzeugte Simulationsdaten, Ergebnisse und Auswertungen gehören dem Lizenznehmer.

## 5. Lizenzschlüssel und Aktivierung

1. Die Software ist erst nach Eingabe eines gültigen Lizenzschlüssels nutzbar. Der Schlüssel ist an den Rechner-Code und den Namen des Lizenznehmers gebunden. Der Name wird in der Software angezeigt.
2. Die Aktivierung erfolgt offline. Der Rechner-Code ist ein aus der Windows-Installation abgeleiteter Prüfwert und enthält keine personenbezogenen Daten.
3. Der Lizenznehmer hält seinen Lizenzschlüssel geheim. Gelangt ein Lizenzschlüssel in fremde Hände, informiert er den Lizenzgeber unverzüglich.

## 6. Simulationsergebnisse, keine Gewähr für Richtigkeit

1. Die Software steuert Simulationsprogramme Dritter und bereitet deren Ergebnisse auf. Die Qualität von Simulationsergebnissen hängt maßgeblich von Geometrie, Rechennetz, Einstellungen und Modellannahmen ab, die der Lizenznehmer verantwortet.
2. Der Lizenzgeber übernimmt keine Gewähr dafür, dass Simulationsergebnisse die physikalische Realität zutreffend abbilden oder für einen bestimmten Zweck geeignet sind, etwa für Konstruktionsentscheidungen oder Wettbewerbe. Der Lizenznehmer prüft die Ergebnisse eigenverantwortlich auf Plausibilität.
3. Der Lizenznehmer ist für regelmäßige Sicherungen seiner Daten selbst verantwortlich. Funktionen wie „Ergebnisse löschen“ oder „Aufräumen“ entfernen Daten endgültig.

## 7. Gewährleistung

1. Der Lizenzgeber gewährleistet, dass die Software bei vertragsgemäßem Einsatz im Wesentlichen wie in der Dokumentation beschrieben funktioniert. Unerhebliche Abweichungen begründen keinen Mangel.
2. Für Verbraucher gelten die gesetzlichen Gewährleistungsrechte, insbesondere die §§ 327 ff. BGB für digitale Produkte. Sie werden durch diesen Vertrag nicht eingeschränkt.
3. Gegenüber Unternehmern beträgt die Verjährungsfrist für Mängelansprüche ein Jahr ab Bereitstellung, soweit nicht Ziffer 8 Abs. 1 betroffen ist.
4. Keine Gewähr wird für Fehler übernommen, die auf Drittsoftware, auf eine nicht unterstützte Systemumgebung oder auf Veränderungen der Software durch den Lizenznehmer zurückgehen.

## 8. Haftung

1. Der Lizenzgeber haftet unbeschränkt bei Vorsatz und grober Fahrlässigkeit, bei der Verletzung von Leben, Körper oder Gesundheit, nach dem Produkthaftungsgesetz sowie im Umfang einer übernommenen Garantie.
2. Bei leicht fahrlässiger Verletzung einer wesentlichen Vertragspflicht (Kardinalpflicht) ist die Haftung auf den vertragstypischen, vorhersehbaren Schaden begrenzt. Kardinalpflichten sind Pflichten, deren Erfüllung die ordnungsgemäße Durchführung des Vertrags überhaupt erst ermöglicht und auf deren Einhaltung der Lizenznehmer regelmäßig vertrauen darf.
3. Im Übrigen ist die Haftung für leichte Fahrlässigkeit ausgeschlossen.
4. Für den Verlust von Daten haftet der Lizenzgeber nur in dem Umfang, der auch bei ordnungsgemäßer und regelmäßiger Datensicherung durch den Lizenznehmer entstanden wäre.

## 9. Datenschutz

Die Software läuft vollständig lokal auf dem Rechner des Lizenznehmers. Sie überträgt keine Daten an den Lizenzgeber oder an Dritte. Für die Ausstellung des Lizenzschlüssels verarbeitet der Lizenzgeber nur die vom Lizenznehmer mitgeteilten Daten (Name, Kontaktdaten, Rechner-Code). Dies geschieht ausschließlich zur Vertragsdurchführung (Art. 6 Abs. 1 lit. b DSGVO).

## 10. Laufzeit und Beendigung

1. Verstößt der Lizenznehmer schwerwiegend gegen diesen Vertrag, insbesondere gegen Ziffer 3, endet das Nutzungsrecht ohne gesonderte Kündigung. Das Recht zur außerordentlichen Kündigung bleibt unberührt.
2. Nach Beendigung des Nutzungsrechts hat der Lizenznehmer die Nutzung einzustellen und die Software einschließlich aller Kopien zu löschen.
3. Weitergehende Ansprüche des Lizenzgebers, insbesondere auf Schadensersatz und Unterlassung nach §§ 97 ff. UrhG, bleiben unberührt.

## 11. Updates und Support

Ein Anspruch auf Updates, neue Versionen oder Support besteht nur, soweit dies gesondert vereinbart ist. Stellt der Lizenzgeber Updates bereit, gelten für sie die Bedingungen dieses Vertrags.

## 12. Schlussbestimmungen

1. Es gilt das Recht der Bundesrepublik Deutschland unter Ausschluss des UN-Kaufrechts. Gegenüber Verbrauchern gilt diese Rechtswahl nur, soweit dadurch nicht der Schutz entzogen wird, den zwingende Bestimmungen des Rechts ihres gewöhnlichen Aufenthaltsstaates gewähren.
2. Ist der Lizenznehmer Kaufmann, juristische Person des öffentlichen Rechts oder öffentlich-rechtliches Sondervermögen, ist ausschließlicher Gerichtsstand München.
3. Änderungen und Ergänzungen dieses Vertrags bedürfen der Textform.
4. Sollte eine Bestimmung dieses Vertrags ganz oder teilweise unwirksam sein oder werden, bleibt die Wirksamkeit der übrigen Bestimmungen unberührt. An die Stelle der unwirksamen Bestimmung tritt die gesetzliche Regelung.
